-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Host: mysql.dfotw.com
-- Generation Time: Nov 19, 2011 at 08:06 AM
-- Server version: 5.1.53
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dfotw`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `aid` varchar(255) NOT NULL DEFAULT '0' COMMENT 'Primary Key: Unique actions ID.',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT 'The object that that action acts on (node, user, comment, system or custom types.)',
  `callback` varchar(255) NOT NULL DEFAULT '' COMMENT 'The callback function that executes when the action runs.',
  `parameters` longblob NOT NULL COMMENT 'Parameters to be passed to the callback function.',
  `label` varchar(255) NOT NULL DEFAULT '0' COMMENT 'Label of the action.',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`aid`, `type`, `callback`, `parameters`, `label`) VALUES
('4', 'system', 'system_send_email_action', 0x613a333a7b733a393a22726563697069656e74223b733a31393a22616c65784077656264726f702e6e65742e6272223b733a373a227375626a656374223b733a31333a2244464f545720436f6d6d656e74223b733a373a226d657373616765223b733a33343a225b636f6d6d656e743a617574686f725d0d0a0d0a5b636f6d6d656e743a626f64795d223b7d, 'Send e-mail'),
('comment_publish_action', 'comment', 'comment_publish_action', '', 'Publish comment'),
('comment_save_action', 'comment', 'comment_save_action', '', 'Save comment'),
('comment_unpublish_action', 'comment', 'comment_unpublish_action', '', 'Unpublish comment'),
('node_make_sticky_action', 'node', 'node_make_sticky_action', '', 'Make content sticky'),
('node_make_unsticky_action', 'node', 'node_make_unsticky_action', '', 'Make content unsticky'),
('node_promote_action', 'node', 'node_promote_action', '', 'Promote content to front page'),
('node_publish_action', 'node', 'node_publish_action', '', 'Publish content'),
('node_save_action', 'node', 'node_save_action', '', 'Save content'),
('node_unpromote_action', 'node', 'node_unpromote_action', '', 'Remove content from front page'),
('node_unpublish_action', 'node', 'node_unpublish_action', '', 'Unpublish content'),
('system_block_ip_action', 'user', 'system_block_ip_action', '', 'Ban IP address of current user'),
('user_block_user_action', 'user', 'user_block_user_action', '', 'Block current user');

-- --------------------------------------------------------

--
-- Table structure for table `authmap`
--

CREATE TABLE IF NOT EXISTS `authmap` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique authmap ID.',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'User’s users.uid.',
  `authname` varchar(128) NOT NULL DEFAULT '' COMMENT 'Unique authentication name.',
  `module` varchar(128) NOT NULL DEFAULT '' COMMENT 'Module which is controlling the authentication.',
  PRIMARY KEY (`aid`),
  UNIQUE KEY `authname` (`authname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `authmap`
--


-- --------------------------------------------------------

--
-- Table structure for table `backup_migrate_destinations`
--

CREATE TABLE IF NOT EXISTS `backup_migrate_destinations` (
  `destination_id` varchar(32) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a profile.',
  `name` varchar(255) NOT NULL COMMENT 'The name of the profile.',
  `type` varchar(32) NOT NULL COMMENT 'The type of the destination.',
  `location` text NOT NULL COMMENT 'The the location string of the destination.',
  `settings` text NOT NULL COMMENT 'Other settings for the destination.',
  PRIMARY KEY (`destination_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `backup_migrate_destinations`
--


-- --------------------------------------------------------

--
-- Table structure for table `backup_migrate_profiles`
--

CREATE TABLE IF NOT EXISTS `backup_migrate_profiles` (
  `profile_id` varchar(32) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a profile.',
  `name` varchar(255) NOT NULL COMMENT 'The name of the profile.',
  `filename` varchar(50) NOT NULL COMMENT 'The name of the profile.',
  `append_timestamp` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Append a timestamp to the filename.',
  `timestamp_format` varchar(14) NOT NULL COMMENT 'The format of the timestamp.',
  `filters` text NOT NULL COMMENT 'The filter settings for the profile.',
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `backup_migrate_profiles`
--

INSERT INTO `backup_migrate_profiles` (`profile_id`, `name`, `filename`, `append_timestamp`, `timestamp_format`, `filters`) VALUES
('default', 'Default Settings', '[site:name]', 1, 'Y-m-d\\TH-i-s', 'a:8:{s:11:"compression";s:4:"bzip";s:21:"notify_success_enable";i:0;s:20:"notify_success_email";s:19:"alex@webdrop.net.br";s:21:"notify_failure_enable";i:0;s:20:"notify_failure_email";s:19:"alex@webdrop.net.br";s:18:"utils_site_offline";i:0;s:26:"utils_site_offline_message";s:115:"Drupal Function of the Week is currently under maintenance. We should be back shortly. Thank you for your patience.";s:12:"destinations";a:1:{s:2:"db";a:3:{s:14:"exclude_tables";a:0:{}s:13:"nodata_tables";a:16:{s:5:"cache";s:5:"cache";s:11:"cache_block";s:11:"cache_block";s:15:"cache_bootstrap";s:15:"cache_bootstrap";s:11:"cache_field";s:11:"cache_field";s:12:"cache_filter";s:12:"cache_filter";s:10:"cache_form";s:10:"cache_form";s:10:"cache_menu";s:10:"cache_menu";s:10:"cache_page";s:10:"cache_page";s:10:"cache_path";s:10:"cache_path";s:12:"cache_update";s:12:"cache_update";s:11:"cache_views";s:11:"cache_views";s:14:"search_dataset";s:14:"search_dataset";s:12:"search_index";s:12:"search_index";s:12:"search_total";s:12:"search_total";s:8:"sessions";s:8:"sessions";s:8:"watchdog";s:8:"watchdog";}s:17:"utils_lock_tables";i:0;}}}');

-- --------------------------------------------------------

--
-- Table structure for table `backup_migrate_schedules`
--

CREATE TABLE IF NOT EXISTS `backup_migrate_schedules` (
  `schedule_id` varchar(32) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a profile.',
  `name` varchar(255) NOT NULL COMMENT 'The name of the profile.',
  `source_id` varchar(32) NOT NULL DEFAULT 'db' COMMENT 'The backup_migrate_destination.destination_id of the source to backup from.',
  `destination_id` varchar(32) NOT NULL DEFAULT '0' COMMENT 'The backup_migrate_destination.destination_id of the destination to back up to.',
  `profile_id` varchar(32) NOT NULL DEFAULT '0' COMMENT 'The primary identifier for a profile.',
  `keep` int(11) NOT NULL DEFAULT '0' COMMENT 'The number of backups to keep.',
  `period` int(11) NOT NULL DEFAULT '0' COMMENT 'The number of seconds between backups.',
  `last_run` int(11) NOT NULL DEFAULT '0' COMMENT 'The last time the backup was run.',
  `enabled` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Whether the schedule is enabled.',
  `cron` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Whether the schedule should be run during cron.',
  PRIMARY KEY (`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `backup_migrate_schedules`
--

INSERT INTO `backup_migrate_schedules` (`schedule_id`, `name`, `source_id`, `destination_id`, `profile_id`, `keep`, `period`, `last_run`, `enabled`, `cron`) VALUES
('611afc939720ed40795a19050b89d380', 'Daily Backup', 'db', 'scheduled', 'default', 14, 86400, 1315395806, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE IF NOT EXISTS `batch` (
  `bid` int(10) unsigned NOT NULL COMMENT 'Primary Key: Unique batch ID.',
  `token` varchar(64) NOT NULL COMMENT 'A string token generated against the current user’s session id and the batch id, used to ensure that only the user who submitted the batch can effectively access it.',
  `timestamp` int(11) NOT NULL COMMENT 'A Unix timestamp indicating when this batch was submitted for processing. Stale batches are purged at cron time.',
  `batch` longblob COMMENT 'A serialized array containing the processing data for the batch.',
  PRIMARY KEY (`bid`),
  KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `batch`
--


-- --------------------------------------------------------

--
-- Table structure for table `block`
--

CREATE TABLE IF NOT EXISTS `block` (
  `bid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique block ID.',
  `module` varchar(64) NOT NULL DEFAULT '' COMMENT 'The module from which the block originates; for example, ’user’ for the Who’s Online block, and ’block’ for any custom blocks.',
  `delta` varchar(32) NOT NULL DEFAULT '0' COMMENT 'Unique ID for block within a module.',
  `theme` varchar(64) NOT NULL DEFAULT '' COMMENT 'The theme under which the block settings apply.',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Block enabled status. (1 = enabled, 0 = disabled)',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'Block weight within region.',
  `region` varchar(64) NOT NULL DEFAULT '' COMMENT 'Theme region within which the block is set.',
  `custom` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Flag to indicate how users may control visibility of the block. (0 = Users cannot control, 1 = On by default, but can be hidden, 2 = Hidden by default, but can be shown)',
  `visibility` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Flag to indicate how to show blocks on pages. (0 = Show on all pages except listed pages, 1 = Show only on listed pages, 2 = Use custom PHP code to determine visibility)',
  `pages` text NOT NULL COMMENT 'Contents of the `Pages` block; contains either a list of paths on which to include/exclude the block or PHP code, depending on `visibility` setting.',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT 'Custom title for the block. (Empty string will use block default title, <none> will remove the title, text will cause block to use specified title.)',
  `cache` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Binary flag to indicate block cache mode. (-2: Custom cache, -1: Do not cache, 1: Cache per role, 2: Cache per user, 4: Cache per page, 8: Block cache global) See DRUPAL_CACHE_* constants in ../includes/common.inc for more detailed information.',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `tmd` (`theme`,`module`,`delta`),
  KEY `list` (`theme`,`status`,`region`,`weight`,`module`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=90 ;

--
-- Dumping data for table `block`
--

INSERT INTO `block` (`bid`, `module`, `delta`, `theme`, `status`, `weight`, `region`, `custom`, `visibility`, `pages`, `title`, `cache`) VALUES
(1, 'system', 'main', 'bartik', 1, 0, 'content', 0, 0, '', '', -1),
(2, 'search', 'form', 'bartik', 1, -1, 'header', 0, 0, '', '', -1),
(3, 'node', 'recent', 'seven', 0, 10, '-1', 0, 0, '', '', -1),
(4, 'user', 'login', 'bartik', 0, -8, '-1', 0, 0, '', '', -1),
(5, 'system', 'navigation', 'bartik', 0, 0, '-1', 0, 0, '', '', -1),
(6, 'system', 'powered-by', 'bartik', 1, -8, 'footer', 0, 0, '', '', -1),
(7, 'system', 'help', 'bartik', 0, -7, '-1', 0, 0, '', '', -1),
(8, 'system', 'main', 'seven', 1, 0, 'content', 0, 0, '', '', -1),
(9, 'system', 'help', 'seven', 1, 0, 'help', 0, 0, '', '', -1),
(10, 'user', 'login', 'seven', 1, 10, 'content', 0, 0, '', '', -1),
(11, 'user', 'new', 'seven', 0, 0, '-1', 0, 0, '', '', -1),
(12, 'search', 'form', 'seven', 0, -10, '-1', 0, 0, '', '', -1),
(13, 'comment', 'recent', 'bartik', 0, -4, '-1', 0, 0, '', '', 1),
(14, 'node', 'syndicate', 'bartik', 0, -1, '-1', 0, 0, '', '', -1),
(15, 'node', 'recent', 'bartik', 0, -3, '-1', 0, 0, '', '', 1),
(17, 'system', 'management', 'bartik', 0, -5, '-1', 0, 0, '', '', -1),
(18, 'system', 'user-menu', 'bartik', 0, 0, '-1', 0, 0, '', '', -1),
(19, 'system', 'main-menu', 'bartik', 0, -6, '-1', 0, 0, '', '', -1),
(20, 'user', 'new', 'bartik', 0, 1, '-1', 0, 0, '', '', 1),
(21, 'user', 'online', 'bartik', 0, 2, '-1', 0, 0, '', '', -1),
(22, 'comment', 'recent', 'seven', 0, 0, '-1', 0, 0, '', '', 1),
(23, 'node', 'syndicate', 'seven', 0, 0, '-1', 0, 0, '', '', -1),
(25, 'system', 'powered-by', 'seven', 0, 10, '-1', 0, 0, '', '', -1),
(26, 'system', 'navigation', 'seven', 0, 0, '-1', 0, 0, '', '', -1),
(27, 'system', 'management', 'seven', 0, 0, '-1', 0, 0, '', '', -1),
(28, 'system', 'user-menu', 'seven', 0, 0, '-1', 0, 0, '', '', -1),
(29, 'system', 'main-menu', 'seven', 0, 0, '-1', 0, 0, '', '', -1),
(30, 'user', 'online', 'seven', 0, 0, '-1', 0, 0, '', '', -1),
(31, 'comment', 'recent', 'corolla', 1, -6, 'sidebar_second', 0, 0, '', '', 1),
(32, 'node', 'recent', 'corolla', 0, -7, '-1', 0, 0, '', '', 1),
(33, 'node', 'syndicate', 'corolla', 0, -6, '-1', 0, 0, '', '', -1),
(34, 'search', 'form', 'corolla', 1, -9, 'sidebar_second', 0, 0, '', '', -1),
(36, 'system', 'help', 'corolla', 0, -5, '-1', 0, 0, '', '', -1),
(37, 'system', 'main', 'corolla', 1, -10, 'content', 0, 0, '', '', -1),
(38, 'system', 'main-menu', 'corolla', 1, -8, 'header_menu', 0, 0, '', '', -1),
(39, 'system', 'management', 'corolla', 0, -9, '-1', 0, 0, '', '', -1),
(40, 'system', 'navigation', 'corolla', 0, -8, '-1', 0, 0, '', '', -1),
(41, 'system', 'powered-by', 'corolla', 1, -10, 'footer_menu', 0, 0, '', '', -1),
(42, 'system', 'user-menu', 'corolla', 0, -3, '-1', 0, 0, '', '', -1),
(43, 'user', 'login', 'corolla', 0, -4, '-1', 0, 0, '', '', -1),
(44, 'user', 'new', 'corolla', 0, -2, '-1', 0, 0, '', '', 1),
(45, 'user', 'online', 'corolla', 0, -1, '-1', 0, 0, '', '', -1),
(50, 'dfotw_tweaks', 'dfotw_recent_content', 'corolla', 1, -8, 'sidebar_second', 0, 0, '', '', 8),
(51, 'dfotw_tweaks', 'dfotw_recent_content', 'bartik', 0, 0, '-1', 0, 0, '', '', 8),
(52, 'dfotw_tweaks', 'dfotw_recent_content', 'seven', 0, 0, '-1', 0, 0, '', '', 8),
(53, 'dfotw_tweaks', 'dfotw_browse_version', 'corolla', 1, -7, 'sidebar_second', 0, 0, '', '', 8),
(54, 'dfotw_tweaks', 'dfotw_browse_version', 'bartik', 0, 0, '-1', 0, 0, '', '', 8),
(55, 'dfotw_tweaks', 'dfotw_browse_version', 'seven', 0, 0, '-1', 0, 0, '', '', 8),
(56, 'dfotw_tweaks', 'dfotw_share_global', 'corolla', 1, -10, 'sidebar_second', 0, 0, '', '', 8),
(57, 'dfotw_tweaks', 'dfotw_share_post', 'corolla', 0, -9, '-1', 0, 0, '', '', 8),
(58, 'dfotw_tweaks', 'dfotw_share_post', 'bartik', 0, 0, '-1', 0, 0, '', '', 8),
(59, 'dfotw_tweaks', 'dfotw_share_post', 'seven', 0, 0, '-1', 0, 0, '', '', 8),
(60, 'dfotw_tweaks', 'dfotw_share_global', 'bartik', 0, 0, '-1', 0, 0, '', '', 8),
(61, 'dfotw_tweaks', 'dfotw_share_global', 'seven', 0, 0, '-1', 0, 0, '', '', 8),
(62, 'dfotw_tweaks', 'dfotw_feedburner', 'corolla', 0, 0, '-1', 0, 0, '', '', 8),
(63, 'menu', 'features', 'bartik', 0, 0, '-1', 0, 0, '', '', -1),
(64, 'menu', 'features', 'corolla', 0, -10, '-1', 0, 0, '', '', -1),
(65, 'menu', 'features', 'seven', 0, 0, '-1', 0, 0, '', '', -1),
(67, 'comment', 'recent', 'dfotw_corolla', 0, -2, '-1', 0, 0, '', '', 1),
(68, 'dfotw_tweaks', 'dfotw_browse_version', 'dfotw_corolla', 0, -11, '-1', 0, 0, '', '', 8),
(69, 'dfotw_tweaks', 'dfotw_feedburner', 'dfotw_corolla', 0, 0, '-1', 0, 0, '', '', 8),
(70, 'dfotw_tweaks', 'dfotw_recent_content', 'dfotw_corolla', 0, -10, '-1', 0, 0, '', '', 8),
(71, 'dfotw_tweaks', 'dfotw_share_global', 'dfotw_corolla', 0, -9, '-1', 0, 0, '', '', 8),
(72, 'dfotw_tweaks', 'dfotw_share_post', 'dfotw_corolla', 0, -8, '-1', 0, 0, '', '', 4),
(73, 'menu', 'features', 'dfotw_corolla', 0, -7, '-1', 0, 0, '', '', -1),
(74, 'node', 'recent', 'dfotw_corolla', 0, -1, '-1', 0, 0, '', '', 1),
(75, 'node', 'syndicate', 'dfotw_corolla', 0, 1, '-1', 0, 0, '', '', -1),
(76, 'search', 'form', 'dfotw_corolla', 0, 0, '-1', 0, 0, '', '', -1),
(77, 'system', 'help', 'dfotw_corolla', 0, 2, '-1', 0, 0, '', '', -1),
(78, 'system', 'main', 'dfotw_corolla', 0, -10, '-1', 0, 0, '', '', -1),
(79, 'system', 'main-menu', 'dfotw_corolla', 0, -6, '-1', 0, 0, '', '', -1),
(80, 'system', 'management', 'dfotw_corolla', 0, -5, '-1', 0, 0, '', '', -1),
(81, 'system', 'navigation', 'dfotw_corolla', 0, -4, '-1', 0, 0, '', '', -1),
(82, 'system', 'powered-by', 'dfotw_corolla', 0, -3, '-1', 0, 0, '', '', -1),
(83, 'system', 'user-menu', 'dfotw_corolla', 0, 5, '-1', 0, 0, '', '', -1),
(84, 'user', 'login', 'dfotw_corolla', 0, 4, '-1', 0, 0, '', '', -1),
(85, 'user', 'new', 'dfotw_corolla', 0, 6, '-1', 0, 0, '', '', 1),
(86, 'user', 'online', 'dfotw_corolla', 0, 7, '-1', 0, 0, '', '', -1),
(87, 'context_ui', 'editor', 'dfotw_corolla', 1, 0, '', 0, 0, '', '', 1),
(88, 'dfotw_tweaks', 'dfotw_user_submission', 'dfotw_corolla', 0, 0, '-1', 0, 0, '', '', 8),
(89, 'shortcut', 'shortcuts', 'dfotw_corolla', 0, 0, '-1', 0, 0, '', '', -1);

-- --------------------------------------------------------

--
-- Table structure for table `blocked_ips`
--

CREATE TABLE IF NOT EXISTS `blocked_ips` (
  `iid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: unique ID for IP addresses.',
  `ip` varchar(40) NOT NULL DEFAULT '' COMMENT 'IP address',
  PRIMARY KEY (`iid`),
  KEY `blocked_ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `blocked_ips`
--


-- --------------------------------------------------------

--
-- Table structure for table `block_custom`
--

CREATE TABLE IF NOT EXISTS `block_custom` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The block’s block.bid.',
  `body` longtext COMMENT 'Block contents.',
  `info` varchar(128) NOT NULL DEFAULT '' COMMENT 'Block description.',
  `format` varchar(255) DEFAULT NULL COMMENT 'The filter_format.format of the block body.',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `info` (`info`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `block_custom`
--


-- --------------------------------------------------------

--
-- Table structure for table `block_node_type`
--

CREATE TABLE IF NOT EXISTS `block_node_type` (
  `module` varchar(64) NOT NULL COMMENT 'The block’s origin module, from block.module.',
  `delta` varchar(32) NOT NULL COMMENT 'The block’s unique delta within module, from block.delta.',
  `type` varchar(32) NOT NULL COMMENT 'The machine-readable name of this type from node_type.type.',
  PRIMARY KEY (`module`,`delta`,`type`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `block_node_type`
--

INSERT INTO `block_node_type` (`module`, `delta`, `type`) VALUES
('dfotw_tweaks', 'dfotw_share_post', 'function');

-- --------------------------------------------------------

--
-- Table structure for table `block_role`
--

CREATE TABLE IF NOT EXISTS `block_role` (
  `module` varchar(64) NOT NULL COMMENT 'The block’s origin module, from block.module.',
  `delta` varchar(32) NOT NULL COMMENT 'The block’s unique delta within module, from block.delta.',
  `rid` int(10) unsigned NOT NULL COMMENT 'The user’s role ID from users_roles.rid.',
  PRIMARY KEY (`module`,`delta`,`rid`),
  KEY `rid` (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `block_role`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE IF NOT EXISTS `cache` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_admin_menu`
--

CREATE TABLE IF NOT EXISTS `cache_admin_menu` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cache table for Administration menu to store client-side...';

--
-- Dumping data for table `cache_admin_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_block`
--

CREATE TABLE IF NOT EXISTS `cache_block` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_block`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_bootstrap`
--

CREATE TABLE IF NOT EXISTS `cache_bootstrap` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_bootstrap`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_field`
--

CREATE TABLE IF NOT EXISTS `cache_field` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_field`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_filter`
--

CREATE TABLE IF NOT EXISTS `cache_filter` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_filter`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_form`
--

CREATE TABLE IF NOT EXISTS `cache_form` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_form`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_menu`
--

CREATE TABLE IF NOT EXISTS `cache_menu` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_menu`
--

INSERT INTO `cache_menu` (`cid`, `data`, `expire`, `created`, `serialized`) VALUES
('menu_custom', 0x613a353a7b733a383a226665617475726573223b613a333a7b733a393a226d656e755f6e616d65223b733a383a226665617475726573223b733a353a227469746c65223b733a383a224665617475726573223b733a31313a226465736372697074696f6e223b733a33363a224d656e75206974656d7320666f7220616e7920656e61626c65642066656174757265732e223b7d733a393a226d61696e2d6d656e75223b613a333a7b733a393a226d656e755f6e616d65223b733a393a226d61696e2d6d656e75223b733a353a227469746c65223b733a393a224d61696e206d656e75223b733a31313a226465736372697074696f6e223b733a3131353a22546865203c656d3e4d61696e3c2f656d3e206d656e752069732075736564206f6e206d616e7920736974657320746f2073686f7720746865206d616a6f722073656374696f6e73206f662074686520736974652c206f6674656e20696e206120746f70206e617669676174696f6e206261722e223b7d733a31303a226d616e6167656d656e74223b613a333a7b733a393a226d656e755f6e616d65223b733a31303a226d616e6167656d656e74223b733a353a227469746c65223b733a31303a224d616e6167656d656e74223b733a31313a226465736372697074696f6e223b733a36393a22546865203c656d3e4d616e6167656d656e743c2f656d3e206d656e7520636f6e7461696e73206c696e6b7320666f722061646d696e697374726174697665207461736b732e223b7d733a31303a226e617669676174696f6e223b613a333a7b733a393a226d656e755f6e616d65223b733a31303a226e617669676174696f6e223b733a353a227469746c65223b733a31303a224e617669676174696f6e223b733a31313a226465736372697074696f6e223b733a3135303a22546865203c656d3e4e617669676174696f6e3c2f656d3e206d656e7520636f6e7461696e73206c696e6b7320696e74656e64656420666f7220736974652076697369746f72732e204c696e6b732061726520616464656420746f20746865203c656d3e4e617669676174696f6e3c2f656d3e206d656e75206175746f6d61746963616c6c7920627920736f6d65206d6f64756c65732e223b7d733a393a22757365722d6d656e75223b613a333a7b733a393a226d656e755f6e616d65223b733a393a22757365722d6d656e75223b733a353a227469746c65223b733a393a2255736572206d656e75223b733a31313a226465736372697074696f6e223b733a39393a22546865203c656d3e557365723c2f656d3e206d656e7520636f6e7461696e73206c696e6b732072656c6174656420746f2074686520757365722773206163636f756e742c2061732077656c6c2061732074686520274c6f67206f757427206c696e6b2e223b7d7d, 0, 1315428196, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cache_page`
--

CREATE TABLE IF NOT EXISTS `cache_page` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_page`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_path`
--

CREATE TABLE IF NOT EXISTS `cache_path` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_path`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_token`
--

CREATE TABLE IF NOT EXISTS `cache_token` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_token`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_update`
--

CREATE TABLE IF NOT EXISTS `cache_update` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_update`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_variable`
--

CREATE TABLE IF NOT EXISTS `cache_variable` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cache table for variables.';

--
-- Dumping data for table `cache_variable`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_views`
--

CREATE TABLE IF NOT EXISTS `cache_views` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_views`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_views_data`
--

CREATE TABLE IF NOT EXISTS `cache_views_data` (
  `cid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique cache ID.',
  `data` longblob COMMENT 'A collection of data to cache.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry should expire, or 0 for never.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when the cache entry was created.',
  `serialized` smallint(6) NOT NULL DEFAULT '1' COMMENT 'A flag to indicate whether content is serialized (1) or not (0).',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_views_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `cid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique comment ID.',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT 'The comment.cid to which this comment is a reply. If set to 0, this comment is not a reply to an existing comment.',
  `nid` int(11) NOT NULL DEFAULT '0' COMMENT 'The node.nid to which this comment is a reply.',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid who authored the comment. If set to 0, this comment was created by an anonymous user.',
  `subject` varchar(64) NOT NULL DEFAULT '' COMMENT 'The comment title.',
  `hostname` varchar(128) NOT NULL DEFAULT '' COMMENT 'The author’s host name.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'The time that the comment was created, as a Unix timestamp.',
  `changed` int(11) NOT NULL DEFAULT '0' COMMENT 'The time that the comment was last edited, as a Unix timestamp.',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT 'The published status of a comment. (0 = Not Published, 1 = Published)',
  `thread` varchar(255) NOT NULL COMMENT 'The vancode representation of the comment’s place in a thread.',
  `name` varchar(60) DEFAULT NULL COMMENT 'The comment author’s name. Uses users.name if the user is logged in, otherwise uses the value typed into the comment form.',
  `mail` varchar(64) DEFAULT NULL COMMENT 'The comment author’s e-mail address from the comment form, if user is anonymous, and the ’Anonymous users may/must leave their contact information’ setting is turned on.',
  `homepage` varchar(255) DEFAULT NULL COMMENT 'The comment author’s home page address from the comment form, if user is anonymous, and the ’Anonymous users may/must leave their contact information’ setting is turned on.',
  `language` varchar(12) NOT NULL DEFAULT '' COMMENT 'The languages.language of this comment.',
  PRIMARY KEY (`cid`),
  KEY `comment_status_pid` (`pid`,`status`),
  KEY `comment_num_new` (`nid`,`status`,`created`,`cid`,`thread`),
  KEY `comment_uid` (`uid`),
  KEY `comment_nid_language` (`nid`,`language`),
  KEY `comment_created` (`created`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`cid`, `pid`, `nid`, `uid`, `subject`, `hostname`, `created`, `changed`, `status`, `thread`, `name`, `mail`, `homepage`, `language`) VALUES
(1, 0, 2, 0, 'Great Idea', '186.220.155.247', 1306438294, 1306438293, 1, '01/', 'Miguel Trindade Jr', '', '', 'und'),
(2, 0, 3, 0, 'Email field', '187.106.38.249', 1306596887, 1306596886, 1, '01/', 'Capi Etheriel', '', '', 'und'),
(3, 2, 3, 1, 'Good call!', '186.220.155.247', 1306775566, 1306775566, 1, '01.00/', 'admin', '', '', 'und'),
(9, 0, 4, 0, 'This seems a great finding,', '14.97.63.36', 1307249344, 1307249344, 1, '02/', 'William Smith', '', '', 'und'),
(10, 0, 3, 0, 'This is a great way to detect', '14.97.215.97', 1307875988, 1307875988, 0, '02/', 'Salvage Cars', '', '', 'und'),
(11, 0, 2, 0, 'Hey that''s great, all this', '14.97.215.97', 1307876277, 1307876276, 1, '02/', 'William Smith', '', '', 'und'),
(12, 0, 3, 0, 'Update the title theme to', '14.97.143.189', 1308379200, 1308379199, 0, '03/', 'William Smith', '', '', 'und'),
(13, 0, 3, 0, 'Nice explanation of the', '59.96.134.178', 1309172419, 1309172417, 0, '04/', 'Chennai Domain Name', '', '', 'und'),
(14, 0, 3, 0, 'Do you people have a facebook', '95.160.199.227', 1309638056, 1309638055, 0, '05/', 'Joshua', '', '', 'und');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique category ID.',
  `category` varchar(255) NOT NULL DEFAULT '' COMMENT 'Category name.',
  `recipients` longtext NOT NULL COMMENT 'Comma-separated list of recipient e-mail addresses.',
  `reply` longtext NOT NULL COMMENT 'Text of the auto-reply message.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'The category’s weight.',
  `selected` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Flag to indicate whether or not category is selected by default. (1 = Yes, 0 = No)',
  PRIMARY KEY (`cid`),
  UNIQUE KEY `category` (`category`),
  KEY `list` (`weight`,`category`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`cid`, `category`, `recipients`, `reply`, `weight`, `selected`) VALUES
(1, 'Submit Function', 'alex@webdrop.net.br', 'Thanks for your submission! It will be checked out and put into the queue before you know it!', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `context`
--

CREATE TABLE IF NOT EXISTS `context` (
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'The primary identifier for a context.',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT 'Description for this context.',
  `tag` varchar(255) NOT NULL DEFAULT '' COMMENT 'Tag for this context.',
  `conditions` text COMMENT 'Serialized storage of all context condition settings.',
  `reactions` text COMMENT 'Serialized storage of all context reaction settings.',
  `condition_mode` int(11) DEFAULT '0' COMMENT 'Condition mode for this context.',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Storage for normal (user-defined) contexts.';

--
-- Dumping data for table `context`
--

INSERT INTO `context` (`name`, `description`, `tag`, `conditions`, `reactions`, `condition_mode`) VALUES
('contact', 'Contact form', '', 'a:1:{s:4:"path";a:1:{s:6:"values";a:1:{s:7:"contact";s:7:"contact";}}}', 'a:1:{s:5:"block";a:1:{s:6:"blocks";a:1:{s:34:"dfotw_tweaks-dfotw_user_submission";a:4:{s:6:"module";s:12:"dfotw_tweaks";s:5:"delta";s:21:"dfotw_user_submission";s:6:"region";s:11:"content_top";s:6:"weight";s:3:"-10";}}}}', 0),
('dfotw', 'Sitewide context', '', 'a:1:{s:8:"sitewide";a:1:{s:6:"values";a:1:{i:1;i:1;}}}', 'a:1:{s:5:"block";a:1:{s:6:"blocks";a:8:{s:16:"system-main-menu";a:4:{s:6:"module";s:6:"system";s:5:"delta";s:9:"main-menu";s:6:"region";s:11:"header_menu";s:6:"weight";s:3:"-10";}s:17:"system-powered-by";a:4:{s:6:"module";s:6:"system";s:5:"delta";s:10:"powered-by";s:6:"region";s:11:"footer_menu";s:6:"weight";s:3:"-10";}s:31:"dfotw_tweaks-dfotw_share_global";a:4:{s:6:"module";s:12:"dfotw_tweaks";s:5:"delta";s:18:"dfotw_share_global";s:6:"region";s:14:"sidebar_second";s:6:"weight";s:3:"-12";}s:11:"search-form";a:4:{s:6:"module";s:6:"search";s:5:"delta";s:4:"form";s:6:"region";s:14:"sidebar_second";s:6:"weight";s:3:"-11";}s:33:"dfotw_tweaks-dfotw_recent_content";a:4:{s:6:"module";s:12:"dfotw_tweaks";s:5:"delta";s:20:"dfotw_recent_content";s:6:"region";s:14:"sidebar_second";s:6:"weight";s:3:"-10";}s:33:"dfotw_tweaks-dfotw_browse_version";a:4:{s:6:"module";s:12:"dfotw_tweaks";s:5:"delta";s:20:"dfotw_browse_version";s:6:"region";s:14:"sidebar_second";s:6:"weight";s:2:"-9";}s:14:"comment-recent";a:4:{s:6:"module";s:7:"comment";s:5:"delta";s:6:"recent";s:6:"region";s:14:"sidebar_second";s:6:"weight";s:2:"-8";}s:11:"system-main";a:4:{s:6:"module";s:6:"system";s:5:"delta";s:4:"main";s:6:"region";s:7:"content";s:6:"weight";s:3:"-10";}}}}', 0),
('function', 'Function Node Pages', '', 'a:1:{s:4:"node";a:2:{s:6:"values";a:1:{s:8:"function";s:8:"function";}s:7:"options";a:1:{s:9:"node_form";s:1:"0";}}}', 'a:1:{s:5:"block";a:1:{s:6:"blocks";a:1:{s:29:"dfotw_tweaks-dfotw_share_post";a:4:{s:6:"module";s:12:"dfotw_tweaks";s:5:"delta";s:16:"dfotw_share_post";s:6:"region";s:11:"content_top";s:6:"weight";s:3:"-10";}}}}', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ctools_css_cache`
--

CREATE TABLE IF NOT EXISTS `ctools_css_cache` (
  `cid` varchar(128) NOT NULL COMMENT 'The CSS ID this cache object belongs to.',
  `filename` varchar(255) DEFAULT NULL COMMENT 'The filename this CSS is stored in.',
  `css` longtext COMMENT 'CSS being stored.',
  `filter` tinyint(4) DEFAULT NULL COMMENT 'Whether or not this CSS needs to be filtered.',
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctools_css_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `ctools_object_cache`
--

CREATE TABLE IF NOT EXISTS `ctools_object_cache` (
  `sid` varchar(64) NOT NULL COMMENT 'The session ID this cache object belongs to.',
  `name` varchar(128) NOT NULL COMMENT 'The name of the object this cache is attached to.',
  `obj` varchar(32) NOT NULL COMMENT 'The type of the object this cache is attached to; this essentially represents the owner so that several sub-systems can use this cache.',
  `updated` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The time this cache was created or updated.',
  `data` longtext COMMENT 'Serialized data being stored.',
  PRIMARY KEY (`sid`,`obj`,`name`),
  KEY `updated` (`updated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ctools_object_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `date_formats`
--

CREATE TABLE IF NOT EXISTS `date_formats` (
  `dfid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The date format identifier.',
  `format` varchar(100) NOT NULL COMMENT 'The date format string.',
  `type` varchar(64) NOT NULL COMMENT 'The date format type, e.g. medium.',
  `locked` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Whether or not this format can be modified.',
  PRIMARY KEY (`dfid`),
  UNIQUE KEY `formats` (`format`,`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `date_formats`
--

INSERT INTO `date_formats` (`dfid`, `format`, `type`, `locked`) VALUES
(1, 'Y-m-d H:i', 'short', 1),
(2, 'm/d/Y - H:i', 'short', 1),
(3, 'd/m/Y - H:i', 'short', 1),
(4, 'Y/m/d - H:i', 'short', 1),
(5, 'd.m.Y - H:i', 'short', 1),
(6, 'm/d/Y - g:ia', 'short', 1),
(7, 'd/m/Y - g:ia', 'short', 1),
(8, 'Y/m/d - g:ia', 'short', 1),
(9, 'M j Y - H:i', 'short', 1),
(10, 'j M Y - H:i', 'short', 1),
(11, 'Y M j - H:i', 'short', 1),
(12, 'M j Y - g:ia', 'short', 1),
(13, 'j M Y - g:ia', 'short', 1),
(14, 'Y M j - g:ia', 'short', 1),
(15, 'D, Y-m-d H:i', 'medium', 1),
(16, 'D, m/d/Y - H:i', 'medium', 1),
(17, 'D, d/m/Y - H:i', 'medium', 1),
(18, 'D, Y/m/d - H:i', 'medium', 1),
(19, 'F j, Y - H:i', 'medium', 1),
(20, 'j F, Y - H:i', 'medium', 1),
(21, 'Y, F j - H:i', 'medium', 1),
(22, 'D, m/d/Y - g:ia', 'medium', 1),
(23, 'D, d/m/Y - g:ia', 'medium', 1),
(24, 'D, Y/m/d - g:ia', 'medium', 1),
(25, 'F j, Y - g:ia', 'medium', 1),
(26, 'j F Y - g:ia', 'medium', 1),
(27, 'Y, F j - g:ia', 'medium', 1),
(28, 'j. F Y - G:i', 'medium', 1),
(29, 'l, F j, Y - H:i', 'long', 1),
(30, 'l, j F, Y - H:i', 'long', 1),
(31, 'l, Y,  F j - H:i', 'long', 1),
(32, 'l, F j, Y - g:ia', 'long', 1),
(33, 'l, j F Y - g:ia', 'long', 1),
(34, 'l, Y,  F j - g:ia', 'long', 1),
(35, 'l, j. F Y - G:i', 'long', 1);

-- --------------------------------------------------------

--
-- Table structure for table `date_format_locale`
--

CREATE TABLE IF NOT EXISTS `date_format_locale` (
  `format` varchar(100) NOT NULL COMMENT 'The date format string.',
  `type` varchar(64) NOT NULL COMMENT 'The date format type, e.g. medium.',
  `language` varchar(12) NOT NULL COMMENT 'A languages.language for this format to be used with.',
  PRIMARY KEY (`type`,`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `date_format_locale`
--


-- --------------------------------------------------------

--
-- Table structure for table `date_format_type`
--

CREATE TABLE IF NOT EXISTS `date_format_type` (
  `type` varchar(64) NOT NULL COMMENT 'The date format type, e.g. medium.',
  `title` varchar(255) NOT NULL COMMENT 'The human readable name of the format type.',
  `locked` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Whether or not this is a system provided format.',
  PRIMARY KEY (`type`),
  KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `date_format_type`
--

INSERT INTO `date_format_type` (`type`, `title`, `locked`) VALUES
('long', 'Long', 1),
('medium', 'Medium', 1),
('short', 'Short', 1);

-- --------------------------------------------------------

--
-- Table structure for table `field_config`
--

CREATE TABLE IF NOT EXISTS `field_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a field',
  `field_name` varchar(32) NOT NULL COMMENT 'The name of this field. Non-deleted field names are unique, but multiple deleted fields can have the same name.',
  `type` varchar(128) NOT NULL COMMENT 'The type of this field.',
  `module` varchar(128) NOT NULL DEFAULT '' COMMENT 'The module that implements the field type.',
  `active` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether the module that implements the field type is enabled.',
  `storage_type` varchar(128) NOT NULL COMMENT 'The storage backend for the field.',
  `storage_module` varchar(128) NOT NULL DEFAULT '' COMMENT 'The module that implements the storage backend.',
  `storage_active` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether the module that implements the storage backend is enabled.',
  `locked` tinyint(4) NOT NULL DEFAULT '0' COMMENT '@TODO',
  `data` longblob NOT NULL COMMENT 'Serialized data containing the field properties that do not warrant a dedicated column.',
  `cardinality` tinyint(4) NOT NULL DEFAULT '0',
  `translatable` tinyint(4) NOT NULL DEFAULT '0',
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_name` (`field_name`),
  KEY `active` (`active`),
  KEY `storage_active` (`storage_active`),
  KEY `deleted` (`deleted`),
  KEY `module` (`module`),
  KEY `storage_module` (`storage_module`),
  KEY `type` (`type`),
  KEY `storage_type` (`storage_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `field_config`
--

INSERT INTO `field_config` (`id`, `field_name`, `type`, `module`, `active`, `storage_type`, `storage_module`, `storage_active`, `locked`, `data`, `cardinality`, `translatable`, `deleted`) VALUES
(1, 'comment_body', 'text_long', 'text', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a22656e746974795f7479706573223b613a313a7b693a303b733a373a22636f6d6d656e74223b7d733a31323a22666f726569676e206b657973223b613a313a7b733a363a22666f726d6174223b613a323a7b733a373a22636f6c756d6e73223b613a313a7b733a363a22666f726d6174223b733a363a22666f726d6174223b7d733a353a227461626c65223b733a31333a2266696c7465725f666f726d6174223b7d7d733a373a22696e6465786573223b613a313a7b733a363a22666f726d6174223b613a313a7b693a303b733a363a22666f726d6174223b7d7d733a383a2273657474696e6773223b613a303a7b7d733a31323a227472616e736c617461626c65223b733a313a2230223b733a373a2273746f72616765223b613a343a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b7d733a323a226964223b733a313a2231223b7d, 1, 0, 0),
(2, 'body', 'text_with_summary', 'text', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a22656e746974795f7479706573223b613a313a7b693a303b733a343a226e6f6465223b7d733a31323a22666f726569676e206b657973223b613a313a7b733a363a22666f726d6174223b613a323a7b733a373a22636f6c756d6e73223b613a313a7b733a363a22666f726d6174223b733a363a22666f726d6174223b7d733a353a227461626c65223b733a31333a2266696c7465725f666f726d6174223b7d7d733a373a22696e6465786573223b613a313a7b733a363a22666f726d6174223b613a313a7b693a303b733a363a22666f726d6174223b7d7d733a383a2273657474696e6773223b613a303a7b7d733a31323a227472616e736c617461626c65223b733a313a2231223b733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a31353a226669656c645f646174615f626f6479223b613a333a7b733a353a2276616c7565223b733a31303a22626f64795f76616c7565223b733a373a2273756d6d617279223b733a31323a22626f64795f73756d6d617279223b733a363a22666f726d6174223b733a31313a22626f64795f666f726d6174223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a31393a226669656c645f7265766973696f6e5f626f6479223b613a333a7b733a353a2276616c7565223b733a31303a22626f64795f76616c7565223b733a373a2273756d6d617279223b733a31323a22626f64795f73756d6d617279223b733a363a22666f726d6174223b733a31313a22626f64795f666f726d6174223b7d7d7d7d7d733a323a226964223b733a313a2232223b7d, 1, 1, 0),
(6, 'field_function_docs', 'link_field', 'link', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a22656e746974795f7479706573223b613a303a7b7d733a31323a22666f726569676e206b657973223b613a303a7b7d733a373a22696e6465786573223b613a303a7b7d733a383a2273657474696e6773223b613a363a7b733a31303a2261747472696275746573223b613a333a7b733a353a22636c617373223b733a303a22223b733a333a2272656c223b733a303a22223b733a363a22746172676574223b733a373a2264656661756c74223b7d733a373a22646973706c6179223b613a313a7b733a31303a2275726c5f6375746f6666223b693a38303b7d733a31333a22656e61626c655f746f6b656e73223b693a313b733a353a227469746c65223b733a383a226f7074696f6e616c223b733a31313a227469746c655f76616c7565223b733a303a22223b733a333a2275726c223b693a303b7d733a31323a227472616e736c617461626c65223b733a313a2231223b733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a33303a226669656c645f646174615f6669656c645f66756e6374696f6e5f646f6373223b613a333a7b733a333a2275726c223b733a32333a226669656c645f66756e6374696f6e5f646f63735f75726c223b733a353a227469746c65223b733a32353a226669656c645f66756e6374696f6e5f646f63735f7469746c65223b733a31303a2261747472696275746573223b733a33303a226669656c645f66756e6374696f6e5f646f63735f61747472696275746573223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a33343a226669656c645f7265766973696f6e5f6669656c645f66756e6374696f6e5f646f6373223b613a333a7b733a333a2275726c223b733a32333a226669656c645f66756e6374696f6e5f646f63735f75726c223b733a353a227469746c65223b733a32353a226669656c645f66756e6374696f6e5f646f63735f7469746c65223b733a31303a2261747472696275746573223b733a33303a226669656c645f66756e6374696f6e5f646f63735f61747472696275746573223b7d7d7d7d7d733a323a226964223b733a313a2236223b7d, -1, 1, 0),
(7, 'field_function_author', 'link_field', 'link', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a22656e746974795f7479706573223b613a303a7b7d733a31323a22666f726569676e206b657973223b613a303a7b7d733a373a22696e6465786573223b613a303a7b7d733a383a2273657474696e6773223b613a363a7b733a31303a2261747472696275746573223b613a333a7b733a353a22636c617373223b733a303a22223b733a333a2272656c223b733a303a22223b733a363a22746172676574223b733a373a2264656661756c74223b7d733a373a22646973706c6179223b613a313a7b733a31303a2275726c5f6375746f6666223b693a38303b7d733a31333a22656e61626c655f746f6b656e73223b693a313b733a353a227469746c65223b733a383a226f7074696f6e616c223b733a31313a227469746c655f76616c7565223b733a303a22223b733a333a2275726c223b693a303b7d733a31323a227472616e736c617461626c65223b733a313a2231223b733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a33323a226669656c645f646174615f6669656c645f66756e6374696f6e5f617574686f72223b613a333a7b733a333a2275726c223b733a32353a226669656c645f66756e6374696f6e5f617574686f725f75726c223b733a353a227469746c65223b733a32373a226669656c645f66756e6374696f6e5f617574686f725f7469746c65223b733a31303a2261747472696275746573223b733a33323a226669656c645f66756e6374696f6e5f617574686f725f61747472696275746573223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a33363a226669656c645f7265766973696f6e5f6669656c645f66756e6374696f6e5f617574686f72223b613a333a7b733a333a2275726c223b733a32353a226669656c645f66756e6374696f6e5f617574686f725f75726c223b733a353a227469746c65223b733a32373a226669656c645f66756e6374696f6e5f617574686f725f7469746c65223b733a31303a2261747472696275746573223b733a33323a226669656c645f66756e6374696f6e5f617574686f725f61747472696275746573223b7d7d7d7d7d733a323a226964223b733a313a2237223b7d, 1, 1, 0),
(8, 'field_function_tags', 'taxonomy_term_reference', 'taxonomy', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a22656e746974795f7479706573223b613a303a7b7d733a31323a22666f726569676e206b657973223b613a313a7b733a333a22746964223b613a323a7b733a373a22636f6c756d6e73223b613a313a7b733a333a22746964223b733a333a22746964223b7d733a353a227461626c65223b733a31383a227461786f6e6f6d795f7465726d5f64617461223b7d7d733a373a22696e6465786573223b613a313a7b733a333a22746964223b613a313a7b693a303b733a333a22746964223b7d7d733a383a2273657474696e6773223b613a313a7b733a31343a22616c6c6f7765645f76616c756573223b613a313a7b693a303b613a323a7b733a31303a22766f636162756c617279223b733a343a2274616773223b733a363a22706172656e74223b733a313a2230223b7d7d7d733a31323a227472616e736c617461626c65223b733a313a2231223b733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a33303a226669656c645f646174615f6669656c645f66756e6374696f6e5f74616773223b613a313a7b733a333a22746964223b733a32333a226669656c645f66756e6374696f6e5f746167735f746964223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a33343a226669656c645f7265766973696f6e5f6669656c645f66756e6374696f6e5f74616773223b613a313a7b733a333a22746964223b733a32333a226669656c645f66756e6374696f6e5f746167735f746964223b7d7d7d7d7d733a323a226964223b733a313a2238223b7d, -1, 1, 0),
(9, 'field_function_version', 'taxonomy_term_reference', 'taxonomy', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a22656e746974795f7479706573223b613a303a7b7d733a31323a22666f726569676e206b657973223b613a313a7b733a333a22746964223b613a323a7b733a373a22636f6c756d6e73223b613a313a7b733a333a22746964223b733a333a22746964223b7d733a353a227461626c65223b733a31383a227461786f6e6f6d795f7465726d5f64617461223b7d7d733a373a22696e6465786573223b613a313a7b733a333a22746964223b613a313a7b693a303b733a333a22746964223b7d7d733a383a2273657474696e6773223b613a313a7b733a31343a22616c6c6f7765645f76616c756573223b613a313a7b693a303b613a323a7b733a363a22706172656e74223b733a313a2230223b733a31303a22766f636162756c617279223b733a373a2276657273696f6e223b7d7d7d733a31323a227472616e736c617461626c65223b733a313a2231223b733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a33333a226669656c645f646174615f6669656c645f66756e6374696f6e5f76657273696f6e223b613a313a7b733a333a22746964223b733a32363a226669656c645f66756e6374696f6e5f76657273696f6e5f746964223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a33373a226669656c645f7265766973696f6e5f6669656c645f66756e6374696f6e5f76657273696f6e223b613a313a7b733a333a22746964223b733a32363a226669656c645f66756e6374696f6e5f76657273696f6e5f746964223b7d7d7d7d7d733a323a226964223b733a313a2239223b7d, -1, 1, 0),
(10, 'meta_keywords', 'metatags_quick', 'metatags_quick', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a22656e746974795f7479706573223b613a303a7b7d733a31323a22666f726569676e206b657973223b613a303a7b7d733a373a22696e6465786573223b613a303a7b7d733a383a2273657474696e6773223b613a323a7b693a303b733a393a226d6574615f6e616d65223b733a393a226d6574615f6e616d65223b733a383a226b6579776f726473223b7d733a31323a227472616e736c617461626c65223b733a313a2230223b733a373a2273746f72616765223b613a343a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b7d733a323a226964223b733a323a223130223b7d, 1, 0, 0),
(11, 'meta_description', 'metatags_quick', 'metatags_quick', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a22656e746974795f7479706573223b613a303a7b7d733a31323a22666f726569676e206b657973223b613a303a7b7d733a373a22696e6465786573223b613a303a7b7d733a383a2273657474696e6773223b613a323a7b693a303b733a393a226d6574615f6e616d65223b733a393a226d6574615f6e616d65223b733a31313a226465736372697074696f6e223b7d733a31323a227472616e736c617461626c65223b733a313a2230223b733a373a2273746f72616765223b613a343a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b7d733a323a226964223b733a323a223131223b7d, 1, 0, 0),
(13, 'field_function_intro', 'text_long', 'text', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a227472616e736c617461626c65223b733a313a2230223b733a31323a22656e746974795f7479706573223b613a303a7b7d733a383a2273657474696e6773223b613a303a7b7d733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a33313a226669656c645f646174615f6669656c645f66756e6374696f6e5f696e74726f223b613a323a7b733a353a2276616c7565223b733a32363a226669656c645f66756e6374696f6e5f696e74726f5f76616c7565223b733a363a22666f726d6174223b733a32373a226669656c645f66756e6374696f6e5f696e74726f5f666f726d6174223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a33353a226669656c645f7265766973696f6e5f6669656c645f66756e6374696f6e5f696e74726f223b613a323a7b733a353a2276616c7565223b733a32363a226669656c645f66756e6374696f6e5f696e74726f5f76616c7565223b733a363a22666f726d6174223b733a32373a226669656c645f66756e6374696f6e5f696e74726f5f666f726d6174223b7d7d7d7d7d733a31323a22666f726569676e206b657973223b613a313a7b733a363a22666f726d6174223b613a323a7b733a353a227461626c65223b733a31333a2266696c7465725f666f726d6174223b733a373a22636f6c756d6e73223b613a313a7b733a363a22666f726d6174223b733a363a22666f726d6174223b7d7d7d733a373a22696e6465786573223b613a313a7b733a363a22666f726d6174223b613a313a7b693a303b733a363a22666f726d6174223b7d7d733a323a226964223b733a323a223133223b7d, 1, 0, 0),
(15, 'field_function_desc', 'text_long', 'text', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a227472616e736c617461626c65223b733a313a2230223b733a31323a22656e746974795f7479706573223b613a303a7b7d733a383a2273657474696e6773223b613a303a7b7d733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a33303a226669656c645f646174615f6669656c645f66756e6374696f6e5f64657363223b613a323a7b733a353a2276616c7565223b733a32353a226669656c645f66756e6374696f6e5f646573635f76616c7565223b733a363a22666f726d6174223b733a32363a226669656c645f66756e6374696f6e5f646573635f666f726d6174223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a33343a226669656c645f7265766973696f6e5f6669656c645f66756e6374696f6e5f64657363223b613a323a7b733a353a2276616c7565223b733a32353a226669656c645f66756e6374696f6e5f646573635f76616c7565223b733a363a22666f726d6174223b733a32363a226669656c645f66756e6374696f6e5f646573635f666f726d6174223b7d7d7d7d7d733a31323a22666f726569676e206b657973223b613a313a7b733a363a22666f726d6174223b613a323a7b733a353a227461626c65223b733a31333a2266696c7465725f666f726d6174223b733a373a22636f6c756d6e73223b613a313a7b733a363a22666f726d6174223b733a363a22666f726d6174223b7d7d7d733a373a22696e6465786573223b613a313a7b733a363a22666f726d6174223b613a313a7b693a303b733a363a22666f726d6174223b7d7d733a323a226964223b733a323a223135223b7d, 1, 0, 0),
(16, 'field_function_example', 'text_long', 'text', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a227472616e736c617461626c65223b733a313a2230223b733a31323a22656e746974795f7479706573223b613a303a7b7d733a383a2273657474696e6773223b613a303a7b7d733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a33333a226669656c645f646174615f6669656c645f66756e6374696f6e5f6578616d706c65223b613a323a7b733a353a2276616c7565223b733a32383a226669656c645f66756e6374696f6e5f6578616d706c655f76616c7565223b733a363a22666f726d6174223b733a32393a226669656c645f66756e6374696f6e5f6578616d706c655f666f726d6174223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a33373a226669656c645f7265766973696f6e5f6669656c645f66756e6374696f6e5f6578616d706c65223b613a323a7b733a353a2276616c7565223b733a32383a226669656c645f66756e6374696f6e5f6578616d706c655f76616c7565223b733a363a22666f726d6174223b733a32393a226669656c645f66756e6374696f6e5f6578616d706c655f666f726d6174223b7d7d7d7d7d733a31323a22666f726569676e206b657973223b613a313a7b733a363a22666f726d6174223b613a323a7b733a353a227461626c65223b733a31333a2266696c7465725f666f726d6174223b733a373a22636f6c756d6e73223b613a313a7b733a363a22666f726d6174223b733a363a22666f726d6174223b7d7d7d733a373a22696e6465786573223b613a313a7b733a363a22666f726d6174223b613a313a7b693a303b733a363a22666f726d6174223b7d7d733a323a226964223b733a323a223136223b7d, -1, 0, 0),
(17, 'field_user_fullname', 'text', 'text', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a227472616e736c617461626c65223b733a313a2230223b733a31323a22656e746974795f7479706573223b613a303a7b7d733a383a2273657474696e6773223b613a313a7b733a31303a226d61785f6c656e677468223b733a333a22323535223b7d733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a33303a226669656c645f646174615f6669656c645f757365725f66756c6c6e616d65223b613a323a7b733a353a2276616c7565223b733a32353a226669656c645f757365725f66756c6c6e616d655f76616c7565223b733a363a22666f726d6174223b733a32363a226669656c645f757365725f66756c6c6e616d655f666f726d6174223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a33343a226669656c645f7265766973696f6e5f6669656c645f757365725f66756c6c6e616d65223b613a323a7b733a353a2276616c7565223b733a32353a226669656c645f757365725f66756c6c6e616d655f76616c7565223b733a363a22666f726d6174223b733a32363a226669656c645f757365725f66756c6c6e616d655f666f726d6174223b7d7d7d7d7d733a31323a22666f726569676e206b657973223b613a313a7b733a363a22666f726d6174223b613a323a7b733a353a227461626c65223b733a31333a2266696c7465725f666f726d6174223b733a373a22636f6c756d6e73223b613a313a7b733a363a22666f726d6174223b733a363a22666f726d6174223b7d7d7d733a373a22696e6465786573223b613a313a7b733a363a22666f726d6174223b613a313a7b693a303b733a363a22666f726d6174223b7d7d733a323a226964223b733a323a223137223b7d, 1, 0, 0),
(18, 'field_user_url', 'link_field', 'link', 1, 'field_sql_storage', 'field_sql_storage', 1, 0, 0x613a373a7b733a31323a227472616e736c617461626c65223b733a313a2230223b733a31323a22656e746974795f7479706573223b613a303a7b7d733a383a2273657474696e6773223b613a363a7b733a31303a2261747472696275746573223b613a333a7b733a363a22746172676574223b733a373a2264656661756c74223b733a353a22636c617373223b733a303a22223b733a333a2272656c223b733a303a22223b7d733a333a2275726c223b693a303b733a353a227469746c65223b733a383a226f7074696f6e616c223b733a31313a227469746c655f76616c7565223b733a303a22223b733a31333a22656e61626c655f746f6b656e73223b693a313b733a373a22646973706c6179223b613a313a7b733a31303a2275726c5f6375746f6666223b693a38303b7d7d733a373a2273746f72616765223b613a353a7b733a343a2274797065223b733a31373a226669656c645f73716c5f73746f72616765223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31373a226669656c645f73716c5f73746f72616765223b733a363a22616374697665223b733a313a2231223b733a373a2264657461696c73223b613a313a7b733a333a2273716c223b613a323a7b733a31383a224649454c445f4c4f41445f43555252454e54223b613a313a7b733a32353a226669656c645f646174615f6669656c645f757365725f75726c223b613a333a7b733a333a2275726c223b733a31383a226669656c645f757365725f75726c5f75726c223b733a353a227469746c65223b733a32303a226669656c645f757365725f75726c5f7469746c65223b733a31303a2261747472696275746573223b733a32353a226669656c645f757365725f75726c5f61747472696275746573223b7d7d733a31393a224649454c445f4c4f41445f5245564953494f4e223b613a313a7b733a32393a226669656c645f7265766973696f6e5f6669656c645f757365725f75726c223b613a333a7b733a333a2275726c223b733a31383a226669656c645f757365725f75726c5f75726c223b733a353a227469746c65223b733a32303a226669656c645f757365725f75726c5f7469746c65223b733a31303a2261747472696275746573223b733a32353a226669656c645f757365725f75726c5f61747472696275746573223b7d7d7d7d7d733a31323a22666f726569676e206b657973223b613a303a7b7d733a373a22696e6465786573223b613a303a7b7d733a323a226964223b733a323a223138223b7d, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `field_config_instance`
--

CREATE TABLE IF NOT EXISTS `field_config_instance` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a field instance',
  `field_id` int(11) NOT NULL COMMENT 'The identifier of the field attached by this instance',
  `field_name` varchar(32) NOT NULL DEFAULT '',
  `entity_type` varchar(32) NOT NULL DEFAULT '',
  `bundle` varchar(128) NOT NULL DEFAULT '',
  `data` longblob NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `field_name_bundle` (`field_name`,`entity_type`,`bundle`),
  KEY `deleted` (`deleted`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `field_config_instance`
--

INSERT INTO `field_config_instance` (`id`, `field_id`, `field_name`, `entity_type`, `bundle`, `data`, `deleted`) VALUES
(1, 1, 'comment_body', 'comment', 'comment_node_page', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a313a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b693a303b7d7d733a353a226c6162656c223b733a373a22436f6d6d656e74223b733a383a227265717569726564223b623a313b733a383a2273657474696e6773223b613a323a7b733a31353a22746578745f70726f63657373696e67223b693a313b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a313a7b733a343a22726f7773223b693a353b7d733a343a2274797065223b733a31333a22746578745f7465787461726561223b733a363a22776569676874223b693a303b7d7d, 0),
(2, 2, 'body', 'node', 'page', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a323a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a2274657874223b7d733a363a22746561736572223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a32333a22746578745f73756d6d6172795f6f725f7472696d6d6564223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a313a7b733a31313a227472696d5f6c656e677468223b693a3630303b7d733a363a226d6f64756c65223b733a343a2274657874223b7d7d733a353a226c6162656c223b733a343a22426f6479223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a333a7b733a31353a22646973706c61795f73756d6d617279223b623a313b733a31353a22746578745f70726f63657373696e67223b693a313b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a323a7b733a343a22726f7773223b693a32303b733a31323a2273756d6d6172795f726f7773223b693a353b7d733a343a2274797065223b733a32363a22746578745f74657874617265615f776974685f73756d6d617279223b733a363a22776569676874223b693a2d343b7d7d, 0),
(3, 1, 'comment_body', 'comment', 'comment_node_article', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a313a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b693a303b7d7d733a353a226c6162656c223b733a373a22436f6d6d656e74223b733a383a227265717569726564223b623a313b733a383a2273657474696e6773223b613a323a7b733a31353a22746578745f70726f63657373696e67223b693a313b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a313a7b733a343a22726f7773223b693a353b7d733a343a2274797065223b733a31333a22746578745f7465787461726561223b733a363a22776569676874223b693a303b7d7d, 0),
(4, 2, 'body', 'node', 'article', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a353a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a2274657874223b7d733a333a22727373223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b733a313a2230223b7d733a31323a227365617263685f696e646578223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b733a313a2230223b7d733a31333a227365617263685f726573756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b733a313a2230223b7d733a363a22746561736572223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a313a7b733a31313a227472696d5f6c656e677468223b693a3630303b7d733a343a2274797065223b733a32333a22746578745f73756d6d6172795f6f725f7472696d6d6564223b733a363a22776569676874223b693a303b7d7d733a353a226c6162656c223b733a343a22426f6479223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a333a7b733a31353a22646973706c61795f73756d6d617279223b623a313b733a31353a22746578745f70726f63657373696e67223b693a313b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a323a7b733a343a22726f7773223b693a32303b733a31323a2273756d6d6172795f726f7773223b693a353b7d733a343a2274797065223b733a32363a22746578745f74657874617265615f776974685f73756d6d617279223b733a363a22776569676874223b693a2d343b7d7d, 0),
(6, 4, 'field_image', 'node', 'article', 0x613a363a7b733a353a226c6162656c223b733a353a22496d616765223b733a31313a226465736372697074696f6e223b733a34303a2255706c6f616420616e20696d61676520746f20676f207769746820746869732061727469636c652e223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a383a7b733a31343a2266696c655f6469726563746f7279223b733a31313a226669656c642f696d616765223b733a31353a2266696c655f657874656e73696f6e73223b733a31363a22706e6720676966206a7067206a706567223b733a31323a226d61785f66696c6573697a65223b733a303a22223b733a31343a226d61785f7265736f6c7574696f6e223b733a303a22223b733a31343a226d696e5f7265736f6c7574696f6e223b733a303a22223b733a393a22616c745f6669656c64223b623a313b733a31313a227469746c655f6669656c64223b733a303a22223b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a343a2274797065223b733a31313a22696d6167655f696d616765223b733a383a2273657474696e6773223b613a323a7b733a31383a2270726f67726573735f696e64696361746f72223b733a383a227468726f62626572223b733a31393a22707265766965775f696d6167655f7374796c65223b733a393a227468756d626e61696c223b7d733a363a22776569676874223b693a2d313b733a363a226d6f64756c65223b733a353a22696d616765223b7d733a373a22646973706c6179223b613a323a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a353a22696d616765223b733a383a2273657474696e6773223b613a323a7b733a31313a22696d6167655f7374796c65223b733a353a226c61726765223b733a31303a22696d6167655f6c696e6b223b733a303a22223b7d733a363a22776569676874223b693a2d313b733a363a226d6f64756c65223b733a353a22696d616765223b7d733a363a22746561736572223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a353a22696d616765223b733a383a2273657474696e6773223b613a323a7b733a31313a22696d6167655f7374796c65223b733a363a226d656469756d223b733a31303a22696d6167655f6c696e6b223b733a373a22636f6e74656e74223b7d733a363a22776569676874223b693a2d313b733a363a226d6f64756c65223b733a353a22696d616765223b7d7d7d, 0),
(7, 1, 'comment_body', 'comment', 'comment_node_function', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a313a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b693a303b7d7d733a353a226c6162656c223b733a373a22436f6d6d656e74223b733a383a227265717569726564223b623a313b733a383a2273657474696e6773223b613a323a7b733a31353a22746578745f70726f63657373696e67223b693a313b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a343a2274657874223b733a383a2273657474696e6773223b613a313a7b733a343a22726f7773223b693a353b7d733a343a2274797065223b733a31333a22746578745f7465787461726561223b733a363a22776569676874223b693a303b7d7d, 0),
(8, 2, 'body', 'node', 'function', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a3131393a2257726974652061206269742061626f757420746869732066756e6374696f6e20686572652e205468697320746578742077696c6c206170706561722062656c6f77207468652066756e6374696f6e20696e666f726d6174696f6e20616e642061626f7665207468652066756e6374696f6e207573616765223b733a373a22646973706c6179223b613a353a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b733a313a2232223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a2274657874223b7d733a333a22727373223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a31323a22746578745f7472696d6d6564223b733a363a22776569676874223b733a313a2231223b733a383a2273657474696e6773223b613a313a7b733a31313a227472696d5f6c656e677468223b733a333a22333030223b7d733a363a226d6f64756c65223b733a343a2274657874223b7d733a31323a227365617263685f696e646578223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b733a313a2231223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a2274657874223b7d733a31333a227365617263685f726573756c74223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a32333a22746578745f73756d6d6172795f6f725f7472696d6d6564223b733a363a22776569676874223b733a313a2231223b733a383a2273657474696e6773223b613a313a7b733a31313a227472696d5f6c656e677468223b733a333a22333030223b7d733a363a226d6f64756c65223b733a343a2274657874223b7d733a363a22746561736572223b613a353a7b733a353a226c6162656c223b733a363a2268696464656e223b733a343a2274797065223b733a32333a22746578745f73756d6d6172795f6f725f7472696d6d6564223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a313a7b733a31313a227472696d5f6c656e677468223b733a333a22333030223b7d733a363a226d6f64756c65223b733a343a2274657874223b7d7d733a353a226c6162656c223b733a343a22426f6479223b733a383a227265717569726564223b693a303b733a383a2273657474696e6773223b613a333a7b733a31353a22746578745f70726f63657373696e67223b733a313a2231223b733a31353a22646973706c61795f73756d6d617279223b693a303b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a353a7b733a363a22776569676874223b733a313a2233223b733a343a2274797065223b733a32363a22746578745f74657874617265615f776974685f73756d6d617279223b733a363a226d6f64756c65223b733a343a2274657874223b733a363a22616374697665223b693a313b733a383a2273657474696e6773223b613a323a7b733a343a22726f7773223b733a313a2234223b733a31323a2273756d6d6172795f726f7773223b693a353b7d7d7d, 0),
(10, 6, 'field_function_docs', 'node', 'function', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a353a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a373a2264656661756c74223b733a363a22776569676874223b733a313a2233223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a226c696e6b223b7d733a333a22727373223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2232223b733a383a2273657474696e6773223b613a303a7b7d7d733a31323a227365617263685f696e646578223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2232223b733a383a2273657474696e6773223b613a303a7b7d7d733a31333a227365617263685f726573756c74223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2232223b733a383a2273657474696e6773223b613a303a7b7d7d733a363a22746561736572223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2236223b733a383a2273657474696e6773223b613a303a7b7d7d7d733a353a226c6162656c223b733a31333a22446f63756d656e746174696f6e223b733a383a227265717569726564223b693a313b733a383a2273657474696e6773223b613a373a7b733a31303a2261747472696275746573223b613a333a7b733a353a22636c617373223b733a303a22223b733a333a2272656c223b733a383a226e6f666f6c6c6f77223b733a363a22746172676574223b733a363a225f626c616e6b223b7d733a373a22646973706c6179223b613a313a7b733a31303a2275726c5f6375746f6666223b733a323a223830223b7d733a31333a22656e61626c655f746f6b656e73223b693a313b733a353a227469746c65223b733a383a227265717569726564223b733a31313a227469746c655f76616c7565223b733a303a22223b733a333a2275726c223b693a303b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a353a7b733a363a22616374697665223b693a303b733a363a226d6f64756c65223b733a343a226c696e6b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a31303a226c696e6b5f6669656c64223b733a363a22776569676874223b733a313a2233223b7d7d, 0),
(11, 7, 'field_function_author', 'node', 'function', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b613a313a7b693a303b613a323a7b733a353a227469746c65223b733a353a2244464f5457223b733a333a2275726c223b733a31363a22687474703a2f2f64666f74772e636f6d223b7d7d733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a353a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a373a2264656661756c74223b733a363a22776569676874223b733a313a2235223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a226c696e6b223b7d733a333a22727373223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2234223b733a383a2273657474696e6773223b613a303a7b7d7d733a31323a227365617263685f696e646578223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2234223b733a383a2273657474696e6773223b613a303a7b7d7d733a31333a227365617263685f726573756c74223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2234223b733a383a2273657474696e6773223b613a303a7b7d7d733a363a22746561736572223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2235223b733a383a2273657474696e6773223b613a303a7b7d7d7d733a353a226c6162656c223b733a31323a225375626d6974746564206279223b733a383a227265717569726564223b693a303b733a383a2273657474696e6773223b613a373a7b733a333a2275726c223b733a383a226f7074696f6e616c223b733a353a227469746c65223b733a383a226f7074696f6e616c223b733a31313a227469746c655f76616c7565223b733a303a22223b733a31333a22656e61626c655f746f6b656e73223b693a313b733a373a22646973706c6179223b613a313a7b733a31303a2275726c5f6375746f6666223b733a323a223830223b7d733a31303a2261747472696275746573223b613a333a7b733a363a22746172676574223b733a363a225f626c616e6b223b733a333a2272656c223b733a363a22666f6c6c6f77223b733a353a22636c617373223b733a303a22223b7d733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a353a7b733a363a22776569676874223b733a313a2231223b733a343a2274797065223b733a31303a226c696e6b5f6669656c64223b733a363a226d6f64756c65223b733a343a226c696e6b223b733a363a22616374697665223b693a303b733a383a2273657474696e6773223b613a303a7b7d7d7d, 0),
(12, 8, 'field_function_tags', 'node', 'function', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a353a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a32383a227461786f6e6f6d795f7465726d5f7265666572656e63655f6c696e6b223b733a363a22776569676874223b733a313a2234223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a383a227461786f6e6f6d79223b7d733a333a22727373223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2233223b733a383a2273657474696e6773223b613a303a7b7d7d733a31323a227365617263685f696e646578223b613a353a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a32383a227461786f6e6f6d795f7465726d5f7265666572656e63655f6c696e6b223b733a363a22776569676874223b733a313a2233223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a383a227461786f6e6f6d79223b7d733a31333a227365617263685f726573756c74223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2233223b733a383a2273657474696e6773223b613a303a7b7d7d733a363a22746561736572223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2232223b733a383a2273657474696e6773223b613a303a7b7d7d7d733a353a226c6162656c223b733a343a2254616773223b733a383a227265717569726564223b693a313b733a383a2273657474696e6773223b613a313a7b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a353a7b733a363a22776569676874223b733a313a2232223b733a343a2274797065223b733a32313a227461786f6e6f6d795f6175746f636f6d706c657465223b733a363a226d6f64756c65223b733a383a227461786f6e6f6d79223b733a363a22616374697665223b693a303b733a383a2273657474696e6773223b613a323a7b733a343a2273697a65223b693a36303b733a31373a226175746f636f6d706c6574655f70617468223b733a32313a227461786f6e6f6d792f6175746f636f6d706c657465223b7d7d7d, 0),
(13, 9, 'field_function_version', 'node', 'function', 0x613a373a7b733a31333a2264656661756c745f76616c7565223b613a313a7b693a303b613a313a7b733a333a22746964223b733a313a2231223b7d7d733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a353a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a32383a227461786f6e6f6d795f7465726d5f7265666572656e63655f6c696e6b223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a383a227461786f6e6f6d79223b7d733a333a22727373223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d7d733a31323a227365617263685f696e646578223b613a353a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a32383a227461786f6e6f6d795f7465726d5f7265666572656e63655f6c696e6b223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a383a227461786f6e6f6d79223b7d733a31333a227365617263685f726573756c74223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d7d733a363a22746561736572223b613a343a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2231223b733a383a2273657474696e6773223b613a303a7b7d7d7d733a353a226c6162656c223b733a373a2256657273696f6e223b733a383a227265717569726564223b693a313b733a383a2273657474696e6773223b613a313a7b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a353a7b733a363a22616374697665223b693a313b733a363a226d6f64756c65223b733a373a226f7074696f6e73223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a31353a226f7074696f6e735f627574746f6e73223b733a363a22776569676874223b733a313a2231223b7d7d, 0),
(14, 10, 'meta_keywords', 'node', 'article', 0x613a383a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a343a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2231223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a333a22727373223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2231223b7d733a31323a227365617263685f696e646578223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2231223b7d733a31333a227365617263685f726573756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2231223b7d7d733a393a22666f726d6174746572223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a353a226c6162656c223b733a383a224b6579776f726473223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a313a7b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32343a226d657461746167735f717569636b5f746578746669656c64223b733a363a22776569676874223b693a303b7d7d, 0),
(15, 10, 'meta_keywords', 'node', 'function', 0x613a383a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a353a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2236223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a333a22727373223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2235223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a31323a227365617263685f696e646578223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2235223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a31333a227365617263685f726573756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2235223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a363a22746561736572223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2234223b733a383a2273657474696e6773223b613a303a7b7d7d7d733a393a22666f726d6174746572223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a353a226c6162656c223b733a383a224b6579776f726473223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a313a7b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32343a226d657461746167735f717569636b5f746578746669656c64223b733a363a22776569676874223b733a313a2231223b7d7d, 0),
(16, 10, 'meta_keywords', 'node', 'page', 0x613a383a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a323a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2231223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a363a22746561736572223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d7d7d733a393a22666f726d6174746572223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a353a226c6162656c223b733a383a224b6579776f726473223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a313a7b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32343a226d657461746167735f717569636b5f746578746669656c64223b733a363a22776569676874223b693a303b7d7d, 0),
(17, 11, 'meta_description', 'node', 'article', 0x613a383a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a343a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2232223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a333a22727373223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2232223b7d733a31323a227365617263685f696e646578223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2232223b7d733a31333a227365617263685f726573756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2232223b7d7d733a393a22666f726d6174746572223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a353a226c6162656c223b733a31313a224465736372697074696f6e223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a313a7b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32333a226d657461746167735f717569636b5f7465787461726561223b733a363a22776569676874223b693a303b7d7d, 0),
(18, 11, 'meta_description', 'node', 'function', 0x613a383a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a353a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2237223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a333a22727373223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2236223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a31323a227365617263685f696e646578223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2236223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a31333a227365617263685f726573756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2236223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a363a22746561736572223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2233223b733a383a2273657474696e6773223b613a303a7b7d7d7d733a393a22666f726d6174746572223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a353a226c6162656c223b733a31313a224465736372697074696f6e223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a313a7b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32333a226d657461746167735f717569636b5f7465787461726561223b733a363a22776569676874223b733a313a2230223b7d7d, 0),
(19, 11, 'meta_description', 'node', 'page', 0x613a383a7b733a31333a2264656661756c745f76616c7565223b4e3b733a31313a226465736372697074696f6e223b733a303a22223b733a373a22646973706c6179223b613a323a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a363a22776569676874223b733a313a2232223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b7d733a363a22746561736572223b613a343a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a363a2268696464656e223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d7d7d733a393a22666f726d6174746572223b733a32323a226d657461746167735f717569636b5f64656661756c74223b733a353a226c6162656c223b733a31313a224465736372697074696f6e223b733a383a227265717569726564223b623a303b733a383a2273657474696e6773223b613a313a7b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a363a22776964676574223b613a343a7b733a363a226d6f64756c65223b733a31343a226d657461746167735f717569636b223b733a383a2273657474696e6773223b613a303a7b7d733a343a2274797065223b733a32333a226d657461746167735f717569636b5f7465787461726561223b733a363a22776569676874223b693a303b7d7d, 0),
(21, 13, 'field_function_intro', 'node', 'function', 0x613a373a7b733a353a226c6162656c223b733a31323a22496e74726f64756374696f6e223b733a363a22776964676574223b613a353a7b733a363a22776569676874223b733a313a2232223b733a343a2274797065223b733a31333a22746578745f7465787461726561223b733a363a226d6f64756c65223b733a343a2274657874223b733a363a22616374697665223b693a313b733a383a2273657474696e6773223b613a313a7b733a343a22726f7773223b733a313a2233223b7d7d733a383a2273657474696e6773223b613a323a7b733a31353a22746578745f70726f63657373696e67223b733a313a2230223b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a373a22646973706c6179223b613a313a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a2274657874223b733a363a22776569676874223b693a393b7d7d733a383a227265717569726564223b693a313b733a31313a226465736372697074696f6e223b733a35393a22412066657720776f72647320746f20696e74726f6475636520746869732066756e6374696f6e20616e642077687920697420697320677265617421223b733a31333a2264656661756c745f76616c7565223b4e3b7d, 0),
(23, 15, 'field_function_desc', 'node', 'function', 0x613a373a7b733a353a226c6162656c223b733a32303a2246756e6374696f6e204465736372697074696f6e223b733a363a22776964676574223b613a353a7b733a363a22776569676874223b733a313a2232223b733a343a2274797065223b733a31333a22746578745f7465787461726561223b733a363a226d6f64756c65223b733a343a2274657874223b733a363a22616374697665223b693a313b733a383a2273657474696e6773223b613a313a7b733a343a22726f7773223b733a313a2233223b7d7d733a383a2273657474696e6773223b613a323a7b733a31353a22746578745f70726f63657373696e67223b733a313a2230223b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a373a22646973706c6179223b613a313a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a2274657874223b733a363a22776569676874223b693a31303b7d7d733a383a227265717569726564223b693a313b733a31313a226465736372697074696f6e223b733a37333a22436f707920616e64207061737465207468652066756e6374696f6e2773206465736372697074696f6e2066726f6d20687474703a2f2f6170692e64727570616c2e6f72672068657265223b733a31333a2264656661756c745f76616c7565223b4e3b7d, 0),
(24, 16, 'field_function_example', 'node', 'function', 0x613a373a7b733a353a226c6162656c223b733a383a224578616d706c6573223b733a363a22776964676574223b613a353a7b733a363a22776569676874223b733a313a2238223b733a343a2274797065223b733a31333a22746578745f7465787461726561223b733a363a226d6f64756c65223b733a343a2274657874223b733a363a22616374697665223b693a313b733a383a2273657474696e6773223b613a313a7b733a343a22726f7773223b733a313a2234223b7d7d733a383a2273657474696e6773223b613a323a7b733a31353a22746578745f70726f63657373696e67223b733a313a2230223b733a31383a22757365725f72656769737465725f666f726d223b623a303b7d733a373a22646973706c6179223b613a313a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a353a2261626f7665223b733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a2274657874223b733a363a22776569676874223b693a31313b7d7d733a383a227265717569726564223b693a303b733a31313a226465736372697074696f6e223b733a3131333a2250726f76696465206120636f75706c65207573616765206578616d706c657320666f72207468652066756e6374696f6e2e20203c7374726f6e673e506c65617365207772617020736f757263652d636f646520696e203c656d3e7072653c2f656d3e2074616773213c2f7374726f6e673e223b733a31333a2264656661756c745f76616c7565223b4e3b7d, 0),
(25, 17, 'field_user_fullname', 'user', 'user', 0x613a373a7b733a353a226c6162656c223b733a393a2246756c6c204e616d65223b733a363a22776964676574223b613a353a7b733a363a22776569676874223b733a313a2231223b733a343a2274797065223b733a31343a22746578745f746578746669656c64223b733a363a226d6f64756c65223b733a343a2274657874223b733a363a22616374697665223b693a313b733a383a2273657474696e6773223b613a313a7b733a343a2273697a65223b733a323a223630223b7d7d733a383a2273657474696e6773223b613a323a7b733a31353a22746578745f70726f63657373696e67223b733a313a2230223b733a31383a22757365725f72656769737465725f666f726d223b693a313b7d733a373a22646973706c6179223b613a313a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a31323a22746578745f64656661756c74223b733a363a22776569676874223b733a313a2230223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a2274657874223b7d7d733a383a227265717569726564223b693a313b733a31313a226465736372697074696f6e223b733a303a22223b733a31333a2264656661756c745f76616c7565223b4e3b7d, 0),
(26, 18, 'field_user_url', 'user', 'user', 0x613a373a7b733a353a226c6162656c223b733a333a2255524c223b733a363a22776964676574223b613a353a7b733a363a22776569676874223b733a313a2232223b733a343a2274797065223b733a31303a226c696e6b5f6669656c64223b733a363a226d6f64756c65223b733a343a226c696e6b223b733a363a22616374697665223b693a303b733a383a2273657474696e6773223b613a303a7b7d7d733a383a2273657474696e6773223b613a373a7b733a333a2275726c223b693a303b733a353a227469746c65223b733a353a2276616c7565223b733a31313a227469746c655f76616c7565223b733a32363a225b757365723a6669656c645f757365725f66756c6c6e616d655d223b733a31333a22656e61626c655f746f6b656e73223b693a313b733a373a22646973706c6179223b613a313a7b733a31303a2275726c5f6375746f6666223b733a323a223830223b7d733a31303a2261747472696275746573223b613a333a7b733a363a22746172676574223b733a363a225f626c616e6b223b733a333a2272656c223b733a363a22666f6c6c6f77223b733a353a22636c617373223b733a303a22223b7d733a31383a22757365725f72656769737465725f666f726d223b693a313b7d733a373a22646973706c6179223b613a313a7b733a373a2264656661756c74223b613a353a7b733a353a226c6162656c223b733a363a22696e6c696e65223b733a343a2274797065223b733a333a2275726c223b733a363a22776569676874223b733a313a2231223b733a383a2273657474696e6773223b613a303a7b7d733a363a226d6f64756c65223b733a343a226c696e6b223b7d7d733a383a227265717569726564223b693a313b733a31313a226465736372697074696f6e223b733a36363a22496e7365727420612055524c206865726520746f206c696e6b20746f207768656e20736f6d656f6e6520636c69636b73206f6e20796f757220757365726e616d652e223b733a31333a2264656661756c745f76616c7565223b4e3b7d, 0);

-- --------------------------------------------------------

--
-- Table structure for table `field_data_body`
--

CREATE TABLE IF NOT EXISTS `field_data_body` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `body_value` longtext,
  `body_summary` longtext,
  `body_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `body_format` (`body_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_body`
--

INSERT INTO `field_data_body` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `body_value`, `body_summary`, `body_format`) VALUES
('node', 'page', 0, 1, 1, 'und', 0, '<p>Despite being seasoned developers, Drupal constantly surprises us at <a href="http://webdrop.net.br" rel="follow" target="_blank">Webdrop</a>. The API is rich and there are so many functions that are so useful and often not that well-known.</p><p>We decided to start this website to share these and other hidden gems with the rest of the community.</p>\r\n\r\n<h2>How it works</h2>\r\n<p>Every week we will (try to) publish a selected Drupal function along with an explanation, usage examples and links to the official documentation.</p>\r\n\r\n<p>Subscribe to our <a href="http://feeds.feedburner.com/dfotw">rss feed</a> and follow us on <a href="http://twitter.com/drfotw">twitter</a> to keep in the loop!</p>\r\n\r\n<h2>Chip in!</h2>\r\n<p>Anyone can submit a function!</p>\r\n<p>Got a function you absolutely love or recently discovered? <a href="/contact">Submit it</a> and tell us why!</p>\r\n\r\n<h2>GitHub</h2>\r\n<p>The entire site''s codebase is now available on GitHub!  You can now file issues, create forks and submit pull requests!\r\n<p><a href="https://github.com/alexweber/DFOTW" target="_blank">DFOTW @ GitHub</a></p>', '<p>Despite being seasoned developers, Drupal constantly surprises us at <a href="http://webdrop.net.br" rel="follow" target="_blank">Webdrop</a>. The API is rich and there are so many functions that are so useful and often not that well-known.</p><p>We decided to start this website to share these and other hidden gems with the rest of the community.</p>', 'full_html'),
('node', 'article', 0, 2, 2, 'und', 0, '<p>Despite being seasoned developers, Drupal constantly surprises us at <a href="http://webdrop.net.br" rel="follow" target="_blank">Webdrop</a>. The API is rich and there are so many functions that are so useful and often not that well-known.</p><p>We decided to start this website to share these and other hidden gems with the rest of the community. Read more at our <a href="/about">about page</a>!</p>', '', 'full_html'),
('node', 'function', 0, 3, 3, 'und', 0, 'This is the classic kind of function that people always end up implementing manually because they didn''t know it was in the API.', 'Verifies the syntax of the given e-mail address.', 'full_html'),
('node', 'function', 0, 4, 4, 'und', 0, 'Here is one that is definitely one of the least well-known functions in the Drupal API and, funnily enough, also one of the most useful ones. Based on a schema it will save or update a record of your choice with zero hand-written SQL, yay!', 'drupal_write_record() is a Drupal function that saves (inserts or updates) a record to the database based upon the schema.', 'full_html'),
('node', 'function', 0, 6, 6, 'und', 0, 'Often when dealing with CCK (Fields) and file uploads we need to quickly grab the filename or path of the uploaded fle. However, in some situations, the only information available in the $node object is the $fid. This function retrieves all the associated information from the database.', '', 'full_html');

-- --------------------------------------------------------

--
-- Table structure for table `field_data_comment_body`
--

CREATE TABLE IF NOT EXISTS `field_data_comment_body` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `comment_body_value` longtext,
  `comment_body_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `comment_body_format` (`comment_body_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_comment_body`
--

INSERT INTO `field_data_comment_body` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `comment_body_value`, `comment_body_format`) VALUES
('comment', 'comment_node_article', 0, 1, 1, 'und', 0, 'Tks for share with us.', 'plain_text'),
('comment', 'comment_node_function', 0, 2, 2, 'und', 0, 'This is how the Email field (cck) validates the email. It would be nice to check if the modules that could make use of this function (comment, contact, signup) make proper use of this function.', 'filtered_html'),
('comment', 'comment_node_function', 0, 3, 3, 'und', 0, 'Good call, after all email validation can be tricky sometimes and its great to have a unified core function that takes care of it!', 'filtered_html'),
('comment', 'comment_node_function', 0, 9, 9, 'und', 0, 'This seems a great finding, earlier this I was unable to use Drupal platform for the reason of database and similar issues, but now it seems I can overcome same problems. Thanks for share and will let you know Once I overcome the issues.\r\n\r\n<a href="http://www.autobidmaster.com">Salvage Cars</a>', 'filtered_html'),
('comment', 'comment_node_function', 0, 10, 10, 'und', 0, 'This is a great way to detect the input of email address is whether correct or not. But I always think about if any incorrect email address has been provided how can a software detect whether it is a legid email address or not.\r\n\r\n<a href="http://www.autobidmaster.com/carfinder-online-auto-auctions/">Salvage Cars</a>', 'filtered_html'),
('comment', 'comment_node_article', 0, 11, 11, 'und', 0, 'Hey that''s great, all this community member will get benefit of this share. Hope there should definitely be some platform where all those community member can share some useful tips and get to learn from others. \r\n\r\n<a href="http://www.autobidmaster.com/howtobuy-copart-auto-auctions/">Car Auctions</a>', 'filtered_html'),
('comment', 'comment_node_function', 0, 12, 12, 'und', 0, 'Update the title theme to highlight the key question - RFC compliance. This is a bug in all versions of Drupal, and even v7 due to a bug in PHP. While it is understandable that one should not expect to correct errors in the underlying language, which is a bug in previous versions and can be solved in all versions with a patch in my humble opinion to consider.\r\n\r\n<a href="http://www.autobidmaster.com/carfinder-online-auto-auctions/salvage-motorcycles/">Salvage Motorcycles</a>', 'filtered_html'),
('comment', 'comment_node_function', 0, 13, 13, 'und', 0, 'Nice explanation of the syntax ', 'plain_text'),
('comment', 'comment_node_function', 0, 14, 14, 'und', 0, 'Do you people have a facebook fan page? I seemed for one on twitter but could not discover one, I would really like to change into a fan! <a href="http://onet.pl">portal</a>', 'filtered_html');

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_function_author`
--

CREATE TABLE IF NOT EXISTS `field_data_field_function_author` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_author_url` varchar(2048) DEFAULT NULL,
  `field_function_author_title` varchar(255) DEFAULT NULL,
  `field_function_author_attributes` mediumtext,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_field_function_author`
--

INSERT INTO `field_data_field_function_author` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_author_url`, `field_function_author_title`, `field_function_author_attributes`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'http://www.alexweber.com.br', 'Alex', 'a:0:{}'),
('node', 'function', 0, 4, 4, 'und', 0, 'http://www.alexweber.com.br', 'Alex', 'a:0:{}'),
('node', 'function', 0, 6, 6, 'und', 0, 'http://nunesweb.com', 'Leandro', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_function_desc`
--

CREATE TABLE IF NOT EXISTS `field_data_field_function_desc` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_desc_value` longtext,
  `field_function_desc_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_desc_format` (`field_function_desc_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Data storage for field 15 (field_function_desc)';

--
-- Dumping data for table `field_data_field_function_desc`
--

INSERT INTO `field_data_field_function_desc` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_desc_value`, `field_function_desc_format`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'Verifies the syntax of the given e-mail address.', NULL),
('node', 'function', 0, 4, 4, 'und', 0, 'Saves (inserts or updates) a record to the database based upon the schema.', NULL),
('node', 'function', 0, 6, 6, 'und', 0, 'Load a file object from the database.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_function_docs`
--

CREATE TABLE IF NOT EXISTS `field_data_field_function_docs` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_docs_url` varchar(2048) DEFAULT NULL,
  `field_function_docs_title` varchar(255) DEFAULT NULL,
  `field_function_docs_attributes` mediumtext,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_field_function_docs`
--

INSERT INTO `field_data_field_function_docs` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_docs_url`, `field_function_docs_title`, `field_function_docs_attributes`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'http://api.drupal.org/api/drupal/includes--common.inc/function/valid_email_address/6', 'Drupal 6', 'a:0:{}'),
('node', 'function', 0, 3, 3, 'und', 1, 'http://api.drupal.org/api/drupal/includes--common.inc/function/valid_email_address', 'Drupal 7', 'a:0:{}'),
('node', 'function', 0, 3, 3, 'und', 2, 'http://api.drupal.org/api/drupal/includes--common.inc/function/valid_email_address/8', 'Drupal 8', 'a:0:{}'),
('node', 'function', 0, 4, 4, 'und', 0, 'http://api.drupal.org/api/drupal/includes--common.inc/function/drupal_write_record/6', 'Drupal 6', 'a:0:{}'),
('node', 'function', 0, 4, 4, 'und', 1, 'http://api.drupal.org/api/drupal/includes--common.inc/function/drupal_write_record', 'Drupal 7', 'a:0:{}'),
('node', 'function', 0, 4, 4, 'und', 2, 'http://api.drupal.org/api/drupal/includes--common.inc/function/drupal_write_record/8', 'Drupal 8', 'a:0:{}'),
('node', 'function', 0, 6, 6, 'und', 0, 'http://api.lullabot.com/field_file_load', 'Drupal 6', 'a:0:{}'),
('node', 'function', 0, 6, 6, 'und', 1, 'http://api.drupal.org/api/drupal/includes--file.inc/function/file_load/7', 'Drupal 7', 'a:0:{}'),
('node', 'function', 0, 6, 6, 'und', 2, 'http://api.drupal.org/api/drupal/includes--file.inc/function/file_load/8', 'Drupal 8', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_function_example`
--

CREATE TABLE IF NOT EXISTS `field_data_field_function_example` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_example_value` longtext,
  `field_function_example_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_example_format` (`field_function_example_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Data storage for field 16 (field_function_example)';

--
-- Dumping data for table `field_data_field_function_example`
--

INSERT INTO `field_data_field_function_example` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_example_value`, `field_function_example_format`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, '<p>The function accepts a single parameter and returns TRUE if the parameter is a valid email address or FALSE otherwise.</p>\r\n\r\n<pre>\r\nif (!valid_mail_address($mail)) {\r\n  form_set_error(''field_email'', t(''Invalid email address!''));\r\n}\r\n</pre>', NULL),
('node', 'function', 0, 4, 4, 'und', 0, '<p>As mentioned, we need a schema:</p>\r\n\r\n<pre>\r\n/**\r\n * Implements hook_schema().\r\n */\r\nfunction my_test_schema() {\r\n  $schema[''my_test''] = array(\r\n    ''fields'' => array(\r\n      ''id'' => array(\r\n        ''description'' => ''Primary key.'',\r\n        ''type'' => ''serial'',\r\n      ),\r\n      ''description'' => array(\r\n        ''description'' => ''Description'',\r\n        ''type'' => ''varchar'',\r\n        ''length'' => 255,\r\n        ''not null'' => TRUE,\r\n        ''default'' => '''',\r\n      ),\r\n    ),\r\n    ''primary key'' => array(''id''),\r\n  );\r\n  return $schema;\r\n}\r\n</pre>', NULL),
('node', 'function', 0, 4, 4, 'und', 1, '<p>Now, with the above schema, we can easily insert and update rows in the database:</p>\r\n\r\n<pre>\r\n// insert a new row\r\n$object = new stdClass();\r\n$object->description = ''foo'';\r\n$object->tag = ''bar''; // note that extra attributes are ignored\r\ndrupal_write_record(''my_test'', $object);\r\n\r\n// to update a row, pass the PK as the 3rd parameter\r\ndrupal_write_record(''my_test'', $object, ''id);\r\n</pre>\r\n\r\n<p>Despite the change in variable names, the Drupal 7 & 8 versions are identical to the Drupal 6 version in functionality!</p>', NULL),
('node', 'function', 0, 6, 6, 'und', 0, '<pre>\r\n$fid = $node->field_my_field_name[0][''fid''];\r\n$file = field_file_load($fid);\r\n$filename = $file[''filepath''];\r\n</pre>', NULL),
('node', 'function', 0, 6, 6, 'und', 1, '<p>In Drupal 7 & 8, the function was moved from contrib to core and changed name and return type, the rest is the same:</p>\r\n\r\n<pre>\r\n$file = file_load($fid);\r\n$filename = $file->filepath; // notice its a stdClass\r\n</pre>', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_function_intro`
--

CREATE TABLE IF NOT EXISTS `field_data_field_function_intro` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_intro_value` longtext,
  `field_function_intro_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_intro_format` (`field_function_intro_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Data storage for field 13 (field_function_intro)';

--
-- Dumping data for table `field_data_field_function_intro`
--

INSERT INTO `field_data_field_function_intro` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_intro_value`, `field_function_intro_format`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'It doesn''t get any simpler than this, valid_mail_address() does exactly what you would expect!', NULL),
('node', 'function', 0, 4, 4, 'und', 0, 'Who''s tired of writing SQL manually in Drupal? This function helps ease the pain...', NULL),
('node', 'function', 0, 6, 6, 'und', 0, 'Ever needed to grab the filepath of from a filefield from a node object?', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_function_tags`
--

CREATE TABLE IF NOT EXISTS `field_data_field_function_tags` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_tags_tid` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_tags_tid` (`field_function_tags_tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_field_function_tags`
--

INSERT INTO `field_data_field_function_tags` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_tags_tid`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 3),
('node', 'function', 0, 4, 4, 'und', 0, 5),
('node', 'function', 0, 4, 4, 'und', 1, 6),
('node', 'function', 0, 6, 6, 'und', 0, 9),
('node', 'function', 0, 6, 6, 'und', 1, 10),
('node', 'function', 0, 6, 6, 'und', 2, 11);

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_function_version`
--

CREATE TABLE IF NOT EXISTS `field_data_field_function_version` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_version_tid` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_version_tid` (`field_function_version_tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_field_function_version`
--

INSERT INTO `field_data_field_function_version` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_version_tid`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 1),
('node', 'function', 0, 3, 3, 'und', 1, 2),
('node', 'function', 0, 3, 3, 'und', 2, 4),
('node', 'function', 0, 4, 4, 'und', 0, 1),
('node', 'function', 0, 4, 4, 'und', 1, 2),
('node', 'function', 0, 4, 4, 'und', 2, 4),
('node', 'function', 0, 6, 6, 'und', 0, 1),
('node', 'function', 0, 6, 6, 'und', 1, 2),
('node', 'function', 0, 6, 6, 'und', 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_image`
--

CREATE TABLE IF NOT EXISTS `field_data_field_image` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_image_fid` int(10) unsigned DEFAULT NULL COMMENT 'The file_managed.fid being referenced in this field.',
  `field_image_alt` varchar(128) DEFAULT NULL COMMENT 'Alternative image text, for the image’s ’alt’ attribute.',
  `field_image_title` varchar(128) DEFAULT NULL COMMENT 'Image title text, for the image’s ’title’ attribute.',
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_image_fid` (`field_image_fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_field_image`
--


-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_user_fullname`
--

CREATE TABLE IF NOT EXISTS `field_data_field_user_fullname` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_user_fullname_value` varchar(255) DEFAULT NULL,
  `field_user_fullname_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_user_fullname_format` (`field_user_fullname_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Data storage for field 17 (field_user_fullname)';

--
-- Dumping data for table `field_data_field_user_fullname`
--

INSERT INTO `field_data_field_user_fullname` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_user_fullname_value`, `field_user_fullname_format`) VALUES
('user', 'user', 0, 1, 1, 'und', 0, 'DFOTW', NULL),
('user', 'user', 0, 10, 10, 'und', 0, 'Alex Weber', NULL),
('user', 'user', 0, 11, 11, 'und', 0, 'Leandro Nunes', NULL),
('user', 'user', 0, 12, 12, 'und', 0, 'Miguel Trindade', NULL),
('user', 'user', 0, 13, 13, 'und', 0, 'João Otávio Gallo', NULL),
('user', 'user', 0, 14, 14, 'und', 0, 'Capi Etheriel', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `field_data_field_user_url`
--

CREATE TABLE IF NOT EXISTS `field_data_field_user_url` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_user_url_url` varchar(2048) DEFAULT NULL,
  `field_user_url_title` varchar(255) DEFAULT NULL,
  `field_user_url_attributes` mediumtext,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Data storage for field 18 (field_user_url)';

--
-- Dumping data for table `field_data_field_user_url`
--

INSERT INTO `field_data_field_user_url` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_user_url_url`, `field_user_url_title`, `field_user_url_attributes`) VALUES
('user', 'user', 0, 1, 1, 'und', 0, 'http://dfotw.com', NULL, 'a:0:{}'),
('user', 'user', 0, 10, 10, 'und', 0, 'http://www.alexweber.com.br', NULL, 'a:0:{}'),
('user', 'user', 0, 11, 11, 'und', 0, 'http://nunesweb.com', NULL, 'a:0:{}'),
('user', 'user', 0, 12, 12, 'und', 0, 'http://migueltrindade.com.br', NULL, 'a:0:{}'),
('user', 'user', 0, 13, 13, 'und', 0, 'http://twitter.com/jotagallo', NULL, 'a:0:{}'),
('user', 'user', 0, 14, 14, 'und', 0, 'http://twitter.com/barraponto', NULL, 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `field_data_meta_description`
--

CREATE TABLE IF NOT EXISTS `field_data_meta_description` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `meta_description_metatags_quick` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_meta_description`
--

INSERT INTO `field_data_meta_description` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `meta_description_metatags_quick`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'Verifies the syntax of the given e-mail address.'),
('node', 'function', 0, 4, 4, 'und', 0, 'drupal_write_record() is a Drupal function that saves (inserts or updates) a record to the database based upon the schema.'),
('node', 'function', 0, 6, 6, 'und', 0, 'Drupal function to load a file object from the database.');

-- --------------------------------------------------------

--
-- Table structure for table `field_data_meta_keywords`
--

CREATE TABLE IF NOT EXISTS `field_data_meta_keywords` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned DEFAULT NULL COMMENT 'The entity revision id this data is attached to, or NULL if the entity type is not versioned',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `meta_keywords_metatags_quick` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_data_meta_keywords`
--

INSERT INTO `field_data_meta_keywords` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `meta_keywords_metatags_quick`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'drupal, mail, validation'),
('node', 'function', 0, 4, 4, 'und', 0, 'database, schema'),
('node', 'function', 0, 6, 6, 'und', 0, 'filefield, contrib, upload');

-- --------------------------------------------------------

--
-- Table structure for table `field_group`
--

CREATE TABLE IF NOT EXISTS `field_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a group',
  `identifier` varchar(255) NOT NULL DEFAULT '' COMMENT 'The unique string identifier for a group.',
  `group_name` varchar(32) NOT NULL DEFAULT '' COMMENT 'The name of this group.',
  `entity_type` varchar(32) NOT NULL DEFAULT '',
  `bundle` varchar(128) NOT NULL DEFAULT '',
  `mode` varchar(128) NOT NULL DEFAULT '',
  `parent_name` varchar(32) NOT NULL DEFAULT '' COMMENT 'The parent name for a group',
  `data` longblob NOT NULL COMMENT 'Serialized data containing the group properties that do not warrant a dedicated column.',
  PRIMARY KEY (`id`),
  KEY `group_name` (`group_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Table that contains field group entries and settings.' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `field_group`
--

INSERT INTO `field_group` (`id`, `identifier`, `group_name`, `entity_type`, `bundle`, `mode`, `parent_name`, `data`) VALUES
(1, 'group_function_meta|node|function|form', 'group_function_meta', 'node', 'function', 'form', '', 0x613a353a7b733a353a226c6162656c223b733a393a224d6574612054616773223b733a363a22776569676874223b733a313a2236223b733a383a226368696c6472656e223b613a323a7b693a303b733a31333a226d6574615f6b6579776f726473223b693a313b733a31363a226d6574615f6465736372697074696f6e223b7d733a31313a22666f726d61745f74797065223b733a333a22746162223b733a31353a22666f726d61745f73657474696e6773223b613a323a7b733a393a22666f726d6174746572223b733a363a22636c6f736564223b733a31373a22696e7374616e63655f73657474696e6773223b613a323a7b733a373a22636c6173736573223b733a303a22223b733a31353a2272657175697265645f6669656c6473223b693a313b7d7d7d),
(2, 'group_function_info|node|function|form', 'group_function_info', 'node', 'function', 'form', '', 0x613a353a7b733a353a226c6162656c223b733a32303a2246756e6374696f6e20496e666f726d6174696f6e223b733a363a22776569676874223b733a313a2234223b733a383a226368696c6472656e223b613a333a7b693a303b733a31393a226669656c645f66756e6374696f6e5f646f6373223b693a313b733a32323a226669656c645f66756e6374696f6e5f76657273696f6e223b693a323b733a31393a226669656c645f66756e6374696f6e5f64657363223b7d733a31313a22666f726d61745f74797065223b733a333a22746162223b733a31353a22666f726d61745f73657474696e6773223b613a323a7b733a393a22666f726d6174746572223b733a363a22636c6f736564223b733a31373a22696e7374616e63655f73657474696e6773223b613a323a7b733a373a22636c6173736573223b733a303a22223b733a31353a2272657175697265645f6669656c6473223b693a313b7d7d7d),
(3, 'group_function_layout|node|function|form', 'group_function_layout', 'node', 'function', 'form', '', 0x613a353a7b733a353a226c6162656c223b733a31313a2250616765204c61796f7574223b733a363a22776569676874223b733a313a2233223b733a383a226368696c6472656e223b613a323a7b693a303b733a343a22626f6479223b693a313b733a32303a226669656c645f66756e6374696f6e5f696e74726f223b7d733a31313a22666f726d61745f74797065223b733a333a22746162223b733a31353a22666f726d61745f73657474696e6773223b613a323a7b733a393a22666f726d6174746572223b733a363a22636c6f736564223b733a31373a22696e7374616e63655f73657474696e6773223b613a323a7b733a373a22636c6173736573223b733a303a22223b733a31353a2272657175697265645f6669656c6473223b693a313b7d7d7d),
(4, 'group_function_usage|node|function|form', 'group_function_usage', 'node', 'function', 'form', '', 0x613a353a7b733a353a226c6162656c223b733a31343a2246756e6374696f6e205573616765223b733a363a22776569676874223b733a313a2235223b733a383a226368696c6472656e223b613a313a7b693a303b733a32323a226669656c645f66756e6374696f6e5f6578616d706c65223b7d733a31313a22666f726d61745f74797065223b733a333a22746162223b733a31353a22666f726d61745f73657474696e6773223b613a333a7b733a353a226c6162656c223b733a31343a2246756e6374696f6e205573616765223b733a31373a22696e7374616e63655f73657474696e6773223b613a333a7b733a31353a2272657175697265645f6669656c6473223b693a303b733a373a22636c6173736573223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b7d733a393a22666f726d6174746572223b733a363a22636c6f736564223b7d7d);

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_body`
--

CREATE TABLE IF NOT EXISTS `field_revision_body` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `body_value` longtext,
  `body_summary` longtext,
  `body_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `body_format` (`body_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_body`
--

INSERT INTO `field_revision_body` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `body_value`, `body_summary`, `body_format`) VALUES
('node', 'page', 0, 1, 1, 'und', 0, '<p>Despite being seasoned developers, Drupal constantly surprises us at <a href="http://webdrop.net.br" rel="follow" target="_blank">Webdrop</a>. The API is rich and there are so many functions that are so useful and often not that well-known.</p><p>We decided to start this website to share these and other hidden gems with the rest of the community.</p>\r\n\r\n<h2>How it works</h2>\r\n<p>Every week we will (try to) publish a selected Drupal function along with an explanation, usage examples and links to the official documentation.</p>\r\n\r\n<p>Subscribe to our <a href="http://feeds.feedburner.com/dfotw">rss feed</a> and follow us on <a href="http://twitter.com/drfotw">twitter</a> to keep in the loop!</p>\r\n\r\n<h2>Chip in!</h2>\r\n<p>Anyone can submit a function!</p>\r\n<p>Got a function you absolutely love or recently discovered? <a href="/contact">Submit it</a> and tell us why!</p>\r\n\r\n<h2>GitHub</h2>\r\n<p>The entire site''s codebase is now available on GitHub!  You can now file issues, create forks and submit pull requests!\r\n<p><a href="https://github.com/alexweber/DFOTW" target="_blank">DFOTW @ GitHub</a></p>', '<p>Despite being seasoned developers, Drupal constantly surprises us at <a href="http://webdrop.net.br" rel="follow" target="_blank">Webdrop</a>. The API is rich and there are so many functions that are so useful and often not that well-known.</p><p>We decided to start this website to share these and other hidden gems with the rest of the community.</p>', 'full_html'),
('node', 'article', 0, 2, 2, 'und', 0, '<p>Despite being seasoned developers, Drupal constantly surprises us at <a href="http://webdrop.net.br" rel="follow" target="_blank">Webdrop</a>. The API is rich and there are so many functions that are so useful and often not that well-known.</p><p>We decided to start this website to share these and other hidden gems with the rest of the community. Read more at our <a href="/about">about page</a>!</p>', '', 'full_html'),
('node', 'function', 0, 3, 3, 'und', 0, 'This is the classic kind of function that people always end up implementing manually because they didn''t know it was in the API.', 'Verifies the syntax of the given e-mail address.', 'full_html'),
('node', 'function', 0, 4, 4, 'und', 0, 'Here is one that is definitely one of the least well-known functions in the Drupal API and, funnily enough, also one of the most useful ones. Based on a schema it will save or update a record of your choice with zero hand-written SQL, yay!', 'drupal_write_record() is a Drupal function that saves (inserts or updates) a record to the database based upon the schema.', 'full_html'),
('node', 'function', 0, 6, 6, 'und', 0, 'Often when dealing with CCK (Fields) and file uploads we need to quickly grab the filename or path of the uploaded fle. However, in some situations, the only information available in the $node object is the $fid. This function retrieves all the associated information from the database.', '', 'full_html');

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_comment_body`
--

CREATE TABLE IF NOT EXISTS `field_revision_comment_body` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `comment_body_value` longtext,
  `comment_body_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `comment_body_format` (`comment_body_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_comment_body`
--

INSERT INTO `field_revision_comment_body` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `comment_body_value`, `comment_body_format`) VALUES
('comment', 'comment_node_article', 0, 1, 1, 'und', 0, 'Tks for share with us.', 'plain_text'),
('comment', 'comment_node_function', 0, 2, 2, 'und', 0, 'This is how the Email field (cck) validates the email. It would be nice to check if the modules that could make use of this function (comment, contact, signup) make proper use of this function.', 'filtered_html'),
('comment', 'comment_node_function', 0, 3, 3, 'und', 0, 'Good call, after all email validation can be tricky sometimes and its great to have a unified core function that takes care of it!', 'filtered_html'),
('comment', 'comment_node_function', 0, 9, 9, 'und', 0, 'This seems a great finding, earlier this I was unable to use Drupal platform for the reason of database and similar issues, but now it seems I can overcome same problems. Thanks for share and will let you know Once I overcome the issues.\r\n\r\n<a href="http://www.autobidmaster.com">Salvage Cars</a>', 'filtered_html'),
('comment', 'comment_node_function', 0, 10, 10, 'und', 0, 'This is a great way to detect the input of email address is whether correct or not. But I always think about if any incorrect email address has been provided how can a software detect whether it is a legid email address or not.\r\n\r\n<a href="http://www.autobidmaster.com/carfinder-online-auto-auctions/">Salvage Cars</a>', 'filtered_html'),
('comment', 'comment_node_article', 0, 11, 11, 'und', 0, 'Hey that''s great, all this community member will get benefit of this share. Hope there should definitely be some platform where all those community member can share some useful tips and get to learn from others. \r\n\r\n<a href="http://www.autobidmaster.com/howtobuy-copart-auto-auctions/">Car Auctions</a>', 'filtered_html'),
('comment', 'comment_node_function', 0, 12, 12, 'und', 0, 'Update the title theme to highlight the key question - RFC compliance. This is a bug in all versions of Drupal, and even v7 due to a bug in PHP. While it is understandable that one should not expect to correct errors in the underlying language, which is a bug in previous versions and can be solved in all versions with a patch in my humble opinion to consider.\r\n\r\n<a href="http://www.autobidmaster.com/carfinder-online-auto-auctions/salvage-motorcycles/">Salvage Motorcycles</a>', 'filtered_html'),
('comment', 'comment_node_function', 0, 13, 13, 'und', 0, 'Nice explanation of the syntax ', 'plain_text'),
('comment', 'comment_node_function', 0, 14, 14, 'und', 0, 'Do you people have a facebook fan page? I seemed for one on twitter but could not discover one, I would really like to change into a fan! <a href="http://onet.pl">portal</a>', 'filtered_html');

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_function_author`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_function_author` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_author_url` varchar(2048) DEFAULT NULL,
  `field_function_author_title` varchar(255) DEFAULT NULL,
  `field_function_author_attributes` mediumtext,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_field_function_author`
--

INSERT INTO `field_revision_field_function_author` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_author_url`, `field_function_author_title`, `field_function_author_attributes`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'http://www.alexweber.com.br', 'Alex', 'a:0:{}'),
('node', 'function', 0, 4, 4, 'und', 0, 'http://www.alexweber.com.br', 'Alex', 'a:0:{}'),
('node', 'function', 0, 6, 6, 'und', 0, 'http://nunesweb.com', 'Leandro', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_function_desc`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_function_desc` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_desc_value` longtext,
  `field_function_desc_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_desc_format` (`field_function_desc_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Revision archive storage for field 15 (field_function_desc)';

--
-- Dumping data for table `field_revision_field_function_desc`
--

INSERT INTO `field_revision_field_function_desc` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_desc_value`, `field_function_desc_format`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'Verifies the syntax of the given e-mail address.', NULL),
('node', 'function', 0, 4, 4, 'und', 0, 'Saves (inserts or updates) a record to the database based upon the schema.', NULL),
('node', 'function', 0, 6, 6, 'und', 0, 'Load a file object from the database.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_function_docs`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_function_docs` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_docs_url` varchar(2048) DEFAULT NULL,
  `field_function_docs_title` varchar(255) DEFAULT NULL,
  `field_function_docs_attributes` mediumtext,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_field_function_docs`
--

INSERT INTO `field_revision_field_function_docs` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_docs_url`, `field_function_docs_title`, `field_function_docs_attributes`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'http://api.drupal.org/api/drupal/includes--common.inc/function/valid_email_address/6', 'Drupal 6', 'a:0:{}'),
('node', 'function', 0, 3, 3, 'und', 1, 'http://api.drupal.org/api/drupal/includes--common.inc/function/valid_email_address', 'Drupal 7', 'a:0:{}'),
('node', 'function', 0, 3, 3, 'und', 2, 'http://api.drupal.org/api/drupal/includes--common.inc/function/valid_email_address/8', 'Drupal 8', 'a:0:{}'),
('node', 'function', 0, 4, 4, 'und', 0, 'http://api.drupal.org/api/drupal/includes--common.inc/function/drupal_write_record/6', 'Drupal 6', 'a:0:{}'),
('node', 'function', 0, 4, 4, 'und', 1, 'http://api.drupal.org/api/drupal/includes--common.inc/function/drupal_write_record', 'Drupal 7', 'a:0:{}'),
('node', 'function', 0, 4, 4, 'und', 2, 'http://api.drupal.org/api/drupal/includes--common.inc/function/drupal_write_record/8', 'Drupal 8', 'a:0:{}'),
('node', 'function', 0, 6, 6, 'und', 0, 'http://api.lullabot.com/field_file_load', 'Drupal 6', 'a:0:{}'),
('node', 'function', 0, 6, 6, 'und', 1, 'http://api.drupal.org/api/drupal/includes--file.inc/function/file_load/7', 'Drupal 7', 'a:0:{}'),
('node', 'function', 0, 6, 6, 'und', 2, 'http://api.drupal.org/api/drupal/includes--file.inc/function/file_load/8', 'Drupal 8', 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_function_example`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_function_example` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_example_value` longtext,
  `field_function_example_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_example_format` (`field_function_example_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Revision archive storage for field 16 (field_function...';

--
-- Dumping data for table `field_revision_field_function_example`
--

INSERT INTO `field_revision_field_function_example` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_example_value`, `field_function_example_format`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, '<p>The function accepts a single parameter and returns TRUE if the parameter is a valid email address or FALSE otherwise.</p>\r\n\r\n<pre>\r\nif (!valid_mail_address($mail)) {\r\n  form_set_error(''field_email'', t(''Invalid email address!''));\r\n}\r\n</pre>', NULL),
('node', 'function', 0, 4, 4, 'und', 0, '<p>As mentioned, we need a schema:</p>\r\n\r\n<pre>\r\n/**\r\n * Implements hook_schema().\r\n */\r\nfunction my_test_schema() {\r\n  $schema[''my_test''] = array(\r\n    ''fields'' => array(\r\n      ''id'' => array(\r\n        ''description'' => ''Primary key.'',\r\n        ''type'' => ''serial'',\r\n      ),\r\n      ''description'' => array(\r\n        ''description'' => ''Description'',\r\n        ''type'' => ''varchar'',\r\n        ''length'' => 255,\r\n        ''not null'' => TRUE,\r\n        ''default'' => '''',\r\n      ),\r\n    ),\r\n    ''primary key'' => array(''id''),\r\n  );\r\n  return $schema;\r\n}\r\n</pre>', NULL),
('node', 'function', 0, 4, 4, 'und', 1, '<p>Now, with the above schema, we can easily insert and update rows in the database:</p>\r\n\r\n<pre>\r\n// insert a new row\r\n$object = new stdClass();\r\n$object->description = ''foo'';\r\n$object->tag = ''bar''; // note that extra attributes are ignored\r\ndrupal_write_record(''my_test'', $object);\r\n\r\n// to update a row, pass the PK as the 3rd parameter\r\ndrupal_write_record(''my_test'', $object, ''id);\r\n</pre>\r\n\r\n<p>Despite the change in variable names, the Drupal 7 & 8 versions are identical to the Drupal 6 version in functionality!</p>', NULL),
('node', 'function', 0, 6, 6, 'und', 0, '<pre>\r\n$fid = $node->field_my_field_name[0][''fid''];\r\n$file = field_file_load($fid);\r\n$filename = $file[''filepath''];\r\n</pre>', NULL),
('node', 'function', 0, 6, 6, 'und', 1, '<p>In Drupal 7 & 8, the function was moved from contrib to core and changed name and return type, the rest is the same:</p>\r\n\r\n<pre>\r\n$file = file_load($fid);\r\n$filename = $file->filepath; // notice its a stdClass\r\n</pre>', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_function_intro`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_function_intro` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_intro_value` longtext,
  `field_function_intro_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_intro_format` (`field_function_intro_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Revision archive storage for field 13 (field_function_intro)';

--
-- Dumping data for table `field_revision_field_function_intro`
--

INSERT INTO `field_revision_field_function_intro` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_intro_value`, `field_function_intro_format`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'It doesn''t get any simpler than this, valid_mail_address() does exactly what you would expect!', NULL),
('node', 'function', 0, 4, 4, 'und', 0, 'Who''s tired of writing SQL manually in Drupal? This function helps ease the pain...', NULL),
('node', 'function', 0, 6, 6, 'und', 0, 'Ever needed to grab the filepath of from a filefield from a node object?', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_function_tags`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_function_tags` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_tags_tid` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_tags_tid` (`field_function_tags_tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_field_function_tags`
--

INSERT INTO `field_revision_field_function_tags` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_tags_tid`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 3),
('node', 'function', 0, 4, 4, 'und', 0, 5),
('node', 'function', 0, 4, 4, 'und', 1, 6),
('node', 'function', 0, 6, 6, 'und', 0, 9),
('node', 'function', 0, 6, 6, 'und', 1, 10),
('node', 'function', 0, 6, 6, 'und', 2, 11);

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_function_version`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_function_version` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_function_version_tid` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_function_version_tid` (`field_function_version_tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_field_function_version`
--

INSERT INTO `field_revision_field_function_version` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_function_version_tid`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 1),
('node', 'function', 0, 3, 3, 'und', 1, 2),
('node', 'function', 0, 3, 3, 'und', 2, 4),
('node', 'function', 0, 4, 4, 'und', 0, 1),
('node', 'function', 0, 4, 4, 'und', 1, 2),
('node', 'function', 0, 4, 4, 'und', 2, 4),
('node', 'function', 0, 6, 6, 'und', 0, 1),
('node', 'function', 0, 6, 6, 'und', 1, 2),
('node', 'function', 0, 6, 6, 'und', 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_image`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_image` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_image_fid` int(10) unsigned DEFAULT NULL COMMENT 'The file_managed.fid being referenced in this field.',
  `field_image_alt` varchar(128) DEFAULT NULL COMMENT 'Alternative image text, for the image’s ’alt’ attribute.',
  `field_image_title` varchar(128) DEFAULT NULL COMMENT 'Image title text, for the image’s ’title’ attribute.',
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_image_fid` (`field_image_fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_field_image`
--


-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_user_fullname`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_user_fullname` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_user_fullname_value` varchar(255) DEFAULT NULL,
  `field_user_fullname_format` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`),
  KEY `field_user_fullname_format` (`field_user_fullname_format`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Revision archive storage for field 17 (field_user_fullname)';

--
-- Dumping data for table `field_revision_field_user_fullname`
--

INSERT INTO `field_revision_field_user_fullname` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_user_fullname_value`, `field_user_fullname_format`) VALUES
('user', 'user', 0, 1, 1, 'und', 0, 'DFOTW', NULL),
('user', 'user', 0, 10, 10, 'und', 0, 'Alex Weber', NULL),
('user', 'user', 0, 11, 11, 'und', 0, 'Leandro Nunes', NULL),
('user', 'user', 0, 12, 12, 'und', 0, 'Miguel Trindade', NULL),
('user', 'user', 0, 13, 13, 'und', 0, 'João Otávio Gallo', NULL),
('user', 'user', 0, 14, 14, 'und', 0, 'Capi Etheriel', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_field_user_url`
--

CREATE TABLE IF NOT EXISTS `field_revision_field_user_url` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `field_user_url_url` varchar(2048) DEFAULT NULL,
  `field_user_url_title` varchar(255) DEFAULT NULL,
  `field_user_url_attributes` mediumtext,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Revision archive storage for field 18 (field_user_url)';

--
-- Dumping data for table `field_revision_field_user_url`
--

INSERT INTO `field_revision_field_user_url` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `field_user_url_url`, `field_user_url_title`, `field_user_url_attributes`) VALUES
('user', 'user', 0, 1, 1, 'und', 0, 'http://dfotw.com', NULL, 'a:0:{}'),
('user', 'user', 0, 10, 10, 'und', 0, 'http://www.alexweber.com.br', NULL, 'a:0:{}'),
('user', 'user', 0, 11, 11, 'und', 0, 'http://nunesweb.com', NULL, 'a:0:{}'),
('user', 'user', 0, 12, 12, 'und', 0, 'http://migueltrindade.com.br', NULL, 'a:0:{}'),
('user', 'user', 0, 13, 13, 'und', 0, 'http://twitter.com/jotagallo', NULL, 'a:0:{}'),
('user', 'user', 0, 14, 14, 'und', 0, 'http://twitter.com/barraponto', NULL, 'a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_meta_description`
--

CREATE TABLE IF NOT EXISTS `field_revision_meta_description` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `meta_description_metatags_quick` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_meta_description`
--

INSERT INTO `field_revision_meta_description` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `meta_description_metatags_quick`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'Verifies the syntax of the given e-mail address.'),
('node', 'function', 0, 4, 4, 'und', 0, 'drupal_write_record() is a Drupal function that saves (inserts or updates) a record to the database based upon the schema.'),
('node', 'function', 0, 6, 6, 'und', 0, 'Drupal function to load a file object from the database.');

-- --------------------------------------------------------

--
-- Table structure for table `field_revision_meta_keywords`
--

CREATE TABLE IF NOT EXISTS `field_revision_meta_keywords` (
  `entity_type` varchar(128) NOT NULL DEFAULT '' COMMENT 'The entity type this data is attached to',
  `bundle` varchar(128) NOT NULL DEFAULT '' COMMENT 'The field instance bundle to which this row belongs, used when deleting a field instance',
  `deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this data item has been deleted',
  `entity_id` int(10) unsigned NOT NULL COMMENT 'The entity id this data is attached to',
  `revision_id` int(10) unsigned NOT NULL COMMENT 'The entity revision id this data is attached to',
  `language` varchar(32) NOT NULL DEFAULT '' COMMENT 'The language for this data item.',
  `delta` int(10) unsigned NOT NULL COMMENT 'The sequence number for this data item, used for multi-value fields',
  `meta_keywords_metatags_quick` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`entity_type`,`entity_id`,`revision_id`,`deleted`,`delta`,`language`),
  KEY `entity_type` (`entity_type`),
  KEY `bundle` (`bundle`),
  KEY `deleted` (`deleted`),
  KEY `entity_id` (`entity_id`),
  KEY `revision_id` (`revision_id`),
  KEY `language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `field_revision_meta_keywords`
--

INSERT INTO `field_revision_meta_keywords` (`entity_type`, `bundle`, `deleted`, `entity_id`, `revision_id`, `language`, `delta`, `meta_keywords_metatags_quick`) VALUES
('node', 'function', 0, 3, 3, 'und', 0, 'drupal, mail, validation'),
('node', 'function', 0, 4, 4, 'und', 0, 'database, schema'),
('node', 'function', 0, 6, 6, 'und', 0, 'filefield, contrib, upload');

-- --------------------------------------------------------

--
-- Table structure for table `file_managed`
--

CREATE TABLE IF NOT EXISTS `file_managed` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'File ID.',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The users.uid of the user who is associated with the file.',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT 'Name of the file with no path components. This may differ from the basename of the URI if the file is renamed to avoid overwriting an existing file.',
  `uri` varchar(255) NOT NULL DEFAULT '' COMMENT 'The URI to access the file (either local or remote).',
  `filemime` varchar(255) NOT NULL DEFAULT '' COMMENT 'The file’s MIME type.',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The size of the file in bytes.',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A field indicating the status of the file. Two status are defined in core: temporary (0) and permanent (1). Temporary files older than DRUPAL_MAXIMUM_TEMP_FILE_AGE will be removed during a cron run.',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'UNIX timestamp for when the file was added.',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `uri` (`uri`),
  KEY `uid` (`uid`),
  KEY `status` (`status`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `file_managed`
--

INSERT INTO `file_managed` (`fid`, `uid`, `filename`, `uri`, `filemime`, `filesize`, `status`, `timestamp`) VALUES
(1, 1, 'picture-10-1315423290.jpg', 'public://pictures/picture-10-1315423290.jpg', 'image/jpeg', 4776, 1, 1315423290),
(2, 1, 'picture-1-1315423315.png', 'public://pictures/picture-1-1315423315.png', 'image/png', 4012, 1, 1315423315);

-- --------------------------------------------------------

--
-- Table structure for table `file_usage`
--

CREATE TABLE IF NOT EXISTS `file_usage` (
  `fid` int(10) unsigned NOT NULL COMMENT 'File ID.',
  `module` varchar(255) NOT NULL DEFAULT '' COMMENT 'The name of the module that is using the file.',
  `type` varchar(64) NOT NULL DEFAULT '' COMMENT 'The name of the object type in which the file is used.',
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The primary key of the object using the file.',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The number of times this file is used by this object.',
  PRIMARY KEY (`fid`,`type`,`id`,`module`),
  KEY `type_id` (`type`,`id`),
  KEY `fid_count` (`fid`,`count`),
  KEY `fid_module` (`fid`,`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `file_usage`
--

INSERT INTO `file_usage` (`fid`, `module`, `type`, `id`, `count`) VALUES
(1, 'user', 'user', 10, 1),
(2, 'user', 'user', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `filter`
--

CREATE TABLE IF NOT EXISTS `filter` (
  `format` varchar(255) NOT NULL COMMENT 'Foreign key: The filter_format.format to which this filter is assigned.',
  `module` varchar(64) NOT NULL DEFAULT '' COMMENT 'The origin module of the filter.',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT 'Name of the filter being referenced.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'Weight of filter within format.',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT 'Filter enabled status. (1 = enabled, 0 = disabled)',
  `settings` longblob COMMENT 'A serialized array of name value pairs that store the filter settings for the specific format.',
  PRIMARY KEY (`format`,`name`),
  KEY `list` (`weight`,`module`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filter`
--

INSERT INTO `filter` (`format`, `module`, `name`, `weight`, `status`, `settings`) VALUES
('filtered_html', 'filter', 'filter_autop', 2, 1, 0x613a303a7b7d),
('filtered_html', 'filter', 'filter_html', 1, 1, 0x613a333a7b733a31323a22616c6c6f7765645f68746d6c223b733a37343a223c613e203c656d3e203c7374726f6e673e203c636974653e203c626c6f636b71756f74653e203c636f64653e203c756c3e203c6f6c3e203c6c693e203c646c3e203c64743e203c64643e223b733a31363a2266696c7465725f68746d6c5f68656c70223b693a313b733a32303a2266696c7465725f68746d6c5f6e6f666f6c6c6f77223b693a303b7d),
('filtered_html', 'filter', 'filter_htmlcorrector', 10, 1, 0x613a303a7b7d),
('filtered_html', 'filter', 'filter_html_escape', 10, 0, 0x613a303a7b7d),
('filtered_html', 'filter', 'filter_url', 0, 1, 0x613a313a7b733a31373a2266696c7465725f75726c5f6c656e677468223b693a37323b7d),
('full_html', 'filter', 'filter_autop', 1, 1, 0x613a303a7b7d),
('full_html', 'filter', 'filter_html', 10, 0, 0x613a333a7b733a31323a22616c6c6f7765645f68746d6c223b733a37343a223c613e203c656d3e203c7374726f6e673e203c636974653e203c626c6f636b71756f74653e203c636f64653e203c756c3e203c6f6c3e203c6c693e203c646c3e203c64743e203c64643e223b733a31363a2266696c7465725f68746d6c5f68656c70223b693a313b733a32303a2266696c7465725f68746d6c5f6e6f666f6c6c6f77223b693a303b7d),
('full_html', 'filter', 'filter_htmlcorrector', 10, 1, 0x613a303a7b7d),
('full_html', 'filter', 'filter_html_escape', 10, 0, 0x613a303a7b7d),
('full_html', 'filter', 'filter_url', 0, 1, 0x613a313a7b733a31373a2266696c7465725f75726c5f6c656e677468223b693a37323b7d),
('plain_text', 'filter', 'filter_autop', 2, 1, 0x613a303a7b7d),
('plain_text', 'filter', 'filter_html', 10, 0, 0x613a333a7b733a31323a22616c6c6f7765645f68746d6c223b733a37343a223c613e203c656d3e203c7374726f6e673e203c636974653e203c626c6f636b71756f74653e203c636f64653e203c756c3e203c6f6c3e203c6c693e203c646c3e203c64743e203c64643e223b733a31363a2266696c7465725f68746d6c5f68656c70223b693a313b733a32303a2266696c7465725f68746d6c5f6e6f666f6c6c6f77223b693a303b7d),
('plain_text', 'filter', 'filter_htmlcorrector', 10, 0, 0x613a303a7b7d),
('plain_text', 'filter', 'filter_html_escape', 0, 1, 0x613a303a7b7d),
('plain_text', 'filter', 'filter_url', 1, 1, 0x613a313a7b733a31373a2266696c7465725f75726c5f6c656e677468223b693a37323b7d);

-- --------------------------------------------------------

--
-- Table structure for table `filter_format`
--

CREATE TABLE IF NOT EXISTS `filter_format` (
  `format` varchar(255) NOT NULL COMMENT 'Primary Key: Unique machine name of the format.',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'Name of the text format (Filtered HTML).',
  `cache` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Flag to indicate whether format is cacheable. (1 = cacheable, 0 = not cacheable)',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT 'The status of the text format. (1 = enabled, 0 = disabled)',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'Weight of text format to use when listing.',
  PRIMARY KEY (`format`),
  UNIQUE KEY `name` (`name`),
  KEY `status_weight` (`status`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filter_format`
--

INSERT INTO `filter_format` (`format`, `name`, `cache`, `status`, `weight`) VALUES
('filtered_html', 'Filtered HTML', 1, 1, 0),
('full_html', 'Full HTML', 1, 1, 1),
('plain_text', 'Plain text', 1, 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `flood`
--

CREATE TABLE IF NOT EXISTS `flood` (
  `fid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique flood event ID.',
  `event` varchar(64) NOT NULL DEFAULT '' COMMENT 'Name of event (e.g. contact).',
  `identifier` varchar(128) NOT NULL DEFAULT '' COMMENT 'Identifier of the visitor, such as an IP address or hostname.',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'Timestamp of the event.',
  `expiration` int(11) NOT NULL DEFAULT '0' COMMENT 'Expiration timestamp. Expired events are purged on cron run.',
  PRIMARY KEY (`fid`),
  KEY `allow` (`event`,`identifier`,`timestamp`),
  KEY `purge` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `flood`
--


-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid that read the node nid.',
  `nid` int(11) NOT NULL DEFAULT '0' COMMENT 'The node.nid that was read.',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp at which the read occurred.',
  PRIMARY KEY (`uid`,`nid`),
  KEY `nid` (`nid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`uid`, `nid`, `timestamp`) VALUES
(1, 1, 1315425876),
(1, 2, 1315421455),
(1, 3, 1315421403),
(1, 4, 1315421405),
(1, 6, 1315422994);

-- --------------------------------------------------------

--
-- Table structure for table `menu_custom`
--

CREATE TABLE IF NOT EXISTS `menu_custom` (
  `menu_name` varchar(32) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique key for menu. This is used as a block delta so length is 32.',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT 'Menu title; displayed at top of block.',
  `description` text COMMENT 'Menu description.',
  PRIMARY KEY (`menu_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu_custom`
--

INSERT INTO `menu_custom` (`menu_name`, `title`, `description`) VALUES
('features', 'Features', 'Menu items for any enabled features.'),
('main-menu', 'Main menu', 'The <em>Main</em> menu is used on many sites to show the major sections of the site, often in a top navigation bar.'),
('management', 'Management', 'The <em>Management</em> menu contains links for administrative tasks.'),
('navigation', 'Navigation', 'The <em>Navigation</em> menu contains links intended for site visitors. Links are added to the <em>Navigation</em> menu automatically by some modules.'),
('user-menu', 'User menu', 'The <em>User</em> menu contains links related to the user''s account, as well as the ''Log out'' link.');

-- --------------------------------------------------------

--
-- Table structure for table `menu_links`
--

CREATE TABLE IF NOT EXISTS `menu_links` (
  `menu_name` varchar(32) NOT NULL DEFAULT '' COMMENT 'The menu name. All links with the same menu name (such as ’navigation’) are part of the same menu.',
  `mlid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The menu link ID (mlid) is the integer primary key.',
  `plid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The parent link ID (plid) is the mlid of the link above in the hierarchy, or zero if the link is at the top level in its menu.',
  `link_path` varchar(255) NOT NULL DEFAULT '' COMMENT 'The Drupal path or external path this link points to.',
  `router_path` varchar(255) NOT NULL DEFAULT '' COMMENT 'For links corresponding to a Drupal path (external = 0), this connects the link to a menu_router.path for joins.',
  `link_title` varchar(255) NOT NULL DEFAULT '' COMMENT 'The text displayed for the link, which may be modified by a title callback stored in menu_router.',
  `options` blob COMMENT 'A serialized array of options to be passed to the url() or l() function, such as a query string or HTML attributes.',
  `module` varchar(255) NOT NULL DEFAULT 'system' COMMENT 'The name of the module that generated this link.',
  `hidden` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag for whether the link should be rendered in menus. (1 = a disabled menu item that may be shown on admin screens, -1 = a menu callback, 0 = a normal, visible link)',
  `external` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate if the link points to a full URL starting with a protocol, like http:// (1 = external, 0 = internal).',
  `has_children` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Flag indicating whether any links have this link as a parent (1 = children exist, 0 = no children).',
  `expanded` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Flag for whether this link should be rendered as expanded in menus - expanded links always have their child links displayed, instead of only when the link is in the active trail (1 = expanded, 0 = not expanded)',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'Link weight among links in the same menu at the same depth.',
  `depth` smallint(6) NOT NULL DEFAULT '0' COMMENT 'The depth relative to the top level. A link with plid == 0 will have depth == 1.',
  `customized` smallint(6) NOT NULL DEFAULT '0' COMMENT 'A flag to indicate that the user has manually created or edited the link (1 = customized, 0 = not customized).',
  `p1` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The first mlid in the materialized path. If N = depth, then pN must equal the mlid. If depth > 1 then p(N-1) must equal the plid. All pX where X > depth must equal zero. The columns p1 .. p9 are also called the parents.',
  `p2` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The second mlid in the materialized path. See p1.',
  `p3` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The third mlid in the materialized path. See p1.',
  `p4` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The fourth mlid in the materialized path. See p1.',
  `p5` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The fifth mlid in the materialized path. See p1.',
  `p6` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The sixth mlid in the materialized path. See p1.',
  `p7` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The seventh mlid in the materialized path. See p1.',
  `p8` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The eighth mlid in the materialized path. See p1.',
  `p9` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The ninth mlid in the materialized path. See p1.',
  `updated` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Flag that indicates that this link was generated during the update from Drupal 5.',
  PRIMARY KEY (`mlid`),
  KEY `path_menu` (`link_path`(128),`menu_name`),
  KEY `menu_plid_expand_child` (`menu_name`,`plid`,`expanded`,`has_children`),
  KEY `menu_parents` (`menu_name`,`p1`,`p2`,`p3`,`p4`,`p5`,`p6`,`p7`,`p8`,`p9`),
  KEY `router_path` (`router_path`(128))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=723 ;

--
-- Dumping data for table `menu_links`
--

INSERT INTO `menu_links` (`menu_name`, `mlid`, `plid`, `link_path`, `router_path`, `link_title`, `options`, `module`, `hidden`, `external`, `has_children`, `expanded`, `weight`, `depth`, `customized`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `p8`, `p9`, `updated`) VALUES
('management', 1, 0, 'admin', 'admin', 'Administration', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 9, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('user-menu', 2, 0, 'user', 'user', 'User account', 0x613a313a7b733a353a22616c746572223b623a313b7d, 'system', 0, 0, 0, 0, -10, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 3, 0, 'comment/%', 'comment/%', 'Comment permalink', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 4, 0, 'filter/tips', 'filter/tips', 'Compose tips', 0x613a303a7b7d, 'system', 1, 0, 0, 0, 0, 1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 5, 0, 'node/%', 'node/%', '', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 1, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 6, 0, 'node/add', 'node/add', 'Add content', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 1, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 7, 1, 'admin/appearance', 'admin/appearance', 'Appearance', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33333a2253656c65637420616e6420636f6e66696775726520796f7572207468656d65732e223b7d7d, 'system', 0, 0, 0, 0, -6, 2, 0, 1, 7, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 8, 1, 'admin/config', 'admin/config', 'Configuration', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32303a2241646d696e69737465722073657474696e67732e223b7d7d, 'system', 0, 0, 1, 0, 0, 2, 0, 1, 8, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 9, 1, 'admin/content', 'admin/content', 'Content', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33323a2241646d696e697374657220636f6e74656e7420616e6420636f6d6d656e74732e223b7d7d, 'system', 0, 0, 1, 0, -10, 2, 0, 1, 9, 0, 0, 0, 0, 0, 0, 0, 0),
('user-menu', 10, 2, 'user/register', 'user/register', 'Create new account', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 2, 0, 2, 10, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 12, 1, 'admin/help', 'admin/help', 'Help', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34383a225265666572656e636520666f722075736167652c20636f6e66696775726174696f6e2c20616e64206d6f64756c65732e223b7d7d, 'system', 0, 0, 0, 0, 9, 2, 0, 1, 12, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 13, 1, 'admin/index', 'admin/index', 'Index', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -18, 2, 0, 1, 13, 0, 0, 0, 0, 0, 0, 0, 0),
('user-menu', 14, 2, 'user/login', 'user/login', 'Log in', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 2, 0, 2, 14, 0, 0, 0, 0, 0, 0, 0, 0),
('user-menu', 15, 0, 'user/logout', 'user/logout', 'Log out', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 10, 1, 0, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 16, 1, 'admin/modules', 'admin/modules', 'Modules', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32363a22457874656e6420736974652066756e6374696f6e616c6974792e223b7d7d, 'system', 0, 0, 0, 0, -2, 2, 0, 1, 16, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 17, 0, 'user/%', 'user/%', 'My account', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 1, 0, 17, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 18, 1, 'admin/people', 'admin/people', 'People', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34353a224d616e6167652075736572206163636f756e74732c20726f6c65732c20616e64207065726d697373696f6e732e223b7d7d, 'system', 0, 0, 0, 0, -4, 2, 0, 1, 18, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 19, 1, 'admin/reports', 'admin/reports', 'Reports', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33343a2256696577207265706f7274732c20757064617465732c20616e64206572726f72732e223b7d7d, 'system', 0, 0, 1, 0, 5, 2, 0, 1, 19, 0, 0, 0, 0, 0, 0, 0, 0),
('user-menu', 20, 2, 'user/password', 'user/password', 'Request new password', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 2, 0, 2, 20, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 21, 1, 'admin/structure', 'admin/structure', 'Structure', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34353a2241646d696e697374657220626c6f636b732c20636f6e74656e742074797065732c206d656e75732c206574632e223b7d7d, 'system', 0, 0, 1, 0, -8, 2, 0, 1, 21, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 22, 1, 'admin/tasks', 'admin/tasks', 'Tasks', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -20, 2, 0, 1, 22, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 23, 0, 'comment/reply/%', 'comment/reply/%', 'Add new comment', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 1, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 24, 3, 'comment/%/approve', 'comment/%/approve', 'Approve', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 1, 2, 0, 3, 24, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 25, 3, 'comment/%/delete', 'comment/%/delete', 'Delete', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 2, 0, 3, 25, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 26, 3, 'comment/%/edit', 'comment/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 2, 0, 3, 26, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 27, 0, 'taxonomy/term/%', 'taxonomy/term/%', 'Taxonomy term', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 1, 0, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 28, 3, 'comment/%/view', 'comment/%/view', 'View comment', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 2, 0, 3, 28, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 29, 18, 'admin/people/create', 'admin/people/create', 'Add user', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 18, 29, 0, 0, 0, 0, 0, 0, 0),
('management', 30, 21, 'admin/structure/block', 'admin/structure/block', 'Blocks', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a37393a22436f6e666967757265207768617420626c6f636b20636f6e74656e74206170706561727320696e20796f75722073697465277320736964656261727320616e64206f7468657220726567696f6e732e223b7d7d, 'system', 0, 0, 1, 0, 0, 3, 0, 1, 21, 30, 0, 0, 0, 0, 0, 0, 0),
('navigation', 31, 17, 'user/%/cancel', 'user/%/cancel', 'Cancel account', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 2, 0, 17, 31, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 32, 9, 'admin/content/comment', 'admin/content/comment', 'Comments', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a35393a224c69737420616e642065646974207369746520636f6d6d656e747320616e642074686520636f6d6d656e7420617070726f76616c2071756575652e223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 9, 32, 0, 0, 0, 0, 0, 0, 0),
('management', 34, 9, 'admin/content/node', 'admin/content/node', 'Content', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 3, 0, 1, 9, 34, 0, 0, 0, 0, 0, 0, 0),
('management', 35, 8, 'admin/config/content', 'admin/config/content', 'Content authoring', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a35333a2253657474696e67732072656c6174656420746f20666f726d617474696e6720616e6420617574686f72696e6720636f6e74656e742e223b7d7d, 'system', 0, 0, 1, 0, -15, 3, 0, 1, 8, 35, 0, 0, 0, 0, 0, 0, 0),
('management', 36, 21, 'admin/structure/types', 'admin/structure/types', 'Content types', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a39323a224d616e61676520636f6e74656e742074797065732c20696e636c7564696e672064656661756c74207374617475732c2066726f6e7420706167652070726f6d6f74696f6e2c20636f6d6d656e742073657474696e67732c206574632e223b7d7d, 'system', 0, 0, 1, 0, 0, 3, 0, 1, 21, 36, 0, 0, 0, 0, 0, 0, 0),
('navigation', 38, 5, 'node/%/delete', 'node/%/delete', 'Delete', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 2, 0, 5, 38, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 39, 8, 'admin/config/development', 'admin/config/development', 'Development', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a31383a22446576656c6f706d656e7420746f6f6c732e223b7d7d, 'system', 0, 0, 1, 0, -10, 3, 0, 1, 8, 39, 0, 0, 0, 0, 0, 0, 0),
('navigation', 40, 17, 'user/%/edit', 'user/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 2, 0, 17, 40, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 41, 5, 'node/%/edit', 'node/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 2, 0, 5, 41, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 42, 19, 'admin/reports/fields', 'admin/reports/fields', 'Field list', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33393a224f76657276696577206f66206669656c6473206f6e20616c6c20656e746974792074797065732e223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 19, 42, 0, 0, 0, 0, 0, 0, 0),
('management', 43, 7, 'admin/appearance/list', 'admin/appearance/list', 'List', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33313a2253656c65637420616e6420636f6e66696775726520796f7572207468656d65223b7d7d, 'system', -1, 0, 0, 0, -1, 3, 0, 1, 7, 43, 0, 0, 0, 0, 0, 0, 0),
('management', 44, 16, 'admin/modules/list', 'admin/modules/list', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 16, 44, 0, 0, 0, 0, 0, 0, 0),
('management', 45, 18, 'admin/people/people', 'admin/people/people', 'List', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a35303a2246696e6420616e64206d616e6167652070656f706c6520696e746572616374696e67207769746820796f757220736974652e223b7d7d, 'system', -1, 0, 0, 0, -10, 3, 0, 1, 18, 45, 0, 0, 0, 0, 0, 0, 0),
('management', 46, 8, 'admin/config/media', 'admin/config/media', 'Media', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a31323a224d6564696120746f6f6c732e223b7d7d, 'system', 0, 0, 1, 0, -10, 3, 0, 1, 8, 46, 0, 0, 0, 0, 0, 0, 0),
('management', 47, 21, 'admin/structure/menu', 'admin/structure/menu', 'Menus', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a38363a22416464206e6577206d656e757320746f20796f757220736974652c2065646974206578697374696e67206d656e75732c20616e642072656e616d6520616e642072656f7267616e697a65206d656e75206c696e6b732e223b7d7d, 'system', 0, 0, 1, 0, 0, 3, 0, 1, 21, 47, 0, 0, 0, 0, 0, 0, 0),
('management', 48, 8, 'admin/config/people', 'admin/config/people', 'People', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32343a22436f6e6669677572652075736572206163636f756e74732e223b7d7d, 'system', 0, 0, 1, 0, -20, 3, 0, 1, 8, 48, 0, 0, 0, 0, 0, 0, 0),
('management', 49, 18, 'admin/people/permissions', 'admin/people/permissions', 'Permissions', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a36343a2244657465726d696e652061636365737320746f2066656174757265732062792073656c656374696e67207065726d697373696f6e7320666f7220726f6c65732e223b7d7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 18, 49, 0, 0, 0, 0, 0, 0, 0),
('management', 50, 19, 'admin/reports/dblog', 'admin/reports/dblog', 'Recent log messages', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34333a2256696577206576656e74732074686174206861766520726563656e746c79206265656e206c6f676765642e223b7d7d, 'system', 0, 0, 0, 0, -1, 3, 0, 1, 19, 50, 0, 0, 0, 0, 0, 0, 0),
('management', 51, 8, 'admin/config/regional', 'admin/config/regional', 'Regional and language', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34383a22526567696f6e616c2073657474696e67732c206c6f63616c697a6174696f6e20616e64207472616e736c6174696f6e2e223b7d7d, 'system', 0, 0, 1, 0, -5, 3, 0, 1, 8, 51, 0, 0, 0, 0, 0, 0, 0),
('navigation', 52, 5, 'node/%/revisions', 'node/%/revisions', 'Revisions', 0x613a303a7b7d, 'system', -1, 0, 1, 0, 2, 2, 0, 5, 52, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 53, 8, 'admin/config/search', 'admin/config/search', 'Search and metadata', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33363a224c6f63616c2073697465207365617263682c206d6574616461746120616e642053454f2e223b7d7d, 'system', 0, 0, 1, 0, -10, 3, 0, 1, 8, 53, 0, 0, 0, 0, 0, 0, 0),
('management', 54, 7, 'admin/appearance/settings', 'admin/appearance/settings', 'Settings', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34363a22436f6e6669677572652064656661756c7420616e64207468656d652073706563696669632073657474696e67732e223b7d7d, 'system', -1, 0, 0, 0, 20, 3, 0, 1, 7, 54, 0, 0, 0, 0, 0, 0, 0),
('management', 55, 19, 'admin/reports/status', 'admin/reports/status', 'Status report', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a37343a22476574206120737461747573207265706f72742061626f757420796f757220736974652773206f7065726174696f6e20616e6420616e792064657465637465642070726f626c656d732e223b7d7d, 'system', 0, 0, 0, 0, -60, 3, 0, 1, 19, 55, 0, 0, 0, 0, 0, 0, 0),
('management', 56, 8, 'admin/config/system', 'admin/config/system', 'System', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33373a2247656e6572616c2073797374656d2072656c6174656420636f6e66696775726174696f6e2e223b7d7d, 'system', 0, 0, 1, 0, -20, 3, 0, 1, 8, 56, 0, 0, 0, 0, 0, 0, 0),
('management', 57, 21, 'admin/structure/taxonomy', 'admin/structure/taxonomy', 'Taxonomy', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a36373a224d616e6167652074616767696e672c2063617465676f72697a6174696f6e2c20616e6420636c617373696669636174696f6e206f6620796f757220636f6e74656e742e223b7d7d, 'system', 0, 0, 1, 0, 0, 3, 0, 1, 21, 57, 0, 0, 0, 0, 0, 0, 0),
('management', 58, 19, 'admin/reports/access-denied', 'admin/reports/access-denied', 'Top ''access denied'' errors', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33353a225669657720276163636573732064656e69656427206572726f7273202834303373292e223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 19, 58, 0, 0, 0, 0, 0, 0, 0),
('management', 59, 19, 'admin/reports/page-not-found', 'admin/reports/page-not-found', 'Top ''page not found'' errors', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33363a2256696577202770616765206e6f7420666f756e6427206572726f7273202834303473292e223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 19, 59, 0, 0, 0, 0, 0, 0, 0),
('management', 60, 16, 'admin/modules/uninstall', 'admin/modules/uninstall', 'Uninstall', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 20, 3, 0, 1, 16, 60, 0, 0, 0, 0, 0, 0, 0),
('management', 61, 8, 'admin/config/user-interface', 'admin/config/user-interface', 'User interface', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33383a22546f6f6c73207468617420656e68616e636520746865207573657220696e746572666163652e223b7d7d, 'system', 0, 0, 1, 0, -15, 3, 0, 1, 8, 61, 0, 0, 0, 0, 0, 0, 0),
('navigation', 62, 5, 'node/%/view', 'node/%/view', 'View', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 2, 0, 5, 62, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 63, 17, 'user/%/view', 'user/%/view', 'View', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 2, 0, 17, 63, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 64, 8, 'admin/config/services', 'admin/config/services', 'Web services', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33303a22546f6f6c732072656c6174656420746f207765622073657276696365732e223b7d7d, 'system', 0, 0, 1, 0, 0, 3, 0, 1, 8, 64, 0, 0, 0, 0, 0, 0, 0),
('management', 65, 8, 'admin/config/workflow', 'admin/config/workflow', 'Workflow', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34333a22436f6e74656e7420776f726b666c6f772c20656469746f7269616c20776f726b666c6f7720746f6f6c732e223b7d7d, 'system', 0, 0, 0, 0, 5, 3, 0, 1, 8, 65, 0, 0, 0, 0, 0, 0, 0),
('management', 66, 12, 'admin/help/block', 'admin/help/block', 'block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 66, 0, 0, 0, 0, 0, 0, 0),
('management', 67, 12, 'admin/help/color', 'admin/help/color', 'color', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 67, 0, 0, 0, 0, 0, 0, 0),
('management', 68, 12, 'admin/help/comment', 'admin/help/comment', 'comment', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 68, 0, 0, 0, 0, 0, 0, 0),
('management', 69, 12, 'admin/help/contextual', 'admin/help/contextual', 'contextual', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 69, 0, 0, 0, 0, 0, 0, 0),
('management', 71, 12, 'admin/help/dblog', 'admin/help/dblog', 'dblog', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 71, 0, 0, 0, 0, 0, 0, 0),
('management', 72, 12, 'admin/help/field', 'admin/help/field', 'field', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 72, 0, 0, 0, 0, 0, 0, 0),
('management', 73, 12, 'admin/help/field_sql_storage', 'admin/help/field_sql_storage', 'field_sql_storage', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 73, 0, 0, 0, 0, 0, 0, 0),
('management', 74, 12, 'admin/help/field_ui', 'admin/help/field_ui', 'field_ui', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 74, 0, 0, 0, 0, 0, 0, 0),
('management', 75, 12, 'admin/help/file', 'admin/help/file', 'file', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 75, 0, 0, 0, 0, 0, 0, 0),
('management', 76, 12, 'admin/help/filter', 'admin/help/filter', 'filter', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 76, 0, 0, 0, 0, 0, 0, 0),
('management', 77, 12, 'admin/help/help', 'admin/help/help', 'help', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 77, 0, 0, 0, 0, 0, 0, 0),
('management', 79, 12, 'admin/help/list', 'admin/help/list', 'list', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 79, 0, 0, 0, 0, 0, 0, 0),
('management', 80, 12, 'admin/help/menu', 'admin/help/menu', 'menu', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 80, 0, 0, 0, 0, 0, 0, 0),
('management', 81, 12, 'admin/help/node', 'admin/help/node', 'node', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 81, 0, 0, 0, 0, 0, 0, 0),
('management', 82, 12, 'admin/help/options', 'admin/help/options', 'options', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 82, 0, 0, 0, 0, 0, 0, 0),
('management', 83, 12, 'admin/help/system', 'admin/help/system', 'system', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 83, 0, 0, 0, 0, 0, 0, 0),
('management', 84, 12, 'admin/help/taxonomy', 'admin/help/taxonomy', 'taxonomy', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 84, 0, 0, 0, 0, 0, 0, 0),
('management', 85, 12, 'admin/help/text', 'admin/help/text', 'text', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 85, 0, 0, 0, 0, 0, 0, 0),
('management', 86, 12, 'admin/help/user', 'admin/help/user', 'user', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 86, 0, 0, 0, 0, 0, 0, 0),
('navigation', 87, 27, 'taxonomy/term/%/edit', 'taxonomy/term/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 2, 0, 27, 87, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 88, 27, 'taxonomy/term/%/view', 'taxonomy/term/%/view', 'View', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 2, 0, 27, 88, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 89, 48, 'admin/config/people/accounts', 'admin/config/people/accounts', 'Account settings', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a3130393a22436f6e6669677572652064656661756c74206265686176696f72206f662075736572732c20696e636c7564696e6720726567697374726174696f6e20726571756972656d656e74732c20652d6d61696c732c206669656c64732c20616e6420757365722070696374757265732e223b7d7d, 'system', 0, 0, 0, 0, -10, 4, 0, 1, 8, 48, 89, 0, 0, 0, 0, 0, 0),
('management', 90, 56, 'admin/config/system/actions', 'admin/config/system/actions', 'Actions', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34313a224d616e6167652074686520616374696f6e7320646566696e656420666f7220796f757220736974652e223b7d7d, 'system', 0, 0, 1, 0, 0, 4, 0, 1, 8, 56, 90, 0, 0, 0, 0, 0, 0),
('management', 91, 30, 'admin/structure/block/add', 'admin/structure/block/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 91, 0, 0, 0, 0, 0, 0),
('management', 92, 36, 'admin/structure/types/add', 'admin/structure/types/add', 'Add content type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 36, 92, 0, 0, 0, 0, 0, 0),
('management', 93, 47, 'admin/structure/menu/add', 'admin/structure/menu/add', 'Add menu', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 47, 93, 0, 0, 0, 0, 0, 0),
('management', 94, 57, 'admin/structure/taxonomy/add', 'admin/structure/taxonomy/add', 'Add vocabulary', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 57, 94, 0, 0, 0, 0, 0, 0),
('management', 95, 54, 'admin/appearance/settings/bartik', 'admin/appearance/settings/bartik', 'Bartik', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 95, 0, 0, 0, 0, 0, 0),
('management', 96, 53, 'admin/config/search/clean-urls', 'admin/config/search/clean-urls', 'Clean URLs', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34333a22456e61626c65206f722064697361626c6520636c65616e2055524c7320666f7220796f757220736974652e223b7d7d, 'system', 0, 0, 0, 0, 5, 4, 0, 1, 8, 53, 96, 0, 0, 0, 0, 0, 0),
('management', 97, 56, 'admin/config/system/cron', 'admin/config/system/cron', 'Cron', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34303a224d616e616765206175746f6d617469632073697465206d61696e74656e616e6365207461736b732e223b7d7d, 'system', 0, 0, 0, 0, 20, 4, 0, 1, 8, 56, 97, 0, 0, 0, 0, 0, 0),
('management', 98, 51, 'admin/config/regional/date-time', 'admin/config/regional/date-time', 'Date and time', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34343a22436f6e66696775726520646973706c617920666f726d61747320666f72206461746520616e642074696d652e223b7d7d, 'system', 0, 0, 0, 0, -15, 4, 0, 1, 8, 51, 98, 0, 0, 0, 0, 0, 0),
('management', 99, 19, 'admin/reports/event/%', 'admin/reports/event/%', 'Details', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 19, 99, 0, 0, 0, 0, 0, 0, 0),
('management', 100, 46, 'admin/config/media/file-system', 'admin/config/media/file-system', 'File system', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a36383a2254656c6c2044727570616c20776865726520746f2073746f72652075706c6f616465642066696c657320616e6420686f772074686579206172652061636365737365642e223b7d7d, 'system', 0, 0, 0, 0, -10, 4, 0, 1, 8, 46, 100, 0, 0, 0, 0, 0, 0),
('management', 101, 54, 'admin/appearance/settings/garland', 'admin/appearance/settings/garland', 'Garland', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 101, 0, 0, 0, 0, 0, 0),
('management', 102, 54, 'admin/appearance/settings/global', 'admin/appearance/settings/global', 'Global settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -1, 4, 0, 1, 7, 54, 102, 0, 0, 0, 0, 0, 0),
('management', 103, 48, 'admin/config/people/ip-blocking', 'admin/config/people/ip-blocking', 'IP address blocking', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32383a224d616e61676520626c6f636b6564204950206164647265737365732e223b7d7d, 'system', 0, 0, 1, 0, 10, 4, 0, 1, 8, 48, 103, 0, 0, 0, 0, 0, 0),
('management', 105, 46, 'admin/config/media/image-toolkit', 'admin/config/media/image-toolkit', 'Image toolkit', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a37343a2243686f6f736520776869636820696d61676520746f6f6c6b697420746f2075736520696620796f75206861766520696e7374616c6c6564206f7074696f6e616c20746f6f6c6b6974732e223b7d7d, 'system', 0, 0, 0, 0, 20, 4, 0, 1, 8, 46, 105, 0, 0, 0, 0, 0, 0),
('management', 106, 44, 'admin/modules/list/confirm', 'admin/modules/list/confirm', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 16, 44, 106, 0, 0, 0, 0, 0, 0),
('management', 107, 36, 'admin/structure/types/list', 'admin/structure/types/list', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 4, 0, 1, 21, 36, 107, 0, 0, 0, 0, 0, 0),
('management', 108, 57, 'admin/structure/taxonomy/list', 'admin/structure/taxonomy/list', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 4, 0, 1, 21, 57, 108, 0, 0, 0, 0, 0, 0),
('management', 109, 47, 'admin/structure/menu/list', 'admin/structure/menu/list', 'List menus', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 4, 0, 1, 21, 47, 109, 0, 0, 0, 0, 0, 0),
('management', 110, 39, 'admin/config/development/logging', 'admin/config/development/logging', 'Logging and errors', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a3135343a2253657474696e677320666f72206c6f6767696e6720616e6420616c65727473206d6f64756c65732e20566172696f7573206d6f64756c65732063616e20726f7574652044727570616c27732073797374656d206576656e747320746f20646966666572656e742064657374696e6174696f6e732c2073756368206173207379736c6f672c2064617461626173652c20656d61696c2c206574632e223b7d7d, 'system', 0, 0, 0, 0, -15, 4, 0, 1, 8, 39, 110, 0, 0, 0, 0, 0, 0),
('management', 111, 39, 'admin/config/development/maintenance', 'admin/config/development/maintenance', 'Maintenance mode', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a36323a2254616b65207468652073697465206f66666c696e6520666f72206d61696e74656e616e6365206f72206272696e67206974206261636b206f6e6c696e652e223b7d7d, 'system', 0, 0, 0, 0, -10, 4, 0, 1, 8, 39, 111, 0, 0, 0, 0, 0, 0),
('management', 112, 39, 'admin/config/development/performance', 'admin/config/development/performance', 'Performance', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a3130313a22456e61626c65206f722064697361626c6520706167652063616368696e6720666f7220616e6f6e796d6f757320757365727320616e64207365742043535320616e64204a532062616e647769647468206f7074696d697a6174696f6e206f7074696f6e732e223b7d7d, 'system', 0, 0, 0, 0, -20, 4, 0, 1, 8, 39, 112, 0, 0, 0, 0, 0, 0),
('management', 113, 49, 'admin/people/permissions/list', 'admin/people/permissions/list', 'Permissions', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a36343a2244657465726d696e652061636365737320746f2066656174757265732062792073656c656374696e67207065726d697373696f6e7320666f7220726f6c65732e223b7d7d, 'system', -1, 0, 0, 0, -8, 4, 0, 1, 18, 49, 113, 0, 0, 0, 0, 0, 0),
('management', 114, 32, 'admin/content/comment/new', 'admin/content/comment/new', 'Published comments', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 4, 0, 1, 9, 32, 114, 0, 0, 0, 0, 0, 0),
('management', 115, 64, 'admin/config/services/rss-publishing', 'admin/config/services/rss-publishing', 'RSS publishing', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a3131343a22436f6e666967757265207468652073697465206465736372697074696f6e2c20746865206e756d626572206f66206974656d7320706572206665656420616e6420776865746865722066656564732073686f756c64206265207469746c65732f746561736572732f66756c6c2d746578742e223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 64, 115, 0, 0, 0, 0, 0, 0),
('management', 116, 51, 'admin/config/regional/settings', 'admin/config/regional/settings', 'Regional settings', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a35343a2253657474696e677320666f7220746865207369746527732064656661756c742074696d65207a6f6e6520616e6420636f756e7472792e223b7d7d, 'system', 0, 0, 0, 0, -20, 4, 0, 1, 8, 51, 116, 0, 0, 0, 0, 0, 0),
('management', 117, 49, 'admin/people/permissions/roles', 'admin/people/permissions/roles', 'Roles', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33303a224c6973742c20656469742c206f7220616464207573657220726f6c65732e223b7d7d, 'system', -1, 0, 1, 0, -5, 4, 0, 1, 18, 49, 117, 0, 0, 0, 0, 0, 0),
('management', 118, 47, 'admin/structure/menu/settings', 'admin/structure/menu/settings', 'Settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 5, 4, 0, 1, 21, 47, 118, 0, 0, 0, 0, 0, 0),
('management', 119, 54, 'admin/appearance/settings/seven', 'admin/appearance/settings/seven', 'Seven', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 119, 0, 0, 0, 0, 0, 0),
('management', 120, 56, 'admin/config/system/site-information', 'admin/config/system/site-information', 'Site information', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a3130343a224368616e67652073697465206e616d652c20652d6d61696c20616464726573732c20736c6f67616e2c2064656661756c742066726f6e7420706167652c20616e64206e756d626572206f6620706f7374732070657220706167652c206572726f722070616765732e223b7d7d, 'system', 0, 0, 0, 0, -20, 4, 0, 1, 8, 56, 120, 0, 0, 0, 0, 0, 0),
('management', 121, 54, 'admin/appearance/settings/stark', 'admin/appearance/settings/stark', 'Stark', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 121, 0, 0, 0, 0, 0, 0),
('management', 122, 54, 'admin/appearance/settings/test_theme', 'admin/appearance/settings/test_theme', 'Test theme', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 122, 0, 0, 0, 0, 0, 0),
('management', 123, 35, 'admin/config/content/formats', 'admin/config/content/formats', 'Text formats', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a3132373a22436f6e66696775726520686f7720636f6e74656e7420696e7075742062792075736572732069732066696c74657265642c20696e636c7564696e6720616c6c6f7765642048544d4c20746167732e20416c736f20616c6c6f777320656e61626c696e67206f66206d6f64756c652d70726f76696465642066696c746572732e223b7d7d, 'system', 0, 0, 1, 0, 0, 4, 0, 1, 8, 35, 123, 0, 0, 0, 0, 0, 0),
('management', 124, 32, 'admin/content/comment/approval', 'admin/content/comment/approval', 'Unapproved comments', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 9, 32, 124, 0, 0, 0, 0, 0, 0),
('management', 125, 60, 'admin/modules/uninstall/confirm', 'admin/modules/uninstall/confirm', 'Uninstall', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 16, 60, 125, 0, 0, 0, 0, 0, 0),
('management', 126, 54, 'admin/appearance/settings/update_test_basetheme', 'admin/appearance/settings/update_test_basetheme', 'Update test base theme', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 126, 0, 0, 0, 0, 0, 0),
('management', 127, 57, 'admin/structure/taxonomy/%', 'admin/structure/taxonomy/%', '', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 21, 57, 127, 0, 0, 0, 0, 0, 0),
('management', 128, 54, 'admin/appearance/settings/update_test_subtheme', 'admin/appearance/settings/update_test_subtheme', 'Update test subtheme', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 128, 0, 0, 0, 0, 0, 0),
('navigation', 129, 40, 'user/%/edit/account', 'user/%/edit/account', 'Account', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 17, 40, 129, 0, 0, 0, 0, 0, 0, 0),
('management', 130, 123, 'admin/config/content/formats/%', 'admin/config/content/formats/%', '', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 5, 0, 1, 8, 35, 123, 130, 0, 0, 0, 0, 0),
('management', 132, 127, 'admin/structure/taxonomy/%/add', 'admin/structure/taxonomy/%/add', 'Add term', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 57, 127, 132, 0, 0, 0, 0, 0),
('management', 133, 123, 'admin/config/content/formats/add', 'admin/config/content/formats/add', 'Add text format', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 5, 0, 1, 8, 35, 123, 133, 0, 0, 0, 0, 0),
('management', 134, 30, 'admin/structure/block/list/bartik', 'admin/structure/block/list/bartik', 'Bartik', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 134, 0, 0, 0, 0, 0, 0),
('management', 135, 90, 'admin/config/system/actions/configure', 'admin/config/system/actions/configure', 'Configure an advanced action', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 56, 90, 135, 0, 0, 0, 0, 0),
('management', 136, 47, 'admin/structure/menu/manage/%', 'admin/structure/menu/manage/%', 'Customize menu', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 4, 0, 1, 21, 47, 136, 0, 0, 0, 0, 0, 0),
('management', 137, 127, 'admin/structure/taxonomy/%/edit', 'admin/structure/taxonomy/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 5, 0, 1, 21, 57, 127, 137, 0, 0, 0, 0, 0),
('management', 138, 36, 'admin/structure/types/manage/%', 'admin/structure/types/manage/%', 'Edit content type', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 4, 0, 1, 21, 36, 138, 0, 0, 0, 0, 0, 0),
('management', 139, 98, 'admin/config/regional/date-time/formats', 'admin/config/regional/date-time/formats', 'Formats', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a35313a22436f6e66696775726520646973706c617920666f726d617420737472696e677320666f72206461746520616e642074696d652e223b7d7d, 'system', -1, 0, 1, 0, -9, 5, 0, 1, 8, 51, 98, 139, 0, 0, 0, 0, 0),
('management', 140, 30, 'admin/structure/block/list/garland', 'admin/structure/block/list/garland', 'Garland', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 140, 0, 0, 0, 0, 0, 0),
('management', 141, 123, 'admin/config/content/formats/list', 'admin/config/content/formats/list', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 35, 123, 141, 0, 0, 0, 0, 0),
('management', 142, 127, 'admin/structure/taxonomy/%/list', 'admin/structure/taxonomy/%/list', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -20, 5, 0, 1, 21, 57, 127, 142, 0, 0, 0, 0, 0),
('management', 144, 90, 'admin/config/system/actions/manage', 'admin/config/system/actions/manage', 'Manage actions', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34313a224d616e6167652074686520616374696f6e7320646566696e656420666f7220796f757220736974652e223b7d7d, 'system', -1, 0, 0, 0, -2, 5, 0, 1, 8, 56, 90, 144, 0, 0, 0, 0, 0),
('management', 145, 89, 'admin/config/people/accounts/settings', 'admin/config/people/accounts/settings', 'Settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 5, 0, 1, 8, 48, 89, 145, 0, 0, 0, 0, 0),
('management', 146, 30, 'admin/structure/block/list/seven', 'admin/structure/block/list/seven', 'Seven', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 146, 0, 0, 0, 0, 0, 0),
('management', 147, 30, 'admin/structure/block/list/stark', 'admin/structure/block/list/stark', 'Stark', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 147, 0, 0, 0, 0, 0, 0),
('management', 148, 30, 'admin/structure/block/list/test_theme', 'admin/structure/block/list/test_theme', 'Test theme', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 148, 0, 0, 0, 0, 0, 0),
('management', 149, 98, 'admin/config/regional/date-time/types', 'admin/config/regional/date-time/types', 'Types', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34343a22436f6e66696775726520646973706c617920666f726d61747320666f72206461746520616e642074696d652e223b7d7d, 'system', -1, 0, 1, 0, -10, 5, 0, 1, 8, 51, 98, 149, 0, 0, 0, 0, 0),
('management', 150, 30, 'admin/structure/block/list/update_test_basetheme', 'admin/structure/block/list/update_test_basetheme', 'Update test base theme', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 150, 0, 0, 0, 0, 0, 0),
('management', 151, 30, 'admin/structure/block/list/update_test_subtheme', 'admin/structure/block/list/update_test_subtheme', 'Update test subtheme', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 151, 0, 0, 0, 0, 0, 0),
('navigation', 152, 52, 'node/%/revisions/%/delete', 'node/%/revisions/%/delete', 'Delete earlier revision', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 3, 0, 5, 52, 152, 0, 0, 0, 0, 0, 0, 0),
('navigation', 153, 52, 'node/%/revisions/%/revert', 'node/%/revisions/%/revert', 'Revert to earlier revision', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 3, 0, 5, 52, 153, 0, 0, 0, 0, 0, 0, 0),
('navigation', 154, 52, 'node/%/revisions/%/view', 'node/%/revisions/%/view', 'Revisions', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 3, 0, 5, 52, 154, 0, 0, 0, 0, 0, 0, 0),
('management', 155, 140, 'admin/structure/block/list/garland/add', 'admin/structure/block/list/garland/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 140, 155, 0, 0, 0, 0, 0),
('management', 156, 146, 'admin/structure/block/list/seven/add', 'admin/structure/block/list/seven/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 146, 156, 0, 0, 0, 0, 0),
('management', 157, 147, 'admin/structure/block/list/stark/add', 'admin/structure/block/list/stark/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 147, 157, 0, 0, 0, 0, 0),
('management', 158, 148, 'admin/structure/block/list/test_theme/add', 'admin/structure/block/list/test_theme/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 148, 158, 0, 0, 0, 0, 0),
('management', 159, 150, 'admin/structure/block/list/update_test_basetheme/add', 'admin/structure/block/list/update_test_basetheme/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 150, 159, 0, 0, 0, 0, 0),
('management', 160, 151, 'admin/structure/block/list/update_test_subtheme/add', 'admin/structure/block/list/update_test_subtheme/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 151, 160, 0, 0, 0, 0, 0),
('management', 161, 149, 'admin/config/regional/date-time/types/add', 'admin/config/regional/date-time/types/add', 'Add date type', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a31383a22416464206e6577206461746520747970652e223b7d7d, 'system', -1, 0, 0, 0, -10, 6, 0, 1, 8, 51, 98, 149, 161, 0, 0, 0, 0),
('management', 162, 139, 'admin/config/regional/date-time/formats/add', 'admin/config/regional/date-time/formats/add', 'Add format', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34333a22416c6c6f7720757365727320746f20616464206164646974696f6e616c206461746520666f726d6174732e223b7d7d, 'system', -1, 0, 0, 0, -10, 6, 0, 1, 8, 51, 98, 139, 162, 0, 0, 0, 0),
('management', 163, 136, 'admin/structure/menu/manage/%/add', 'admin/structure/menu/manage/%/add', 'Add link', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 47, 136, 163, 0, 0, 0, 0, 0),
('management', 164, 30, 'admin/structure/block/manage/%/%', 'admin/structure/block/manage/%/%', 'Configure block', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 21, 30, 164, 0, 0, 0, 0, 0, 0),
('navigation', 165, 31, 'user/%/cancel/confirm/%/%', 'user/%/cancel/confirm/%/%', 'Confirm account cancellation', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 3, 0, 17, 31, 165, 0, 0, 0, 0, 0, 0, 0),
('management', 166, 138, 'admin/structure/types/manage/%/delete', 'admin/structure/types/manage/%/delete', 'Delete', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 21, 36, 138, 166, 0, 0, 0, 0, 0),
('management', 167, 103, 'admin/config/people/ip-blocking/delete/%', 'admin/config/people/ip-blocking/delete/%', 'Delete IP address', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 8, 48, 103, 167, 0, 0, 0, 0, 0),
('management', 168, 90, 'admin/config/system/actions/delete/%', 'admin/config/system/actions/delete/%', 'Delete action', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a31373a2244656c65746520616e20616374696f6e2e223b7d7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 8, 56, 90, 168, 0, 0, 0, 0, 0),
('management', 169, 136, 'admin/structure/menu/manage/%/delete', 'admin/structure/menu/manage/%/delete', 'Delete menu', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 21, 47, 136, 169, 0, 0, 0, 0, 0),
('management', 170, 47, 'admin/structure/menu/item/%/delete', 'admin/structure/menu/item/%/delete', 'Delete menu link', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 21, 47, 170, 0, 0, 0, 0, 0, 0),
('management', 171, 117, 'admin/people/permissions/roles/delete/%', 'admin/people/permissions/roles/delete/%', 'Delete role', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 18, 49, 117, 171, 0, 0, 0, 0, 0),
('management', 172, 130, 'admin/config/content/formats/%/disable', 'admin/config/content/formats/%/disable', 'Disable text format', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 8, 35, 123, 130, 172, 0, 0, 0, 0),
('management', 173, 138, 'admin/structure/types/manage/%/edit', 'admin/structure/types/manage/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 36, 138, 173, 0, 0, 0, 0, 0),
('management', 174, 136, 'admin/structure/menu/manage/%/edit', 'admin/structure/menu/manage/%/edit', 'Edit menu', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 47, 136, 174, 0, 0, 0, 0, 0),
('management', 175, 47, 'admin/structure/menu/item/%/edit', 'admin/structure/menu/item/%/edit', 'Edit menu link', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 21, 47, 175, 0, 0, 0, 0, 0, 0),
('management', 176, 117, 'admin/people/permissions/roles/edit/%', 'admin/people/permissions/roles/edit/%', 'Edit role', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 18, 49, 117, 176, 0, 0, 0, 0, 0),
('management', 178, 136, 'admin/structure/menu/manage/%/list', 'admin/structure/menu/manage/%/list', 'List links', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 5, 0, 1, 21, 47, 136, 178, 0, 0, 0, 0, 0),
('management', 179, 47, 'admin/structure/menu/item/%/reset', 'admin/structure/menu/item/%/reset', 'Reset menu link', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 21, 47, 179, 0, 0, 0, 0, 0, 0),
('management', 182, 138, 'admin/structure/types/manage/%/comment/display', 'admin/structure/types/manage/%/comment/display', 'Comment display', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 4, 5, 0, 1, 21, 36, 138, 182, 0, 0, 0, 0, 0),
('management', 183, 138, 'admin/structure/types/manage/%/comment/fields', 'admin/structure/types/manage/%/comment/fields', 'Comment fields', 0x613a303a7b7d, 'system', -1, 0, 1, 0, 3, 5, 0, 1, 21, 36, 138, 183, 0, 0, 0, 0, 0),
('management', 184, 164, 'admin/structure/block/manage/%/%/configure', 'admin/structure/block/manage/%/%/configure', 'Configure block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 164, 184, 0, 0, 0, 0, 0),
('management', 185, 164, 'admin/structure/block/manage/%/%/delete', 'admin/structure/block/manage/%/%/delete', 'Delete block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 164, 185, 0, 0, 0, 0, 0),
('management', 186, 139, 'admin/config/regional/date-time/formats/%/delete', 'admin/config/regional/date-time/formats/%/delete', 'Delete date format', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34373a22416c6c6f7720757365727320746f2064656c657465206120636f6e66696775726564206461746520666f726d61742e223b7d7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 8, 51, 98, 139, 186, 0, 0, 0, 0),
('management', 187, 149, 'admin/config/regional/date-time/types/%/delete', 'admin/config/regional/date-time/types/%/delete', 'Delete date type', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34353a22416c6c6f7720757365727320746f2064656c657465206120636f6e66696775726564206461746520747970652e223b7d7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 8, 51, 98, 149, 187, 0, 0, 0, 0),
('management', 188, 139, 'admin/config/regional/date-time/formats/%/edit', 'admin/config/regional/date-time/formats/%/edit', 'Edit date format', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34353a22416c6c6f7720757365727320746f2065646974206120636f6e66696775726564206461746520666f726d61742e223b7d7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 8, 51, 98, 139, 188, 0, 0, 0, 0),
('management', 192, 47, 'admin/structure/menu/manage/main-menu', 'admin/structure/menu/manage/%', 'Main menu', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, 0, 4, 0, 1, 21, 47, 192, 0, 0, 0, 0, 0, 0),
('management', 193, 47, 'admin/structure/menu/manage/management', 'admin/structure/menu/manage/%', 'Management', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, 0, 4, 0, 1, 21, 47, 193, 0, 0, 0, 0, 0, 0),
('management', 194, 47, 'admin/structure/menu/manage/navigation', 'admin/structure/menu/manage/%', 'Navigation', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, 0, 4, 0, 1, 21, 47, 194, 0, 0, 0, 0, 0, 0),
('management', 195, 47, 'admin/structure/menu/manage/user-menu', 'admin/structure/menu/manage/%', 'User menu', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, 0, 4, 0, 1, 21, 47, 195, 0, 0, 0, 0, 0, 0),
('shortcut-set-1', 196, 0, 'node/add', 'node/add', 'Add content', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, -20, 1, 0, 196, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('shortcut-set-1', 197, 0, 'admin/content', 'admin/content', 'Find content', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, -19, 1, 0, 197, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('main-menu', 198, 0, '<front>', '', 'Home', 0x613a303a7b7d, 'menu', 0, 1, 0, 0, -50, 1, 1, 198, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 199, 0, 'search', 'search', 'Search', 0x613a303a7b7d, 'system', 1, 0, 0, 0, 0, 1, 0, 199, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 200, 199, 'search/node', 'search/node', 'Content', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 2, 0, 199, 200, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 202, 6, 'node/add/article', 'node/add/article', 'Article', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a38393a22557365203c656d3e61727469636c65733c2f656d3e20666f722074696d652d73656e73697469766520636f6e74656e74206c696b65206e6577732c2070726573732072656c6561736573206f7220626c6f6720706f7374732e223b7d7d, 'system', 0, 0, 0, 0, 0, 2, 0, 6, 202, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 203, 6, 'node/add/page', 'node/add/page', 'Basic page', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a37373a22557365203c656d3e62617369632070616765733c2f656d3e20666f7220796f75722073746174696320636f6e74656e742c207375636820617320616e202741626f75742075732720706167652e223b7d7d, 'system', 0, 0, 0, 0, 0, 2, 0, 6, 203, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 204, 200, 'search/node/%', 'search/node/%', 'Content', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 199, 200, 204, 0, 0, 0, 0, 0, 0, 0),
('management', 206, 19, 'admin/reports/search', 'admin/reports/search', 'Top search phrases', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33333a2256696577206d6f737420706f70756c61722073656172636820706872617365732e223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 19, 206, 0, 0, 0, 0, 0, 0, 0),
('management', 210, 12, 'admin/help/path', 'admin/help/path', 'path', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 210, 0, 0, 0, 0, 0, 0, 0),
('management', 211, 12, 'admin/help/rdf', 'admin/help/rdf', 'rdf', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 211, 0, 0, 0, 0, 0, 0, 0),
('management', 212, 12, 'admin/help/search', 'admin/help/search', 'search', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 212, 0, 0, 0, 0, 0, 0, 0),
('management', 215, 53, 'admin/config/search/settings', 'admin/config/search/settings', 'Search settings', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a36373a22436f6e6669677572652072656c6576616e63652073657474696e677320666f722073656172636820616e64206f7468657220696e646578696e67206f7074696f6e732e223b7d7d, 'system', 0, 0, 0, 0, -10, 4, 0, 1, 8, 53, 215, 0, 0, 0, 0, 0, 0),
('management', 217, 53, 'admin/config/search/path', 'admin/config/search/path', 'URL aliases', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34363a224368616e676520796f7572207369746527732055524c20706174687320627920616c696173696e67207468656d2e223b7d7d, 'system', 0, 0, 1, 0, -5, 4, 0, 1, 8, 53, 217, 0, 0, 0, 0, 0, 0),
('management', 218, 217, 'admin/config/search/path/add', 'admin/config/search/path/add', 'Add alias', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 53, 217, 218, 0, 0, 0, 0, 0),
('management', 220, 215, 'admin/config/search/settings/reindex', 'admin/config/search/settings/reindex', 'Clear index', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 53, 215, 220, 0, 0, 0, 0, 0),
('management', 222, 217, 'admin/config/search/path/list', 'admin/config/search/path/list', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 5, 0, 1, 8, 53, 217, 222, 0, 0, 0, 0, 0),
('management', 224, 217, 'admin/config/search/path/delete/%', 'admin/config/search/path/delete/%', 'Delete alias', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 8, 53, 217, 224, 0, 0, 0, 0, 0),
('management', 226, 217, 'admin/config/search/path/edit/%', 'admin/config/search/path/edit/%', 'Edit alias', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 8, 53, 217, 226, 0, 0, 0, 0, 0),
('management', 269, 19, 'admin/reports/updates', 'admin/reports/updates', 'Available updates', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a38323a22476574206120737461747573207265706f72742061626f757420617661696c61626c65207570646174657320666f7220796f757220696e7374616c6c6564206d6f64756c657320616e64207468656d65732e223b7d7d, 'system', 0, 0, 0, 0, -50, 3, 0, 1, 19, 269, 0, 0, 0, 0, 0, 0, 0),
('management', 270, 16, 'admin/modules/install', 'admin/modules/install', 'Install new module', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 25, 3, 0, 1, 16, 270, 0, 0, 0, 0, 0, 0, 0),
('management', 271, 7, 'admin/appearance/install', 'admin/appearance/install', 'Install new theme', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 25, 3, 0, 1, 7, 271, 0, 0, 0, 0, 0, 0, 0),
('management', 272, 16, 'admin/modules/update', 'admin/modules/update', 'Update', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 3, 0, 1, 16, 272, 0, 0, 0, 0, 0, 0, 0),
('management', 273, 7, 'admin/appearance/update', 'admin/appearance/update', 'Update', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 3, 0, 1, 7, 273, 0, 0, 0, 0, 0, 0, 0),
('management', 274, 12, 'admin/help/update', 'admin/help/update', 'update', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 274, 0, 0, 0, 0, 0, 0, 0),
('management', 275, 269, 'admin/reports/updates/install', 'admin/reports/updates/install', 'Install new module or theme', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 25, 4, 0, 1, 19, 269, 275, 0, 0, 0, 0, 0, 0),
('management', 276, 269, 'admin/reports/updates/update', 'admin/reports/updates/update', 'Update', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 4, 0, 1, 19, 269, 276, 0, 0, 0, 0, 0, 0),
('management', 277, 269, 'admin/reports/updates/list', 'admin/reports/updates/list', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 19, 269, 277, 0, 0, 0, 0, 0, 0),
('management', 278, 269, 'admin/reports/updates/settings', 'admin/reports/updates/settings', 'Settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 50, 4, 0, 1, 19, 269, 278, 0, 0, 0, 0, 0, 0),
('management', 317, 54, 'admin/appearance/settings/corolla', 'admin/appearance/settings/corolla', 'Corolla', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 317, 0, 0, 0, 0, 0, 0);
INSERT INTO `menu_links` (`menu_name`, `mlid`, `plid`, `link_path`, `router_path`, `link_title`, `options`, `module`, `hidden`, `external`, `has_children`, `expanded`, `weight`, `depth`, `customized`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `p8`, `p9`, `updated`) VALUES
('management', 318, 30, 'admin/structure/block/list/corolla', 'admin/structure/block/list/corolla', 'Corolla', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 30, 318, 0, 0, 0, 0, 0, 0),
('main-menu', 321, 0, 'node/1', 'node/%', 'About', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, -47, 1, 1, 321, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 322, 0, 'contact', 'contact', 'Contact', 0x613a303a7b7d, 'system', 1, 0, 0, 0, 0, 1, 0, 322, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 325, 17, 'user/%/contact', 'user/%/contact', 'Contact', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 2, 0, 17, 325, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 326, 21, 'admin/structure/contact', 'admin/structure/contact', 'Contact form', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a37313a2243726561746520612073797374656d20636f6e7461637420666f726d20616e64207365742075702063617465676f7269657320666f722074686520666f726d20746f207573652e223b7d7d, 'system', 0, 0, 1, 0, 0, 3, 0, 1, 21, 326, 0, 0, 0, 0, 0, 0, 0),
('management', 328, 8, 'admin/config/headjs', 'admin/config/headjs', 'HeadJS', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33363a22436f6e6669677572652073657474696e677320666f7220486561646a73206d6f64756c65223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 8, 328, 0, 0, 0, 0, 0, 0, 0),
('management', 329, 12, 'admin/help/contact', 'admin/help/contact', 'contact', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 329, 0, 0, 0, 0, 0, 0, 0),
('management', 330, 12, 'admin/help/headjs', 'admin/help/headjs', 'headjs', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 330, 0, 0, 0, 0, 0, 0, 0),
('management', 332, 326, 'admin/structure/contact/add', 'admin/structure/contact/add', 'Add category', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 4, 0, 1, 21, 326, 332, 0, 0, 0, 0, 0, 0),
('management', 333, 326, 'admin/structure/contact/delete/%', 'admin/structure/contact/delete/%', 'Delete contact', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 21, 326, 333, 0, 0, 0, 0, 0, 0),
('management', 334, 326, 'admin/structure/contact/edit/%', 'admin/structure/contact/edit/%', 'Edit contact category', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 21, 326, 334, 0, 0, 0, 0, 0, 0),
('management', 335, 112, 'admin/config/development/performance/headjs', 'admin/config/development/performance/headjs', 'HeadJS', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33363a22436f6e6669677572652073657474696e677320666f7220486561646a73206d6f64756c65223b7d7d, 'system', -1, 0, 0, 0, 9, 5, 0, 1, 8, 39, 112, 335, 0, 0, 0, 0, 0),
('management', 336, 112, 'admin/config/development/performance/default', 'admin/config/development/performance/default', 'Performance', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 39, 112, 336, 0, 0, 0, 0, 0),
('main-menu', 337, 0, 'contact', 'contact', 'Contact', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a303a22223b7d7d, 'menu', 0, 0, 0, 0, -46, 1, 1, 337, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 338, 6, 'node/add/function', 'node/add/function', 'Function', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a31373a2244727570616c2046756e6374696f6e7321223b7d7d, 'system', 0, 0, 0, 0, 0, 2, 0, 6, 338, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 339, 9, 'admin/content/scheduler', 'admin/content/scheduler', 'Scheduled', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33333a22446973706c61792061206c697374206f66207363686564756c6564206e6f646573223b7d7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 9, 339, 0, 0, 0, 0, 0, 0, 0),
('management', 340, 19, 'admin/reports/mollom', 'admin/reports/mollom', 'Mollom statistics', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a35313a225265706f72747320616e64207573616765207374617469737469637320666f7220746865204d6f6c6c6f6d206d6f64756c652e223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 19, 340, 0, 0, 0, 0, 0, 0, 0),
('management', 341, 12, 'admin/help/globalredirect', 'admin/help/globalredirect', 'globalredirect', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 341, 0, 0, 0, 0, 0, 0, 0),
('management', 342, 12, 'admin/help/mollom', 'admin/help/mollom', 'mollom', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 342, 0, 0, 0, 0, 0, 0, 0),
('management', 343, 12, 'admin/help/scheduler', 'admin/help/scheduler', 'scheduler', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 343, 0, 0, 0, 0, 0, 0, 0),
('management', 344, 56, 'admin/config/system/globalredirect', 'admin/config/system/globalredirect', 'Global Redirect', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a36333a2243686f736520776869636820666561747572657320796f7520776f756c64206c696b6520656e61626c656420666f7220476c6f62616c205265646972656374223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 56, 344, 0, 0, 0, 0, 0, 0),
('management', 345, 35, 'admin/config/content/mollom', 'admin/config/content/mollom', 'Mollom content moderation', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a39333a22436f6e66696775726520686f7720746865204d6f6c6c6f6d2073657276696365206d6f6465726174657320757365722d7375626d697474656420636f6e74656e742073756368206173207370616d20616e642070726f66616e6974792e223b7d7d, 'system', 0, 0, 1, 0, 0, 4, 0, 1, 8, 35, 345, 0, 0, 0, 0, 0, 0),
('management', 346, 35, 'admin/config/content/scheduler', 'admin/config/content/scheduler', 'Scheduler module settings', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34323a22416c6c6f777320736974652061646d696e7320746f20636f6e666967757265207363686564756c65722e223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 35, 346, 0, 0, 0, 0, 0, 0),
('management', 347, 345, 'admin/config/content/mollom/add', 'admin/config/content/mollom/add', 'Add form', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 35, 345, 347, 0, 0, 0, 0, 0),
('management', 348, 345, 'admin/config/content/mollom/blacklist', 'admin/config/content/mollom/blacklist', 'Blacklists', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32313a22436f6e66696775726520626c61636b6c697374732e223b7d7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 35, 345, 348, 0, 0, 0, 0, 0),
('management', 349, 345, 'admin/config/content/mollom/forms', 'admin/config/content/mollom/forms', 'Forms', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 5, 0, 1, 8, 35, 345, 349, 0, 0, 0, 0, 0),
('management', 350, 346, 'admin/config/content/scheduler/cron', 'admin/config/content/scheduler/cron', 'Lightweight Cron', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a39303a2241206c696768747765696768742063726f6e2068616e646c657220746f20616c6c6f77206d6f7265206672657175656e742072756e73206f66205363686564756c65727320696e7465726e616c2063726f6e2073797374656d2e223b7d7d, 'system', -1, 0, 0, 0, 10, 5, 0, 1, 8, 35, 346, 350, 0, 0, 0, 0, 0),
('management', 351, 346, 'admin/config/content/scheduler/default', 'admin/config/content/scheduler/default', 'Settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 5, 5, 0, 1, 8, 35, 346, 351, 0, 0, 0, 0, 0),
('management', 352, 345, 'admin/config/content/mollom/settings', 'admin/config/content/mollom/settings', 'Settings', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34323a22436f6e666967757265204d6f6c6c6f6d206b65797320616e6420676c6f62616c2073657474696e67732e223b7d7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 35, 345, 352, 0, 0, 0, 0, 0),
('management', 353, 346, 'admin/config/content/scheduler/timecheck', 'admin/config/content/scheduler/timecheck', 'Time Check', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a35353a22416c6c6f777320736974652061646d696e20746f20636865636b207468656972207365727665727320696e7465726e616c20636c6f636b223b7d7d, 'system', -1, 0, 0, 0, 15, 5, 0, 1, 8, 35, 346, 353, 0, 0, 0, 0, 0),
('management', 354, 345, 'admin/config/content/mollom/manage/%', 'admin/config/content/mollom/manage/%', 'Configure', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 8, 35, 345, 354, 0, 0, 0, 0, 0),
('management', 355, 348, 'admin/config/content/mollom/blacklist/profanity', 'admin/config/content/mollom/blacklist/profanity', 'Profanity', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33383a22436f6e6669677572652070726f66616e69747920626c61636b6c69737420656e74726965732e223b7d7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 8, 35, 345, 348, 355, 0, 0, 0, 0),
('management', 356, 348, 'admin/config/content/mollom/blacklist/spam', 'admin/config/content/mollom/blacklist/spam', 'Spam', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33333a22436f6e666967757265207370616d20626c61636b6c69737420656e74726965732e223b7d7d, 'system', -1, 0, 0, 0, -10, 6, 0, 1, 8, 35, 345, 348, 356, 0, 0, 0, 0),
('management', 357, 345, 'admin/config/content/mollom/unprotect/%', 'admin/config/content/mollom/unprotect/%', 'Unprotect form', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 5, 0, 1, 8, 35, 345, 357, 0, 0, 0, 0, 0),
('management', 358, 348, 'admin/config/content/mollom/blacklist/unwanted', 'admin/config/content/mollom/blacklist/unwanted', 'Unwanted', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33373a22436f6e66696775726520756e77616e74656420626c61636b6c69737420656e74726965732e223b7d7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 8, 35, 345, 348, 358, 0, 0, 0, 0),
('management', 360, 12, 'admin/help/backup_migrate', 'admin/help/backup_migrate', 'backup_migrate', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 360, 0, 0, 0, 0, 0, 0, 0),
('management', 364, 56, 'admin/config/system/backup_migrate', 'admin/config/system/backup_migrate', 'Backup and Migrate', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a37363a224261636b75702f726573746f726520796f7572206461746162617365206f72206d696772617465206461746120746f206f722066726f6d20616e6f746865722044727570616c20736974652e223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 56, 364, 0, 0, 0, 0, 0, 0),
('management', 369, 364, 'admin/config/system/backup_migrate/export', 'admin/config/system/backup_migrate/export', 'Backup', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32303a224261636b7570207468652064617461626173652e223b7d7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 56, 364, 369, 0, 0, 0, 0, 0),
('management', 371, 364, 'admin/config/system/backup_migrate/destination', 'admin/config/system/backup_migrate/destination', 'Destinations', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 5, 0, 1, 8, 56, 364, 371, 0, 0, 0, 0, 0),
('management', 372, 364, 'admin/config/system/backup_migrate/profile', 'admin/config/system/backup_migrate/profile', 'Profiles', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 5, 0, 1, 8, 56, 364, 372, 0, 0, 0, 0, 0),
('management', 373, 364, 'admin/config/system/backup_migrate/restore', 'admin/config/system/backup_migrate/restore', 'Restore', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34333a22526573746f7265207468652064617461626173652066726f6d20612070726576696f7573206261636b7570223b7d7d, 'system', -1, 0, 0, 0, 1, 5, 0, 1, 8, 56, 364, 373, 0, 0, 0, 0, 0),
('management', 374, 364, 'admin/config/system/backup_migrate/schedule', 'admin/config/system/backup_migrate/schedule', 'Schedules', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 5, 0, 1, 8, 56, 364, 374, 0, 0, 0, 0, 0),
('management', 376, 369, 'admin/config/system/backup_migrate/export/advanced', 'admin/config/system/backup_migrate/export/advanced', 'Advanced Backup', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32303a224261636b7570207468652064617461626173652e223b7d7d, 'system', -1, 0, 0, 0, 1, 6, 0, 1, 8, 56, 364, 369, 376, 0, 0, 0, 0),
('management', 380, 371, 'admin/config/system/backup_migrate/destination/list', 'admin/config/system/backup_migrate/destination/list', 'List !type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 6, 0, 1, 8, 56, 364, 371, 380, 0, 0, 0, 0),
('management', 381, 372, 'admin/config/system/backup_migrate/profile/list', 'admin/config/system/backup_migrate/profile/list', 'List !type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 6, 0, 1, 8, 56, 364, 372, 381, 0, 0, 0, 0),
('management', 382, 374, 'admin/config/system/backup_migrate/schedule/list', 'admin/config/system/backup_migrate/schedule/list', 'List !type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 6, 0, 1, 8, 56, 364, 374, 382, 0, 0, 0, 0),
('management', 383, 369, 'admin/config/system/backup_migrate/export/quick', 'admin/config/system/backup_migrate/export/quick', 'Quick Backup', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32303a224261636b7570207468652064617461626173652e223b7d7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 8, 56, 364, 369, 383, 0, 0, 0, 0),
('management', 388, 380, 'admin/config/system/backup_migrate/destination/list/add', 'admin/config/system/backup_migrate/destination/list/add', 'Add !type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 7, 0, 1, 8, 56, 364, 371, 380, 388, 0, 0, 0),
('management', 389, 381, 'admin/config/system/backup_migrate/profile/list/add', 'admin/config/system/backup_migrate/profile/list/add', 'Add !type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 7, 0, 1, 8, 56, 364, 372, 381, 389, 0, 0, 0),
('management', 390, 382, 'admin/config/system/backup_migrate/schedule/list/add', 'admin/config/system/backup_migrate/schedule/list/add', 'Add !type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 7, 0, 1, 8, 56, 364, 374, 382, 390, 0, 0, 0),
('management', 391, 380, 'admin/config/system/backup_migrate/destination/list/files', 'admin/config/system/backup_migrate/destination/list/files', 'Destination Files', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 8, 56, 364, 371, 380, 391, 0, 0, 0),
('management', 394, 12, 'admin/help/googleanalytics', 'admin/help/googleanalytics', 'googleanalytics', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 394, 0, 0, 0, 0, 0, 0, 0),
('management', 395, 56, 'admin/config/system/googleanalytics', 'admin/config/system/googleanalytics', 'Google Analytics', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a39383a22436f6e66696775726520747261636b696e67206265686176696f7220746f2067657420696e73696768747320696e746f20796f75722077656273697465207472616666696320616e64206d61726b6574696e67206566666563746976656e6573732e223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 56, 395, 0, 0, 0, 0, 0, 0),
('management', 396, 12, 'admin/help/pathauto', 'admin/help/pathauto', 'pathauto', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 396, 0, 0, 0, 0, 0, 0, 0),
('management', 397, 12, 'admin/help/token', 'admin/help/token', 'token', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 397, 0, 0, 0, 0, 0, 0, 0),
('management', 398, 217, 'admin/config/search/path/update_bulk', 'admin/config/search/path/update_bulk', 'Bulk update', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 30, 5, 0, 1, 8, 53, 217, 398, 0, 0, 0, 0, 0),
('management', 399, 217, 'admin/config/search/path/delete_bulk', 'admin/config/search/path/delete_bulk', 'Delete aliases', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 40, 5, 0, 1, 8, 53, 217, 399, 0, 0, 0, 0, 0),
('management', 400, 217, 'admin/config/search/path/patterns', 'admin/config/search/path/patterns', 'Patterns', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 5, 0, 1, 8, 53, 217, 400, 0, 0, 0, 0, 0),
('management', 401, 217, 'admin/config/search/path/settings', 'admin/config/search/path/settings', 'Settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 20, 5, 0, 1, 8, 53, 217, 401, 0, 0, 0, 0, 0),
('management', 403, 21, 'admin/structure/features', 'admin/structure/features', 'Features', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a31363a224d616e6167652066656174757265732e223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 21, 403, 0, 0, 0, 0, 0, 0, 0),
('management', 404, 12, 'admin/help/features', 'admin/help/features', 'features', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 404, 0, 0, 0, 0, 0, 0, 0),
('management', 405, 403, 'admin/structure/features/create', 'admin/structure/features/create', 'Create feature', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32313a224372656174652061206e657720666561747572652e223b7d7d, 'system', -1, 0, 0, 0, 10, 4, 0, 1, 21, 403, 405, 0, 0, 0, 0, 0, 0),
('management', 406, 403, 'admin/structure/features/manage', 'admin/structure/features/manage', 'Manage', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32383a22456e61626c6520616e642064697361626c652066656174757265732e223b7d7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 403, 406, 0, 0, 0, 0, 0, 0),
('management', 407, 403, 'admin/structure/features/%/view', 'admin/structure/features/%/view', 'View', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33323a22446973706c617920636f6d706f6e656e7473206f66206120666561747572652e223b7d7d, 'system', -1, 0, 0, 0, -10, 4, 0, 1, 21, 403, 407, 0, 0, 0, 0, 0, 0),
('management', 408, 403, 'admin/structure/features/%/recreate', 'admin/structure/features/%/recreate', 'Recreate', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32393a22526563726561746520616e206578697374696e6720666561747572652e223b7d7d, 'system', -1, 0, 0, 0, 11, 4, 0, 1, 21, 403, 408, 0, 0, 0, 0, 0, 0),
('management', 409, 21, 'admin/structure/trigger', 'admin/structure/trigger', 'Triggers', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33343a22436f6e666967757265207768656e20746f206578656375746520616374696f6e732e223b7d7d, 'system', 0, 0, 1, 0, 0, 3, 0, 1, 21, 409, 0, 0, 0, 0, 0, 0, 0),
('management', 410, 12, 'admin/help/trigger', 'admin/help/trigger', 'trigger', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 410, 0, 0, 0, 0, 0, 0, 0),
('management', 411, 409, 'admin/structure/trigger/comment', 'admin/structure/trigger/comment', 'Comment', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 409, 411, 0, 0, 0, 0, 0, 0),
('management', 412, 409, 'admin/structure/trigger/node', 'admin/structure/trigger/node', 'Node', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 409, 412, 0, 0, 0, 0, 0, 0),
('management', 413, 409, 'admin/structure/trigger/system', 'admin/structure/trigger/system', 'System', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 409, 413, 0, 0, 0, 0, 0, 0),
('management', 414, 409, 'admin/structure/trigger/taxonomy', 'admin/structure/trigger/taxonomy', 'Taxonomy', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 409, 414, 0, 0, 0, 0, 0, 0),
('management', 415, 409, 'admin/structure/trigger/unassign', 'admin/structure/trigger/unassign', 'Unassign', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33343a22556e61737369676e20616e20616374696f6e2066726f6d206120747269676765722e223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 21, 409, 415, 0, 0, 0, 0, 0, 0),
('management', 416, 409, 'admin/structure/trigger/user', 'admin/structure/trigger/user', 'User', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 409, 416, 0, 0, 0, 0, 0, 0),
('management', 417, 12, 'admin/help/piwik', 'admin/help/piwik', 'piwik', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 417, 0, 0, 0, 0, 0, 0, 0),
('management', 418, 56, 'admin/config/system/piwik', 'admin/config/system/piwik', 'Piwik', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a36353a22436f6e666967757265207468652073657474696e6773207573656420746f2067656e657261746520796f757220506977696b20747261636b696e6720636f64652e223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 56, 418, 0, 0, 0, 0, 0, 0),
('management', 419, 8, 'admin/config/administration', 'admin/config/administration', 'Administration', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32313a2241646d696e697374726174696f6e20746f6f6c732e223b7d7d, 'system', 0, 0, 1, 0, 0, 3, 0, 1, 8, 419, 0, 0, 0, 0, 0, 0, 0),
('management', 420, 12, 'admin/help/admin_menu', 'admin/help/admin_menu', 'admin_menu', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 420, 0, 0, 0, 0, 0, 0, 0),
('management', 421, 419, 'admin/config/administration/admin_menu', 'admin/config/administration/admin_menu', 'Administration menu', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33363a2241646a7573742061646d696e697374726174696f6e206d656e752073657474696e67732e223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 419, 421, 0, 0, 0, 0, 0, 0),
('management', 498, 61, 'admin/config/user-interface/modulefilter', 'admin/config/user-interface/modulefilter', 'Module filter', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a33373a22436f6e6669677572652073657474696e677320666f72204d6f64756c652046696c7465722e223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 61, 498, 0, 0, 0, 0, 0, 0),
('management', 537, 53, 'admin/config/search/metatags_quick', 'admin/config/search/metatags_quick', 'Meta tags (quick) settings', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 53, 537, 0, 0, 0, 0, 0, 0),
('management', 538, 537, 'admin/config/search/metatags_quick/settings', 'admin/config/search/metatags_quick/settings', 'General', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 53, 537, 538, 0, 0, 0, 0, 0),
('management', 539, 537, 'admin/config/search/metatags_quick/upgrade', 'admin/config/search/metatags_quick/upgrade', 'Upgrade from nodewords', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 53, 537, 539, 0, 0, 0, 0, 0),
('management', 590, 35, 'admin/config/content/easysocial', 'admin/config/content/easysocial', 'Easy Social Settings', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a34333a22436f6e6669677572652074686520736f6369616c20627574746f6e7320616e64206e6f6465207479706573223b7d7d, 'system', 0, 0, 0, 0, 0, 4, 0, 1, 8, 35, 590, 0, 0, 0, 0, 0, 0),
('management', 641, 54, 'admin/appearance/settings/dfotw_corolla', 'admin/appearance/settings/dfotw_corolla', 'DFOTW Corolla', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 7, 54, 641, 0, 0, 0, 0, 0, 0),
('management', 642, 30, 'admin/structure/block/list/dfotw_corolla', 'admin/structure/block/list/dfotw_corolla', 'DFOTW Corolla', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 4, 0, 1, 21, 30, 642, 0, 0, 0, 0, 0, 0),
('management', 644, 318, 'admin/structure/block/list/corolla/add', 'admin/structure/block/list/corolla/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 318, 644, 0, 0, 0, 0, 0),
('management', 646, 134, 'admin/structure/block/list/bartik/add', 'admin/structure/block/list/bartik/add', 'Add block', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 30, 134, 646, 0, 0, 0, 0, 0),
('management', 647, 21, 'admin/structure/context', 'admin/structure/context', 'Context', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a38343a224173736f6369617465206d656e75732c2076696577732c20626c6f636b732c206574632e207769746820646966666572656e7420636f6e746578747320746f2073747275637475726520796f757220736974652e223b7d7d, 'system', 0, 0, 0, 0, 0, 3, 0, 1, 21, 647, 0, 0, 0, 0, 0, 0, 0),
('management', 648, 12, 'admin/help/context', 'admin/help/context', 'context', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 648, 0, 0, 0, 0, 0, 0, 0),
('management', 649, 12, 'admin/help/context_ui', 'admin/help/context_ui', 'context_ui', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 649, 0, 0, 0, 0, 0, 0, 0),
('management', 650, 647, 'admin/structure/context/add', 'admin/structure/context/add', 'Add', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 647, 650, 0, 0, 0, 0, 0, 0),
('management', 651, 647, 'admin/structure/context/import', 'admin/structure/context/import', 'Import', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 4, 0, 1, 21, 647, 651, 0, 0, 0, 0, 0, 0),
('management', 652, 647, 'admin/structure/context/list', 'admin/structure/context/list', 'List', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 4, 0, 1, 21, 647, 652, 0, 0, 0, 0, 0, 0),
('management', 653, 647, 'admin/structure/context/settings', 'admin/structure/context/settings', 'Settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 3, 4, 0, 1, 21, 647, 653, 0, 0, 0, 0, 0, 0),
('management', 654, 652, 'admin/structure/context/list/%/edit', 'admin/structure/context/list/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 5, 0, 1, 21, 647, 652, 654, 0, 0, 0, 0, 0),
('management', 655, 652, 'admin/structure/context/list/%/export', 'admin/structure/context/list/%/export', 'Export', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 21, 647, 652, 655, 0, 0, 0, 0, 0),
('management', 656, 537, 'admin/config/search/metatags_quick/display', 'admin/config/search/metatags_quick/display', 'Manage display', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 5, 0, 1, 8, 53, 537, 656, 0, 0, 0, 0, 0),
('management', 657, 127, 'admin/structure/taxonomy/%/display', 'admin/structure/taxonomy/%/display', 'Manage display', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 5, 0, 1, 21, 57, 127, 657, 0, 0, 0, 0, 0),
('management', 658, 89, 'admin/config/people/accounts/display', 'admin/config/people/accounts/display', 'Manage display', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 5, 0, 1, 8, 48, 89, 658, 0, 0, 0, 0, 0),
('management', 659, 537, 'admin/config/search/metatags_quick/fields', 'admin/config/search/metatags_quick/fields', 'Manage fields', 0x613a303a7b7d, 'system', -1, 0, 1, 0, 1, 5, 0, 1, 8, 53, 537, 659, 0, 0, 0, 0, 0),
('management', 660, 127, 'admin/structure/taxonomy/%/fields', 'admin/structure/taxonomy/%/fields', 'Manage fields', 0x613a303a7b7d, 'system', -1, 0, 1, 0, 1, 5, 0, 1, 21, 57, 127, 660, 0, 0, 0, 0, 0),
('management', 661, 89, 'admin/config/people/accounts/fields', 'admin/config/people/accounts/fields', 'Manage fields', 0x613a303a7b7d, 'system', -1, 0, 1, 0, 1, 5, 0, 1, 8, 48, 89, 661, 0, 0, 0, 0, 0),
('management', 662, 656, 'admin/config/search/metatags_quick/display/default', 'admin/config/search/metatags_quick/display/default', 'Default', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 6, 0, 1, 8, 53, 537, 656, 662, 0, 0, 0, 0),
('management', 663, 657, 'admin/structure/taxonomy/%/display/default', 'admin/structure/taxonomy/%/display/default', 'Default', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 6, 0, 1, 21, 57, 127, 657, 663, 0, 0, 0, 0),
('management', 664, 658, 'admin/config/people/accounts/display/default', 'admin/config/people/accounts/display/default', 'Default', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 6, 0, 1, 8, 48, 89, 658, 664, 0, 0, 0, 0),
('management', 665, 138, 'admin/structure/types/manage/%/display', 'admin/structure/types/manage/%/display', 'Manage display', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 5, 0, 1, 21, 36, 138, 665, 0, 0, 0, 0, 0),
('management', 666, 138, 'admin/structure/types/manage/%/fields', 'admin/structure/types/manage/%/fields', 'Manage fields', 0x613a303a7b7d, 'system', -1, 0, 1, 0, 1, 5, 0, 1, 21, 36, 138, 666, 0, 0, 0, 0, 0),
('management', 667, 657, 'admin/structure/taxonomy/%/display/full', 'admin/structure/taxonomy/%/display/full', 'Taxonomy term page', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 21, 57, 127, 657, 667, 0, 0, 0, 0),
('management', 668, 657, 'admin/structure/taxonomy/%/display/token', 'admin/structure/taxonomy/%/display/token', 'Tokens', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 6, 0, 1, 21, 57, 127, 657, 668, 0, 0, 0, 0),
('management', 669, 658, 'admin/config/people/accounts/display/token', 'admin/config/people/accounts/display/token', 'Tokens', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 6, 0, 1, 8, 48, 89, 658, 669, 0, 0, 0, 0),
('management', 670, 658, 'admin/config/people/accounts/display/full', 'admin/config/people/accounts/display/full', 'User account', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 8, 48, 89, 658, 670, 0, 0, 0, 0),
('management', 671, 659, 'admin/config/search/metatags_quick/fields/%', 'admin/config/search/metatags_quick/fields/%', '', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 8, 53, 537, 659, 671, 0, 0, 0, 0),
('management', 672, 660, 'admin/structure/taxonomy/%/fields/%', 'admin/structure/taxonomy/%/fields/%', '', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 21, 57, 127, 660, 672, 0, 0, 0, 0),
('management', 673, 661, 'admin/config/people/accounts/fields/%', 'admin/config/people/accounts/fields/%', '', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 8, 48, 89, 661, 673, 0, 0, 0, 0),
('management', 674, 665, 'admin/structure/types/manage/%/display/default', 'admin/structure/types/manage/%/display/default', 'Default', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 6, 0, 1, 21, 36, 138, 665, 674, 0, 0, 0, 0),
('management', 675, 665, 'admin/structure/types/manage/%/display/full', 'admin/structure/types/manage/%/display/full', 'Full content', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 21, 36, 138, 665, 675, 0, 0, 0, 0),
('management', 676, 665, 'admin/structure/types/manage/%/display/rss', 'admin/structure/types/manage/%/display/rss', 'RSS', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 2, 6, 0, 1, 21, 36, 138, 665, 676, 0, 0, 0, 0),
('management', 677, 665, 'admin/structure/types/manage/%/display/search_index', 'admin/structure/types/manage/%/display/search_index', 'Search index', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 3, 6, 0, 1, 21, 36, 138, 665, 677, 0, 0, 0, 0),
('management', 678, 665, 'admin/structure/types/manage/%/display/search_result', 'admin/structure/types/manage/%/display/search_result', 'Search result', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 4, 6, 0, 1, 21, 36, 138, 665, 678, 0, 0, 0, 0),
('management', 679, 665, 'admin/structure/types/manage/%/display/teaser', 'admin/structure/types/manage/%/display/teaser', 'Teaser', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 6, 0, 1, 21, 36, 138, 665, 679, 0, 0, 0, 0),
('management', 680, 665, 'admin/structure/types/manage/%/display/token', 'admin/structure/types/manage/%/display/token', 'Tokens', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 5, 6, 0, 1, 21, 36, 138, 665, 680, 0, 0, 0, 0),
('management', 681, 671, 'admin/config/search/metatags_quick/fields/%/delete', 'admin/config/search/metatags_quick/fields/%/delete', 'Delete', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 7, 0, 1, 8, 53, 537, 659, 671, 681, 0, 0, 0),
('management', 682, 671, 'admin/config/search/metatags_quick/fields/%/edit', 'admin/config/search/metatags_quick/fields/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 8, 53, 537, 659, 671, 682, 0, 0, 0),
('management', 683, 671, 'admin/config/search/metatags_quick/fields/%/field-settings', 'admin/config/search/metatags_quick/fields/%/field-settings', 'Field settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 8, 53, 537, 659, 671, 683, 0, 0, 0),
('management', 684, 671, 'admin/config/search/metatags_quick/fields/%/widget-type', 'admin/config/search/metatags_quick/fields/%/widget-type', 'Widget type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 8, 53, 537, 659, 671, 684, 0, 0, 0),
('management', 685, 666, 'admin/structure/types/manage/%/fields/%', 'admin/structure/types/manage/%/fields/%', '', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 21, 36, 138, 666, 685, 0, 0, 0, 0),
('management', 686, 672, 'admin/structure/taxonomy/%/fields/%/delete', 'admin/structure/taxonomy/%/fields/%/delete', 'Delete', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 7, 0, 1, 21, 57, 127, 660, 672, 686, 0, 0, 0),
('management', 687, 672, 'admin/structure/taxonomy/%/fields/%/edit', 'admin/structure/taxonomy/%/fields/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 57, 127, 660, 672, 687, 0, 0, 0),
('management', 688, 672, 'admin/structure/taxonomy/%/fields/%/field-settings', 'admin/structure/taxonomy/%/fields/%/field-settings', 'Field settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 57, 127, 660, 672, 688, 0, 0, 0),
('management', 689, 672, 'admin/structure/taxonomy/%/fields/%/widget-type', 'admin/structure/taxonomy/%/fields/%/widget-type', 'Widget type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 57, 127, 660, 672, 689, 0, 0, 0),
('management', 690, 673, 'admin/config/people/accounts/fields/%/delete', 'admin/config/people/accounts/fields/%/delete', 'Delete', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 7, 0, 1, 8, 48, 89, 661, 673, 690, 0, 0, 0),
('management', 691, 673, 'admin/config/people/accounts/fields/%/edit', 'admin/config/people/accounts/fields/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 8, 48, 89, 661, 673, 691, 0, 0, 0),
('management', 692, 673, 'admin/config/people/accounts/fields/%/field-settings', 'admin/config/people/accounts/fields/%/field-settings', 'Field settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 8, 48, 89, 661, 673, 692, 0, 0, 0),
('management', 693, 673, 'admin/config/people/accounts/fields/%/widget-type', 'admin/config/people/accounts/fields/%/widget-type', 'Widget type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 8, 48, 89, 661, 673, 693, 0, 0, 0),
('management', 694, 182, 'admin/structure/types/manage/%/comment/display/default', 'admin/structure/types/manage/%/comment/display/default', 'Default', 0x613a303a7b7d, 'system', -1, 0, 0, 0, -10, 6, 0, 1, 21, 36, 138, 182, 694, 0, 0, 0, 0),
('management', 695, 182, 'admin/structure/types/manage/%/comment/display/full', 'admin/structure/types/manage/%/comment/display/full', 'Full comment', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 21, 36, 138, 182, 695, 0, 0, 0, 0),
('management', 696, 182, 'admin/structure/types/manage/%/comment/display/token', 'admin/structure/types/manage/%/comment/display/token', 'Tokens', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 1, 6, 0, 1, 21, 36, 138, 182, 696, 0, 0, 0, 0),
('management', 697, 183, 'admin/structure/types/manage/%/comment/fields/%', 'admin/structure/types/manage/%/comment/fields/%', '', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 21, 36, 138, 183, 697, 0, 0, 0, 0),
('management', 698, 685, 'admin/structure/types/manage/%/fields/%/delete', 'admin/structure/types/manage/%/fields/%/delete', 'Delete', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 7, 0, 1, 21, 36, 138, 666, 685, 698, 0, 0, 0),
('management', 699, 685, 'admin/structure/types/manage/%/fields/%/edit', 'admin/structure/types/manage/%/fields/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 36, 138, 666, 685, 699, 0, 0, 0),
('management', 700, 685, 'admin/structure/types/manage/%/fields/%/field-settings', 'admin/structure/types/manage/%/fields/%/field-settings', 'Field settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 36, 138, 666, 685, 700, 0, 0, 0),
('management', 701, 685, 'admin/structure/types/manage/%/fields/%/widget-type', 'admin/structure/types/manage/%/fields/%/widget-type', 'Widget type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 36, 138, 666, 685, 701, 0, 0, 0),
('management', 702, 697, 'admin/structure/types/manage/%/comment/fields/%/delete', 'admin/structure/types/manage/%/comment/fields/%/delete', 'Delete', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 7, 0, 1, 21, 36, 138, 183, 697, 702, 0, 0, 0),
('management', 703, 697, 'admin/structure/types/manage/%/comment/fields/%/edit', 'admin/structure/types/manage/%/comment/fields/%/edit', 'Edit', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 36, 138, 183, 697, 703, 0, 0, 0),
('management', 704, 697, 'admin/structure/types/manage/%/comment/fields/%/field-settings', 'admin/structure/types/manage/%/comment/fields/%/field-settings', 'Field settings', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 36, 138, 183, 697, 704, 0, 0, 0),
('management', 705, 697, 'admin/structure/types/manage/%/comment/fields/%/widget-type', 'admin/structure/types/manage/%/comment/fields/%/widget-type', 'Widget type', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 7, 0, 1, 21, 36, 138, 183, 697, 705, 0, 0, 0),
('shortcut-set-1', 708, 0, 'node/add', 'node/add', 'Add content', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, -20, 1, 0, 708, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('shortcut-set-1', 709, 0, 'admin/content', 'admin/content', 'Find content', 0x613a303a7b7d, 'menu', 0, 0, 0, 0, -19, 1, 0, 709, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 710, 17, 'user/%/shortcuts', 'user/%/shortcuts', 'Shortcuts', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 2, 0, 17, 710, 0, 0, 0, 0, 0, 0, 0, 0),
('management', 711, 12, 'admin/help/shortcut', 'admin/help/shortcut', 'shortcut', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 3, 0, 1, 12, 711, 0, 0, 0, 0, 0, 0, 0),
('management', 713, 61, 'admin/config/user-interface/shortcut', 'admin/config/user-interface/shortcut', 'Shortcuts', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a32393a2241646420616e64206d6f646966792073686f727463757420736574732e223b7d7d, 'system', 0, 0, 1, 0, 0, 4, 0, 1, 8, 61, 713, 0, 0, 0, 0, 0, 0),
('management', 714, 713, 'admin/config/user-interface/shortcut/add-set', 'admin/config/user-interface/shortcut/add-set', 'Add shortcut set', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 5, 0, 1, 8, 61, 713, 714, 0, 0, 0, 0, 0),
('management', 715, 713, 'admin/config/user-interface/shortcut/%', 'admin/config/user-interface/shortcut/%', 'Edit shortcuts', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 5, 0, 1, 8, 61, 713, 715, 0, 0, 0, 0, 0),
('management', 716, 715, 'admin/config/user-interface/shortcut/%/add-link', 'admin/config/user-interface/shortcut/%/add-link', 'Add shortcut', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 8, 61, 713, 715, 716, 0, 0, 0, 0),
('management', 717, 715, 'admin/config/user-interface/shortcut/%/delete', 'admin/config/user-interface/shortcut/%/delete', 'Delete shortcut set', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 8, 61, 713, 715, 717, 0, 0, 0, 0),
('management', 718, 715, 'admin/config/user-interface/shortcut/%/edit', 'admin/config/user-interface/shortcut/%/edit', 'Edit set name', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 10, 6, 0, 1, 8, 61, 713, 715, 718, 0, 0, 0, 0),
('management', 719, 713, 'admin/config/user-interface/shortcut/link/%', 'admin/config/user-interface/shortcut/link/%', 'Edit shortcut', 0x613a303a7b7d, 'system', 0, 0, 1, 0, 0, 5, 0, 1, 8, 61, 713, 719, 0, 0, 0, 0, 0),
('management', 720, 715, 'admin/config/user-interface/shortcut/%/links', 'admin/config/user-interface/shortcut/%/links', 'List links', 0x613a303a7b7d, 'system', -1, 0, 0, 0, 0, 6, 0, 1, 8, 61, 713, 715, 720, 0, 0, 0, 0),
('management', 721, 719, 'admin/config/user-interface/shortcut/link/%/delete', 'admin/config/user-interface/shortcut/link/%/delete', 'Delete shortcut', 0x613a303a7b7d, 'system', 0, 0, 0, 0, 0, 6, 0, 1, 8, 61, 713, 719, 721, 0, 0, 0, 0),
('main-menu', 722, 0, 'user', 'user', 'My Account', 0x613a313a7b733a31303a2261747472696275746573223b613a313a7b733a353a227469746c65223b733a303a22223b7d7d, 'menu', 0, 0, 0, 0, 0, 1, 1, 722, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu_router`
--

CREATE TABLE IF NOT EXISTS `menu_router` (
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: the Drupal path this entry describes',
  `load_functions` blob NOT NULL COMMENT 'A serialized array of function names (like node_load) to be called to load an object corresponding to a part of the current path.',
  `to_arg_functions` blob NOT NULL COMMENT 'A serialized array of function names (like user_uid_optional_to_arg) to be called to replace a part of the router path with another string.',
  `access_callback` varchar(255) NOT NULL DEFAULT '' COMMENT 'The callback which determines the access to this router path. Defaults to user_access.',
  `access_arguments` blob COMMENT 'A serialized array of arguments for the access callback.',
  `page_callback` varchar(255) NOT NULL DEFAULT '' COMMENT 'The name of the function that renders the page.',
  `page_arguments` blob COMMENT 'A serialized array of arguments for the page callback.',
  `delivery_callback` varchar(255) NOT NULL DEFAULT '' COMMENT 'The name of the function that sends the result of the page_callback function to the browser.',
  `fit` int(11) NOT NULL DEFAULT '0' COMMENT 'A numeric representation of how specific the path is.',
  `number_parts` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Number of parts in this router path.',
  `context` int(11) NOT NULL DEFAULT '0' COMMENT 'Only for local tasks (tabs) - the context of a local task to control its placement.',
  `tab_parent` varchar(255) NOT NULL DEFAULT '' COMMENT 'Only for local tasks (tabs) - the router path of the parent page (which may also be a local task).',
  `tab_root` varchar(255) NOT NULL DEFAULT '' COMMENT 'Router path of the closest non-tab parent page. For pages that are not local tasks, this will be the same as the path.',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT 'The title for the current page, or the title for the tab if this is a local task.',
  `title_callback` varchar(255) NOT NULL DEFAULT '' COMMENT 'A function which will alter the title. Defaults to t()',
  `title_arguments` varchar(255) NOT NULL DEFAULT '' COMMENT 'A serialized array of arguments for the title callback. If empty, the title will be used as the sole argument for the title callback.',
  `theme_callback` varchar(255) NOT NULL DEFAULT '' COMMENT 'A function which returns the name of the theme that will be used to render this page. If left empty, the default theme will be used.',
  `theme_arguments` varchar(255) NOT NULL DEFAULT '' COMMENT 'A serialized array of arguments for the theme callback.',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'Numeric representation of the type of the menu item, like MENU_LOCAL_TASK.',
  `description` text NOT NULL COMMENT 'A description of this item.',
  `position` varchar(255) NOT NULL DEFAULT '' COMMENT 'The position of the block (left or right) on the system administration page for this item.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'Weight of the element. Lighter weights are higher up, heavier weights go down.',
  `include_file` mediumtext COMMENT 'The file to include for this element, usually the page callback function lives in this file.',
  PRIMARY KEY (`path`),
  KEY `fit` (`fit`),
  KEY `tab_parent` (`tab_parent`(64),`weight`,`title`),
  KEY `tab_root_weight_title` (`tab_root`(64),`weight`,`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu_router`
--

INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `delivery_callback`, `fit`, `number_parts`, `context`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `theme_callback`, `theme_arguments`, `type`, `description`, `position`, `weight`, `include_file`) VALUES
('admin', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 1, 1, 0, '', 'admin', 'Administration', 't', '', '', 'a:0:{}', 6, '', '', 9, 'modules/system/system.admin.inc'),
('admin/appearance', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572207468656d6573223b7d, 'system_themes_page', 0x613a303a7b7d, '', 3, 2, 0, '', 'admin/appearance', 'Appearance', 't', '', '', 'a:0:{}', 6, 'Select and configure your themes.', 'left', -6, 'modules/system/system.admin.inc'),
('admin/appearance/default', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572207468656d6573223b7d, 'system_theme_default', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/appearance/default', 'Set default theme', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/disable', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572207468656d6573223b7d, 'system_theme_disable', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/appearance/disable', 'Disable theme', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/enable', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572207468656d6573223b7d, 'system_theme_enable', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/appearance/enable', 'Enable theme', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/install', '', '', 'update_manager_access', 0x613a303a7b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32373a227570646174655f6d616e616765725f696e7374616c6c5f666f726d223b693a313b733a353a227468656d65223b7d, '', 7, 3, 1, 'admin/appearance', 'admin/appearance', 'Install new theme', 't', '', '', 'a:0:{}', 388, '', '', 25, 'modules/update/update.manager.inc'),
('admin/appearance/list', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572207468656d6573223b7d, 'system_themes_page', 0x613a303a7b7d, '', 7, 3, 1, 'admin/appearance', 'admin/appearance', 'List', 't', '', '', 'a:0:{}', 140, 'Select and configure your theme', '', -1, 'modules/system/system.admin.inc'),
('admin/appearance/settings', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572207468656d6573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b7d, '', 7, 3, 1, 'admin/appearance', 'admin/appearance', 'Settings', 't', '', '', 'a:0:{}', 132, 'Configure default and theme specific settings.', '', 20, 'modules/system/system.admin.inc'),
('admin/appearance/settings/bartik', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32353a227468656d65732f62617274696b2f62617274696b2e696e666f223b733a343a226e616d65223b733a363a2262617274696b223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a363a2242617274696b223b733a31313a226465736372697074696f6e223b733a34383a224120666c657869626c652c207265636f6c6f7261626c65207468656d652077697468206d616e7920726567696f6e732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a31343a226373732f6c61796f75742e637373223b733a32383a227468656d65732f62617274696b2f6373732f6c61796f75742e637373223b733a31333a226373732f7374796c652e637373223b733a32373a227468656d65732f62617274696b2f6373732f7374796c652e637373223b733a31343a226373732f636f6c6f72732e637373223b733a32383a227468656d65732f62617274696b2f6373732f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a31333a226373732f7072696e742e637373223b733a32373a227468656d65732f62617274696b2f6373732f7072696e742e637373223b7d7d733a373a22726567696f6e73223b613a31373a7b733a363a22686561646572223b733a363a22486561646572223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a383a226665617475726564223b733a383a224665617475726564223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31333a22736964656261725f6669727374223b733a31333a2253696465626172206669727374223b733a31343a22736964656261725f7365636f6e64223b733a31343a2253696465626172207365636f6e64223b733a31343a2274726970747963685f6669727374223b733a31343a225472697074796368206669727374223b733a31353a2274726970747963685f6d6964646c65223b733a31353a225472697074796368206d6964646c65223b733a31333a2274726970747963685f6c617374223b733a31333a225472697074796368206c617374223b733a31383a22666f6f7465725f6669727374636f6c756d6e223b733a31393a22466f6f74657220666972737420636f6c756d6e223b733a31393a22666f6f7465725f7365636f6e64636f6c756d6e223b733a32303a22466f6f746572207365636f6e6420636f6c756d6e223b733a31383a22666f6f7465725f7468697264636f6c756d6e223b733a31393a22466f6f74657220746869726420636f6c756d6e223b733a31393a22666f6f7465725f666f75727468636f6c756d6e223b733a32303a22466f6f74657220666f7572746820636f6c756d6e223b733a363a22666f6f746572223b733a363a22466f6f746572223b7d733a383a2273657474696e6773223b613a313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2230223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32383a227468656d65732f62617274696b2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a31343a226373732f6c61796f75742e637373223b733a32383a227468656d65732f62617274696b2f6373732f6c61796f75742e637373223b733a31333a226373732f7374796c652e637373223b733a32373a227468656d65732f62617274696b2f6373732f7374796c652e637373223b733a31343a226373732f636f6c6f72732e637373223b733a32383a227468656d65732f62617274696b2f6373732f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a31333a226373732f7072696e742e637373223b733a32373a227468656d65732f62617274696b2f6373732f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a363a2262617274696b223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Bartik', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/settings/corolla', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a33373a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f726f6c6c612e696e666f223b733a343a226e616d65223b733a373a22636f726f6c6c61223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a373a22436f726f6c6c61223b733a31313a226465736372697074696f6e223b733a39323a224120636f6c6f7261626c652c20666c756964207769647468207468656d652c2077697468206d696e20616e64206d6178207769647468732c20746861742063616e20737570706f727420312c2032206f72203320636f6c756d6e732e223b733a373a2276657273696f6e223b733a383a22372e782d312e3231223b733a343a22636f7265223b733a333a22372e78223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a363a7b693a303b733a343a226c6f676f223b693a313b733a343a226e616d65223b693a323b733a363a22736c6f67616e223b693a333b733a31373a226e6f64655f757365725f70696374757265223b693a343b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a353b733a373a2266617669636f6e223b7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a383a22626173652e637373223b733a33333a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f626173652e637373223b733a393a227374796c652e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7374796c652e637373223b733a31303a22636f6c6f72732e637373223b733a33353a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7072696e742e637373223b7d7d733a373a22726567696f6e73223b613a31313a7b733a31313a226865616465725f6d656e75223b733a31313a22486561646572206d656e75223b733a31313a22666f6f7465725f6d656e75223b733a31313a22466f6f746572206d656e75223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31343a225365636f6e642073696465626172223b733a393a22686967686c69676874223b733a31313a22486967686c696768746564223b733a31313a22636f6e74656e745f746f70223b733a31313a22436f6e74656e7420746f70223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31343a22636f6e74656e745f626f74746f6d223b733a31343a22436f6e74656e7420626f74746f6d223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a2273657474696e6773223b613a31313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a31383a22c2a9203230313020596f7572204e616d652e223b7d733a373a2270726f6a656374223b733a373a22636f726f6c6c61223b733a393a22646174657374616d70223b733a31303a2231323934373737323831223b733a31303a2273637265656e73686f74223b733a33393a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a383a22626173652e637373223b733a33333a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f626173652e637373223b733a393a227374796c652e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7374796c652e637373223b733a31303a22636f6c6f72732e637373223b733a33353a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a373a22636f726f6c6c61223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Corolla', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/settings/dfotw_corolla', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31323a7b733a383a2266696c656e616d65223b733a34393a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e696e666f223b733a343a226e616d65223b733a31333a2264666f74775f636f726f6c6c61223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2231223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31343a7b733a343a226e616d65223b733a31333a2244464f545720436f726f6c6c61223b733a31313a226465736372697074696f6e223b733a34393a22436f726f6c6c61207375622d7468656d6520666f722044727570616c2046756e6374696f6e206f6620746865205765656b223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a2262617365207468656d65223b733a373a22636f726f6c6c61223b733a383a226665617475726573223b613a363a7b693a303b733a343a226c6f676f223b693a313b733a343a226e616d65223b693a323b733a363a22736c6f67616e223b693a333b733a31373a226e6f64655f757365725f70696374757265223b693a343b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a353b733a373a2266617669636f6e223b7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31373a2264666f74775f636f726f6c6c612e637373223b733a34383a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e637373223b7d7d733a373a22726567696f6e73223b613a31313a7b733a31313a226865616465725f6d656e75223b733a31313a22486561646572206d656e75223b733a31313a22666f6f7465725f6d656e75223b733a31313a22466f6f746572206d656e75223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31343a225365636f6e642073696465626172223b733a393a22686967686c69676874223b733a31313a22486967686c696768746564223b733a31313a22636f6e74656e745f746f70223b733a31313a22436f6e74656e7420746f70223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31343a22636f6e74656e745f626f74746f6d223b733a31343a22436f6e74656e7420626f74746f6d223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a2273657474696e6773223b613a31313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a38303a22c2a92032303131203c6120687265663d22687474703a2f2f77656264726f702e6e65742e627222207469746c653d2257656264726f70222072656c3d22666f6c6c6f77223e57656264726f703c2f613e223b7d733a31303a2273637265656e73686f74223b733a34353a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31373a2264666f74775f636f726f6c6c612e637373223b733a34383a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a22626173655f7468656d65223b733a373a22636f726f6c6c61223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a31333a2264666f74775f636f726f6c6c61223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'DFOTW Corolla', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/settings/garland', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32373a227468656d65732f6761726c616e642f6761726c616e642e696e666f223b733a343a226e616d65223b733a373a226761726c616e64223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a373a224761726c616e64223b733a31313a226465736372697074696f6e223b733a3131313a2241206d756c74692d636f6c756d6e207468656d652077686963682063616e20626520636f6e6669677572656420746f206d6f6469667920636f6c6f727320616e6420737769746368206265747765656e20666978656420616e6420666c756964207769647468206c61796f7574732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a313a7b733a393a227374796c652e637373223b733a32343a227468656d65732f6761726c616e642f7374796c652e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a32343a227468656d65732f6761726c616e642f7072696e742e637373223b7d7d733a383a2273657474696e6773223b613a313a7b733a31333a226761726c616e645f7769647468223b733a353a22666c756964223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32393a227468656d65732f6761726c616e642f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a313a7b733a393a227374796c652e637373223b733a32343a227468656d65732f6761726c616e642f7374796c652e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a32343a227468656d65732f6761726c616e642f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a373a226761726c616e64223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Garland', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/settings/global', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572207468656d6573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Global settings', 't', '', '', 'a:0:{}', 140, '', '', -1, 'modules/system/system.admin.inc'),
('admin/appearance/settings/seven', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32333a227468656d65732f736576656e2f736576656e2e696e666f223b733a343a226e616d65223b733a353a22736576656e223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a353a22536576656e223b733a31313a226465736372697074696f6e223b733a36353a22412073696d706c65206f6e652d636f6c756d6e2c207461626c656c6573732c20666c7569642077696474682061646d696e697374726174696f6e207468656d652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a313a7b733a363a2273637265656e223b613a323a7b733a393a2272657365742e637373223b733a32323a227468656d65732f736576656e2f72657365742e637373223b733a393a227374796c652e637373223b733a32323a227468656d65732f736576656e2f7374796c652e637373223b7d7d733a383a2273657474696e6773223b613a313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b7d733a373a22726567696f6e73223b613a353a7b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b7d733a31343a22726567696f6e735f68696464656e223b613a333a7b693a303b733a31333a22736964656261725f6669727374223b693a313b733a383a22706167655f746f70223b693a323b733a31313a22706167655f626f74746f6d223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32373a227468656d65732f736576656e2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d7d733a31313a227374796c65736865657473223b613a313a7b733a363a2273637265656e223b613a323a7b733a393a2272657365742e637373223b733a32323a227468656d65732f736576656e2f72657365742e637373223b733a393a227374796c652e637373223b733a32323a227468656d65732f736576656e2f7374796c652e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a353a22736576656e223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Seven', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/settings/stark', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32333a227468656d65732f737461726b2f737461726b2e696e666f223b733a343a226e616d65223b733a353a22737461726b223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a353a22537461726b223b733a31313a226465736372697074696f6e223b733a3230383a2254686973207468656d652064656d6f6e737472617465732044727570616c27732064656661756c742048544d4c206d61726b757020616e6420435353207374796c65732e20546f206c6561726e20686f7720746f206275696c6420796f7572206f776e207468656d6520616e64206f766572726964652044727570616c27732064656661756c7420636f64652c2073656520746865203c6120687265663d22687474703a2f2f64727570616c2e6f72672f7468656d652d6775696465223e5468656d696e672047756964653c2f613e2e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a226c61796f75742e637373223b733a32333a227468656d65732f737461726b2f6c61796f75742e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32373a227468656d65732f737461726b2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a226c61796f75742e637373223b733a32333a227468656d65732f737461726b2f6c61796f75742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a353a22737461726b223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Stark', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/settings/test_theme', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a33393a227468656d65732f74657374732f746573745f7468656d652f746573745f7468656d652e696e666f223b733a343a226e616d65223b733a31303a22746573745f7468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a31303a2254657374207468656d65223b733a31313a226465736372697074696f6e223b733a33343a225468656d6520666f722074657374696e6720746865207468656d652073797374656d223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31353a2273797374656d2e626173652e637373223b733a33393a227468656d65732f74657374732f746573745f7468656d652f73797374656d2e626173652e637373223b7d7d733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a33383a227468656d65732f74657374732f746573745f7468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31353a2273797374656d2e626173652e637373223b733a33393a227468656d65732f74657374732f746573745f7468656d652f73797374656d2e626173652e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a31303a22746573745f7468656d65223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Test theme', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/settings/update_test_basetheme', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31303a7b733a383a2266696c656e616d65223b733a36313a227468656d65732f74657374732f7570646174655f746573745f626173657468656d652f7570646174655f746573745f626173657468656d652e696e666f223b733a343a226e616d65223b733a32313a227570646174655f746573745f626173657468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a32323a2255706461746520746573742062617365207468656d65223b733a31313a226465736372697074696f6e223b733a36333a2254657374207468656d65207768696368206163747320617320612062617365207468656d6520666f72206f746865722074657374207375627468656d65732e223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a34393a227468656d65732f74657374732f7570646174655f746573745f626173657468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a31313a227374796c65736865657473223b613a303a7b7d733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a32313a227570646174655f746573745f626173657468656d65223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Update test base theme', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/settings/update_test_subtheme', '', '', '_system_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a35393a227468656d65732f74657374732f7570646174655f746573745f7375627468656d652f7570646174655f746573745f7375627468656d652e696e666f223b733a343a226e616d65223b733a32303a227570646174655f746573745f7375627468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a32303a225570646174652074657374207375627468656d65223b733a31313a226465736372697074696f6e223b733a36323a2254657374207468656d652077686963682075736573207570646174655f746573745f626173657468656d65206173207468652062617365207468656d652e223b733a343a22636f7265223b733a333a22372e78223b733a31303a2262617365207468656d65223b733a32313a227570646174655f746573745f626173657468656d65223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a34383a227468656d65732f74657374732f7570646174655f746573745f7375627468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a31313a227374796c65736865657473223b613a303a7b7d733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a22626173655f7468656d65223b733a32313a227570646174655f746573745f626173657468656d65223b7d7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2273797374656d5f7468656d655f73657474696e6773223b693a313b733a32303a227570646174655f746573745f7375627468656d65223b7d, '', 15, 4, 1, 'admin/appearance/settings', 'admin/appearance', 'Update test subtheme', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/system/system.admin.inc'),
('admin/appearance/update', '', '', 'update_manager_access', 0x613a303a7b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a227570646174655f6d616e616765725f7570646174655f666f726d223b693a313b733a353a227468656d65223b7d, '', 7, 3, 1, 'admin/appearance', 'admin/appearance', 'Update', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/update/update.manager.inc'),
('admin/compact', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_compact_page', 0x613a303a7b7d, '', 3, 2, 0, '', 'admin/compact', 'Compact mode', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/config', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_config_page', 0x613a303a7b7d, '', 3, 2, 0, '', 'admin/config', 'Configuration', 't', '', '', 'a:0:{}', 6, 'Administer settings.', '', 0, 'modules/system/system.admin.inc'),
('admin/config/administration', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/administration', 'Administration', 't', '', '', 'a:0:{}', 6, 'Administration tools.', '', 0, 'modules/system/system.admin.inc'),
('admin/config/administration/admin_menu', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32353a2261646d696e5f6d656e755f7468656d655f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/administration/admin_menu', 'Administration menu', 't', '', '', 'a:0:{}', 6, 'Adjust administration menu settings.', '', 0, 'sites/all/modules/contrib/admin_menu/admin_menu.inc'),
('admin/config/content', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/content', 'Content authoring', 't', '', '', 'a:0:{}', 6, 'Settings related to formatting and authoring content.', 'left', -15, 'modules/system/system.admin.inc'),
('admin/config/content/easysocial', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e6973746572206561737920736f6369616c223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32343a2261646d696e5f636f6e6669675f656173795f736f6369616c223b7d, '', 15, 4, 0, '', 'admin/config/content/easysocial', 'Easy Social Settings', 't', '', '', 'a:0:{}', 6, 'Configure the social buttons and node types', '', 0, ''),
('admin/config/content/formats', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e69737465722066696c74657273223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32313a2266696c7465725f61646d696e5f6f76657276696577223b7d, '', 15, 4, 0, '', 'admin/config/content/formats', 'Text formats', 't', '', '', 'a:0:{}', 6, 'Configure how content input by users is filtered, including allowed HTML tags. Also allows enabling of module-provided filters.', '', 0, 'modules/filter/filter.admin.inc'),
('admin/config/content/formats/%', 0x613a313a7b693a343b733a31383a2266696c7465725f666f726d61745f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e69737465722066696c74657273223b7d, 'filter_admin_format_page', 0x613a313a7b693a303b693a343b7d, '', 30, 5, 0, '', 'admin/config/content/formats/%', '', 'filter_admin_format_title', 'a:1:{i:0;i:4;}', '', 'a:0:{}', 6, '', '', 0, 'modules/filter/filter.admin.inc'),
('admin/config/content/formats/%/disable', 0x613a313a7b693a343b733a31383a2266696c7465725f666f726d61745f6c6f6164223b7d, '', '_filter_disable_format_access', 0x613a313a7b693a303b693a343b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32303a2266696c7465725f61646d696e5f64697361626c65223b693a313b693a343b7d, '', 61, 6, 0, '', 'admin/config/content/formats/%/disable', 'Disable text format', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/filter/filter.admin.inc'),
('admin/config/content/formats/add', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e69737465722066696c74657273223b7d, 'filter_admin_format_page', 0x613a303a7b7d, '', 31, 5, 1, 'admin/config/content/formats', 'admin/config/content/formats', 'Add text format', 't', '', '', 'a:0:{}', 388, '', '', 1, 'modules/filter/filter.admin.inc'),
('admin/config/content/formats/list', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e69737465722066696c74657273223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32313a2266696c7465725f61646d696e5f6f76657276696577223b7d, '', 31, 5, 1, 'admin/config/content/formats', 'admin/config/content/formats', 'List', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/filter/filter.admin.inc'),
('admin/config/content/mollom', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'mollom_admin_form_list', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/config/content/mollom', 'Mollom content moderation', 't', '', '', 'a:0:{}', 6, 'Configure how the Mollom service moderates user-submitted content such as spam and profanity.', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32373a226d6f6c6c6f6d5f61646d696e5f636f6e6669677572655f666f726d223b7d, '', 31, 5, 1, 'admin/config/content/mollom', 'admin/config/content/mollom', 'Add form', 't', '', '', 'a:0:{}', 388, '', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/blacklist', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32373a226d6f6c6c6f6d5f61646d696e5f626c61636b6c6973745f666f726d223b7d, '', 31, 5, 1, 'admin/config/content/mollom', 'admin/config/content/mollom', 'Blacklists', 't', '', '', 'a:0:{}', 132, 'Configure blacklists.', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/blacklist/delete', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32393a226d6f6c6c6f6d5f61646d696e5f626c61636b6c6973745f64656c657465223b7d, '', 63, 6, 0, '', 'admin/config/content/mollom/blacklist/delete', 'Delete', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/blacklist/profanity', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32373a226d6f6c6c6f6d5f61646d696e5f626c61636b6c6973745f666f726d223b693a313b693a353b7d, '', 63, 6, 1, 'admin/config/content/mollom/blacklist', 'admin/config/content/mollom', 'Profanity', 't', '', '', 'a:0:{}', 132, 'Configure profanity blacklist entries.', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/blacklist/spam', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32373a226d6f6c6c6f6d5f61646d696e5f626c61636b6c6973745f666f726d223b7d, '', 63, 6, 1, 'admin/config/content/mollom/blacklist', 'admin/config/content/mollom', 'Spam', 't', '', '', 'a:0:{}', 140, 'Configure spam blacklist entries.', '', -10, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/blacklist/unwanted', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32373a226d6f6c6c6f6d5f61646d696e5f626c61636b6c6973745f666f726d223b693a313b693a353b7d, '', 63, 6, 1, 'admin/config/content/mollom/blacklist', 'admin/config/content/mollom', 'Unwanted', 't', '', '', 'a:0:{}', 132, 'Configure unwanted blacklist entries.', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/forms', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'mollom_admin_form_list', 0x613a303a7b7d, '', 31, 5, 1, 'admin/config/content/mollom', 'admin/config/content/mollom', 'Forms', 't', '', '', 'a:0:{}', 140, '', '', -10, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/manage/%', 0x613a313a7b693a353b733a31363a226d6f6c6c6f6d5f666f726d5f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32373a226d6f6c6c6f6d5f61646d696e5f636f6e6669677572655f666f726d223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/config/content/mollom/manage/%', 'Configure', 't', '', '', 'a:0:{}', 6, '', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/settings', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32313a226d6f6c6c6f6d5f61646d696e5f73657474696e6773223b7d, '', 31, 5, 1, 'admin/config/content/mollom', 'admin/config/content/mollom', 'Settings', 't', '', '', 'a:0:{}', 132, 'Configure Mollom keys and global settings.', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/mollom/unprotect/%', 0x613a313a7b693a353b733a31363a226d6f6c6c6f6d5f666f726d5f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e6973746572206d6f6c6c6f6d223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32373a226d6f6c6c6f6d5f61646d696e5f756e70726f746563745f666f726d223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/config/content/mollom/unprotect/%', 'Unprotect form', 't', '', '', 'a:0:{}', 6, '', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/config/content/scheduler', '', '', 'user_access', 0x613a313a7b693a303b733a32303a2261646d696e6973746572207363686564756c6572223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31353a227363686564756c65725f61646d696e223b7d, '', 15, 4, 0, '', 'admin/config/content/scheduler', 'Scheduler module settings', 't', '', '', 'a:0:{}', 6, 'Allows site admins to configure scheduler.', '', 0, ''),
('admin/config/content/scheduler/cron', '', '', '1', 0x613a313a7b693a303b733a32303a2261646d696e6973746572207363686564756c6572223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32373a225f7363686564756c65725f6c696768747765696768745f63726f6e223b7d, '', 31, 5, 1, 'admin/config/content/scheduler', 'admin/config/content/scheduler', 'Lightweight Cron', 't', '', '', 'a:0:{}', 132, 'A lightweight cron handler to allow more frequent runs of Schedulers internal cron system.', '', 10, '');
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `delivery_callback`, `fit`, `number_parts`, `context`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `theme_callback`, `theme_arguments`, `type`, `description`, `position`, `weight`, `include_file`) VALUES
('admin/config/content/scheduler/default', '', '', 'user_access', 0x613a313a7b693a303b733a32303a2261646d696e6973746572207363686564756c6572223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31353a227363686564756c65725f61646d696e223b7d, '', 31, 5, 1, 'admin/config/content/scheduler', 'admin/config/content/scheduler', 'Settings', 't', '', '', 'a:0:{}', 140, '', '', 5, ''),
('admin/config/content/scheduler/timecheck', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, '_scheduler_timecheck', 0x613a303a7b7d, '', 31, 5, 1, 'admin/config/content/scheduler', 'admin/config/content/scheduler', 'Time Check', 't', '', '', 'a:0:{}', 132, 'Allows site admin to check their servers internal clock', '', 15, ''),
('admin/config/development', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/development', 'Development', 't', '', '', 'a:0:{}', 6, 'Development tools.', 'right', -10, 'modules/system/system.admin.inc'),
('admin/config/development/logging', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32333a2273797374656d5f6c6f6767696e675f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/development/logging', 'Logging and errors', 't', '', '', 'a:0:{}', 6, 'Settings for logging and alerts modules. Various modules can route Drupal''s system events to different destinations, such as syslog, database, email, etc.', '', -15, 'modules/system/system.admin.inc'),
('admin/config/development/maintenance', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32383a2273797374656d5f736974655f6d61696e74656e616e63655f6d6f6465223b7d, '', 15, 4, 0, '', 'admin/config/development/maintenance', 'Maintenance mode', 't', '', '', 'a:0:{}', 6, 'Take the site offline for maintenance or bring it back online.', '', -10, 'modules/system/system.admin.inc'),
('admin/config/development/performance', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32373a2273797374656d5f706572666f726d616e63655f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/development/performance', 'Performance', 't', '', '', 'a:0:{}', 6, 'Enable or disable page caching for anonymous users and set CSS and JS bandwidth optimization options.', '', -20, 'modules/system/system.admin.inc'),
('admin/config/development/performance/default', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32373a2273797374656d5f706572666f726d616e63655f73657474696e6773223b7d, '', 31, 5, 1, 'admin/config/development/performance', 'admin/config/development/performance', 'Performance', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/system/system.admin.inc'),
('admin/config/development/performance/headjs', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220686561646a73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31353a22686561646a735f73657474696e6773223b7d, '', 31, 5, 1, 'admin/config/development/performance', 'admin/config/development/performance', 'HeadJS', 't', '', '', 'a:0:{}', 132, 'Configure settings for Headjs module', '', 9, 'sites/all/modules/contrib/headjs/includes/headjs.admin.inc'),
('admin/config/headjs', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220686561646a73223b7d, 'drupal_goto', 0x613a313a7b693a303b733a33333a2261646d696e2f73657474696e67732f706572666f726d616e63652f686561646a73223b7d, '', 7, 3, 0, '', 'admin/config/headjs', 'HeadJS', 't', '', '', 'a:0:{}', 6, 'Configure settings for Headjs module', '', 0, ''),
('admin/config/media', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/media', 'Media', 't', '', '', 'a:0:{}', 6, 'Media tools.', 'left', -10, 'modules/system/system.admin.inc'),
('admin/config/media/file-system', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32373a2273797374656d5f66696c655f73797374656d5f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/media/file-system', 'File system', 't', '', '', 'a:0:{}', 6, 'Tell Drupal where to store uploaded files and how they are accessed.', '', -10, 'modules/system/system.admin.inc'),
('admin/config/media/image-toolkit', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32393a2273797374656d5f696d6167655f746f6f6c6b69745f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/media/image-toolkit', 'Image toolkit', 't', '', '', 'a:0:{}', 6, 'Choose which image toolkit to use if you have installed optional toolkits.', '', 20, 'modules/system/system.admin.inc'),
('admin/config/people', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/people', 'People', 't', '', '', 'a:0:{}', 6, 'Configure user accounts.', 'left', -20, 'modules/system/system.admin.inc'),
('admin/config/people/accounts', '', '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31393a22757365725f61646d696e5f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/people/accounts', 'Account settings', 't', '', '', 'a:0:{}', 6, 'Configure default behavior of users, including registration requirements, e-mails, fields, and user pictures.', '', -10, 'modules/user/user.admin.inc'),
('admin/config/people/accounts/display', '', '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a2275736572223b693a323b733a343a2275736572223b693a333b733a373a2264656661756c74223b7d, '', 31, 5, 1, 'admin/config/people/accounts', 'admin/config/people/accounts', 'Manage display', 't', '', '', 'a:0:{}', 132, '', '', 2, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/display/default', '', '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a373a2264656661756c74223b693a333b733a31313a22757365725f616363657373223b693a343b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a2275736572223b693a323b733a343a2275736572223b693a333b733a373a2264656661756c74223b7d, '', 63, 6, 1, 'admin/config/people/accounts/display', 'admin/config/people/accounts', 'Default', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/display/full', '', '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a343a2266756c6c223b693a333b733a31313a22757365725f616363657373223b693a343b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a2275736572223b693a323b733a343a2275736572223b693a333b733a343a2266756c6c223b7d, '', 63, 6, 1, 'admin/config/people/accounts/display', 'admin/config/people/accounts', 'User account', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/display/token', '', '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a353a22746f6b656e223b693a333b733a31313a22757365725f616363657373223b693a343b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a2275736572223b693a323b733a343a2275736572223b693a333b733a353a22746f6b656e223b7d, '', 63, 6, 1, 'admin/config/people/accounts/display', 'admin/config/people/accounts', 'Tokens', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/fields', '', '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a32383a226669656c645f75695f6669656c645f6f766572766965775f666f726d223b693a313b733a343a2275736572223b693a323b733a343a2275736572223b7d, '', 31, 5, 1, 'admin/config/people/accounts', 'admin/config/people/accounts', 'Manage fields', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/fields/%', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/config/people/accounts/fields/%', '', 'field_ui_menu_title', 'a:1:{i:0;i:5;}', '', 'a:0:{}', 6, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/fields/%/delete', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a226669656c645f75695f6669656c645f64656c6574655f666f726d223b693a313b693a353b7d, '', 125, 7, 1, 'admin/config/people/accounts/fields/%', 'admin/config/people/accounts/fields/%', 'Delete', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/fields/%/edit', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a353b7d, '', 125, 7, 1, 'admin/config/people/accounts/fields/%', 'admin/config/people/accounts/fields/%', 'Edit', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/fields/%/field-settings', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32383a226669656c645f75695f6669656c645f73657474696e67735f666f726d223b693a313b693a353b7d, '', 125, 7, 1, 'admin/config/people/accounts/fields/%', 'admin/config/people/accounts/fields/%', 'Field settings', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/fields/%/widget-type', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a226669656c645f75695f7769646765745f747970655f666f726d223b693a313b693a353b7d, '', 125, 7, 1, 'admin/config/people/accounts/fields/%', 'admin/config/people/accounts/fields/%', 'Widget type', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/people/accounts/groups/%/delete', 0x613a313a7b693a353b613a313a7b733a32313a226669656c645f67726f75705f6d656e755f6c6f6164223b613a343a7b693a303b733a343a2275736572223b693a313b733a343a2275736572223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32333a226669656c645f67726f75705f64656c6574655f666f726d223b693a313b693a353b7d, '', 125, 7, 0, '', 'admin/config/people/accounts/groups/%/delete', 'Delete', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/field_group/field_group.field_ui.inc'),
('admin/config/people/accounts/settings', '', '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31393a22757365725f61646d696e5f73657474696e6773223b7d, '', 31, 5, 1, 'admin/config/people/accounts', 'admin/config/people/accounts', 'Settings', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/user/user.admin.inc'),
('admin/config/people/ip-blocking', '', '', 'user_access', 0x613a313a7b693a303b733a31383a22626c6f636b20495020616464726573736573223b7d, 'system_ip_blocking', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/config/people/ip-blocking', 'IP address blocking', 't', '', '', 'a:0:{}', 6, 'Manage blocked IP addresses.', '', 10, 'modules/system/system.admin.inc'),
('admin/config/people/ip-blocking/delete/%', 0x613a313a7b693a353b733a31353a22626c6f636b65645f69705f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31383a22626c6f636b20495020616464726573736573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a2273797374656d5f69705f626c6f636b696e675f64656c657465223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/config/people/ip-blocking/delete/%', 'Delete IP address', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/system/system.admin.inc'),
('admin/config/regional', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/regional', 'Regional and language', 't', '', '', 'a:0:{}', 6, 'Regional settings, localization and translation.', 'left', -5, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32353a2273797374656d5f646174655f74696d655f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/regional/date-time', 'Date and time', 't', '', '', 'a:0:{}', 6, 'Configure display formats for date and time.', '', -15, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time/formats', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'system_date_time_formats', 0x613a303a7b7d, '', 31, 5, 1, 'admin/config/regional/date-time', 'admin/config/regional/date-time', 'Formats', 't', '', '', 'a:0:{}', 132, 'Configure display format strings for date and time.', '', -9, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time/formats/%/delete', 0x613a313a7b693a353b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a33303a2273797374656d5f646174655f64656c6574655f666f726d61745f666f726d223b693a313b693a353b7d, '', 125, 7, 0, '', 'admin/config/regional/date-time/formats/%/delete', 'Delete date format', 't', '', '', 'a:0:{}', 6, 'Allow users to delete a configured date format.', '', 0, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time/formats/%/edit', 0x613a313a7b693a353b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a33343a2273797374656d5f636f6e6669677572655f646174655f666f726d6174735f666f726d223b693a313b693a353b7d, '', 125, 7, 0, '', 'admin/config/regional/date-time/formats/%/edit', 'Edit date format', 't', '', '', 'a:0:{}', 6, 'Allow users to edit a configured date format.', '', 0, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time/formats/add', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a33343a2273797374656d5f636f6e6669677572655f646174655f666f726d6174735f666f726d223b7d, '', 63, 6, 1, 'admin/config/regional/date-time/formats', 'admin/config/regional/date-time', 'Add format', 't', '', '', 'a:0:{}', 388, 'Allow users to add additional date formats.', '', -10, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time/formats/lookup', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'system_date_time_lookup', 0x613a303a7b7d, '', 63, 6, 0, '', 'admin/config/regional/date-time/formats/lookup', 'Date and time lookup', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time/types', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32353a2273797374656d5f646174655f74696d655f73657474696e6773223b7d, '', 31, 5, 1, 'admin/config/regional/date-time', 'admin/config/regional/date-time', 'Types', 't', '', '', 'a:0:{}', 140, 'Configure display formats for date and time.', '', -10, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time/types/%/delete', 0x613a313a7b693a353b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a33353a2273797374656d5f64656c6574655f646174655f666f726d61745f747970655f666f726d223b693a313b693a353b7d, '', 125, 7, 0, '', 'admin/config/regional/date-time/types/%/delete', 'Delete date type', 't', '', '', 'a:0:{}', 6, 'Allow users to delete a configured date type.', '', 0, 'modules/system/system.admin.inc'),
('admin/config/regional/date-time/types/add', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a33323a2273797374656d5f6164645f646174655f666f726d61745f747970655f666f726d223b7d, '', 63, 6, 1, 'admin/config/regional/date-time/types', 'admin/config/regional/date-time', 'Add date type', 't', '', '', 'a:0:{}', 388, 'Add new date type.', '', -10, 'modules/system/system.admin.inc'),
('admin/config/regional/settings', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32343a2273797374656d5f726567696f6e616c5f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/regional/settings', 'Regional settings', 't', '', '', 'a:0:{}', 6, 'Settings for the site''s default time zone and country.', '', -20, 'modules/system/system.admin.inc'),
('admin/config/search', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/search', 'Search and metadata', 't', '', '', 'a:0:{}', 6, 'Local site search, metadata and SEO.', 'left', -10, 'modules/system/system.admin.inc'),
('admin/config/search/clean-urls', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32353a2273797374656d5f636c65616e5f75726c5f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/search/clean-urls', 'Clean URLs', 't', '', '', 'a:0:{}', 6, 'Enable or disable clean URLs for your site.', '', 5, 'modules/system/system.admin.inc'),
('admin/config/search/clean-urls/check', '', '', '1', 0x613a303a7b7d, 'drupal_json_output', 0x613a313a7b693a303b613a313a7b733a363a22737461747573223b623a313b7d7d, '', 31, 5, 0, '', 'admin/config/search/clean-urls/check', 'Clean URL check', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/config/search/metatags_quick', '', '', 'user_access', 0x613a313a7b693a303b733a32353a2261646d696e6973746572206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32393a226d657461746167735f717569636b5f61646d696e5f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/search/metatags_quick', 'Meta tags (quick) settings', 't', '', '', 'a:0:{}', 6, '', '', 0, 'sites/all/modules/contrib/metatags_quick/metatags_quick.admin.inc'),
('admin/config/search/metatags_quick/display', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a31393a226d657461746167735f706174685f6261736564223b693a333b733a373a2264656661756c74223b7d, '', 31, 5, 1, 'admin/config/search/metatags_quick', 'admin/config/search/metatags_quick', 'Manage display', 't', '', '', 'a:0:{}', 132, '', '', 2, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/search/metatags_quick/display/default', '', '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a31393a226d657461746167735f706174685f6261736564223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a373a2264656661756c74223b693a333b733a31313a22757365725f616363657373223b693a343b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a31393a226d657461746167735f706174685f6261736564223b693a333b733a373a2264656661756c74223b7d, '', 63, 6, 1, 'admin/config/search/metatags_quick/display', 'admin/config/search/metatags_quick', 'Default', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/search/metatags_quick/fields', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a32383a226669656c645f75695f6669656c645f6f766572766965775f666f726d223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a31393a226d657461746167735f706174685f6261736564223b7d, '', 31, 5, 1, 'admin/config/search/metatags_quick', 'admin/config/search/metatags_quick', 'Manage fields', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/search/metatags_quick/fields/%', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31393a226d657461746167735f706174685f6261736564223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/config/search/metatags_quick/fields/%', '', 'field_ui_menu_title', 'a:1:{i:0;i:5;}', '', 'a:0:{}', 6, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/search/metatags_quick/fields/%/delete', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31393a226d657461746167735f706174685f6261736564223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a226669656c645f75695f6669656c645f64656c6574655f666f726d223b693a313b693a353b7d, '', 125, 7, 1, 'admin/config/search/metatags_quick/fields/%', 'admin/config/search/metatags_quick/fields/%', 'Delete', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/search/metatags_quick/fields/%/edit', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31393a226d657461746167735f706174685f6261736564223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a353b7d, '', 125, 7, 1, 'admin/config/search/metatags_quick/fields/%', 'admin/config/search/metatags_quick/fields/%', 'Edit', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/search/metatags_quick/fields/%/field-settings', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31393a226d657461746167735f706174685f6261736564223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32383a226669656c645f75695f6669656c645f73657474696e67735f666f726d223b693a313b693a353b7d, '', 125, 7, 1, 'admin/config/search/metatags_quick/fields/%', 'admin/config/search/metatags_quick/fields/%', 'Field settings', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/search/metatags_quick/fields/%/widget-type', 0x613a313a7b693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31393a226d657461746167735f706174685f6261736564223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a226669656c645f75695f7769646765745f747970655f666f726d223b693a313b693a353b7d, '', 125, 7, 1, 'admin/config/search/metatags_quick/fields/%', 'admin/config/search/metatags_quick/fields/%', 'Widget type', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/config/search/metatags_quick/groups/%/delete', 0x613a313a7b693a353b613a313a7b733a32313a226669656c645f67726f75705f6d656e755f6c6f6164223b613a343a7b693a303b733a31393a226d657461746167735f706174685f6261736564223b693a313b733a31393a226d657461746167735f706174685f6261736564223b693a323b733a313a2230223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32333a226669656c645f67726f75705f64656c6574655f666f726d223b693a313b693a353b7d, '', 125, 7, 0, '', 'admin/config/search/metatags_quick/groups/%/delete', 'Delete', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/field_group/field_group.field_ui.inc'),
('admin/config/search/metatags_quick/path', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2265646974206d657461746167735f717569636b223b7d, 'metatags_quick_admin_path_page', 0x613a303a7b7d, '', 31, 5, 0, '', 'admin/config/search/metatags_quick/path', 'Edit meta tags', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/metatags_quick/metatags_quick.admin.inc'),
('admin/config/search/metatags_quick/settings', '', '', 'user_access', 0x613a313a7b693a303b733a32353a2261646d696e6973746572206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32393a226d657461746167735f717569636b5f61646d696e5f73657474696e6773223b7d, '', 31, 5, 1, 'admin/config/search/metatags_quick', 'admin/config/search/metatags_quick', 'General', 't', '', '', 'a:0:{}', 140, '', '', 0, 'sites/all/modules/contrib/metatags_quick/metatags_quick.admin.inc'),
('admin/config/search/metatags_quick/upgrade', '', '', 'user_access', 0x613a313a7b693a303b733a32353a2261646d696e6973746572206d657461746167735f717569636b223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32323a226d657461746167735f717569636b5f75706772616465223b7d, '', 31, 5, 1, 'admin/config/search/metatags_quick', 'admin/config/search/metatags_quick', 'Upgrade from nodewords', 't', '', '', 'a:0:{}', 132, '', '', 0, 'sites/all/modules/contrib/metatags_quick/nodewords_upgrade.inc'),
('admin/config/search/path', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e69737465722075726c20616c6961736573223b7d, 'path_admin_overview', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/config/search/path', 'URL aliases', 't', '', '', 'a:0:{}', 6, 'Change your site''s URL paths by aliasing them.', '', -5, 'modules/path/path.admin.inc'),
('admin/config/search/path/add', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e69737465722075726c20616c6961736573223b7d, 'path_admin_edit', 0x613a303a7b7d, '', 31, 5, 1, 'admin/config/search/path', 'admin/config/search/path', 'Add alias', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/path/path.admin.inc'),
('admin/config/search/path/delete/%', 0x613a313a7b693a353b733a393a22706174685f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e69737465722075726c20616c6961736573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a22706174685f61646d696e5f64656c6574655f636f6e6669726d223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/config/search/path/delete/%', 'Delete alias', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/path/path.admin.inc'),
('admin/config/search/path/delete_bulk', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e69737465722075726c20616c6961736573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32313a22706174686175746f5f61646d696e5f64656c657465223b7d, '', 31, 5, 1, 'admin/config/search/path', 'admin/config/search/path', 'Delete aliases', 't', '', '', 'a:0:{}', 132, '', '', 40, 'sites/all/modules/contrib/pathauto/pathauto.admin.inc'),
('admin/config/search/path/edit/%', 0x613a313a7b693a353b733a393a22706174685f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e69737465722075726c20616c6961736573223b7d, 'path_admin_edit', 0x613a313a7b693a303b693a353b7d, '', 62, 6, 0, '', 'admin/config/search/path/edit/%', 'Edit alias', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/path/path.admin.inc'),
('admin/config/search/path/list', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e69737465722075726c20616c6961736573223b7d, 'path_admin_overview', 0x613a303a7b7d, '', 31, 5, 1, 'admin/config/search/path', 'admin/config/search/path', 'List', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/path/path.admin.inc'),
('admin/config/search/path/patterns', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e697374657220706174686175746f223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32323a22706174686175746f5f7061747465726e735f666f726d223b7d, '', 31, 5, 1, 'admin/config/search/path', 'admin/config/search/path', 'Patterns', 't', '', '', 'a:0:{}', 132, '', '', 10, 'sites/all/modules/contrib/pathauto/pathauto.admin.inc'),
('admin/config/search/path/settings', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e697374657220706174686175746f223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32323a22706174686175746f5f73657474696e67735f666f726d223b7d, '', 31, 5, 1, 'admin/config/search/path', 'admin/config/search/path', 'Settings', 't', '', '', 'a:0:{}', 132, '', '', 20, 'sites/all/modules/contrib/pathauto/pathauto.admin.inc'),
('admin/config/search/path/update_bulk', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e69737465722075726c20616c6961736573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32353a22706174686175746f5f62756c6b5f7570646174655f666f726d223b7d, '', 31, 5, 1, 'admin/config/search/path', 'admin/config/search/path', 'Bulk update', 't', '', '', 'a:0:{}', 132, '', '', 30, 'sites/all/modules/contrib/pathauto/pathauto.admin.inc'),
('admin/config/search/settings', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220736561726368223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32313a227365617263685f61646d696e5f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/search/settings', 'Search settings', 't', '', '', 'a:0:{}', 6, 'Configure relevance settings for search and other indexing options.', '', -10, 'modules/search/search.admin.inc'),
('admin/config/search/settings/reindex', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220736561726368223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32323a227365617263685f7265696e6465785f636f6e6669726d223b7d, '', 31, 5, 0, '', 'admin/config/search/settings/reindex', 'Clear index', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/search/search.admin.inc'),
('admin/config/services', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/services', 'Web services', 't', '', '', 'a:0:{}', 6, 'Tools related to web services.', 'right', 0, 'modules/system/system.admin.inc'),
('admin/config/services/rss-publishing', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32353a2273797374656d5f7273735f66656564735f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/services/rss-publishing', 'RSS publishing', 't', '', '', 'a:0:{}', 6, 'Configure the site description, the number of items per feed and whether feeds should be titles/teasers/full-text.', '', 0, 'modules/system/system.admin.inc'),
('admin/config/system', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/system', 'System', 't', '', '', 'a:0:{}', 6, 'General system related configuration.', 'right', -20, 'modules/system/system.admin.inc'),
('admin/config/system/actions', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'system_actions_manage', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/config/system/actions', 'Actions', 't', '', '', 'a:0:{}', 6, 'Manage the actions defined for your site.', '', 0, 'modules/system/system.admin.inc'),
('admin/config/system/actions/configure', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32343a2273797374656d5f616374696f6e735f636f6e666967757265223b7d, '', 31, 5, 0, '', 'admin/config/system/actions/configure', 'Configure an advanced action', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/system/system.admin.inc'),
('admin/config/system/actions/delete/%', 0x613a313a7b693a353b733a31323a22616374696f6e735f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a2273797374656d5f616374696f6e735f64656c6574655f666f726d223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/config/system/actions/delete/%', 'Delete action', 't', '', '', 'a:0:{}', 6, 'Delete an action.', '', 0, 'modules/system/system.admin.inc'),
('admin/config/system/actions/manage', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'system_actions_manage', 0x613a303a7b7d, '', 31, 5, 1, 'admin/config/system/actions', 'admin/config/system/actions', 'Manage actions', 't', '', '', 'a:0:{}', 140, 'Manage the actions defined for your site.', '', -2, 'modules/system/system.admin.inc'),
('admin/config/system/actions/orphan', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'system_actions_remove_orphans', 0x613a303a7b7d, '', 31, 5, 0, '', 'admin/config/system/actions/orphan', 'Remove orphans', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/config/system/backup_migrate', '', '', 'user_access', 0x613a313a7b693a303b733a32353a22616363657373206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a303a22223b693a313b733a33373a226261636b75705f6d6967726174655f75695f6d616e75616c5f6261636b75705f717569636b223b693a323b623a313b7d, '', 15, 4, 0, '', 'admin/config/system/backup_migrate', 'Backup and Migrate', 't', '', '', 'a:0:{}', 6, 'Backup/restore your database or migrate data to or from another Drupal site.', '', 0, ''),
('admin/config/system/backup_migrate/destination', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f6c697374223b693a323b623a313b7d, '', 31, 5, 1, 'admin/config/system/backup_migrate', 'admin/config/system/backup_migrate', 'Destinations', 't', '', '', 'a:0:{}', 132, '', '', 2, ''),
('admin/config/system/backup_migrate/destination/deletefile', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2264656c657465206261636b75702066696c6573223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a31323a2264657374696e6174696f6e73223b693a313b733a34313a226261636b75705f6d6967726174655f75695f64657374696e6174696f6e5f64656c6574655f66696c65223b693a323b623a313b7d, '', 63, 6, 0, '', 'admin/config/system/backup_migrate/destination/deletefile', 'Delete File', 't', '', '', 'a:0:{}', 0, 'Delete a backup file', '', 0, ''),
('admin/config/system/backup_migrate/destination/downloadfile', '', '', 'user_access', 0x613a313a7b693a303b733a31393a22616363657373206261636b75702066696c6573223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a31323a2264657374696e6174696f6e73223b693a313b733a34333a226261636b75705f6d6967726174655f75695f64657374696e6174696f6e5f646f776e6c6f61645f66696c65223b693a323b623a313b7d, '', 63, 6, 0, '', 'admin/config/system/backup_migrate/destination/downloadfile', 'Download File', 't', '', '', 'a:0:{}', 0, 'Download a backup file', '', 0, ''),
('admin/config/system/backup_migrate/destination/list', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f6c697374223b693a323b623a313b7d, '', 63, 6, 1, 'admin/config/system/backup_migrate/destination', 'admin/config/system/backup_migrate', 'List !type', 't', 'a:1:{s:5:"!type";s:12:"Destinations";}', '', 'a:0:{}', 140, '', '', 1, ''),
('admin/config/system/backup_migrate/destination/list/add', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f637265617465223b693a323b623a313b7d, '', 127, 7, 1, 'admin/config/system/backup_migrate/destination/list', 'admin/config/system/backup_migrate', 'Add !type', 't', 'a:1:{s:5:"!type";s:11:"Destination";}', '', 'a:0:{}', 388, '', '', 2, ''),
('admin/config/system/backup_migrate/destination/list/delete', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f64656c657465223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/destination/list/delete', 'Delete !type', 't', 'a:1:{s:5:"!type";s:11:"Destination";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/backup_migrate/destination/list/edit', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f65646974223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/destination/list/edit', 'Edit !type', 't', 'a:1:{s:5:"!type";s:11:"Destination";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/backup_migrate/destination/list/export', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f6578706f7274223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/destination/list/export', 'Export !type', 't', 'a:1:{s:5:"!type";s:11:"Destination";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/backup_migrate/destination/list/files', '', '', 'user_access', 0x613a313a7b693a303b733a31393a22616363657373206261636b75702066696c6573223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a31323a2264657374696e6174696f6e73223b693a313b733a34333a226261636b75705f6d6967726174655f75695f64657374696e6174696f6e5f646973706c61795f66696c6573223b693a323b623a313b7d, '', 127, 7, 1, 'admin/config/system/backup_migrate/destination/list', 'admin/config/system/backup_migrate', 'Destination Files', 't', '', '', 'a:0:{}', 132, '', '', 0, ''),
('admin/config/system/backup_migrate/destination/restorefile', '', '', 'user_access', 0x613a313a7b693a303b733a31393a22726573746f72652066726f6d206261636b7570223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a31323a2264657374696e6174696f6e73223b693a313b733a34323a226261636b75705f6d6967726174655f75695f64657374696e6174696f6e5f726573746f72655f66696c65223b693a323b623a313b7d, '', 63, 6, 0, '', 'admin/config/system/backup_migrate/destination/restorefile', 'Restore from backup', 't', '', '', 'a:0:{}', 0, 'Restore database from a backup file on the server', '', 0, ''),
('admin/config/system/backup_migrate/export', '', '', 'user_access', 0x613a313a7b693a303b733a32353a22616363657373206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a303a22223b693a313b733a33373a226261636b75705f6d6967726174655f75695f6d616e75616c5f6261636b75705f717569636b223b693a323b623a313b7d, '', 31, 5, 1, 'admin/config/system/backup_migrate', 'admin/config/system/backup_migrate', 'Backup', 't', '', '', 'a:0:{}', 140, 'Backup the database.', '', 0, ''),
('admin/config/system/backup_migrate/export/advanced', '', '', 'user_access', 0x613a313a7b693a303b733a31343a22706572666f726d206261636b7570223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a303a22223b693a313b733a34303a226261636b75705f6d6967726174655f75695f6d616e75616c5f6261636b75705f616476616e636564223b693a323b623a313b7d, '', 63, 6, 1, 'admin/config/system/backup_migrate/export', 'admin/config/system/backup_migrate', 'Advanced Backup', 't', '', '', 'a:0:{}', 132, 'Backup the database.', '', 1, ''),
('admin/config/system/backup_migrate/export/quick', '', '', 'user_access', 0x613a313a7b693a303b733a32353a22616363657373206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a303a22223b693a313b733a33373a226261636b75705f6d6967726174655f75695f6d616e75616c5f6261636b75705f717569636b223b693a323b623a313b7d, '', 63, 6, 1, 'admin/config/system/backup_migrate/export', 'admin/config/system/backup_migrate', 'Quick Backup', 't', '', '', 'a:0:{}', 140, 'Backup the database.', '', 0, ''),
('admin/config/system/backup_migrate/profile', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f6c697374223b693a323b623a313b7d, '', 31, 5, 1, 'admin/config/system/backup_migrate', 'admin/config/system/backup_migrate', 'Profiles', 't', '', '', 'a:0:{}', 132, '', '', 2, ''),
('admin/config/system/backup_migrate/profile/list', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f6c697374223b693a323b623a313b7d, '', 63, 6, 1, 'admin/config/system/backup_migrate/profile', 'admin/config/system/backup_migrate', 'List !type', 't', 'a:1:{s:5:"!type";s:8:"Profiles";}', '', 'a:0:{}', 140, '', '', 1, ''),
('admin/config/system/backup_migrate/profile/list/add', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f637265617465223b693a323b623a313b7d, '', 127, 7, 1, 'admin/config/system/backup_migrate/profile/list', 'admin/config/system/backup_migrate', 'Add !type', 't', 'a:1:{s:5:"!type";s:7:"Profile";}', '', 'a:0:{}', 388, '', '', 2, ''),
('admin/config/system/backup_migrate/profile/list/delete', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f64656c657465223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/profile/list/delete', 'Delete !type', 't', 'a:1:{s:5:"!type";s:7:"Profile";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/backup_migrate/profile/list/edit', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f65646974223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/profile/list/edit', 'Edit !type', 't', 'a:1:{s:5:"!type";s:7:"Profile";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/backup_migrate/profile/list/export', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f6578706f7274223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/profile/list/export', 'Export !type', 't', 'a:1:{s:5:"!type";s:7:"Profile";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/backup_migrate/restore', '', '', 'user_access', 0x613a313a7b693a303b733a31393a22726573746f72652066726f6d206261636b7570223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a303a22223b693a313b733a33323a226261636b75705f6d6967726174655f75695f6d616e75616c5f726573746f7265223b693a323b623a313b7d, '', 31, 5, 1, 'admin/config/system/backup_migrate', 'admin/config/system/backup_migrate', 'Restore', 't', '', '', 'a:0:{}', 132, 'Restore the database from a previous backup', '', 1, ''),
('admin/config/system/backup_migrate/schedule', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f6c697374223b693a323b623a313b7d, '', 31, 5, 1, 'admin/config/system/backup_migrate', 'admin/config/system/backup_migrate', 'Schedules', 't', '', '', 'a:0:{}', 132, '', '', 2, ''),
('admin/config/system/backup_migrate/schedule/list', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f6c697374223b693a323b623a313b7d, '', 63, 6, 1, 'admin/config/system/backup_migrate/schedule', 'admin/config/system/backup_migrate', 'List !type', 't', 'a:1:{s:5:"!type";s:9:"Schedules";}', '', 'a:0:{}', 140, '', '', 1, ''),
('admin/config/system/backup_migrate/schedule/list/add', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f637265617465223b693a323b623a313b7d, '', 127, 7, 1, 'admin/config/system/backup_migrate/schedule/list', 'admin/config/system/backup_migrate', 'Add !type', 't', 'a:1:{s:5:"!type";s:8:"Schedule";}', '', 'a:0:{}', 388, '', '', 2, '');
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `delivery_callback`, `fit`, `number_parts`, `context`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `theme_callback`, `theme_arguments`, `type`, `description`, `position`, `weight`, `include_file`) VALUES
('admin/config/system/backup_migrate/schedule/list/delete', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f64656c657465223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/schedule/list/delete', 'Delete !type', 't', 'a:1:{s:5:"!type";s:8:"Schedule";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/backup_migrate/schedule/list/edit', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32373a226261636b75705f6d6967726174655f637275645f75695f65646974223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/schedule/list/edit', 'Edit !type', 't', 'a:1:{s:5:"!type";s:8:"Schedule";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/backup_migrate/schedule/list/export', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572206261636b757020616e64206d696772617465223b7d, 'backup_migrate_menu_callback', 0x613a333a7b693a303b733a343a2263727564223b693a313b733a32393a226261636b75705f6d6967726174655f637275645f75695f6578706f7274223b693a323b623a313b7d, '', 127, 7, 0, '', 'admin/config/system/backup_migrate/schedule/list/export', 'Export !type', 't', 'a:1:{s:5:"!type";s:8:"Schedule";}', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/config/system/cron', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a2273797374656d5f63726f6e5f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/system/cron', 'Cron', 't', '', '', 'a:0:{}', 6, 'Manage automatic site maintenance tasks.', '', 20, 'modules/system/system.admin.inc'),
('admin/config/system/globalredirect', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32333a22676c6f62616c72656469726563745f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/system/globalredirect', 'Global Redirect', 't', '', '', 'a:0:{}', 6, 'Chose which features you would like enabled for Global Redirect', '', 0, 'sites/all/modules/contrib/globalredirect/globalredirect.admin.inc'),
('admin/config/system/googleanalytics', '', '', 'user_access', 0x613a313a7b693a303b733a32373a2261646d696e697374657220676f6f676c6520616e616c7974696373223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a33353a22676f6f676c65616e616c79746963735f61646d696e5f73657474696e67735f666f726d223b7d, '', 15, 4, 0, '', 'admin/config/system/googleanalytics', 'Google Analytics', 't', '', '', 'a:0:{}', 6, 'Configure tracking behavior to get insights into your website traffic and marketing effectiveness.', '', 0, 'sites/all/modules/contrib/google_analytics/googleanalytics.admin.inc'),
('admin/config/system/piwik', '', '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e697374657220706977696b223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32353a22706977696b5f61646d696e5f73657474696e67735f666f726d223b7d, '', 15, 4, 0, '', 'admin/config/system/piwik', 'Piwik', 't', '', '', 'a:0:{}', 6, 'Configure the settings used to generate your Piwik tracking code.', '', 0, 'sites/all/modules/contrib/piwik/piwik.admin.inc'),
('admin/config/system/site-information', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a33323a2273797374656d5f736974655f696e666f726d6174696f6e5f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/system/site-information', 'Site information', 't', '', '', 'a:0:{}', 6, 'Change site name, e-mail address, slogan, default front page, and number of posts per page, error pages.', '', -20, 'modules/system/system.admin.inc'),
('admin/config/user-interface', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/user-interface', 'User interface', 't', '', '', 'a:0:{}', 6, 'Tools that enhance the user interface.', 'right', -15, 'modules/system/system.admin.inc'),
('admin/config/user-interface/modulefilter', '', '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e6973746572206d6f64756c652066696c746572223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32323a226d6f64756c655f66696c7465725f73657474696e6773223b7d, '', 15, 4, 0, '', 'admin/config/user-interface/modulefilter', 'Module filter', 't', '', '', 'a:0:{}', 6, 'Configure settings for Module Filter.', '', 0, 'sites/all/modules/contrib/module_filter/module_filter.admin.inc'),
('admin/config/user-interface/shortcut', '', '', 'user_access', 0x613a313a7b693a303b733a32303a2261646d696e69737465722073686f727463757473223b7d, 'shortcut_set_admin', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/config/user-interface/shortcut', 'Shortcuts', 't', '', '', 'a:0:{}', 6, 'Add and modify shortcut sets.', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/%', 0x613a313a7b693a343b733a31373a2273686f72746375745f7365745f6c6f6164223b7d, '', 'shortcut_set_edit_access', 0x613a313a7b693a303b693a343b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32323a2273686f72746375745f7365745f637573746f6d697a65223b693a313b693a343b7d, '', 30, 5, 0, '', 'admin/config/user-interface/shortcut/%', 'Edit shortcuts', 'shortcut_set_title', 'a:1:{i:0;i:4;}', '', 'a:0:{}', 6, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/%/add-link', 0x613a313a7b693a343b733a31373a2273686f72746375745f7365745f6c6f6164223b7d, '', 'shortcut_set_edit_access', 0x613a313a7b693a303b693a343b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31373a2273686f72746375745f6c696e6b5f616464223b693a313b693a343b7d, '', 61, 6, 1, 'admin/config/user-interface/shortcut/%', 'admin/config/user-interface/shortcut/%', 'Add shortcut', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/%/add-link-inline', 0x613a313a7b693a343b733a31373a2273686f72746375745f7365745f6c6f6164223b7d, '', 'shortcut_set_edit_access', 0x613a313a7b693a303b693a343b7d, 'shortcut_link_add_inline', 0x613a313a7b693a303b693a343b7d, '', 61, 6, 0, '', 'admin/config/user-interface/shortcut/%/add-link-inline', 'Add shortcut', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/%/delete', 0x613a313a7b693a343b733a31373a2273686f72746375745f7365745f6c6f6164223b7d, '', 'shortcut_set_delete_access', 0x613a313a7b693a303b693a343b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a2273686f72746375745f7365745f64656c6574655f666f726d223b693a313b693a343b7d, '', 61, 6, 0, '', 'admin/config/user-interface/shortcut/%/delete', 'Delete shortcut set', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/%/edit', 0x613a313a7b693a343b733a31373a2273686f72746375745f7365745f6c6f6164223b7d, '', 'shortcut_set_edit_access', 0x613a313a7b693a303b693a343b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32323a2273686f72746375745f7365745f656469745f666f726d223b693a313b693a343b7d, '', 61, 6, 1, 'admin/config/user-interface/shortcut/%', 'admin/config/user-interface/shortcut/%', 'Edit set name', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/%/links', 0x613a313a7b693a343b733a31373a2273686f72746375745f7365745f6c6f6164223b7d, '', 'shortcut_set_edit_access', 0x613a313a7b693a303b693a343b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32323a2273686f72746375745f7365745f637573746f6d697a65223b693a313b693a343b7d, '', 61, 6, 1, 'admin/config/user-interface/shortcut/%', 'admin/config/user-interface/shortcut/%', 'List links', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/add-set', '', '', 'user_access', 0x613a313a7b693a303b733a32303a2261646d696e69737465722073686f727463757473223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32313a2273686f72746375745f7365745f6164645f666f726d223b7d, '', 31, 5, 1, 'admin/config/user-interface/shortcut', 'admin/config/user-interface/shortcut', 'Add shortcut set', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/link/%', 0x613a313a7b693a353b733a31343a226d656e755f6c696e6b5f6c6f6164223b7d, '', 'shortcut_link_access', 0x613a313a7b693a303b693a353b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31383a2273686f72746375745f6c696e6b5f65646974223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/config/user-interface/shortcut/link/%', 'Edit shortcut', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/user-interface/shortcut/link/%/delete', 0x613a313a7b693a353b733a31343a226d656e755f6c696e6b5f6c6f6164223b7d, '', 'shortcut_link_access', 0x613a313a7b693a303b693a353b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32303a2273686f72746375745f6c696e6b5f64656c657465223b693a313b693a353b7d, '', 125, 7, 0, '', 'admin/config/user-interface/shortcut/link/%/delete', 'Delete shortcut', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('admin/config/workflow', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/config/workflow', 'Workflow', 't', '', '', 'a:0:{}', 6, 'Content workflow, editorial workflow tools.', 'right', 5, 'modules/system/system.admin.inc'),
('admin/content', '', '', 'user_access', 0x613a313a7b693a303b733a32333a2261636365737320636f6e74656e74206f76657276696577223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31383a226e6f64655f61646d696e5f636f6e74656e74223b7d, '', 3, 2, 0, '', 'admin/content', 'Content', 't', '', '', 'a:0:{}', 6, 'Administer content and comments.', '', -10, 'modules/node/node.admin.inc'),
('admin/content/comment', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e697374657220636f6d6d656e7473223b7d, 'comment_admin', 0x613a303a7b7d, '', 7, 3, 1, 'admin/content', 'admin/content', 'Comments', 't', '', '', 'a:0:{}', 134, 'List and edit site comments and the comment approval queue.', '', 0, 'modules/comment/comment.admin.inc'),
('admin/content/comment/approval', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e697374657220636f6d6d656e7473223b7d, 'comment_admin', 0x613a313a7b693a303b733a383a22617070726f76616c223b7d, '', 15, 4, 1, 'admin/content/comment', 'admin/content', 'Unapproved comments', 'comment_count_unpublished', '', '', 'a:0:{}', 132, '', '', 0, 'modules/comment/comment.admin.inc'),
('admin/content/comment/new', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e697374657220636f6d6d656e7473223b7d, 'comment_admin', 0x613a303a7b7d, '', 15, 4, 1, 'admin/content/comment', 'admin/content', 'Published comments', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/comment/comment.admin.inc'),
('admin/content/node', '', '', 'user_access', 0x613a313a7b693a303b733a32333a2261636365737320636f6e74656e74206f76657276696577223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31383a226e6f64655f61646d696e5f636f6e74656e74223b7d, '', 7, 3, 1, 'admin/content', 'admin/content', 'Content', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/node/node.admin.inc'),
('admin/content/scheduler', '', '', 'scheduler_list_access_callback', 0x613a303a7b7d, 'scheduler_list', 0x613a303a7b7d, '', 7, 3, 1, 'admin/content', 'admin/content', 'Scheduled', 't', '', '', 'a:0:{}', 132, 'Display a list of scheduled nodes', '', 0, ''),
('admin/help', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_main', 0x613a303a7b7d, '', 3, 2, 0, '', 'admin/help', 'Help', 't', '', '', 'a:0:{}', 6, 'Reference for usage, configuration, and modules.', '', 9, 'modules/help/help.admin.inc'),
('admin/help/admin_menu', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/admin_menu', 'admin_menu', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/backup_migrate', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/backup_migrate', 'backup_migrate', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/block', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/block', 'block', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/color', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/color', 'color', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/comment', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/comment', 'comment', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/contact', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/contact', 'contact', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/context', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/context', 'context', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/contextual', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/contextual', 'contextual', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/context_ui', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/context_ui', 'context_ui', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/dblog', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/dblog', 'dblog', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/features', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/features', 'features', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/field', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/field', 'field', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/field_sql_storage', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/field_sql_storage', 'field_sql_storage', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/field_ui', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/field_ui', 'field_ui', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/file', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/file', 'file', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/filter', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/filter', 'filter', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/globalredirect', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/globalredirect', 'globalredirect', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/googleanalytics', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/googleanalytics', 'googleanalytics', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/headjs', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/headjs', 'headjs', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/help', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/help', 'help', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/list', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/list', 'list', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/menu', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/menu', 'menu', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/mollom', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/mollom', 'mollom', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/node', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/node', 'node', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/options', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/options', 'options', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/path', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/path', 'path', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/pathauto', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/pathauto', 'pathauto', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/piwik', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/piwik', 'piwik', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/rdf', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/rdf', 'rdf', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/scheduler', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/scheduler', 'scheduler', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/search', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/search', 'search', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/shortcut', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/shortcut', 'shortcut', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/system', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/system', 'system', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/taxonomy', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/taxonomy', 'taxonomy', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/text', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/text', 'text', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/token', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/token', 'token', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/trigger', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/trigger', 'trigger', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/update', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/update', 'update', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/user', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'help_page', 0x613a313a7b693a303b693a323b7d, '', 7, 3, 0, '', 'admin/help/user', 'user', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/help/help.admin.inc'),
('admin/index', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_index', 0x613a303a7b7d, '', 3, 2, 1, 'admin', 'admin', 'Index', 't', '', '', 'a:0:{}', 132, '', '', -18, 'modules/system/system.admin.inc'),
('admin/modules', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e6973746572206d6f64756c6573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31343a2273797374656d5f6d6f64756c6573223b7d, '', 3, 2, 0, '', 'admin/modules', 'Modules', 't', '', '', 'a:0:{}', 6, 'Extend site functionality.', '', -2, 'modules/system/system.admin.inc'),
('admin/modules/install', '', '', 'update_manager_access', 0x613a303a7b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32373a227570646174655f6d616e616765725f696e7374616c6c5f666f726d223b693a313b733a363a226d6f64756c65223b7d, '', 7, 3, 1, 'admin/modules', 'admin/modules', 'Install new module', 't', '', '', 'a:0:{}', 388, '', '', 25, 'modules/update/update.manager.inc'),
('admin/modules/list', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e6973746572206d6f64756c6573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31343a2273797374656d5f6d6f64756c6573223b7d, '', 7, 3, 1, 'admin/modules', 'admin/modules', 'List', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/system/system.admin.inc'),
('admin/modules/list/confirm', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e6973746572206d6f64756c6573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31343a2273797374656d5f6d6f64756c6573223b7d, '', 15, 4, 0, '', 'admin/modules/list/confirm', 'List', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/system/system.admin.inc'),
('admin/modules/uninstall', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e6973746572206d6f64756c6573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32343a2273797374656d5f6d6f64756c65735f756e696e7374616c6c223b7d, '', 7, 3, 1, 'admin/modules', 'admin/modules', 'Uninstall', 't', '', '', 'a:0:{}', 132, '', '', 20, 'modules/system/system.admin.inc'),
('admin/modules/uninstall/confirm', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e6973746572206d6f64756c6573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32343a2273797374656d5f6d6f64756c65735f756e696e7374616c6c223b7d, '', 15, 4, 0, '', 'admin/modules/uninstall/confirm', 'Uninstall', 't', '', '', 'a:0:{}', 4, '', '', 0, 'modules/system/system.admin.inc'),
('admin/modules/update', '', '', 'update_manager_access', 0x613a303a7b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a227570646174655f6d616e616765725f7570646174655f666f726d223b693a313b733a363a226d6f64756c65223b7d, '', 7, 3, 1, 'admin/modules', 'admin/modules', 'Update', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/update/update.manager.inc'),
('admin/people', '', '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'user_admin', 0x613a313a7b693a303b733a343a226c697374223b7d, '', 3, 2, 0, '', 'admin/people', 'People', 't', '', '', 'a:0:{}', 6, 'Manage user accounts, roles, and permissions.', 'left', -4, 'modules/user/user.admin.inc'),
('admin/people/create', '', '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'user_admin', 0x613a313a7b693a303b733a363a22637265617465223b7d, '', 7, 3, 1, 'admin/people', 'admin/people', 'Add user', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/user/user.admin.inc'),
('admin/people/people', '', '', 'user_access', 0x613a313a7b693a303b733a31363a2261646d696e6973746572207573657273223b7d, 'user_admin', 0x613a313a7b693a303b733a343a226c697374223b7d, '', 7, 3, 1, 'admin/people', 'admin/people', 'List', 't', '', '', 'a:0:{}', 140, 'Find and manage people interacting with your site.', '', -10, 'modules/user/user.admin.inc'),
('admin/people/permissions', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e6973746572207065726d697373696f6e73223b7d, 'filter_perms_admin_perm', 0x613a313a7b693a303b733a32323a22757365725f61646d696e5f7065726d697373696f6e73223b7d, '', 7, 3, 1, 'admin/people', 'admin/people', 'Permissions', 't', '', '', 'a:0:{}', 132, 'Determine access to features by selecting permissions for roles.', '', 0, 'modules/user/user.admin.inc'),
('admin/people/permissions/list', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e6973746572207065726d697373696f6e73223b7d, 'filter_perms_admin_perm', 0x613a313a7b693a303b733a32323a22757365725f61646d696e5f7065726d697373696f6e73223b7d, '', 15, 4, 1, 'admin/people/permissions', 'admin/people', 'Permissions', 't', '', '', 'a:0:{}', 140, 'Determine access to features by selecting permissions for roles.', '', -8, 'modules/user/user.admin.inc'),
('admin/people/permissions/roles', '', '', 'user_access', 0x613a313a7b693a303b733a32323a2261646d696e6973746572207065726d697373696f6e73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31363a22757365725f61646d696e5f726f6c6573223b7d, '', 15, 4, 1, 'admin/people/permissions', 'admin/people', 'Roles', 't', '', '', 'a:0:{}', 132, 'List, edit, or add user roles.', '', -5, 'modules/user/user.admin.inc'),
('admin/people/permissions/roles/delete/%', 0x613a313a7b693a353b733a31343a22757365725f726f6c655f6c6f6164223b7d, '', 'user_role_edit_access', 0x613a313a7b693a303b693a353b7d, 'drupal_get_form', 0x613a323a7b693a303b733a33303a22757365725f61646d696e5f726f6c655f64656c6574655f636f6e6669726d223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/people/permissions/roles/delete/%', 'Delete role', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/user/user.admin.inc'),
('admin/people/permissions/roles/edit/%', 0x613a313a7b693a353b733a31343a22757365725f726f6c655f6c6f6164223b7d, '', 'user_role_edit_access', 0x613a313a7b693a303b693a353b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31353a22757365725f61646d696e5f726f6c65223b693a313b693a353b7d, '', 62, 6, 0, '', 'admin/people/permissions/roles/edit/%', 'Edit role', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/user/user.admin.inc'),
('admin/reports', '', '', 'user_access', 0x613a313a7b693a303b733a31393a226163636573732073697465207265706f727473223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 3, 2, 0, '', 'admin/reports', 'Reports', 't', '', '', 'a:0:{}', 6, 'View reports, updates, and errors.', 'left', 5, 'modules/system/system.admin.inc'),
('admin/reports/access-denied', '', '', 'user_access', 0x613a313a7b693a303b733a31393a226163636573732073697465207265706f727473223b7d, 'dblog_top', 0x613a313a7b693a303b733a31333a226163636573732064656e696564223b7d, '', 7, 3, 0, '', 'admin/reports/access-denied', 'Top ''access denied'' errors', 't', '', '', 'a:0:{}', 6, 'View ''access denied'' errors (403s).', '', 0, 'modules/dblog/dblog.admin.inc'),
('admin/reports/dblog', '', '', 'user_access', 0x613a313a7b693a303b733a31393a226163636573732073697465207265706f727473223b7d, 'dblog_overview', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/reports/dblog', 'Recent log messages', 't', '', '', 'a:0:{}', 6, 'View events that have recently been logged.', '', -1, 'modules/dblog/dblog.admin.inc'),
('admin/reports/event/%', 0x613a313a7b693a333b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a226163636573732073697465207265706f727473223b7d, 'dblog_event', 0x613a313a7b693a303b693a333b7d, '', 14, 4, 0, '', 'admin/reports/event/%', 'Details', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/dblog/dblog.admin.inc'),
('admin/reports/fields', '', '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'field_ui_fields_list', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/reports/fields', 'Field list', 't', '', '', 'a:0:{}', 6, 'Overview of fields on all entity types.', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/reports/mollom', '', '', '_mollom_access', 0x613a313a7b693a303b733a32343a22616363657373206d6f6c6c6f6d2073746174697374696373223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31393a226d6f6c6c6f6d5f7265706f7274735f70616765223b7d, '', 7, 3, 0, '', 'admin/reports/mollom', 'Mollom statistics', 't', '', '', 'a:0:{}', 6, 'Reports and usage statistics for the Mollom module.', '', 0, 'sites/all/modules/contrib/mollom/mollom.admin.inc'),
('admin/reports/page-not-found', '', '', 'user_access', 0x613a313a7b693a303b733a31393a226163636573732073697465207265706f727473223b7d, 'dblog_top', 0x613a313a7b693a303b733a31343a2270616765206e6f7420666f756e64223b7d, '', 7, 3, 0, '', 'admin/reports/page-not-found', 'Top ''page not found'' errors', 't', '', '', 'a:0:{}', 6, 'View ''page not found'' errors (404s).', '', 0, 'modules/dblog/dblog.admin.inc'),
('admin/reports/search', '', '', 'user_access', 0x613a313a7b693a303b733a31393a226163636573732073697465207265706f727473223b7d, 'dblog_top', 0x613a313a7b693a303b733a363a22736561726368223b7d, '', 7, 3, 0, '', 'admin/reports/search', 'Top search phrases', 't', '', '', 'a:0:{}', 6, 'View most popular search phrases.', '', 0, 'modules/dblog/dblog.admin.inc'),
('admin/reports/status', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'system_status', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/reports/status', 'Status report', 't', '', '', 'a:0:{}', 6, 'Get a status report about your site''s operation and any detected problems.', '', -60, 'modules/system/system.admin.inc'),
('admin/reports/status/php', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'system_php', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/reports/status/php', 'PHP', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/reports/status/rebuild', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a33303a226e6f64655f636f6e6669677572655f72656275696c645f636f6e6669726d223b7d, '', 15, 4, 0, '', 'admin/reports/status/rebuild', 'Rebuild permissions', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/node/node.admin.inc'),
('admin/reports/status/run-cron', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'system_run_cron', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/reports/status/run-cron', 'Run cron', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('admin/reports/updates', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'update_status', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/reports/updates', 'Available updates', 't', '', '', 'a:0:{}', 6, 'Get a status report about available updates for your installed modules and themes.', '', -50, 'modules/update/update.report.inc'),
('admin/reports/updates/check', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'update_manual_status', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/reports/updates/check', 'Manual update check', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/update/update.fetch.inc'),
('admin/reports/updates/install', '', '', 'update_manager_access', 0x613a303a7b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32373a227570646174655f6d616e616765725f696e7374616c6c5f666f726d223b693a313b733a363a227265706f7274223b7d, '', 15, 4, 1, 'admin/reports/updates', 'admin/reports/updates', 'Install new module or theme', 't', '', '', 'a:0:{}', 388, '', '', 25, 'modules/update/update.manager.inc'),
('admin/reports/updates/list', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'update_status', 0x613a303a7b7d, '', 15, 4, 1, 'admin/reports/updates', 'admin/reports/updates', 'List', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/update/update.report.inc'),
('admin/reports/updates/settings', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31353a227570646174655f73657474696e6773223b7d, '', 15, 4, 1, 'admin/reports/updates', 'admin/reports/updates', 'Settings', 't', '', '', 'a:0:{}', 132, '', '', 50, 'modules/update/update.settings.inc'),
('admin/reports/updates/update', '', '', 'update_manager_access', 0x613a303a7b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a227570646174655f6d616e616765725f7570646174655f666f726d223b693a313b733a363a227265706f7274223b7d, '', 15, 4, 1, 'admin/reports/updates', 'admin/reports/updates', 'Update', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/update/update.manager.inc'),
('admin/structure', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 3, 2, 0, '', 'admin/structure', 'Structure', 't', '', '', 'a:0:{}', 6, 'Administer blocks, content types, menus, etc.', 'right', -8, 'modules/system/system.admin.inc'),
('admin/structure/block', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'block_admin_display', 0x613a313a7b693a303b733a31333a2264666f74775f636f726f6c6c61223b7d, '', 7, 3, 0, '', 'admin/structure/block', 'Blocks', 't', '', '', 'a:0:{}', 6, 'Configure what block content appears in your site''s sidebars and other regions.', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 15, 4, 1, 'admin/structure/block', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/demo/bartik', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32353a227468656d65732f62617274696b2f62617274696b2e696e666f223b733a343a226e616d65223b733a363a2262617274696b223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a363a2242617274696b223b733a31313a226465736372697074696f6e223b733a34383a224120666c657869626c652c207265636f6c6f7261626c65207468656d652077697468206d616e7920726567696f6e732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a31343a226373732f6c61796f75742e637373223b733a32383a227468656d65732f62617274696b2f6373732f6c61796f75742e637373223b733a31333a226373732f7374796c652e637373223b733a32373a227468656d65732f62617274696b2f6373732f7374796c652e637373223b733a31343a226373732f636f6c6f72732e637373223b733a32383a227468656d65732f62617274696b2f6373732f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a31333a226373732f7072696e742e637373223b733a32373a227468656d65732f62617274696b2f6373732f7072696e742e637373223b7d7d733a373a22726567696f6e73223b613a31373a7b733a363a22686561646572223b733a363a22486561646572223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a383a226665617475726564223b733a383a224665617475726564223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31333a22736964656261725f6669727374223b733a31333a2253696465626172206669727374223b733a31343a22736964656261725f7365636f6e64223b733a31343a2253696465626172207365636f6e64223b733a31343a2274726970747963685f6669727374223b733a31343a225472697074796368206669727374223b733a31353a2274726970747963685f6d6964646c65223b733a31353a225472697074796368206d6964646c65223b733a31333a2274726970747963685f6c617374223b733a31333a225472697074796368206c617374223b733a31383a22666f6f7465725f6669727374636f6c756d6e223b733a31393a22466f6f74657220666972737420636f6c756d6e223b733a31393a22666f6f7465725f7365636f6e64636f6c756d6e223b733a32303a22466f6f746572207365636f6e6420636f6c756d6e223b733a31383a22666f6f7465725f7468697264636f6c756d6e223b733a31393a22466f6f74657220746869726420636f6c756d6e223b733a31393a22666f6f7465725f666f75727468636f6c756d6e223b733a32303a22466f6f74657220666f7572746820636f6c756d6e223b733a363a22666f6f746572223b733a363a22466f6f746572223b7d733a383a2273657474696e6773223b613a313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2230223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32383a227468656d65732f62617274696b2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a31343a226373732f6c61796f75742e637373223b733a32383a227468656d65732f62617274696b2f6373732f6c61796f75742e637373223b733a31333a226373732f7374796c652e637373223b733a32373a227468656d65732f62617274696b2f6373732f7374796c652e637373223b733a31343a226373732f636f6c6f72732e637373223b733a32383a227468656d65732f62617274696b2f6373732f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a31333a226373732f7072696e742e637373223b733a32373a227468656d65732f62617274696b2f6373732f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a363a2262617274696b223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/bartik', 'Bartik', 't', '', '_block_custom_theme', 'a:1:{i:0;s:6:"bartik";}', 0, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/demo/corolla', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a33373a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f726f6c6c612e696e666f223b733a343a226e616d65223b733a373a22636f726f6c6c61223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a373a22436f726f6c6c61223b733a31313a226465736372697074696f6e223b733a39323a224120636f6c6f7261626c652c20666c756964207769647468207468656d652c2077697468206d696e20616e64206d6178207769647468732c20746861742063616e20737570706f727420312c2032206f72203320636f6c756d6e732e223b733a373a2276657273696f6e223b733a383a22372e782d312e3231223b733a343a22636f7265223b733a333a22372e78223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a363a7b693a303b733a343a226c6f676f223b693a313b733a343a226e616d65223b693a323b733a363a22736c6f67616e223b693a333b733a31373a226e6f64655f757365725f70696374757265223b693a343b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a353b733a373a2266617669636f6e223b7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a383a22626173652e637373223b733a33333a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f626173652e637373223b733a393a227374796c652e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7374796c652e637373223b733a31303a22636f6c6f72732e637373223b733a33353a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7072696e742e637373223b7d7d733a373a22726567696f6e73223b613a31313a7b733a31313a226865616465725f6d656e75223b733a31313a22486561646572206d656e75223b733a31313a22666f6f7465725f6d656e75223b733a31313a22466f6f746572206d656e75223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31343a225365636f6e642073696465626172223b733a393a22686967686c69676874223b733a31313a22486967686c696768746564223b733a31313a22636f6e74656e745f746f70223b733a31313a22436f6e74656e7420746f70223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31343a22636f6e74656e745f626f74746f6d223b733a31343a22436f6e74656e7420626f74746f6d223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a2273657474696e6773223b613a31313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a31383a22c2a9203230313020596f7572204e616d652e223b7d733a373a2270726f6a656374223b733a373a22636f726f6c6c61223b733a393a22646174657374616d70223b733a31303a2231323934373737323831223b733a31303a2273637265656e73686f74223b733a33393a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a383a22626173652e637373223b733a33333a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f626173652e637373223b733a393a227374796c652e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7374796c652e637373223b733a31303a22636f6c6f72732e637373223b733a33353a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a373a22636f726f6c6c61223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/corolla', 'Corolla', 't', '', '_block_custom_theme', 'a:1:{i:0;s:7:"corolla";}', 0, '', '', 0, 'modules/block/block.admin.inc');
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `delivery_callback`, `fit`, `number_parts`, `context`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `theme_callback`, `theme_arguments`, `type`, `description`, `position`, `weight`, `include_file`) VALUES
('admin/structure/block/demo/dfotw_corolla', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31323a7b733a383a2266696c656e616d65223b733a34393a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e696e666f223b733a343a226e616d65223b733a31333a2264666f74775f636f726f6c6c61223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2231223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31343a7b733a343a226e616d65223b733a31333a2244464f545720436f726f6c6c61223b733a31313a226465736372697074696f6e223b733a34393a22436f726f6c6c61207375622d7468656d6520666f722044727570616c2046756e6374696f6e206f6620746865205765656b223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a2262617365207468656d65223b733a373a22636f726f6c6c61223b733a383a226665617475726573223b613a363a7b693a303b733a343a226c6f676f223b693a313b733a343a226e616d65223b693a323b733a363a22736c6f67616e223b693a333b733a31373a226e6f64655f757365725f70696374757265223b693a343b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a353b733a373a2266617669636f6e223b7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31373a2264666f74775f636f726f6c6c612e637373223b733a34383a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e637373223b7d7d733a373a22726567696f6e73223b613a31313a7b733a31313a226865616465725f6d656e75223b733a31313a22486561646572206d656e75223b733a31313a22666f6f7465725f6d656e75223b733a31313a22466f6f746572206d656e75223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31343a225365636f6e642073696465626172223b733a393a22686967686c69676874223b733a31313a22486967686c696768746564223b733a31313a22636f6e74656e745f746f70223b733a31313a22436f6e74656e7420746f70223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31343a22636f6e74656e745f626f74746f6d223b733a31343a22436f6e74656e7420626f74746f6d223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a2273657474696e6773223b613a31313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a38303a22c2a92032303131203c6120687265663d22687474703a2f2f77656264726f702e6e65742e627222207469746c653d2257656264726f70222072656c3d22666f6c6c6f77223e57656264726f703c2f613e223b7d733a31303a2273637265656e73686f74223b733a34353a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31373a2264666f74775f636f726f6c6c612e637373223b733a34383a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a22626173655f7468656d65223b733a373a22636f726f6c6c61223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a31333a2264666f74775f636f726f6c6c61223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/dfotw_corolla', 'DFOTW Corolla', 't', '', '_block_custom_theme', 'a:1:{i:0;s:13:"dfotw_corolla";}', 0, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/demo/garland', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32373a227468656d65732f6761726c616e642f6761726c616e642e696e666f223b733a343a226e616d65223b733a373a226761726c616e64223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a373a224761726c616e64223b733a31313a226465736372697074696f6e223b733a3131313a2241206d756c74692d636f6c756d6e207468656d652077686963682063616e20626520636f6e6669677572656420746f206d6f6469667920636f6c6f727320616e6420737769746368206265747765656e20666978656420616e6420666c756964207769647468206c61796f7574732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a313a7b733a393a227374796c652e637373223b733a32343a227468656d65732f6761726c616e642f7374796c652e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a32343a227468656d65732f6761726c616e642f7072696e742e637373223b7d7d733a383a2273657474696e6773223b613a313a7b733a31333a226761726c616e645f7769647468223b733a353a22666c756964223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32393a227468656d65732f6761726c616e642f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a313a7b733a393a227374796c652e637373223b733a32343a227468656d65732f6761726c616e642f7374796c652e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a32343a227468656d65732f6761726c616e642f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a373a226761726c616e64223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/garland', 'Garland', 't', '', '_block_custom_theme', 'a:1:{i:0;s:7:"garland";}', 0, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/demo/seven', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32333a227468656d65732f736576656e2f736576656e2e696e666f223b733a343a226e616d65223b733a353a22736576656e223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a353a22536576656e223b733a31313a226465736372697074696f6e223b733a36353a22412073696d706c65206f6e652d636f6c756d6e2c207461626c656c6573732c20666c7569642077696474682061646d696e697374726174696f6e207468656d652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a313a7b733a363a2273637265656e223b613a323a7b733a393a2272657365742e637373223b733a32323a227468656d65732f736576656e2f72657365742e637373223b733a393a227374796c652e637373223b733a32323a227468656d65732f736576656e2f7374796c652e637373223b7d7d733a383a2273657474696e6773223b613a313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b7d733a373a22726567696f6e73223b613a353a7b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b7d733a31343a22726567696f6e735f68696464656e223b613a333a7b693a303b733a31333a22736964656261725f6669727374223b693a313b733a383a22706167655f746f70223b693a323b733a31313a22706167655f626f74746f6d223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32373a227468656d65732f736576656e2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d7d733a31313a227374796c65736865657473223b613a313a7b733a363a2273637265656e223b613a323a7b733a393a2272657365742e637373223b733a32323a227468656d65732f736576656e2f72657365742e637373223b733a393a227374796c652e637373223b733a32323a227468656d65732f736576656e2f7374796c652e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a353a22736576656e223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/seven', 'Seven', 't', '', '_block_custom_theme', 'a:1:{i:0;s:5:"seven";}', 0, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/demo/stark', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32333a227468656d65732f737461726b2f737461726b2e696e666f223b733a343a226e616d65223b733a353a22737461726b223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a353a22537461726b223b733a31313a226465736372697074696f6e223b733a3230383a2254686973207468656d652064656d6f6e737472617465732044727570616c27732064656661756c742048544d4c206d61726b757020616e6420435353207374796c65732e20546f206c6561726e20686f7720746f206275696c6420796f7572206f776e207468656d6520616e64206f766572726964652044727570616c27732064656661756c7420636f64652c2073656520746865203c6120687265663d22687474703a2f2f64727570616c2e6f72672f7468656d652d6775696465223e5468656d696e672047756964653c2f613e2e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a226c61796f75742e637373223b733a32333a227468656d65732f737461726b2f6c61796f75742e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32373a227468656d65732f737461726b2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a226c61796f75742e637373223b733a32333a227468656d65732f737461726b2f6c61796f75742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a353a22737461726b223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/stark', 'Stark', 't', '', '_block_custom_theme', 'a:1:{i:0;s:5:"stark";}', 0, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/demo/test_theme', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a33393a227468656d65732f74657374732f746573745f7468656d652f746573745f7468656d652e696e666f223b733a343a226e616d65223b733a31303a22746573745f7468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a31303a2254657374207468656d65223b733a31313a226465736372697074696f6e223b733a33343a225468656d6520666f722074657374696e6720746865207468656d652073797374656d223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31353a2273797374656d2e626173652e637373223b733a33393a227468656d65732f74657374732f746573745f7468656d652f73797374656d2e626173652e637373223b7d7d733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a33383a227468656d65732f74657374732f746573745f7468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31353a2273797374656d2e626173652e637373223b733a33393a227468656d65732f74657374732f746573745f7468656d652f73797374656d2e626173652e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a31303a22746573745f7468656d65223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/test_theme', 'Test theme', 't', '', '_block_custom_theme', 'a:1:{i:0;s:10:"test_theme";}', 0, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/demo/update_test_basetheme', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31303a7b733a383a2266696c656e616d65223b733a36313a227468656d65732f74657374732f7570646174655f746573745f626173657468656d652f7570646174655f746573745f626173657468656d652e696e666f223b733a343a226e616d65223b733a32313a227570646174655f746573745f626173657468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a32323a2255706461746520746573742062617365207468656d65223b733a31313a226465736372697074696f6e223b733a36333a2254657374207468656d65207768696368206163747320617320612062617365207468656d6520666f72206f746865722074657374207375627468656d65732e223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a34393a227468656d65732f74657374732f7570646174655f746573745f626173657468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a31313a227374796c65736865657473223b613a303a7b7d733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a32313a227570646174655f746573745f626173657468656d65223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/update_test_basetheme', 'Update test base theme', 't', '', '_block_custom_theme', 'a:1:{i:0;s:21:"update_test_basetheme";}', 0, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/demo/update_test_subtheme', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a35393a227468656d65732f74657374732f7570646174655f746573745f7375627468656d652f7570646174655f746573745f7375627468656d652e696e666f223b733a343a226e616d65223b733a32303a227570646174655f746573745f7375627468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a32303a225570646174652074657374207375627468656d65223b733a31313a226465736372697074696f6e223b733a36323a2254657374207468656d652077686963682075736573207570646174655f746573745f626173657468656d65206173207468652062617365207468656d652e223b733a343a22636f7265223b733a333a22372e78223b733a31303a2262617365207468656d65223b733a32313a227570646174655f746573745f626173657468656d65223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a34383a227468656d65732f74657374732f7570646174655f746573745f7375627468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a31313a227374796c65736865657473223b613a303a7b7d733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a22626173655f7468656d65223b733a32313a227570646174655f746573745f626173657468656d65223b7d7d, 'block_admin_demo', 0x613a313a7b693a303b733a32303a227570646174655f746573745f7375627468656d65223b7d, '', 31, 5, 0, '', 'admin/structure/block/demo/update_test_subtheme', 'Update test subtheme', 't', '', '_block_custom_theme', 'a:1:{i:0;s:20:"update_test_subtheme";}', 0, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/bartik', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32353a227468656d65732f62617274696b2f62617274696b2e696e666f223b733a343a226e616d65223b733a363a2262617274696b223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a363a2242617274696b223b733a31313a226465736372697074696f6e223b733a34383a224120666c657869626c652c207265636f6c6f7261626c65207468656d652077697468206d616e7920726567696f6e732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a31343a226373732f6c61796f75742e637373223b733a32383a227468656d65732f62617274696b2f6373732f6c61796f75742e637373223b733a31333a226373732f7374796c652e637373223b733a32373a227468656d65732f62617274696b2f6373732f7374796c652e637373223b733a31343a226373732f636f6c6f72732e637373223b733a32383a227468656d65732f62617274696b2f6373732f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a31333a226373732f7072696e742e637373223b733a32373a227468656d65732f62617274696b2f6373732f7072696e742e637373223b7d7d733a373a22726567696f6e73223b613a31373a7b733a363a22686561646572223b733a363a22486561646572223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a383a226665617475726564223b733a383a224665617475726564223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31333a22736964656261725f6669727374223b733a31333a2253696465626172206669727374223b733a31343a22736964656261725f7365636f6e64223b733a31343a2253696465626172207365636f6e64223b733a31343a2274726970747963685f6669727374223b733a31343a225472697074796368206669727374223b733a31353a2274726970747963685f6d6964646c65223b733a31353a225472697074796368206d6964646c65223b733a31333a2274726970747963685f6c617374223b733a31333a225472697074796368206c617374223b733a31383a22666f6f7465725f6669727374636f6c756d6e223b733a31393a22466f6f74657220666972737420636f6c756d6e223b733a31393a22666f6f7465725f7365636f6e64636f6c756d6e223b733a32303a22466f6f746572207365636f6e6420636f6c756d6e223b733a31383a22666f6f7465725f7468697264636f6c756d6e223b733a31393a22466f6f74657220746869726420636f6c756d6e223b733a31393a22666f6f7465725f666f75727468636f6c756d6e223b733a32303a22466f6f74657220666f7572746820636f6c756d6e223b733a363a22666f6f746572223b733a363a22466f6f746572223b7d733a383a2273657474696e6773223b613a313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2230223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32383a227468656d65732f62617274696b2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a31343a226373732f6c61796f75742e637373223b733a32383a227468656d65732f62617274696b2f6373732f6c61796f75742e637373223b733a31333a226373732f7374796c652e637373223b733a32373a227468656d65732f62617274696b2f6373732f7374796c652e637373223b733a31343a226373732f636f6c6f72732e637373223b733a32383a227468656d65732f62617274696b2f6373732f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a31333a226373732f7072696e742e637373223b733a32373a227468656d65732f62617274696b2f6373732f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a363a2262617274696b223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'Bartik', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/bartik/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 63, 6, 1, 'admin/structure/block/list/bartik', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/corolla', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a33373a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f726f6c6c612e696e666f223b733a343a226e616d65223b733a373a22636f726f6c6c61223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a373a22436f726f6c6c61223b733a31313a226465736372697074696f6e223b733a39323a224120636f6c6f7261626c652c20666c756964207769647468207468656d652c2077697468206d696e20616e64206d6178207769647468732c20746861742063616e20737570706f727420312c2032206f72203320636f6c756d6e732e223b733a373a2276657273696f6e223b733a383a22372e782d312e3231223b733a343a22636f7265223b733a333a22372e78223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a363a7b693a303b733a343a226c6f676f223b693a313b733a343a226e616d65223b693a323b733a363a22736c6f67616e223b693a333b733a31373a226e6f64655f757365725f70696374757265223b693a343b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a353b733a373a2266617669636f6e223b7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a383a22626173652e637373223b733a33333a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f626173652e637373223b733a393a227374796c652e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7374796c652e637373223b733a31303a22636f6c6f72732e637373223b733a33353a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7072696e742e637373223b7d7d733a373a22726567696f6e73223b613a31313a7b733a31313a226865616465725f6d656e75223b733a31313a22486561646572206d656e75223b733a31313a22666f6f7465725f6d656e75223b733a31313a22466f6f746572206d656e75223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31343a225365636f6e642073696465626172223b733a393a22686967686c69676874223b733a31313a22486967686c696768746564223b733a31313a22636f6e74656e745f746f70223b733a31313a22436f6e74656e7420746f70223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31343a22636f6e74656e745f626f74746f6d223b733a31343a22436f6e74656e7420626f74746f6d223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a2273657474696e6773223b613a31313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a31383a22c2a9203230313020596f7572204e616d652e223b7d733a373a2270726f6a656374223b733a373a22636f726f6c6c61223b733a393a22646174657374616d70223b733a31303a2231323934373737323831223b733a31303a2273637265656e73686f74223b733a33393a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a383a22626173652e637373223b733a33333a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f626173652e637373223b733a393a227374796c652e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7374796c652e637373223b733a31303a22636f6c6f72732e637373223b733a33353a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a373a22636f726f6c6c61223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'Corolla', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/corolla/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 63, 6, 1, 'admin/structure/block/list/corolla', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/dfotw_corolla', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31323a7b733a383a2266696c656e616d65223b733a34393a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e696e666f223b733a343a226e616d65223b733a31333a2264666f74775f636f726f6c6c61223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2231223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31343a7b733a343a226e616d65223b733a31333a2244464f545720436f726f6c6c61223b733a31313a226465736372697074696f6e223b733a34393a22436f726f6c6c61207375622d7468656d6520666f722044727570616c2046756e6374696f6e206f6620746865205765656b223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a2262617365207468656d65223b733a373a22636f726f6c6c61223b733a383a226665617475726573223b613a363a7b693a303b733a343a226c6f676f223b693a313b733a343a226e616d65223b693a323b733a363a22736c6f67616e223b693a333b733a31373a226e6f64655f757365725f70696374757265223b693a343b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a353b733a373a2266617669636f6e223b7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31373a2264666f74775f636f726f6c6c612e637373223b733a34383a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e637373223b7d7d733a373a22726567696f6e73223b613a31313a7b733a31313a226865616465725f6d656e75223b733a31313a22486561646572206d656e75223b733a31313a22666f6f7465725f6d656e75223b733a31313a22466f6f746572206d656e75223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31343a225365636f6e642073696465626172223b733a393a22686967686c69676874223b733a31313a22486967686c696768746564223b733a31313a22636f6e74656e745f746f70223b733a31313a22436f6e74656e7420746f70223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31343a22636f6e74656e745f626f74746f6d223b733a31343a22436f6e74656e7420626f74746f6d223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a2273657474696e6773223b613a31313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a38303a22c2a92032303131203c6120687265663d22687474703a2f2f77656264726f702e6e65742e627222207469746c653d2257656264726f70222072656c3d22666f6c6c6f77223e57656264726f703c2f613e223b7d733a31303a2273637265656e73686f74223b733a34353a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31373a2264666f74775f636f726f6c6c612e637373223b733a34383a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a22626173655f7468656d65223b733a373a22636f726f6c6c61223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a31333a2264666f74775f636f726f6c6c61223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'DFOTW Corolla', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/block/block.admin.inc'),
('admin/structure/block/list/garland', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32373a227468656d65732f6761726c616e642f6761726c616e642e696e666f223b733a343a226e616d65223b733a373a226761726c616e64223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a373a224761726c616e64223b733a31313a226465736372697074696f6e223b733a3131313a2241206d756c74692d636f6c756d6e207468656d652077686963682063616e20626520636f6e6669677572656420746f206d6f6469667920636f6c6f727320616e6420737769746368206265747765656e20666978656420616e6420666c756964207769647468206c61796f7574732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a313a7b733a393a227374796c652e637373223b733a32343a227468656d65732f6761726c616e642f7374796c652e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a32343a227468656d65732f6761726c616e642f7072696e742e637373223b7d7d733a383a2273657474696e6773223b613a313a7b733a31333a226761726c616e645f7769647468223b733a353a22666c756964223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32393a227468656d65732f6761726c616e642f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a313a7b733a393a227374796c652e637373223b733a32343a227468656d65732f6761726c616e642f7374796c652e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a32343a227468656d65732f6761726c616e642f7072696e742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a373a226761726c616e64223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'Garland', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/garland/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 63, 6, 1, 'admin/structure/block/list/garland', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/seven', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32333a227468656d65732f736576656e2f736576656e2e696e666f223b733a343a226e616d65223b733a353a22736576656e223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a353a22536576656e223b733a31313a226465736372697074696f6e223b733a36353a22412073696d706c65206f6e652d636f6c756d6e2c207461626c656c6573732c20666c7569642077696474682061646d696e697374726174696f6e207468656d652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a313a7b733a363a2273637265656e223b613a323a7b733a393a2272657365742e637373223b733a32323a227468656d65732f736576656e2f72657365742e637373223b733a393a227374796c652e637373223b733a32323a227468656d65732f736576656e2f7374796c652e637373223b7d7d733a383a2273657474696e6773223b613a313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b7d733a373a22726567696f6e73223b613a353a7b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b7d733a31343a22726567696f6e735f68696464656e223b613a333a7b693a303b733a31333a22736964656261725f6669727374223b693a313b733a383a22706167655f746f70223b693a323b733a31313a22706167655f626f74746f6d223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32373a227468656d65732f736576656e2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d7d733a31313a227374796c65736865657473223b613a313a7b733a363a2273637265656e223b613a323a7b733a393a2272657365742e637373223b733a32323a227468656d65732f736576656e2f72657365742e637373223b733a393a227374796c652e637373223b733a32323a227468656d65732f736576656e2f7374796c652e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a353a22736576656e223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'Seven', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/seven/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 63, 6, 1, 'admin/structure/block/list/seven', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc');
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `delivery_callback`, `fit`, `number_parts`, `context`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `theme_callback`, `theme_arguments`, `type`, `description`, `position`, `weight`, `include_file`) VALUES
('admin/structure/block/list/stark', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a32333a227468656d65732f737461726b2f737461726b2e696e666f223b733a343a226e616d65223b733a353a22737461726b223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a353a22537461726b223b733a31313a226465736372697074696f6e223b733a3230383a2254686973207468656d652064656d6f6e737472617465732044727570616c27732064656661756c742048544d4c206d61726b757020616e6420435353207374796c65732e20546f206c6561726e20686f7720746f206275696c6420796f7572206f776e207468656d6520616e64206f766572726964652044727570616c27732064656661756c7420636f64652c2073656520746865203c6120687265663d22687474703a2f2f64727570616c2e6f72672f7468656d652d6775696465223e5468656d696e672047756964653c2f613e2e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a226c61796f75742e637373223b733a32333a227468656d65732f737461726b2f6c61796f75742e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32373a227468656d65732f737461726b2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a226c61796f75742e637373223b733a32333a227468656d65732f737461726b2f6c61796f75742e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a353a22737461726b223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'Stark', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/stark/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 63, 6, 1, 'admin/structure/block/list/stark', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/test_theme', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a33393a227468656d65732f74657374732f746573745f7468656d652f746573745f7468656d652e696e666f223b733a343a226e616d65223b733a31303a22746573745f7468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a31303a2254657374207468656d65223b733a31313a226465736372697074696f6e223b733a33343a225468656d6520666f722074657374696e6720746865207468656d652073797374656d223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31353a2273797374656d2e626173652e637373223b733a33393a227468656d65732f74657374732f746573745f7468656d652f73797374656d2e626173652e637373223b7d7d733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a33383a227468656d65732f74657374732f746573745f7468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31353a2273797374656d2e626173652e637373223b733a33393a227468656d65732f74657374732f746573745f7468656d652f73797374656d2e626173652e637373223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a31303a22746573745f7468656d65223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'Test theme', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/test_theme/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 63, 6, 1, 'admin/structure/block/list/test_theme', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/update_test_basetheme', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31303a7b733a383a2266696c656e616d65223b733a36313a227468656d65732f74657374732f7570646174655f746573745f626173657468656d652f7570646174655f746573745f626173657468656d652e696e666f223b733a343a226e616d65223b733a32313a227570646174655f746573745f626173657468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31353a7b733a343a226e616d65223b733a32323a2255706461746520746573742062617365207468656d65223b733a31313a226465736372697074696f6e223b733a36333a2254657374207468656d65207768696368206163747320617320612062617365207468656d6520666f72206f746865722074657374207375627468656d65732e223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a34393a227468656d65732f74657374732f7570646174655f746573745f626173657468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a31313a227374796c65736865657473223b613a303a7b7d733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a32313a227570646174655f746573745f626173657468656d65223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'Update test base theme', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/update_test_basetheme/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 63, 6, 1, 'admin/structure/block/list/update_test_basetheme', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/update_test_subtheme', '', '', '_block_themes_access', 0x613a313a7b693a303b4f3a383a22737464436c617373223a31313a7b733a383a2266696c656e616d65223b733a35393a227468656d65732f74657374732f7570646174655f746573745f7375627468656d652f7570646174655f746573745f7375627468656d652e696e666f223b733a343a226e616d65223b733a32303a227570646174655f746573745f7375627468656d65223b733a343a2274797065223b733a353a227468656d65223b733a353a226f776e6572223b733a34353a227468656d65732f656e67696e65732f70687074656d706c6174652f70687074656d706c6174652e656e67696e65223b733a363a22737461747573223b733a313a2230223b733a393a22626f6f747374726170223b733a313a2230223b733a31343a22736368656d615f76657273696f6e223b733a323a222d31223b733a363a22776569676874223b733a313a2230223b733a343a22696e666f223b613a31363a7b733a343a226e616d65223b733a32303a225570646174652074657374207375627468656d65223b733a31313a226465736372697074696f6e223b733a36323a2254657374207468656d652077686963682075736573207570646174655f746573745f626173657468656d65206173207468652062617365207468656d652e223b733a343a22636f7265223b733a333a22372e78223b733a31303a2262617365207468656d65223b733a32313a227570646174655f746573745f626173657468656d65223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a34383a227468656d65732f74657374732f7570646174655f746573745f7375627468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a31313a227374796c65736865657473223b613a303a7b7d733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a22626173655f7468656d65223b733a32313a227570646174655f746573745f626173657468656d65223b7d7d, 'block_admin_display', 0x613a313a7b693a303b733a32303a227570646174655f746573745f7375627468656d65223b7d, '', 31, 5, 1, 'admin/structure/block', 'admin/structure/block', 'Update test subtheme', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/list/update_test_subtheme/add', '', '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a22626c6f636b5f6164645f626c6f636b5f666f726d223b7d, '', 63, 6, 1, 'admin/structure/block/list/update_test_subtheme', 'admin/structure/block', 'Add block', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/manage/%/%', 0x613a323a7b693a343b4e3b693a353b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a32313a22626c6f636b5f61646d696e5f636f6e666967757265223b693a313b693a343b693a323b693a353b7d, '', 60, 6, 0, '', 'admin/structure/block/manage/%/%', 'Configure block', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/manage/%/%/configure', 0x613a323a7b693a343b4e3b693a353b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a32313a22626c6f636b5f61646d696e5f636f6e666967757265223b693a313b693a343b693a323b693a353b7d, '', 121, 7, 2, 'admin/structure/block/manage/%/%', 'admin/structure/block/manage/%/%', 'Configure block', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/block/manage/%/%/delete', 0x613a323a7b693a343b4e3b693a353b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31373a2261646d696e697374657220626c6f636b73223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a32353a22626c6f636b5f637573746f6d5f626c6f636b5f64656c657465223b693a313b693a343b693a323b693a353b7d, '', 121, 7, 0, 'admin/structure/block/manage/%/%', 'admin/structure/block/manage/%/%', 'Delete block', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/block/block.admin.inc'),
('admin/structure/contact', '', '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e7461637420666f726d73223b7d, 'contact_category_list', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/structure/contact', 'Contact form', 't', '', '', 'a:0:{}', 6, 'Create a system contact form and set up categories for the form to use.', '', 0, 'modules/contact/contact.admin.inc'),
('admin/structure/contact/add', '', '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e7461637420666f726d73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32363a22636f6e746163745f63617465676f72795f656469745f666f726d223b7d, '', 15, 4, 1, 'admin/structure/contact', 'admin/structure/contact', 'Add category', 't', '', '', 'a:0:{}', 388, '', '', 1, 'modules/contact/contact.admin.inc'),
('admin/structure/contact/delete/%', 0x613a313a7b693a343b733a31323a22636f6e746163745f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e7461637420666f726d73223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32383a22636f6e746163745f63617465676f72795f64656c6574655f666f726d223b693a313b693a343b7d, '', 30, 5, 0, '', 'admin/structure/contact/delete/%', 'Delete contact', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/contact/contact.admin.inc'),
('admin/structure/contact/edit/%', 0x613a313a7b693a343b733a31323a22636f6e746163745f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e7461637420666f726d73223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a22636f6e746163745f63617465676f72795f656469745f666f726d223b693a313b693a343b7d, '', 30, 5, 0, '', 'admin/structure/contact/edit/%', 'Edit contact category', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/contact/contact.admin.inc'),
('admin/structure/context', '', '', 'ctools_export_ui_task_access', 0x613a323a7b693a303b733a373a22636f6e74657874223b693a313b733a343a226c697374223b7d, 'ctools_export_ui_switcher_page', 0x613a323a7b693a303b733a373a22636f6e74657874223b693a313b733a343a226c697374223b7d, '', 7, 3, 0, '', 'admin/structure/context', 'Context', 't', '', '', 'a:0:{}', 6, 'Associate menus, views, blocks, etc. with different contexts to structure your site.', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/add', '', '', 'ctools_export_ui_task_access', 0x613a323a7b693a303b733a373a22636f6e74657874223b693a313b733a333a22616464223b7d, 'ctools_export_ui_switcher_page', 0x613a323a7b693a303b733a373a22636f6e74657874223b693a313b733a333a22616464223b7d, '', 15, 4, 1, 'admin/structure/context', 'admin/structure/context', 'Add', 't', '', '', 'a:0:{}', 388, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/import', '', '', 'ctools_export_ui_task_access', 0x613a323a7b693a303b733a373a22636f6e74657874223b693a313b733a363a22696d706f7274223b7d, 'ctools_export_ui_switcher_page', 0x613a323a7b693a303b733a373a22636f6e74657874223b693a313b733a363a22696d706f7274223b7d, '', 15, 4, 1, 'admin/structure/context', 'admin/structure/context', 'Import', 't', '', '', 'a:0:{}', 388, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list', '', '', 'ctools_export_ui_task_access', 0x613a323a7b693a303b733a373a22636f6e74657874223b693a313b733a343a226c697374223b7d, 'ctools_export_ui_switcher_page', 0x613a323a7b693a303b733a373a22636f6e74657874223b693a313b733a343a226c697374223b7d, '', 15, 4, 1, 'admin/structure/context', 'admin/structure/context', 'List', 't', '', '', 'a:0:{}', 140, '', '', -10, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list/%', 0x613a313a7b693a343b613a313a7b733a32313a2263746f6f6c735f6578706f72745f75695f6c6f6164223b613a313a7b693a303b733a373a22636f6e74657874223b7d7d7d, '', 'ctools_export_ui_task_access', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a343a2265646974223b693a323b693a343b7d, 'ctools_export_ui_switcher_page', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a343a2265646974223b693a323b693a343b7d, '', 30, 5, 0, '', 'admin/structure/context/list/%', '', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list/%/clone', 0x613a313a7b693a343b613a313a7b733a32313a2263746f6f6c735f6578706f72745f75695f6c6f6164223b613a313a7b693a303b733a373a22636f6e74657874223b7d7d7d, '', 'ctools_export_ui_task_access', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a353a22636c6f6e65223b693a323b693a343b7d, 'ctools_export_ui_switcher_page', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a353a22636c6f6e65223b693a323b693a343b7d, '', 61, 6, 0, '', 'admin/structure/context/list/%/clone', 'Clone', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list/%/delete', 0x613a313a7b693a343b613a313a7b733a32313a2263746f6f6c735f6578706f72745f75695f6c6f6164223b613a313a7b693a303b733a373a22636f6e74657874223b7d7d7d, '', 'ctools_export_ui_task_access', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a363a2264656c657465223b693a323b693a343b7d, 'ctools_export_ui_switcher_page', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a363a2264656c657465223b693a323b693a343b7d, '', 61, 6, 0, '', 'admin/structure/context/list/%/delete', 'Delete', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list/%/disable', 0x613a313a7b693a343b613a313a7b733a32313a2263746f6f6c735f6578706f72745f75695f6c6f6164223b613a313a7b693a303b733a373a22636f6e74657874223b7d7d7d, '', 'ctools_export_ui_task_access', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a373a2264697361626c65223b693a323b693a343b7d, 'ctools_export_ui_switcher_page', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a373a2264697361626c65223b693a323b693a343b7d, '', 61, 6, 0, '', 'admin/structure/context/list/%/disable', 'Disable', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list/%/edit', 0x613a313a7b693a343b613a313a7b733a32313a2263746f6f6c735f6578706f72745f75695f6c6f6164223b613a313a7b693a303b733a373a22636f6e74657874223b7d7d7d, '', 'ctools_export_ui_task_access', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a343a2265646974223b693a323b693a343b7d, 'ctools_export_ui_switcher_page', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a343a2265646974223b693a323b693a343b7d, '', 61, 6, 1, 'admin/structure/context/list/%', 'admin/structure/context/list/%', 'Edit', 't', '', '', 'a:0:{}', 140, '', '', -10, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list/%/enable', 0x613a313a7b693a343b613a313a7b733a32313a2263746f6f6c735f6578706f72745f75695f6c6f6164223b613a313a7b693a303b733a373a22636f6e74657874223b7d7d7d, '', 'ctools_export_ui_task_access', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a363a22656e61626c65223b693a323b693a343b7d, 'ctools_export_ui_switcher_page', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a363a22656e61626c65223b693a323b693a343b7d, '', 61, 6, 0, '', 'admin/structure/context/list/%/enable', 'Enable', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list/%/export', 0x613a313a7b693a343b613a313a7b733a32313a2263746f6f6c735f6578706f72745f75695f6c6f6164223b613a313a7b693a303b733a373a22636f6e74657874223b7d7d7d, '', 'ctools_export_ui_task_access', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a363a226578706f7274223b693a323b693a343b7d, 'ctools_export_ui_switcher_page', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a363a226578706f7274223b693a323b693a343b7d, '', 61, 6, 1, 'admin/structure/context/list/%', 'admin/structure/context/list/%', 'Export', 't', '', '', 'a:0:{}', 132, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/list/%/revert', 0x613a313a7b693a343b613a313a7b733a32313a2263746f6f6c735f6578706f72745f75695f6c6f6164223b613a313a7b693a303b733a373a22636f6e74657874223b7d7d7d, '', 'ctools_export_ui_task_access', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a363a22726576657274223b693a323b693a343b7d, 'ctools_export_ui_switcher_page', 0x613a333a7b693a303b733a373a22636f6e74657874223b693a313b733a363a2264656c657465223b693a323b693a343b7d, '', 61, 6, 0, '', 'admin/structure/context/list/%/revert', 'Revert', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/export-ui.inc'),
('admin/structure/context/settings', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31393a22636f6e746578745f75695f73657474696e6773223b7d, '', 15, 4, 1, 'admin/structure/context', 'admin/structure/context', 'Settings', 't', '', '', 'a:0:{}', 132, '', '', 3, ''),
('admin/structure/features', '', '', 'user_access', 0x613a313a7b693a303b733a31353a226d616e616765206665617475726573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31393a2266656174757265735f61646d696e5f666f726d223b7d, '', 7, 3, 0, '', 'admin/structure/features', 'Features', 't', '', '', 'a:0:{}', 6, 'Manage features.', '', 0, 'sites/all/modules/contrib/features/features.admin.inc'),
('admin/structure/features/%', 0x613a313a7b693a333b613a313a7b733a31323a22666561747572655f6c6f6164223b613a323a7b693a303b693a333b693a313b623a313b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572206665617475726573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a2266656174757265735f61646d696e5f636f6d706f6e656e7473223b693a313b693a333b7d, '', 14, 4, 0, '', 'admin/structure/features/%', '', 'features_get_feature_title', 'a:1:{i:0;i:3;}', '', 'a:0:{}', 0, 'Display components of a feature.', '', 0, 'sites/all/modules/contrib/features/features.admin.inc'),
('admin/structure/features/%/recreate', 0x613a313a7b693a333b613a313a7b733a31323a22666561747572655f6c6f6164223b613a323a7b693a303b693a333b693a313b623a313b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572206665617475726573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32303a2266656174757265735f6578706f72745f666f726d223b693a313b693a333b7d, '', 29, 5, 1, 'admin/structure/features/%', 'admin/structure/features/%', 'Recreate', 't', '', '', 'a:0:{}', 132, 'Recreate an existing feature.', '', 11, 'sites/all/modules/contrib/features/features.admin.inc'),
('admin/structure/features/%/status', 0x613a313a7b693a333b613a313a7b733a31323a22666561747572655f6c6f6164223b613a323a7b693a303b693a333b693a313b623a313b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572206665617475726573223b7d, 'features_feature_status', 0x613a313a7b693a303b693a333b7d, '', 29, 5, 0, '', 'admin/structure/features/%/status', 'Status', 't', '', '', 'a:0:{}', 0, 'Javascript status call back.', '', 0, 'sites/all/modules/contrib/features/features.admin.inc'),
('admin/structure/features/%/view', 0x613a313a7b693a333b613a313a7b733a31323a22666561747572655f6c6f6164223b613a323a7b693a303b693a333b693a313b623a313b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572206665617475726573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a2266656174757265735f61646d696e5f636f6d706f6e656e7473223b693a313b693a333b7d, '', 29, 5, 1, 'admin/structure/features/%', 'admin/structure/features/%', 'View', 't', '', '', 'a:0:{}', 140, 'Display components of a feature.', '', -10, 'sites/all/modules/contrib/features/features.admin.inc'),
('admin/structure/features/cleanup', '', '', 'user_access', 0x613a313a7b693a303b733a31353a226d616e616765206665617475726573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a2266656174757265735f636c65616e75705f666f726d223b693a313b693a343b7d, '', 15, 4, 0, '', 'admin/structure/features/cleanup', 'Cleanup', 't', '', '', 'a:0:{}', 0, 'Detect and disable any orphaned feature dependencies.', '', 1, 'sites/all/modules/contrib/features/features.admin.inc'),
('admin/structure/features/create', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572206665617475726573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32303a2266656174757265735f6578706f72745f666f726d223b7d, '', 15, 4, 1, 'admin/structure/features', 'admin/structure/features', 'Create feature', 't', '', '', 'a:0:{}', 132, 'Create a new feature.', '', 10, 'sites/all/modules/contrib/features/features.admin.inc'),
('admin/structure/features/manage', '', '', 'user_access', 0x613a313a7b693a303b733a31353a226d616e616765206665617475726573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31393a2266656174757265735f61646d696e5f666f726d223b7d, '', 15, 4, 1, 'admin/structure/features', 'admin/structure/features', 'Manage', 't', '', '', 'a:0:{}', 140, 'Enable and disable features.', '', 0, 'sites/all/modules/contrib/features/features.admin.inc'),
('admin/structure/menu', '', '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'menu_overview_page', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/structure/menu', 'Menus', 't', '', '', 'a:0:{}', 6, 'Add new menus to your site, edit existing menus, and rename and reorganize menu links.', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/add', '', '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31343a226d656e755f656469745f6d656e75223b693a313b733a333a22616464223b7d, '', 15, 4, 1, 'admin/structure/menu', 'admin/structure/menu', 'Add menu', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/item/%/delete', 0x613a313a7b693a343b733a31343a226d656e755f6c696e6b5f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'menu_item_delete_page', 0x613a313a7b693a303b693a343b7d, '', 61, 6, 0, '', 'admin/structure/menu/item/%/delete', 'Delete menu link', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/item/%/edit', 0x613a313a7b693a343b733a31343a226d656e755f6c696e6b5f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a31343a226d656e755f656469745f6974656d223b693a313b733a343a2265646974223b693a323b693a343b693a333b4e3b7d, '', 61, 6, 0, '', 'admin/structure/menu/item/%/edit', 'Edit menu link', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/item/%/reset', 0x613a313a7b693a343b733a31343a226d656e755f6c696e6b5f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32333a226d656e755f72657365745f6974656d5f636f6e6669726d223b693a313b693a343b7d, '', 61, 6, 0, '', 'admin/structure/menu/item/%/reset', 'Reset menu link', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/list', '', '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'menu_overview_page', 0x613a303a7b7d, '', 15, 4, 1, 'admin/structure/menu', 'admin/structure/menu', 'List menus', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/manage/%', 0x613a313a7b693a343b733a393a226d656e755f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31383a226d656e755f6f766572766965775f666f726d223b693a313b693a343b7d, '', 30, 5, 0, '', 'admin/structure/menu/manage/%', 'Customize menu', 'menu_overview_title', 'a:1:{i:0;i:4;}', '', 'a:0:{}', 6, '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/manage/%/add', 0x613a313a7b693a343b733a393a226d656e755f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a31343a226d656e755f656469745f6974656d223b693a313b733a333a22616464223b693a323b4e3b693a333b693a343b7d, '', 61, 6, 1, 'admin/structure/menu/manage/%', 'admin/structure/menu/manage/%', 'Add link', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/manage/%/delete', 0x613a313a7b693a343b733a393a226d656e755f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'menu_delete_menu_page', 0x613a313a7b693a303b693a343b7d, '', 61, 6, 0, '', 'admin/structure/menu/manage/%/delete', 'Delete menu', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/manage/%/edit', 0x613a313a7b693a343b733a393a226d656e755f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a31343a226d656e755f656469745f6d656e75223b693a313b733a343a2265646974223b693a323b693a343b7d, '', 61, 6, 3, 'admin/structure/menu/manage/%', 'admin/structure/menu/manage/%', 'Edit menu', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/manage/%/list', 0x613a313a7b693a343b733a393a226d656e755f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31383a226d656e755f6f766572766965775f666f726d223b693a313b693a343b7d, '', 61, 6, 3, 'admin/structure/menu/manage/%', 'admin/structure/menu/manage/%', 'List links', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/menu/menu.admin.inc'),
('admin/structure/menu/parents', '', '', 'user_access', 0x613a313a7b693a303b623a313b7d, 'menu_parent_options_js', 0x613a303a7b7d, '', 15, 4, 0, '', 'admin/structure/menu/parents', 'Parent menu items', 't', '', '', 'a:0:{}', 0, '', '', 0, ''),
('admin/structure/menu/settings', '', '', 'user_access', 0x613a313a7b693a303b733a31353a2261646d696e6973746572206d656e75223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31343a226d656e755f636f6e666967757265223b7d, '', 15, 4, 1, 'admin/structure/menu', 'admin/structure/menu', 'Settings', 't', '', '', 'a:0:{}', 132, '', '', 5, 'modules/menu/menu.admin.inc'),
('admin/structure/taxonomy', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a33303a227461786f6e6f6d795f6f766572766965775f766f636162756c6172696573223b7d, '', 7, 3, 0, '', 'admin/structure/taxonomy', 'Taxonomy', 't', '', '', 'a:0:{}', 6, 'Manage tagging, categorization, and classification of your content.', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/structure/taxonomy/%', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32333a227461786f6e6f6d795f6f766572766965775f7465726d73223b693a313b693a333b7d, '', 14, 4, 0, '', 'admin/structure/taxonomy/%', '', 'taxonomy_admin_vocabulary_title_callback', 'a:1:{i:0;i:3;}', '', 'a:0:{}', 6, '', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/structure/taxonomy/%/add', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a31383a227461786f6e6f6d795f666f726d5f7465726d223b693a313b613a303a7b7d693a323b693a333b7d, '', 29, 5, 1, 'admin/structure/taxonomy/%', 'admin/structure/taxonomy/%', 'Add term', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/structure/taxonomy/%/display', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a31333a227461786f6e6f6d795f7465726d223b693a323b693a333b693a333b733a373a2264656661756c74223b7d, '', 29, 5, 1, 'admin/structure/taxonomy/%', 'admin/structure/taxonomy/%', 'Manage display', 't', '', '', 'a:0:{}', 132, '', '', 2, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/display/default', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a373a2264656661756c74223b693a333b733a31313a22757365725f616363657373223b693a343b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a31333a227461786f6e6f6d795f7465726d223b693a323b693a333b693a333b733a373a2264656661756c74223b7d, '', 59, 6, 1, 'admin/structure/taxonomy/%/display', 'admin/structure/taxonomy/%', 'Default', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/display/full', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a343a2266756c6c223b693a333b733a31313a22757365725f616363657373223b693a343b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a31333a227461786f6e6f6d795f7465726d223b693a323b693a333b693a333b733a343a2266756c6c223b7d, '', 59, 6, 1, 'admin/structure/taxonomy/%/display', 'admin/structure/taxonomy/%', 'Taxonomy term page', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/display/token', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a353a22746f6b656e223b693a333b733a31313a22757365725f616363657373223b693a343b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a31333a227461786f6e6f6d795f7465726d223b693a323b693a333b693a333b733a353a22746f6b656e223b7d, '', 59, 6, 1, 'admin/structure/taxonomy/%/display', 'admin/structure/taxonomy/%', 'Tokens', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/edit', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a227461786f6e6f6d795f666f726d5f766f636162756c617279223b693a313b693a333b7d, '', 29, 5, 1, 'admin/structure/taxonomy/%', 'admin/structure/taxonomy/%', 'Edit', 't', '', '', 'a:0:{}', 132, '', '', -10, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/structure/taxonomy/%/fields', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a32383a226669656c645f75695f6669656c645f6f766572766965775f666f726d223b693a313b733a31333a227461786f6e6f6d795f7465726d223b693a323b693a333b7d, '', 29, 5, 1, 'admin/structure/taxonomy/%', 'admin/structure/taxonomy/%', 'Manage fields', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/fields/%', 0x613a323a7b693a333b613a313a7b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a353b7d, '', 58, 6, 0, '', 'admin/structure/taxonomy/%/fields/%', '', 'field_ui_menu_title', 'a:1:{i:0;i:5;}', '', 'a:0:{}', 6, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/fields/%/delete', 0x613a323a7b693a333b613a313a7b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a226669656c645f75695f6669656c645f64656c6574655f666f726d223b693a313b693a353b7d, '', 117, 7, 1, 'admin/structure/taxonomy/%/fields/%', 'admin/structure/taxonomy/%/fields/%', 'Delete', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/fields/%/edit', 0x613a323a7b693a333b613a313a7b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a353b7d, '', 117, 7, 1, 'admin/structure/taxonomy/%/fields/%', 'admin/structure/taxonomy/%/fields/%', 'Edit', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/fields/%/field-settings', 0x613a323a7b693a333b613a313a7b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32383a226669656c645f75695f6669656c645f73657474696e67735f666f726d223b693a313b693a353b7d, '', 117, 7, 1, 'admin/structure/taxonomy/%/fields/%', 'admin/structure/taxonomy/%/fields/%', 'Field settings', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/fields/%/widget-type', 0x613a323a7b693a333b613a313a7b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d693a353b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a226669656c645f75695f7769646765745f747970655f666f726d223b693a313b693a353b7d, '', 117, 7, 1, 'admin/structure/taxonomy/%/fields/%', 'admin/structure/taxonomy/%/fields/%', 'Widget type', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/taxonomy/%/groups/%/delete', 0x613a323a7b693a333b613a313a7b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d693a353b613a313a7b733a32313a226669656c645f67726f75705f6d656e755f6c6f6164223b613a343a7b693a303b733a31333a227461786f6e6f6d795f7465726d223b693a313b693a333b693a323b733a313a2233223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32333a226669656c645f67726f75705f64656c6574655f666f726d223b693a313b693a353b7d, '', 117, 7, 0, '', 'admin/structure/taxonomy/%/groups/%/delete', 'Delete', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/field_group/field_group.field_ui.inc'),
('admin/structure/taxonomy/%/list', 0x613a313a7b693a333b733a33373a227461786f6e6f6d795f766f636162756c6172795f6d616368696e655f6e616d655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32333a227461786f6e6f6d795f6f766572766965775f7465726d73223b693a313b693a333b7d, '', 29, 5, 1, 'admin/structure/taxonomy/%', 'admin/structure/taxonomy/%', 'List', 't', '', '', 'a:0:{}', 140, '', '', -20, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/structure/taxonomy/add', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a32343a227461786f6e6f6d795f666f726d5f766f636162756c617279223b7d, '', 15, 4, 1, 'admin/structure/taxonomy', 'admin/structure/taxonomy', 'Add vocabulary', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/structure/taxonomy/list', '', '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e6973746572207461786f6e6f6d79223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a33303a227461786f6e6f6d795f6f766572766965775f766f636162756c6172696573223b7d, '', 15, 4, 1, 'admin/structure/taxonomy', 'admin/structure/taxonomy', 'List', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/structure/trigger', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'trigger_assign', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/structure/trigger', 'Triggers', 't', '', '', 'a:0:{}', 6, 'Configure when to execute actions.', '', 0, 'modules/trigger/trigger.admin.inc'),
('admin/structure/trigger/comment', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'trigger_assign', 0x613a313a7b693a303b733a373a22636f6d6d656e74223b7d, '', 15, 4, 1, 'admin/structure/trigger', 'admin/structure/trigger', 'Comment', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/trigger/trigger.admin.inc'),
('admin/structure/trigger/node', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'trigger_assign', 0x613a313a7b693a303b733a343a226e6f6465223b7d, '', 15, 4, 1, 'admin/structure/trigger', 'admin/structure/trigger', 'Node', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/trigger/trigger.admin.inc'),
('admin/structure/trigger/system', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'trigger_assign', 0x613a313a7b693a303b733a363a2273797374656d223b7d, '', 15, 4, 1, 'admin/structure/trigger', 'admin/structure/trigger', 'System', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/trigger/trigger.admin.inc'),
('admin/structure/trigger/taxonomy', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'trigger_assign', 0x613a313a7b693a303b733a383a227461786f6e6f6d79223b7d, '', 15, 4, 1, 'admin/structure/trigger', 'admin/structure/trigger', 'Taxonomy', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/trigger/trigger.admin.inc'),
('admin/structure/trigger/unassign', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31363a22747269676765725f756e61737369676e223b7d, '', 15, 4, 0, '', 'admin/structure/trigger/unassign', 'Unassign', 't', '', '', 'a:0:{}', 6, 'Unassign an action from a trigger.', '', 0, 'modules/trigger/trigger.admin.inc');
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `delivery_callback`, `fit`, `number_parts`, `context`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `theme_callback`, `theme_arguments`, `type`, `description`, `position`, `weight`, `include_file`) VALUES
('admin/structure/trigger/user', '', '', 'user_access', 0x613a313a7b693a303b733a31383a2261646d696e697374657220616374696f6e73223b7d, 'trigger_assign', 0x613a313a7b693a303b733a343a2275736572223b7d, '', 15, 4, 1, 'admin/structure/trigger', 'admin/structure/trigger', 'User', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/trigger/trigger.admin.inc'),
('admin/structure/types', '', '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'node_overview_types', 0x613a303a7b7d, '', 7, 3, 0, '', 'admin/structure/types', 'Content types', 't', '', '', 'a:0:{}', 6, 'Manage content types, including default status, front page promotion, comment settings, etc.', '', 0, 'modules/node/content_types.inc'),
('admin/structure/types/add', '', '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31343a226e6f64655f747970655f666f726d223b7d, '', 15, 4, 1, 'admin/structure/types', 'admin/structure/types', 'Add content type', 't', '', '', 'a:0:{}', 388, '', '', 0, 'modules/node/content_types.inc'),
('admin/structure/types/list', '', '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'node_overview_types', 0x613a303a7b7d, '', 15, 4, 1, 'admin/structure/types', 'admin/structure/types', 'List', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/node/content_types.inc'),
('admin/structure/types/manage/%', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31343a226e6f64655f747970655f666f726d223b693a313b693a343b7d, '', 30, 5, 0, '', 'admin/structure/types/manage/%', 'Edit content type', 'node_type_page_title', 'a:1:{i:0;i:4;}', '', 'a:0:{}', 6, '', '', 0, 'modules/node/content_types.inc'),
('admin/structure/types/manage/%/comment/display', 0x613a313a7b693a343b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a373a22636f6d6d656e74223b693a323b693a343b693a333b733a373a2264656661756c74223b7d, '', 123, 7, 1, 'admin/structure/types/manage/%', 'admin/structure/types/manage/%', 'Comment display', 't', '', '', 'a:0:{}', 132, '', '', 4, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/display/default', 0x613a313a7b693a343b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a373a2264656661756c74223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a373a22636f6d6d656e74223b693a323b693a343b693a333b733a373a2264656661756c74223b7d, '', 247, 8, 1, 'admin/structure/types/manage/%/comment/display', 'admin/structure/types/manage/%', 'Default', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/display/full', 0x613a313a7b693a343b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a343a2266756c6c223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a373a22636f6d6d656e74223b693a323b693a343b693a333b733a343a2266756c6c223b7d, '', 247, 8, 1, 'admin/structure/types/manage/%/comment/display', 'admin/structure/types/manage/%', 'Full comment', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/display/token', 0x613a313a7b693a343b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a353a22746f6b656e223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a373a22636f6d6d656e74223b693a323b693a343b693a333b733a353a22746f6b656e223b7d, '', 247, 8, 1, 'admin/structure/types/manage/%/comment/display', 'admin/structure/types/manage/%', 'Tokens', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/fields', 0x613a313a7b693a343b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a32383a226669656c645f75695f6669656c645f6f766572766965775f666f726d223b693a313b733a373a22636f6d6d656e74223b693a323b693a343b7d, '', 123, 7, 1, 'admin/structure/types/manage/%', 'admin/structure/types/manage/%', 'Comment fields', 't', '', '', 'a:0:{}', 132, '', '', 3, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/fields/%', 0x613a323a7b693a343b613a313a7b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a373b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a373b7d, '', 246, 8, 0, '', 'admin/structure/types/manage/%/comment/fields/%', '', 'field_ui_menu_title', 'a:1:{i:0;i:7;}', '', 'a:0:{}', 6, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/fields/%/delete', 0x613a323a7b693a343b613a313a7b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a373b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a226669656c645f75695f6669656c645f64656c6574655f666f726d223b693a313b693a373b7d, '', 493, 9, 1, 'admin/structure/types/manage/%/comment/fields/%', 'admin/structure/types/manage/%/comment/fields/%', 'Delete', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/fields/%/edit', 0x613a323a7b693a343b613a313a7b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a373b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a373b7d, '', 493, 9, 1, 'admin/structure/types/manage/%/comment/fields/%', 'admin/structure/types/manage/%/comment/fields/%', 'Edit', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/fields/%/field-settings', 0x613a323a7b693a343b613a313a7b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a373b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32383a226669656c645f75695f6669656c645f73657474696e67735f666f726d223b693a313b693a373b7d, '', 493, 9, 1, 'admin/structure/types/manage/%/comment/fields/%', 'admin/structure/types/manage/%/comment/fields/%', 'Field settings', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/fields/%/widget-type', 0x613a323a7b693a343b613a313a7b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a373b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a226669656c645f75695f7769646765745f747970655f666f726d223b693a313b693a373b7d, '', 493, 9, 1, 'admin/structure/types/manage/%/comment/fields/%', 'admin/structure/types/manage/%/comment/fields/%', 'Widget type', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/comment/groups/%/delete', 0x613a323a7b693a343b613a313a7b733a32323a22636f6d6d656e745f6e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a373b613a313a7b733a32313a226669656c645f67726f75705f6d656e755f6c6f6164223b613a343a7b693a303b733a373a22636f6d6d656e74223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32333a226669656c645f67726f75705f64656c6574655f666f726d223b693a313b693a373b7d, '', 493, 9, 0, '', 'admin/structure/types/manage/%/comment/groups/%/delete', 'Delete', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/field_group/field_group.field_ui.inc'),
('admin/structure/types/manage/%/delete', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226e6f64655f747970655f64656c6574655f636f6e6669726d223b693a313b693a343b7d, '', 61, 6, 0, '', 'admin/structure/types/manage/%/delete', 'Delete', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/node/content_types.inc'),
('admin/structure/types/manage/%/display', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b693a333b733a373a2264656661756c74223b7d, '', 61, 6, 1, 'admin/structure/types/manage/%', 'admin/structure/types/manage/%', 'Manage display', 't', '', '', 'a:0:{}', 132, '', '', 2, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/display/default', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a373a2264656661756c74223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b693a333b733a373a2264656661756c74223b7d, '', 123, 7, 1, 'admin/structure/types/manage/%/display', 'admin/structure/types/manage/%', 'Default', 't', '', '', 'a:0:{}', 140, '', '', -10, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/display/full', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a343a2266756c6c223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b693a333b733a343a2266756c6c223b7d, '', 123, 7, 1, 'admin/structure/types/manage/%/display', 'admin/structure/types/manage/%', 'Full content', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/display/rss', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a333a22727373223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b693a333b733a333a22727373223b7d, '', 123, 7, 1, 'admin/structure/types/manage/%/display', 'admin/structure/types/manage/%', 'RSS', 't', '', '', 'a:0:{}', 132, '', '', 2, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/display/search_index', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a31323a227365617263685f696e646578223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b693a333b733a31323a227365617263685f696e646578223b7d, '', 123, 7, 1, 'admin/structure/types/manage/%/display', 'admin/structure/types/manage/%', 'Search index', 't', '', '', 'a:0:{}', 132, '', '', 3, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/display/search_result', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a31333a227365617263685f726573756c74223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b693a333b733a31333a227365617263685f726573756c74223b7d, '', 123, 7, 1, 'admin/structure/types/manage/%/display', 'admin/structure/types/manage/%', 'Search result', 't', '', '', 'a:0:{}', 132, '', '', 4, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/display/teaser', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a363a22746561736572223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b693a333b733a363a22746561736572223b7d, '', 123, 7, 1, 'admin/structure/types/manage/%/display', 'admin/structure/types/manage/%', 'Teaser', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/display/token', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', '_field_ui_view_mode_menu_access', 0x613a353a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a353a22746f6b656e223b693a333b733a31313a22757365725f616363657373223b693a343b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a343a7b693a303b733a33303a226669656c645f75695f646973706c61795f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b693a333b733a353a22746f6b656e223b7d, '', 123, 7, 1, 'admin/structure/types/manage/%/display', 'admin/structure/types/manage/%', 'Tokens', 't', '', '', 'a:0:{}', 132, '', '', 5, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/edit', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31343a226e6f64655f747970655f666f726d223b693a313b693a343b7d, '', 61, 6, 1, 'admin/structure/types/manage/%', 'admin/structure/types/manage/%', 'Edit', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/node/content_types.inc'),
('admin/structure/types/manage/%/fields', 0x613a313a7b693a343b733a31343a226e6f64655f747970655f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a333a7b693a303b733a32383a226669656c645f75695f6669656c645f6f766572766965775f666f726d223b693a313b733a343a226e6f6465223b693a323b693a343b7d, '', 61, 6, 1, 'admin/structure/types/manage/%', 'admin/structure/types/manage/%', 'Manage fields', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/fields/%', 0x613a323a7b693a343b613a313a7b733a31343a226e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a363b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a363b7d, '', 122, 7, 0, '', 'admin/structure/types/manage/%/fields/%', '', 'field_ui_menu_title', 'a:1:{i:0;i:6;}', '', 'a:0:{}', 6, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/fields/%/delete', 0x613a323a7b693a343b613a313a7b733a31343a226e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a363b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32363a226669656c645f75695f6669656c645f64656c6574655f666f726d223b693a313b693a363b7d, '', 245, 8, 1, 'admin/structure/types/manage/%/fields/%', 'admin/structure/types/manage/%/fields/%', 'Delete', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/fields/%/edit', 0x613a323a7b693a343b613a313a7b733a31343a226e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a363b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a226669656c645f75695f6669656c645f656469745f666f726d223b693a313b693a363b7d, '', 245, 8, 1, 'admin/structure/types/manage/%/fields/%', 'admin/structure/types/manage/%/fields/%', 'Edit', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/fields/%/field-settings', 0x613a323a7b693a343b613a313a7b733a31343a226e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a363b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32383a226669656c645f75695f6669656c645f73657474696e67735f666f726d223b693a313b693a363b7d, '', 245, 8, 1, 'admin/structure/types/manage/%/fields/%', 'admin/structure/types/manage/%/fields/%', 'Field settings', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/fields/%/widget-type', 0x613a323a7b693a343b613a313a7b733a31343a226e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a363b613a313a7b733a31383a226669656c645f75695f6d656e755f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32353a226669656c645f75695f7769646765745f747970655f666f726d223b693a313b693a363b7d, '', 245, 8, 1, 'admin/structure/types/manage/%/fields/%', 'admin/structure/types/manage/%/fields/%', 'Widget type', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/field_ui/field_ui.admin.inc'),
('admin/structure/types/manage/%/groups/%/delete', 0x613a323a7b693a343b613a313a7b733a31343a226e6f64655f747970655f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d693a363b613a313a7b733a32313a226669656c645f67726f75705f6d656e755f6c6f6164223b613a343a7b693a303b733a343a226e6f6465223b693a313b693a343b693a323b733a313a2234223b693a333b733a343a22256d6170223b7d7d7d, '', 'user_access', 0x613a313a7b693a303b733a32343a2261646d696e697374657220636f6e74656e74207479706573223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32333a226669656c645f67726f75705f64656c6574655f666f726d223b693a313b693a363b7d, '', 245, 8, 0, '', 'admin/structure/types/manage/%/groups/%/delete', 'Delete', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/field_group/field_group.field_ui.inc'),
('admin/tasks', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, 'system_admin_menu_block_page', 0x613a303a7b7d, '', 3, 2, 1, 'admin', 'admin', 'Tasks', 't', '', '', 'a:0:{}', 140, '', '', -20, 'modules/system/system.admin.inc'),
('admin/update/ready', '', '', 'update_manager_access', 0x613a303a7b7d, 'drupal_get_form', 0x613a313a7b693a303b733a33323a227570646174655f6d616e616765725f7570646174655f72656164795f666f726d223b7d, '', 7, 3, 0, '', 'admin/update/ready', 'Ready to update', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/update/update.manager.inc'),
('admin_menu/flush-cache', '', '', 'user_access', 0x613a313a7b693a303b733a31323a22666c75736820636163686573223b7d, 'admin_menu_flush_cache', 0x613a303a7b7d, '', 3, 2, 0, '', 'admin_menu/flush-cache', '', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/admin_menu/admin_menu.inc'),
('admin_menu/toggle-modules', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261646d696e6973746572207369746520636f6e66696775726174696f6e223b7d, 'admin_menu_toggle_modules', 0x613a303a7b7d, '', 3, 2, 0, '', 'admin_menu/toggle-modules', '', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/admin_menu/admin_menu.inc'),
('batch', '', '', '1', 0x613a303a7b7d, 'system_batch_page', 0x613a303a7b7d, '', 1, 1, 0, '', 'batch', '', 't', '', '_system_batch_theme', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('comment/%', 0x613a313a7b693a313b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261636365737320636f6d6d656e7473223b7d, 'comment_permalink', 0x613a313a7b693a303b693a313b7d, '', 2, 2, 0, '', 'comment/%', 'Comment permalink', 't', '', '', 'a:0:{}', 6, '', '', 0, ''),
('comment/%/approve', 0x613a313a7b693a313b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e697374657220636f6d6d656e7473223b7d, 'comment_approve', 0x613a313a7b693a303b693a313b7d, '', 5, 3, 0, '', 'comment/%/approve', 'Approve', 't', '', '', 'a:0:{}', 6, '', '', 1, 'modules/comment/comment.pages.inc'),
('comment/%/delete', 0x613a313a7b693a313b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31393a2261646d696e697374657220636f6d6d656e7473223b7d, 'comment_confirm_delete_page', 0x613a313a7b693a303b693a313b7d, '', 5, 3, 1, 'comment/%', 'comment/%', 'Delete', 't', '', '', 'a:0:{}', 132, '', '', 2, 'modules/comment/comment.admin.inc'),
('comment/%/edit', 0x613a313a7b693a313b733a31323a22636f6d6d656e745f6c6f6164223b7d, '', 'comment_access', 0x613a323a7b693a303b733a343a2265646974223b693a313b693a313b7d, 'comment_edit_page', 0x613a313a7b693a303b693a313b7d, '', 5, 3, 1, 'comment/%', 'comment/%', 'Edit', 't', '', '', 'a:0:{}', 132, '', '', 0, ''),
('comment/%/view', 0x613a313a7b693a313b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31353a2261636365737320636f6d6d656e7473223b7d, 'comment_permalink', 0x613a313a7b693a303b693a313b7d, '', 5, 3, 1, 'comment/%', 'comment/%', 'View comment', 't', '', '', 'a:0:{}', 140, '', '', -10, ''),
('comment/reply/%', 0x613a313a7b693a323b733a393a226e6f64655f6c6f6164223b7d, '', 'node_access', 0x613a323a7b693a303b733a343a2276696577223b693a313b693a323b7d, 'comment_reply', 0x613a313a7b693a303b693a323b7d, '', 6, 3, 0, '', 'comment/reply/%', 'Add new comment', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/comment/comment.pages.inc'),
('contact', '', '', 'user_access', 0x613a313a7b693a303b733a32393a2261636365737320736974652d7769646520636f6e7461637420666f726d223b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31373a22636f6e746163745f736974655f666f726d223b7d, '', 1, 1, 0, '', 'contact', 'Contact', 't', '', '', 'a:0:{}', 20, '', '', 0, 'modules/contact/contact.pages.inc'),
('ctools/autocomplete/%', 0x613a313a7b693a323b4e3b7d, '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'ctools_content_autocomplete_entity', 0x613a313a7b693a303b693a323b7d, '', 6, 3, 0, '', 'ctools/autocomplete/%', '', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/content.menu.inc'),
('ctools/context/ajax/access/add', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'ctools_access_ajax_add', 0x613a303a7b7d, '', 31, 5, 0, '', 'ctools/context/ajax/access/add', '', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/context-access-admin.inc'),
('ctools/context/ajax/access/configure', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'ctools_access_ajax_edit', 0x613a303a7b7d, '', 31, 5, 0, '', 'ctools/context/ajax/access/configure', '', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/context-access-admin.inc'),
('ctools/context/ajax/access/delete', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'ctools_access_ajax_delete', 0x613a303a7b7d, '', 31, 5, 0, '', 'ctools/context/ajax/access/delete', '', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/context-access-admin.inc'),
('ctools/context/ajax/add', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'ctools_context_ajax_item_add', 0x613a303a7b7d, '', 15, 4, 0, '', 'ctools/context/ajax/add', '', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/context-admin.inc'),
('ctools/context/ajax/configure', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'ctools_context_ajax_item_edit', 0x613a303a7b7d, '', 15, 4, 0, '', 'ctools/context/ajax/configure', '', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/context-admin.inc'),
('ctools/context/ajax/delete', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'ctools_context_ajax_item_delete', 0x613a303a7b7d, '', 15, 4, 0, '', 'ctools/context/ajax/delete', '', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/ctools/includes/context-admin.inc'),
('file/ajax', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'file_ajax_upload', 0x613a303a7b7d, 'ajax_deliver', 3, 2, 0, '', 'file/ajax', '', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, ''),
('file/progress', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'file_ajax_progress', 0x613a303a7b7d, 'ajax_deliver', 3, 2, 0, '', 'file/progress', '', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, ''),
('filter/tips', '', '', '1', 0x613a303a7b7d, 'filter_tips_long', 0x613a303a7b7d, '', 3, 2, 0, '', 'filter/tips', 'Compose tips', 't', '', '', 'a:0:{}', 20, '', '', 0, 'modules/filter/filter.pages.inc'),
('js/admin_menu/cache', '', '', 'user_access', 0x613a313a7b693a303b733a32363a226163636573732061646d696e697374726174696f6e206d656e75223b7d, 'admin_menu_js_cache', 0x613a303a7b7d, '', 7, 3, 0, '', 'js/admin_menu/cache', '', 't', '', '', 'a:0:{}', 0, '', '', 0, ''),
('mollom/captcha/%/%/%', 0x613a333a7b693a323b4e3b693a333b4e3b693a343b4e3b7d, '', '_mollom_access', 0x613a303a7b7d, 'mollom_captcha_js', 0x613a333a7b693a303b693a323b693a313b693a333b693a323b693a343b7d, '', 24, 5, 0, '', 'mollom/captcha/%/%/%', '', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/mollom/mollom.pages.inc'),
('mollom/report/%/%', 0x613a323a7b693a323b4e3b693a333b4e3b7d, '', 'mollom_report_access', 0x613a323a7b693a303b693a323b693a313b693a333b7d, 'drupal_get_form', 0x613a333a7b693a303b733a31383a226d6f6c6c6f6d5f7265706f72745f666f726d223b693a313b693a323b693a323b693a333b7d, '', 12, 4, 0, '', 'mollom/report/%/%', 'Report to Mollom', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/mollom/mollom.pages.inc'),
('node', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'node_page_default', 0x613a303a7b7d, '', 1, 1, 0, '', 'node', '', 't', '', '', 'a:0:{}', 0, '', '', 0, ''),
('node/%', 0x613a313a7b693a313b733a393a226e6f64655f6c6f6164223b7d, '', 'node_access', 0x613a323a7b693a303b733a343a2276696577223b693a313b693a313b7d, 'node_page_view', 0x613a313a7b693a303b693a313b7d, '', 2, 2, 0, '', 'node/%', '', 'node_page_title', 'a:1:{i:0;i:1;}', '', 'a:0:{}', 6, '', '', 0, ''),
('node/%/delete', 0x613a313a7b693a313b733a393a226e6f64655f6c6f6164223b7d, '', 'node_access', 0x613a323a7b693a303b733a363a2264656c657465223b693a313b693a313b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31393a226e6f64655f64656c6574655f636f6e6669726d223b693a313b693a313b7d, '', 5, 3, 2, 'node/%', 'node/%', 'Delete', 't', '', '', 'a:0:{}', 132, '', '', 1, 'modules/node/node.pages.inc'),
('node/%/edit', 0x613a313a7b693a313b733a393a226e6f64655f6c6f6164223b7d, '', 'node_access', 0x613a323a7b693a303b733a363a22757064617465223b693a313b693a313b7d, 'node_page_edit', 0x613a313a7b693a303b693a313b7d, '', 5, 3, 3, 'node/%', 'node/%', 'Edit', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/node/node.pages.inc'),
('node/%/revisions', 0x613a313a7b693a313b733a393a226e6f64655f6c6f6164223b7d, '', '_node_revision_access', 0x613a313a7b693a303b693a313b7d, 'node_revision_overview', 0x613a313a7b693a303b693a313b7d, '', 5, 3, 1, 'node/%', 'node/%', 'Revisions', 't', '', '', 'a:0:{}', 132, '', '', 2, 'modules/node/node.pages.inc'),
('node/%/revisions/%/delete', 0x613a323a7b693a313b613a313a7b733a393a226e6f64655f6c6f6164223b613a313a7b693a303b693a333b7d7d693a333b4e3b7d, '', '_node_revision_access', 0x613a323a7b693a303b693a313b693a313b733a363a2264656c657465223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32383a226e6f64655f7265766973696f6e5f64656c6574655f636f6e6669726d223b693a313b693a313b7d, '', 21, 5, 0, '', 'node/%/revisions/%/delete', 'Delete earlier revision', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/node/node.pages.inc'),
('node/%/revisions/%/revert', 0x613a323a7b693a313b613a313a7b733a393a226e6f64655f6c6f6164223b613a313a7b693a303b693a333b7d7d693a333b4e3b7d, '', '_node_revision_access', 0x613a323a7b693a303b693a313b693a313b733a363a22757064617465223b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32383a226e6f64655f7265766973696f6e5f7265766572745f636f6e6669726d223b693a313b693a313b7d, '', 21, 5, 0, '', 'node/%/revisions/%/revert', 'Revert to earlier revision', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/node/node.pages.inc'),
('node/%/revisions/%/view', 0x613a323a7b693a313b613a313a7b733a393a226e6f64655f6c6f6164223b613a313a7b693a303b693a333b7d7d693a333b4e3b7d, '', '_node_revision_access', 0x613a313a7b693a303b693a313b7d, 'node_show', 0x613a323a7b693a303b693a313b693a313b623a313b7d, '', 21, 5, 0, '', 'node/%/revisions/%/view', 'Revisions', 't', '', '', 'a:0:{}', 6, '', '', 0, ''),
('node/%/view', 0x613a313a7b693a313b733a393a226e6f64655f6c6f6164223b7d, '', 'node_access', 0x613a323a7b693a303b733a343a2276696577223b693a313b693a313b7d, 'node_page_view', 0x613a313a7b693a303b693a313b7d, '', 5, 3, 1, 'node/%', 'node/%', 'View', 't', '', '', 'a:0:{}', 140, '', '', -10, ''),
('node/add', '', '', '_node_add_access', 0x613a303a7b7d, 'node_add_page', 0x613a303a7b7d, '', 3, 2, 0, '', 'node/add', 'Add content', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/node/node.pages.inc'),
('node/add/article', '', '', 'node_access', 0x613a323a7b693a303b733a363a22637265617465223b693a313b733a373a2261727469636c65223b7d, 'node_add', 0x613a313a7b693a303b733a373a2261727469636c65223b7d, '', 7, 3, 0, '', 'node/add/article', 'Article', 'check_plain', '', '', 'a:0:{}', 6, 'Use <em>articles</em> for time-sensitive content like news, press releases or blog posts.', '', 0, 'modules/node/node.pages.inc'),
('node/add/function', '', '', 'node_access', 0x613a323a7b693a303b733a363a22637265617465223b693a313b733a383a2266756e6374696f6e223b7d, 'node_add', 0x613a313a7b693a303b733a383a2266756e6374696f6e223b7d, '', 7, 3, 0, '', 'node/add/function', 'Function', 'check_plain', '', '', 'a:0:{}', 6, 'Drupal Functions!', '', 0, 'modules/node/node.pages.inc'),
('node/add/page', '', '', 'node_access', 0x613a323a7b693a303b733a363a22637265617465223b693a313b733a343a2270616765223b7d, 'node_add', 0x613a313a7b693a303b733a343a2270616765223b7d, '', 7, 3, 0, '', 'node/add/page', 'Basic page', 'check_plain', '', '', 'a:0:{}', 6, 'Use <em>basic pages</em> for your static content, such as an ''About us'' page.', '', 0, 'modules/node/node.pages.inc'),
('rss.xml', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'node_feed', 0x613a303a7b7d, '', 1, 1, 0, '', 'rss.xml', 'RSS feed', 't', '', '', 'a:0:{}', 0, '', '', 0, ''),
('scheduler/cron', '', '', '1', 0x613a303a7b7d, '_scheduler_run_cron', 0x613a303a7b7d, '', 3, 2, 0, '', 'scheduler/cron', 'Light weight cron handler', 't', '', '', 'a:0:{}', 0, 'A light weight cron handler to allow more frequent runs of Schedulers internal cron system', '', 0, ''),
('scheduler/timecheck', '', '', 'user_access', 0x613a313a7b693a303b733a32373a226163636573732061646d696e697374726174696f6e207061676573223b7d, '_scheduler_timecheck', 0x613a303a7b7d, '', 3, 2, 0, '', 'scheduler/timecheck', 'Test your servers UTC clock', 't', '', '', 'a:0:{}', 0, 'Allows site admin to check their servers internal clock', '', 0, ''),
('search', '', '', 'search_is_active', 0x613a303a7b7d, 'search_view', 0x613a303a7b7d, '', 1, 1, 0, '', 'search', 'Search', 't', '', '', 'a:0:{}', 20, '', '', 0, 'modules/search/search.pages.inc'),
('search/node', '', '', '_search_menu_access', 0x613a313a7b693a303b733a343a226e6f6465223b7d, 'search_view', 0x613a323a7b693a303b733a343a226e6f6465223b693a313b733a303a22223b7d, '', 3, 2, 1, 'search', 'search', 'Content', 't', '', '', 'a:0:{}', 132, '', '', -10, 'modules/search/search.pages.inc'),
('search/node/%', 0x613a313a7b693a323b613a313a7b733a31343a226d656e755f7461696c5f6c6f6164223b613a323a7b693a303b733a343a22256d6170223b693a313b733a363a2225696e646578223b7d7d7d, 0x613a313a7b693a323b733a31363a226d656e755f7461696c5f746f5f617267223b7d, '_search_menu_access', 0x613a313a7b693a303b733a343a226e6f6465223b7d, 'search_view', 0x613a323a7b693a303b733a343a226e6f6465223b693a313b693a323b7d, '', 6, 3, 1, 'search/node', 'search/node/%', 'Content', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/search/search.pages.inc'),
('system/ajax', '', '', '1', 0x613a303a7b7d, 'ajax_form_callback', 0x613a303a7b7d, 'ajax_deliver', 3, 2, 0, '', 'system/ajax', 'AHAH callback', 't', '', 'ajax_base_page_theme', 'a:0:{}', 0, '', '', 0, 'includes/form.inc'),
('system/files', '', '', '1', 0x613a303a7b7d, 'file_download', 0x613a313a7b693a303b733a373a2270726976617465223b7d, '', 3, 2, 0, '', 'system/files', 'File download', 't', '', '', 'a:0:{}', 0, '', '', 0, ''),
('system/temporary', '', '', '1', 0x613a303a7b7d, 'file_download', 0x613a313a7b693a303b733a393a2274656d706f72617279223b7d, '', 3, 2, 0, '', 'system/temporary', 'Temporary files', 't', '', '', 'a:0:{}', 0, '', '', 0, ''),
('system/timezone', '', '', '1', 0x613a303a7b7d, 'system_timezone', 0x613a303a7b7d, '', 3, 2, 0, '', 'system/timezone', 'Time zone', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/system/system.admin.inc'),
('taxonomy/autocomplete', '', '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'taxonomy_autocomplete', 0x613a303a7b7d, '', 3, 2, 0, '', 'taxonomy/autocomplete', 'Autocomplete taxonomy', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/taxonomy/taxonomy.pages.inc'),
('taxonomy/term/%', 0x613a313a7b693a323b733a31383a227461786f6e6f6d795f7465726d5f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'taxonomy_term_page', 0x613a313a7b693a303b693a323b7d, '', 6, 3, 0, '', 'taxonomy/term/%', 'Taxonomy term', 'taxonomy_term_title', 'a:1:{i:0;i:2;}', '', 'a:0:{}', 6, '', '', 0, 'modules/taxonomy/taxonomy.pages.inc'),
('taxonomy/term/%/edit', 0x613a313a7b693a323b733a31383a227461786f6e6f6d795f7465726d5f6c6f6164223b7d, '', 'taxonomy_term_edit_access', 0x613a313a7b693a303b693a323b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31383a227461786f6e6f6d795f666f726d5f7465726d223b693a313b693a323b7d, '', 13, 4, 1, 'taxonomy/term/%', 'taxonomy/term/%', 'Edit', 't', '', '', 'a:0:{}', 132, '', '', 10, 'modules/taxonomy/taxonomy.admin.inc'),
('taxonomy/term/%/feed', 0x613a313a7b693a323b733a31383a227461786f6e6f6d795f7465726d5f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'taxonomy_term_feed', 0x613a313a7b693a303b693a323b7d, '', 13, 4, 0, '', 'taxonomy/term/%/feed', 'Taxonomy term', 'taxonomy_term_title', 'a:1:{i:0;i:2;}', '', 'a:0:{}', 0, '', '', 0, 'modules/taxonomy/taxonomy.pages.inc'),
('taxonomy/term/%/view', 0x613a313a7b693a323b733a31383a227461786f6e6f6d795f7465726d5f6c6f6164223b7d, '', 'user_access', 0x613a313a7b693a303b733a31343a2261636365737320636f6e74656e74223b7d, 'taxonomy_term_page', 0x613a313a7b693a303b693a323b7d, '', 13, 4, 1, 'taxonomy/term/%', 'taxonomy/term/%', 'View', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/taxonomy/taxonomy.pages.inc'),
('token/autocomplete/%', 0x613a313a7b693a323b733a31353a22746f6b656e5f747970655f6c6f6164223b7d, '', '1', 0x613a303a7b7d, 'token_autocomplete_token', 0x613a313a7b693a303b693a323b7d, '', 6, 3, 0, '', 'token/autocomplete/%', '', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/token/token.pages.inc'),
('token/flush-cache', '', '', 'user_access', 0x613a313a7b693a303b733a31323a22666c75736820636163686573223b7d, 'token_flush_cache_callback', 0x613a303a7b7d, '', 3, 2, 0, '', 'token/flush-cache', '', 't', '', '', 'a:0:{}', 0, '', '', 0, 'sites/all/modules/contrib/token/token.pages.inc'),
('user', '', '', '1', 0x613a303a7b7d, 'user_page', 0x613a303a7b7d, '', 1, 1, 0, '', 'user', 'User account', 'user_menu_title', '', '', 'a:0:{}', 6, '', '', -10, 'modules/user/user.pages.inc'),
('user/%', 0x613a313a7b693a313b733a393a22757365725f6c6f6164223b7d, '', 'user_view_access', 0x613a313a7b693a303b693a313b7d, 'user_view_page', 0x613a313a7b693a303b693a313b7d, '', 2, 2, 0, '', 'user/%', 'My account', 'user_page_title', 'a:1:{i:0;i:1;}', '', 'a:0:{}', 6, '', '', 0, ''),
('user/%/cancel', 0x613a313a7b693a313b733a393a22757365725f6c6f6164223b7d, '', 'user_cancel_access', 0x613a313a7b693a303b693a313b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32343a22757365725f63616e63656c5f636f6e6669726d5f666f726d223b693a313b693a313b7d, '', 5, 3, 0, '', 'user/%/cancel', 'Cancel account', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/user/user.pages.inc'),
('user/%/cancel/confirm/%/%', 0x613a333a7b693a313b733a393a22757365725f6c6f6164223b693a343b4e3b693a353b4e3b7d, '', 'user_cancel_access', 0x613a313a7b693a303b693a313b7d, 'user_cancel_confirm', 0x613a333a7b693a303b693a313b693a313b693a343b693a323b693a353b7d, '', 44, 6, 0, '', 'user/%/cancel/confirm/%/%', 'Confirm account cancellation', 't', '', '', 'a:0:{}', 6, '', '', 0, 'modules/user/user.pages.inc'),
('user/%/contact', 0x613a313a7b693a313b733a393a22757365725f6c6f6164223b7d, '', '_contact_personal_tab_access', 0x613a313a7b693a303b693a313b7d, 'drupal_get_form', 0x613a323a7b693a303b733a32313a22636f6e746163745f706572736f6e616c5f666f726d223b693a313b693a313b7d, '', 5, 3, 1, 'user/%', 'user/%', 'Contact', 't', '', '', 'a:0:{}', 132, '', '', 2, 'modules/contact/contact.pages.inc'),
('user/%/edit', 0x613a313a7b693a313b733a393a22757365725f6c6f6164223b7d, '', 'user_edit_access', 0x613a313a7b693a303b693a313b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31373a22757365725f70726f66696c655f666f726d223b693a313b693a313b7d, '', 5, 3, 1, 'user/%', 'user/%', 'Edit', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/user/user.pages.inc'),
('user/%/edit/account', 0x613a313a7b693a313b613a313a7b733a31383a22757365725f63617465676f72795f6c6f6164223b613a323a7b693a303b733a343a22256d6170223b693a313b733a363a2225696e646578223b7d7d7d, '', 'user_edit_access', 0x613a313a7b693a303b693a313b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31373a22757365725f70726f66696c655f666f726d223b693a313b693a313b7d, '', 11, 4, 1, 'user/%/edit', 'user/%', 'Account', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/user/user.pages.inc'),
('user/%/shortcuts', 0x613a313a7b693a313b733a393a22757365725f6c6f6164223b7d, '', 'shortcut_set_switch_access', 0x613a313a7b693a303b693a313b7d, 'drupal_get_form', 0x613a323a7b693a303b733a31393a2273686f72746375745f7365745f737769746368223b693a313b693a313b7d, '', 5, 3, 1, 'user/%', 'user/%', 'Shortcuts', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/shortcut/shortcut.admin.inc'),
('user/%/view', 0x613a313a7b693a313b733a393a22757365725f6c6f6164223b7d, '', 'user_view_access', 0x613a313a7b693a303b693a313b7d, 'user_view_page', 0x613a313a7b693a303b693a313b7d, '', 5, 3, 1, 'user/%', 'user/%', 'View', 't', '', '', 'a:0:{}', 140, '', '', -10, ''),
('user/autocomplete', '', '', 'user_access', 0x613a313a7b693a303b733a32303a2261636365737320757365722070726f66696c6573223b7d, 'user_autocomplete', 0x613a303a7b7d, '', 3, 2, 0, '', 'user/autocomplete', 'User autocomplete', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/user/user.pages.inc'),
('user/login', '', '', 'user_is_anonymous', 0x613a303a7b7d, 'user_page', 0x613a303a7b7d, '', 3, 2, 1, 'user', 'user', 'Log in', 't', '', '', 'a:0:{}', 140, '', '', 0, 'modules/user/user.pages.inc'),
('user/logout', '', '', 'user_is_logged_in', 0x613a303a7b7d, 'user_logout', 0x613a303a7b7d, '', 3, 2, 0, '', 'user/logout', 'Log out', 't', '', '', 'a:0:{}', 6, '', '', 10, 'modules/user/user.pages.inc'),
('user/password', '', '', '1', 0x613a303a7b7d, 'drupal_get_form', 0x613a313a7b693a303b733a393a22757365725f70617373223b7d, '', 3, 2, 1, 'user', 'user', 'Request new password', 't', '', '', 'a:0:{}', 132, '', '', 0, 'modules/user/user.pages.inc'),
('user/register', '', '', 'user_register_access', 0x613a303a7b7d, 'drupal_get_form', 0x613a313a7b693a303b733a31383a22757365725f72656769737465725f666f726d223b7d, '', 3, 2, 1, 'user', 'user', 'Create new account', 't', '', '', 'a:0:{}', 132, '', '', 0, ''),
('user/reset/%/%/%', 0x613a333a7b693a323b4e3b693a333b4e3b693a343b4e3b7d, '', '1', 0x613a303a7b7d, 'drupal_get_form', 0x613a343a7b693a303b733a31353a22757365725f706173735f7265736574223b693a313b693a323b693a323b693a333b693a333b693a343b7d, '', 24, 5, 0, '', 'user/reset/%/%/%', 'Reset password', 't', '', '', 'a:0:{}', 0, '', '', 0, 'modules/user/user.pages.inc');

-- --------------------------------------------------------

--
-- Table structure for table `metatags_quick_path_based`
--

CREATE TABLE IF NOT EXISTS `metatags_quick_path_based` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Entity id',
  `path` varchar(255) NOT NULL COMMENT 'The path of the page to apply meta tags to',
  `lang` varchar(8) NOT NULL COMMENT 'Language code',
  PRIMARY KEY (`id`,`path`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Path based meta tags' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `metatags_quick_path_based`
--


-- --------------------------------------------------------

--
-- Table structure for table `mollom`
--

CREATE TABLE IF NOT EXISTS `mollom` (
  `entity` varchar(32) NOT NULL DEFAULT '' COMMENT 'Entity type of the content.',
  `id` varchar(32) NOT NULL DEFAULT '' COMMENT 'Unique entity ID of the content.',
  `session_id` varchar(255) NOT NULL DEFAULT '' COMMENT 'Session hash returned by Mollom.',
  `form_id` varchar(255) NOT NULL DEFAULT '' COMMENT 'The form_id of the form being protected.',
  `changed` int(11) NOT NULL DEFAULT '0' COMMENT 'Unix timestamp when the data was changed.',
  `moderate` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Whether the content needs to be moderated.',
  `spam` tinyint(4) DEFAULT NULL COMMENT 'Text analysis spam check result.',
  `quality` float DEFAULT NULL COMMENT 'Text analysis quality check result.',
  `profanity` float DEFAULT NULL COMMENT 'Text analysis profanity check result.',
  `languages` varchar(255) NOT NULL DEFAULT '' COMMENT 'Text analysis language check result.',
  PRIMARY KEY (`entity`,`id`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mollom`
--

INSERT INTO `mollom` (`entity`, `id`, `session_id`, `form_id`, `changed`, `moderate`, `spam`, `quality`, `profanity`, `languages`) VALUES
('comment', '10', '110612b59f57dbfb0c', 'comment_node_function_form', 1307875988, 0, NULL, NULL, NULL, ''),
('comment', '11', '110612c25fda702ff2', 'comment_node_article_form', 1315421454, 0, NULL, NULL, NULL, ''),
('comment', '12', '110618ec13b49c59a7', 'comment_node_function_form', 1308379199, 0, NULL, NULL, NULL, ''),
('comment', '13', '1106276ce2cf73f728', 'comment_node_function_form', 1309172417, 0, NULL, NULL, NULL, ''),
('comment', '14', '11070246dd1d30a842', 'comment_node_function_form', 1309638055, 0, NULL, NULL, NULL, ''),
('comment', '2', '110528c93b1bdeb2ce', 'comment_node_function_form', 1306775507, 0, NULL, NULL, NULL, ''),
('session', '110907f3856e8a9d80', '110907f3856e8a9d80', 'contact_site_form', 1315401167, 0, NULL, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `mollom_form`
--

CREATE TABLE IF NOT EXISTS `mollom_form` (
  `form_id` varchar(255) NOT NULL DEFAULT '' COMMENT 'The protected form ID.',
  `mode` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Protection mode for the form.',
  `checks` text COMMENT 'Text analyis checks to perform.',
  `discard` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Whether to discard (1) or retain (0) bad posts.',
  `enabled_fields` text COMMENT 'Form elements to analyze.',
  `module` varchar(255) NOT NULL DEFAULT '' COMMENT 'Module name owning the form.',
  `strictness` varchar(8) NOT NULL DEFAULT 'normal' COMMENT 'Strictness of text analysis checks.',
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mollom_form`
--

INSERT INTO `mollom_form` (`form_id`, `mode`, `checks`, `discard`, `enabled_fields`, `module`, `strictness`) VALUES
('comment_node_article_form', 1, 'a:1:{i:0;s:4:"spam";}', 0, 'a:2:{i:0;s:7:"subject";i:1;s:27:"comment_body][und][0][value";}', 'comment', 'normal'),
('comment_node_function_form', 1, 'a:1:{i:0;s:4:"spam";}', 1, 'a:2:{i:0;s:7:"subject";i:1;s:27:"comment_body][und][0][value";}', 'comment', 'normal'),
('comment_node_page_form', 1, 'a:1:{i:0;s:4:"spam";}', 1, 'a:2:{i:0;s:7:"subject";i:1;s:27:"comment_body][und][0][value";}', 'comment', 'normal'),
('contact_personal_form', 1, 'a:1:{i:0;s:4:"spam";}', 1, 'a:2:{i:0;s:7:"subject";i:1;s:7:"message";}', 'contact', 'normal'),
('contact_site_form', 1, 'a:1:{i:0;s:4:"spam";}', 1, 'a:2:{i:0;s:7:"subject";i:1;s:7:"message";}', 'contact', 'normal'),
('user_pass', 1, 'a:0:{}', 1, 'a:0:{}', 'user', 'normal'),
('user_register_form', 1, 'a:0:{}', 1, 'a:0:{}', 'user', 'normal');

-- --------------------------------------------------------

--
-- Table structure for table `node`
--

CREATE TABLE IF NOT EXISTS `node` (
  `nid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for a node.',
  `vid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The current node_revision.vid version identifier.',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT 'The node_type.type of this node.',
  `language` varchar(12) NOT NULL DEFAULT '' COMMENT 'The languages.language of this node.',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT 'The title of this node, always treated as non-markup plain text.',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid that owns this node; initially, this is the user that created it.',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT 'Boolean indicating whether the node is published (visible to non-administrators).',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp when the node was created.',
  `changed` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp when the node was most recently saved.',
  `comment` int(11) NOT NULL DEFAULT '0' COMMENT 'Whether comments are allowed on this node: 0 = no, 1 = closed (read only), 2 = open (read/write).',
  `promote` int(11) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether the node should be displayed on the front page.',
  `sticky` int(11) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether the node should be displayed at the top of lists in which it appears.',
  `tnid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The translation set id for this node, which equals the node id of the source post in each set.',
  `translate` int(11) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this translation page needs to be updated.',
  PRIMARY KEY (`nid`),
  UNIQUE KEY `vid` (`vid`),
  KEY `node_changed` (`changed`),
  KEY `node_created` (`created`),
  KEY `node_frontpage` (`promote`,`status`,`sticky`,`created`),
  KEY `node_status_type` (`status`,`type`,`nid`),
  KEY `node_title_type` (`title`,`type`(4)),
  KEY `node_type` (`type`(4)),
  KEY `uid` (`uid`),
  KEY `tnid` (`tnid`),
  KEY `translate` (`translate`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `node`
--

INSERT INTO `node` (`nid`, `vid`, `type`, `language`, `title`, `uid`, `status`, `created`, `changed`, `comment`, `promote`, `sticky`, `tnid`, `translate`) VALUES
(1, 1, 'page', 'und', 'About', 1, 1, 1306424079, 1315425875, 1, 0, 0, 0, 0),
(2, 2, 'article', 'und', 'Introducing DFOTW!', 1, 1, 1306424938, 1306445365, 2, 1, 0, 0, 0),
(3, 3, 'function', 'und', 'valid_email_address()', 1, 1, 1306426042, 1315421282, 2, 1, 0, 0, 0),
(4, 4, 'function', 'und', 'drupal_write_record()', 1, 1, 1306765977, 1315421365, 2, 1, 0, 0, 0),
(6, 6, 'function', 'und', 'field_file_load()', 1, 1, 1307549918, 1315413963, 2, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `node_access`
--

CREATE TABLE IF NOT EXISTS `node_access` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The node.nid this record affects.',
  `gid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The grant ID a user must possess in the specified realm to gain this row’s privileges on the node.',
  `realm` varchar(255) NOT NULL DEFAULT '' COMMENT 'The realm in which the user must possess the grant ID. Each node access node can define one or more realms.',
  `grant_view` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether a user with the realm/grant pair can view this node.',
  `grant_update` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether a user with the realm/grant pair can edit this node.',
  `grant_delete` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether a user with the realm/grant pair can delete this node.',
  PRIMARY KEY (`nid`,`gid`,`realm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_access`
--

INSERT INTO `node_access` (`nid`, `gid`, `realm`, `grant_view`, `grant_update`, `grant_delete`) VALUES
(0, 0, 'all', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `node_comment_statistics`
--

CREATE TABLE IF NOT EXISTS `node_comment_statistics` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The node.nid for which the statistics are compiled.',
  `cid` int(11) NOT NULL DEFAULT '0' COMMENT 'The comment.cid of the last comment.',
  `last_comment_timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp of the last comment that was posted within this node, from comment.timestamp.',
  `last_comment_name` varchar(60) DEFAULT NULL COMMENT 'The name of the latest author to post a comment on this node, from comment.name.',
  `last_comment_uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The user ID of the latest author to post a comment on this node, from comment.uid.',
  `comment_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The total number of comments on this node.',
  PRIMARY KEY (`nid`),
  KEY `node_comment_timestamp` (`last_comment_timestamp`),
  KEY `comment_count` (`comment_count`),
  KEY `last_comment_uid` (`last_comment_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_comment_statistics`
--

INSERT INTO `node_comment_statistics` (`nid`, `cid`, `last_comment_timestamp`, `last_comment_name`, `last_comment_uid`, `comment_count`) VALUES
(1, 0, 1306424079, NULL, 1, 0),
(2, 11, 1307876276, 'William Smith', 0, 2),
(3, 3, 1306775566, '', 1, 2),
(4, 9, 1307249344, 'William Smith', 0, 1),
(6, 0, 1307549918, NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `node_revision`
--

CREATE TABLE IF NOT EXISTS `node_revision` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The node this version belongs to.',
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The primary identifier for this version.',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid that created this version.',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT 'The title of this version.',
  `log` longtext NOT NULL COMMENT 'The log entry explaining the changes in this version.',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'A Unix timestamp indicating when this version was created.',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT 'Boolean indicating whether the node (at the time of this revision) is published (visible to non-administrators).',
  `comment` int(11) NOT NULL DEFAULT '0' COMMENT 'Whether comments are allowed on this node (at the time of this revision): 0 = no, 1 = closed (read only), 2 = open (read/write).',
  `promote` int(11) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether the node (at the time of this revision) should be displayed on the front page.',
  `sticky` int(11) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether the node (at the time of this revision) should be displayed at the top of lists in which it appears.',
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `node_revision`
--

INSERT INTO `node_revision` (`nid`, `vid`, `uid`, `title`, `log`, `timestamp`, `status`, `comment`, `promote`, `sticky`) VALUES
(1, 1, 1, 'About', '', 1315425875, 1, 1, 0, 0),
(2, 2, 1, 'Introducing DFOTW!', '', 1306445365, 1, 2, 1, 0),
(3, 3, 1, 'valid_email_address()', '', 1315421282, 1, 2, 1, 0),
(4, 4, 1, 'drupal_write_record()', '', 1315421365, 1, 2, 1, 0),
(6, 6, 1, 'field_file_load()', '', 1315413963, 1, 2, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `node_type`
--

CREATE TABLE IF NOT EXISTS `node_type` (
  `type` varchar(32) NOT NULL COMMENT 'The machine-readable name of this type.',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'The human-readable name of this type.',
  `base` varchar(255) NOT NULL COMMENT 'The base string used to construct callbacks corresponding to this node type.',
  `module` varchar(255) NOT NULL COMMENT 'The module defining this node type.',
  `description` mediumtext NOT NULL COMMENT 'A brief description of this type.',
  `help` mediumtext NOT NULL COMMENT 'Help information shown to the user when creating a node of this type.',
  `has_title` tinyint(3) unsigned NOT NULL COMMENT 'Boolean indicating whether this type uses the node.title field.',
  `title_label` varchar(255) NOT NULL DEFAULT '' COMMENT 'The label displayed for the title field on the edit form.',
  `custom` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this type is defined by a module (FALSE) or by a user via Add content type (TRUE).',
  `modified` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether this type has been modified by an administrator; currently not used in any way.',
  `locked` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether the administrator can change the machine name of this type.',
  `disabled` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A boolean indicating whether the node type is disabled.',
  `orig_type` varchar(255) NOT NULL DEFAULT '' COMMENT 'The original machine-readable name of this node type. This may be different from the current type name if the locked field is 0.',
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_type`
--

INSERT INTO `node_type` (`type`, `name`, `base`, `module`, `description`, `help`, `has_title`, `title_label`, `custom`, `modified`, `locked`, `disabled`, `orig_type`) VALUES
('article', 'Article', 'node_content', 'node', 'Use <em>articles</em> for time-sensitive content like news, press releases or blog posts.', '', 1, 'Title', 1, 1, 0, 0, 'article'),
('function', 'Function', 'node_content', 'node', 'Drupal Functions!', '', 1, 'Title', 1, 1, 0, 0, 'function'),
('page', 'Basic page', 'node_content', 'node', 'Use <em>basic pages</em> for your static content, such as an ''About us'' page.', '', 1, 'Title', 1, 1, 0, 0, 'page');

-- --------------------------------------------------------

--
-- Table structure for table `queue`
--

CREATE TABLE IF NOT EXISTS `queue` (
  `item_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique item ID.',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'The queue name.',
  `data` longblob COMMENT 'The arbitrary data for the item.',
  `expire` int(11) NOT NULL DEFAULT '0' COMMENT 'Timestamp when the claim lease expires on the item.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'Timestamp when the item was created.',
  PRIMARY KEY (`item_id`),
  KEY `name_created` (`name`,`created`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2316 ;

--
-- Dumping data for table `queue`
--

INSERT INTO `queue` (`item_id`, `name`, `data`, `expire`, `created`) VALUES
(2292, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a353a2264666f7477223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a353a2244464f5457223b733a373a227061636b616765223b733a353a2244464f5457223b733a373a2270726f6a656374223b733a353a2264666f7477223b733a373a2276657273696f6e223b733a373a22372e782d312e35223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353432333533313b733a393a22646174657374616d70223b693a303b7d733a393a22646174657374616d70223b693a303b733a383a22696e636c75646573223b613a313a7b733a353a2264666f7477223b733a353a2244464f5457223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423773),
(2293, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31303a2261646d696e5f6d656e75223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31393a2241646d696e697374726174696f6e206d656e75223b733a373a227061636b616765223b733a31343a2241646d696e697374726174696f6e223b733a373a2276657273696f6e223b733a31313a22372e782d332e302d726331223b733a373a2270726f6a656374223b733a31303a2261646d696e5f6d656e75223b733a393a22646174657374616d70223b733a31303a2231323934333738383730223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231323934333738383730223b733a383a22696e636c75646573223b613a323a7b733a31303a2261646d696e5f6d656e75223b733a31393a2241646d696e697374726174696f6e206d656e75223b733a31383a2261646d696e5f6d656e755f746f6f6c626172223b733a33333a2241646d696e697374726174696f6e206d656e7520546f6f6c626172207374796c65223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2294, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31343a226261636b75705f6d696772617465223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31383a224261636b757020616e64204d696772617465223b733a373a2276657273696f6e223b733a373a22372e782d322e32223b733a373a2270726f6a656374223b733a31343a226261636b75705f6d696772617465223b733a393a22646174657374616d70223b733a31303a2231333130353238323134223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393531323b7d733a393a22646174657374616d70223b733a31303a2231333130353238323134223b733a383a22696e636c75646573223b613a313a7b733a31343a226261636b75705f6d696772617465223b733a31383a224261636b757020616e64204d696772617465223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2295, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a363a2264727570616c223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a353a22426c6f636b223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a383a22696e636c75646573223b613a32363a7b733a353a22626c6f636b223b733a353a22426c6f636b223b733a353a22636f6c6f72223b733a353a22436f6c6f72223b733a373a22636f6d6d656e74223b733a373a22436f6d6d656e74223b733a373a22636f6e74616374223b733a373a22436f6e74616374223b733a31303a22636f6e7465787475616c223b733a31363a22436f6e7465787475616c206c696e6b73223b733a353a2264626c6f67223b733a31363a224461746162617365206c6f6767696e67223b733a353a226669656c64223b733a353a224669656c64223b733a31373a226669656c645f73716c5f73746f72616765223b733a31373a224669656c642053514c2073746f72616765223b733a383a226669656c645f7569223b733a383a224669656c64205549223b733a343a2266696c65223b733a343a2246696c65223b733a363a2266696c746572223b733a363a2246696c746572223b733a343a2268656c70223b733a343a2248656c70223b733a343a226c697374223b733a343a224c697374223b733a343a226d656e75223b733a343a224d656e75223b733a343a226e6f6465223b733a343a224e6f6465223b733a373a226f7074696f6e73223b733a373a224f7074696f6e73223b733a343a2270617468223b733a343a2250617468223b733a333a22726466223b733a333a22524446223b733a363a22736561726368223b733a363a22536561726368223b733a383a2273686f7274637574223b733a383a2253686f7274637574223b733a363a2273797374656d223b733a363a2253797374656d223b733a383a227461786f6e6f6d79223b733a383a225461786f6e6f6d79223b733a343a2274657874223b733a343a2254657874223b733a373a2274726967676572223b733a373a2254726967676572223b733a363a22757064617465223b733a31343a22557064617465206d616e61676572223b733a343a2275736572223b733a343a2255736572223b7d733a31323a2270726f6a6563745f74797065223b733a343a22636f7265223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2296, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a373a22636f6e74657874223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a373a22436f6e74657874223b733a373a227061636b616765223b733a373a22436f6e74657874223b733a373a2276657273696f6e223b733a31333a22372e782d332e302d6265746131223b733a373a2270726f6a656374223b733a373a22636f6e74657874223b733a393a22646174657374616d70223b733a31303a2231323938393235303638223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353431313937353b7d733a393a22646174657374616d70223b733a31303a2231323938393235303638223b733a383a22696e636c75646573223b613a323a7b733a373a22636f6e74657874223b733a373a22436f6e74657874223b733a31303a22636f6e746578745f7569223b733a31303a22436f6e74657874205549223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2297, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a363a2263746f6f6c73223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31313a224368616f7320746f6f6c73223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353431303231343b7d733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a383a22696e636c75646573223b613a313a7b733a363a2263746f6f6c73223b733a31313a224368616f7320746f6f6c73223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2298, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a353a2264666f7477223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a353a2244464f5457223b733a373a227061636b616765223b733a353a2244464f5457223b733a373a2270726f6a656374223b733a353a2264666f7477223b733a373a2276657273696f6e223b733a373a22372e782d312e35223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353432333533313b733a393a22646174657374616d70223b693a303b7d733a393a22646174657374616d70223b693a303b733a383a22696e636c75646573223b613a313a7b733a353a2264666f7477223b733a353a2244464f5457223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2299, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31313a22656173795f736f6369616c223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31313a224561737920536f6369616c223b733a373a2276657273696f6e223b733a31333a22372e782d312e302d6265746134223b733a373a2270726f6a656374223b733a31313a22656173795f736f6369616c223b733a393a22646174657374616d70223b733a31303a2231333133343633343136223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393533333b7d733a393a22646174657374616d70223b733a31303a2231333133343633343136223b733a383a22696e636c75646573223b613a313a7b733a31313a22656173795f736f6369616c223b733a31313a224561737920536f6369616c223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2300, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a383a226665617475726573223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a383a224665617475726573223b733a373a227061636b616765223b733a383a224665617475726573223b733a373a2276657273696f6e223b733a31333a22372e782d312e302d6265746133223b733a373a2270726f6a656374223b733a383a226665617475726573223b733a393a22646174657374616d70223b733a31303a2231333038353938393135223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393531383b7d733a393a22646174657374616d70223b733a31303a2231333038353938393135223b733a383a22696e636c75646573223b613a313a7b733a383a226665617475726573223b733a383a224665617475726573223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2301, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31313a226669656c645f67726f7570223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31303a224669656c6467726f7570223b733a373a227061636b616765223b733a363a224669656c6473223b733a373a2276657273696f6e223b733a373a22372e782d312e30223b733a373a2270726f6a656374223b733a31313a226669656c645f67726f7570223b733a393a22646174657374616d70223b733a31303a2231333036323636343136223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353431303230353b7d733a393a22646174657374616d70223b733a31303a2231333036323636343136223b733a383a22696e636c75646573223b613a313a7b733a31313a226669656c645f67726f7570223b733a31303a224669656c6467726f7570223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2302, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31323a2266696c7465725f7065726d73223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31383a2246696c746572207065726d697373696f6e73223b733a373a227061636b616765223b733a31343a2241646d696e697374726174696f6e223b733a373a2276657273696f6e223b733a31313a22372e782d312e782d646576223b733a373a2270726f6a656374223b733a31323a2266696c7465725f7065726d73223b733a393a22646174657374616d70223b733a31303a2231333134373530343732223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231333134373530343732223b733a383a22696e636c75646573223b613a313a7b733a31323a2266696c7465725f7065726d73223b733a31383a2246696c746572207065726d697373696f6e73223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2303, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31343a22676c6f62616c7265646972656374223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31353a22476c6f62616c205265646972656374223b733a373a2276657273696f6e223b733a373a22372e782d312e33223b733a373a2270726f6a656374223b733a31343a22676c6f62616c7265646972656374223b733a393a22646174657374616d70223b733a31303a2231323934323432393535223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231323934323432393535223b733a383a22696e636c75646573223b613a313a7b733a31343a22676c6f62616c7265646972656374223b733a31353a22476c6f62616c205265646972656374223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2304, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31363a22676f6f676c655f616e616c7974696373223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31363a22476f6f676c6520416e616c7974696373223b733a373a227061636b616765223b733a31303a2253746174697374696373223b733a373a2276657273696f6e223b733a373a22372e782d312e32223b733a373a2270726f6a656374223b733a31363a22676f6f676c655f616e616c7974696373223b733a393a22646174657374616d70223b733a31303a2231333031333430333637223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231333031333430333637223b733a383a22696e636c75646573223b613a313a7b733a31353a22676f6f676c65616e616c7974696373223b733a31363a22476f6f676c6520416e616c7974696373223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2305, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a363a22686561646a73223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a363a22486561644a53223b733a373a227061636b616765223b733a32373a22506572666f726d616e636520616e64207363616c6162696c697479223b733a373a2270726f6a656374223b733a363a22686561646a73223b733a373a2276657273696f6e223b733a373a22372e782d312e34223b733a393a22646174657374616d70223b733a31303a2231333036393839343135223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393532303b7d733a393a22646174657374616d70223b733a31303a2231333036393839343135223b733a383a22696e636c75646573223b613a313a7b733a363a22686561646a73223b733a363a22486561644a53223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2306, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a343a226c696e6b223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a343a224c696e6b223b733a373a227061636b616765223b733a363a224669656c6473223b733a373a2276657273696f6e223b733a31343a22372e782d312e302d616c70686133223b733a373a2270726f6a656374223b733a343a226c696e6b223b733a393a22646174657374616d70223b733a31303a2231323937303631323136223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231323937303631323136223b733a383a22696e636c75646573223b613a313a7b733a343a226c696e6b223b733a343a224c696e6b223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2307, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31343a226d657461746167735f717569636b223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31373a224d65746120746167732028717569636b29223b733a373a227061636b616765223b733a363a224669656c6473223b733a373a2276657273696f6e223b733a373a22372e782d322e30223b733a373a2270726f6a656374223b733a31343a226d657461746167735f717569636b223b733a393a22646174657374616d70223b733a31303a2231333132343033353233223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393532323b7d733a393a22646174657374616d70223b733a31303a2231333132343033353233223b733a383a22696e636c75646573223b613a313a7b733a31343a226d657461746167735f717569636b223b733a31373a224d65746120746167732028717569636b29223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2308, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a31333a226d6f64756c655f66696c746572223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31333a224d6f64756c652066696c746572223b733a373a2276657273696f6e223b733a373a22372e782d312e35223b733a373a2270726f6a656374223b733a31333a226d6f64756c655f66696c746572223b733a393a22646174657374616d70223b733a31303a2231333133353938313230223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231333133353938313230223b733a383a22696e636c75646573223b613a313a7b733a31333a226d6f64756c655f66696c746572223b733a31333a224d6f64756c652066696c746572223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2309, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a363a226d6f6c6c6f6d223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a363a224d6f6c6c6f6d223b733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a363a226d6f6c6c6f6d223b733a393a22646174657374616d70223b733a31303a2231333130323137373230223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393532343b7d733a393a22646174657374616d70223b733a31303a2231333130323137373230223b733a383a22696e636c75646573223b613a313a7b733a363a226d6f6c6c6f6d223b733a363a224d6f6c6c6f6d223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2310, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a383a22706174686175746f223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a383a22506174686175746f223b733a373a2276657273696f6e223b733a31313a22372e782d312e302d726332223b733a373a2270726f6a656374223b733a383a22706174686175746f223b733a393a22646174657374616d70223b733a31303a2231333038323431303231223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393532363b7d733a393a22646174657374616d70223b733a31303a2231333038323431303231223b733a383a22696e636c75646573223b613a313a7b733a383a22706174686175746f223b733a383a22506174686175746f223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2311, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a353a22706977696b223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a31393a22506977696b2057656220616e616c7974696373223b733a373a227061636b616765223b733a31303a2253746174697374696373223b733a373a2276657273696f6e223b733a373a22372e782d322e32223b733a373a2270726f6a656374223b733a353a22706977696b223b733a393a22646174657374616d70223b733a31303a2231333039363036363230223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231333039363036363230223b733a383a22696e636c75646573223b613a313a7b733a353a22706977696b223b733a31393a22506977696b2057656220616e616c7974696373223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2312, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a393a227363686564756c6572223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a393a225363686564756c6572223b733a373a2276657273696f6e223b733a373a22372e782d312e30223b733a373a2270726f6a656374223b733a393a227363686564756c6572223b733a393a22646174657374616d70223b733a31303a2231323939393339303639223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231323939393339303639223b733a383a22696e636c75646573223b613a313a7b733a393a227363686564756c6572223b733a393a225363686564756c6572223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2313, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a353a22746f6b656e223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a353a22546f6b656e223b733a373a2276657273696f6e223b733a31333a22372e782d312e302d6265746135223b733a373a2270726f6a656374223b733a353a22746f6b656e223b733a393a22646174657374616d70223b733a31303a2231333134383034373232223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393532383b7d733a393a22646174657374616d70223b733a31303a2231333134383034373232223b733a383a22696e636c75646573223b613a313a7b733a353a22746f6b656e223b733a353a22546f6b656e223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2314, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a383a227661726961626c65223b733a343a22696e666f223b613a363a7b733a343a226e616d65223b733a383a225661726961626c65223b733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a383a227661726961626c65223b733a393a22646174657374616d70223b733a31303a2231333133303838373231223b733a373a227061636b616765223b733a353a224f74686572223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393833363b7d733a393a22646174657374616d70223b733a31303a2231333133303838373231223b733a383a22696e636c75646573223b613a323a7b733a383a227661726961626c65223b733a383a225661726961626c65223b733a31343a227661726961626c655f7265616c6d223b733a31343a225661726961626c65207265616c6d223b7d733a31323a2270726f6a6563745f74797065223b733a363a226d6f64756c65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a303a7b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837),
(2315, 'update_fetch_tasks', 0x613a383a7b733a343a226e616d65223b733a373a22636f726f6c6c61223b733a343a22696e666f223b613a353a7b733a343a226e616d65223b733a373a22436f726f6c6c61223b733a373a2276657273696f6e223b733a383a22372e782d312e3231223b733a373a2270726f6a656374223b733a373a22636f726f6c6c61223b733a393a22646174657374616d70223b733a31303a2231323934373737323831223b733a31363a225f696e666f5f66696c655f6374696d65223b693a313331353430393236313b7d733a393a22646174657374616d70223b733a31303a2231323934373737323831223b733a383a22696e636c75646573223b613a313a7b733a373a22636f726f6c6c61223b733a373a22436f726f6c6c61223b7d733a31323a2270726f6a6563745f74797065223b733a353a227468656d65223b733a31343a2270726f6a6563745f737461747573223b623a313b733a31303a227375625f7468656d6573223b613a313a7b733a31333a2264666f74775f636f726f6c6c61223b733a31333a2244464f545720436f726f6c6c61223b7d733a31313a22626173655f7468656d6573223b613a303a7b7d7d, 0, 1315423837);

-- --------------------------------------------------------

--
-- Table structure for table `rdf_mapping`
--

CREATE TABLE IF NOT EXISTS `rdf_mapping` (
  `type` varchar(128) NOT NULL COMMENT 'The name of the entity type a mapping applies to (node, user, comment, etc.).',
  `bundle` varchar(128) NOT NULL COMMENT 'The name of the bundle a mapping applies to.',
  `mapping` longblob COMMENT 'The serialized mapping of the bundle type and fields to RDF terms.',
  PRIMARY KEY (`type`,`bundle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rdf_mapping`
--

INSERT INTO `rdf_mapping` (`type`, `bundle`, `mapping`) VALUES
('node', 'article', 0x613a31313a7b733a31313a226669656c645f696d616765223b613a323a7b733a31303a2270726564696361746573223b613a323a7b693a303b733a383a226f673a696d616765223b693a313b733a31323a22726466733a736565416c736f223b7d733a343a2274797065223b733a333a2272656c223b7d733a31303a226669656c645f74616773223b613a323a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31303a2264633a7375626a656374223b7d733a343a2274797065223b733a333a2272656c223b7d733a373a2272646674797065223b613a323a7b693a303b733a393a2273696f633a4974656d223b693a313b733a31333a22666f61663a446f63756d656e74223b7d733a353a227469746c65223b613a313a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a383a2264633a7469746c65223b7d7d733a373a2263726561746564223b613a333a7b733a31303a2270726564696361746573223b613a323a7b693a303b733a373a2264633a64617465223b693a313b733a31303a2264633a63726561746564223b7d733a383a226461746174797065223b733a31323a227873643a6461746554696d65223b733a383a2263616c6c6261636b223b733a31323a22646174655f69736f38363031223b7d733a373a226368616e676564223b613a333a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31313a2264633a6d6f646966696564223b7d733a383a226461746174797065223b733a31323a227873643a6461746554696d65223b733a383a2263616c6c6261636b223b733a31323a22646174655f69736f38363031223b7d733a343a22626f6479223b613a313a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31353a22636f6e74656e743a656e636f646564223b7d7d733a333a22756964223b613a323a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31363a2273696f633a6861735f63726561746f72223b7d733a343a2274797065223b733a333a2272656c223b7d733a343a226e616d65223b613a313a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a393a22666f61663a6e616d65223b7d7d733a31333a22636f6d6d656e745f636f756e74223b613a323a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31363a2273696f633a6e756d5f7265706c696573223b7d733a383a226461746174797065223b733a31313a227873643a696e7465676572223b7d733a31333a226c6173745f6163746976697479223b613a333a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a32333a2273696f633a6c6173745f61637469766974795f64617465223b7d733a383a226461746174797065223b733a31323a227873643a6461746554696d65223b733a383a2263616c6c6261636b223b733a31323a22646174655f69736f38363031223b7d7d),
('node', 'page', 0x613a393a7b733a373a2272646674797065223b613a313a7b693a303b733a31333a22666f61663a446f63756d656e74223b7d733a353a227469746c65223b613a313a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a383a2264633a7469746c65223b7d7d733a373a2263726561746564223b613a333a7b733a31303a2270726564696361746573223b613a323a7b693a303b733a373a2264633a64617465223b693a313b733a31303a2264633a63726561746564223b7d733a383a226461746174797065223b733a31323a227873643a6461746554696d65223b733a383a2263616c6c6261636b223b733a31323a22646174655f69736f38363031223b7d733a373a226368616e676564223b613a333a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31313a2264633a6d6f646966696564223b7d733a383a226461746174797065223b733a31323a227873643a6461746554696d65223b733a383a2263616c6c6261636b223b733a31323a22646174655f69736f38363031223b7d733a343a22626f6479223b613a313a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31353a22636f6e74656e743a656e636f646564223b7d7d733a333a22756964223b613a323a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31363a2273696f633a6861735f63726561746f72223b7d733a343a2274797065223b733a333a2272656c223b7d733a343a226e616d65223b613a313a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a393a22666f61663a6e616d65223b7d7d733a31333a22636f6d6d656e745f636f756e74223b613a323a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a31363a2273696f633a6e756d5f7265706c696573223b7d733a383a226461746174797065223b733a31313a227873643a696e7465676572223b7d733a31333a226c6173745f6163746976697479223b613a333a7b733a31303a2270726564696361746573223b613a313a7b693a303b733a32333a2273696f633a6c6173745f61637469766974795f64617465223b7d733a383a226461746174797065223b733a31323a227873643a6461746554696d65223b733a383a2263616c6c6261636b223b733a31323a22646174655f69736f38363031223b7d7d);

-- --------------------------------------------------------

--
-- Table structure for table `registry`
--

CREATE TABLE IF NOT EXISTS `registry` (
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'The name of the function, class, or interface.',
  `type` varchar(9) NOT NULL DEFAULT '' COMMENT 'Either function or class or interface.',
  `filename` varchar(255) NOT NULL COMMENT 'Name of the file.',
  `module` varchar(255) NOT NULL DEFAULT '' COMMENT 'Name of the module the file belongs to.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'The order in which this module’s hooks should be invoked relative to other modules. Equal-weighted modules are ordered by name.',
  PRIMARY KEY (`name`,`type`),
  KEY `hook` (`type`,`weight`,`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `registry`
--

INSERT INTO `registry` (`name`, `type`, `filename`, `module`, `weight`) VALUES
('AccessDeniedTestCase', 'class', 'modules/system/system.test', 'system', 0),
('AdminMenuLinksTestCase', 'class', 'sites/all/modules/contrib/admin_menu/tests/admin_menu.test', 'admin_menu', 0),
('AdminMenuPermissionsTestCase', 'class', 'sites/all/modules/contrib/admin_menu/tests/admin_menu.test', 'admin_menu', 0),
('AdminMenuWebTestCase', 'class', 'sites/all/modules/contrib/admin_menu/tests/admin_menu.test', 'admin_menu', 0),
('AdminMetaTagTestCase', 'class', 'modules/system/system.test', 'system', 0),
('ArchiverInterface', 'interface', 'includes/archiver.inc', '', 0),
('ArchiverTar', 'class', 'modules/system/system.archiver.inc', 'system', 0),
('ArchiverZip', 'class', 'modules/system/system.archiver.inc', 'system', 0),
('Archive_Tar', 'class', 'modules/system/system.tar.inc', 'system', 0),
('backup_migrate_destination', 'class', 'sites/all/modules/contrib/backup_migrate/includes/destinations.inc', 'backup_migrate', 0),
('backup_migrate_destination_remote', 'class', 'sites/all/modules/contrib/backup_migrate/includes/destinations.inc', 'backup_migrate', 0),
('backup_migrate_profile', 'class', 'sites/all/modules/contrib/backup_migrate/includes/profiles.inc', 'backup_migrate', 0),
('backup_migrate_schedule', 'class', 'sites/all/modules/contrib/backup_migrate/includes/schedules.inc', 'backup_migrate', 0),
('BatchMemoryQueue', 'class', 'includes/batch.queue.inc', '', 0),
('BatchQueue', 'class', 'includes/batch.queue.inc', '', 0),
('BlockAdminThemeTestCase', 'class', 'modules/block/block.test', 'block', -5),
('BlockCacheTestCase', 'class', 'modules/block/block.test', 'block', -5),
('BlockHTMLIdTestCase', 'class', 'modules/block/block.test', 'block', -5),
('BlockTemplateSuggestionsUnitTest', 'class', 'modules/block/block.test', 'block', -5),
('BlockTestCase', 'class', 'modules/block/block.test', 'block', -5),
('ColorTestCase', 'class', 'modules/color/color.test', 'color', 0),
('CommentActionsTestCase', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentAnonymous', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentApprovalTest', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentBlockFunctionalTest', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentContentRebuild', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentController', 'class', 'modules/comment/comment.module', 'comment', 0),
('CommentFieldsTest', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentHelperCase', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentInterfaceTest', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentNodeAccessTest', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentPagerTest', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentPreviewTest', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentRSSUnitTest', 'class', 'modules/comment/comment.test', 'comment', 0),
('CommentTokenReplaceTestCase', 'class', 'modules/comment/comment.test', 'comment', 0),
('ContactPersonalTestCase', 'class', 'modules/contact/contact.test', 'contact', 0),
('ContactSitewideTestCase', 'class', 'modules/contact/contact.test', 'contact', 0),
('ContextConditionBookroot', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionBookTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionContextTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionLanguageTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionMenuTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionNodeTaxonomyTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionNodeTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionPathTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionSitewideTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionUserPageTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextConditionUserTest', 'class', 'sites/all/modules/contrib/context/tests/context.conditions.test', 'context', 0),
('ContextReactionBlockAjaxTest', 'class', 'sites/all/modules/contrib/context/tests/context.reactions.test', 'context', 0),
('ContextReactionBlockTest', 'class', 'sites/all/modules/contrib/context/tests/context.reactions.test', 'context', 0),
('ContextReactionBreadcrumbTest', 'class', 'sites/all/modules/contrib/context/tests/context.reactions.test', 'context', 0),
('ContextReactionMenuTest', 'class', 'sites/all/modules/contrib/context/tests/context.reactions.test', 'context', 0),
('ContextReactionThemeHtmlTest', 'class', 'sites/all/modules/contrib/context/tests/context.reactions.test', 'context', 0),
('ContextUiTestCase', 'class', 'sites/all/modules/contrib/context/context_ui/tests/context_ui.test', 'context_ui', 0),
('ContextUnitTest', 'class', 'sites/all/modules/contrib/context/tests/context.test', 'context', 0),
('context_condition', 'class', 'sites/all/modules/contrib/context/plugins/context_condition.inc', 'context', 0),
('context_condition_context', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_context.inc', 'context', 0),
('context_condition_menu', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_menu.inc', 'context', 0),
('context_condition_node', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_node.inc', 'context', 0),
('context_condition_node_taxonomy', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_node_taxonomy.inc', 'context', 0),
('context_condition_path', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_path.inc', 'context', 0),
('context_condition_sitewide', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_sitewide.inc', 'context', 0),
('context_condition_taxonomy_term', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_taxonomy_term.inc', 'context', 0),
('context_condition_user', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_user.inc', 'context', 0),
('context_condition_user_page', 'class', 'sites/all/modules/contrib/context/plugins/context_condition_user_page.inc', 'context', 0),
('context_export_ui', 'class', 'sites/all/modules/contrib/context/context_ui/export_ui/context_export_ui.class.php', 'context_ui', 0),
('context_reaction', 'class', 'sites/all/modules/contrib/context/plugins/context_reaction.inc', 'context', 0),
('context_reaction_block', 'class', 'sites/all/modules/contrib/context/plugins/context_reaction_block.inc', 'context', 0),
('context_reaction_breadcrumb', 'class', 'sites/all/modules/contrib/context/plugins/context_reaction_breadcrumb.inc', 'context', 0),
('context_reaction_debug', 'class', 'sites/all/modules/contrib/context/plugins/context_reaction_debug.inc', 'context', 0),
('context_reaction_menu', 'class', 'sites/all/modules/contrib/context/plugins/context_reaction_menu.inc', 'context', 0),
('context_reaction_theme', 'class', 'sites/all/modules/contrib/context/plugins/context_reaction_theme.inc', 'context', 0),
('context_reaction_theme_html', 'class', 'sites/all/modules/contrib/context/plugins/context_reaction_theme_html.inc', 'context', 0),
('CronRunTestCase', 'class', 'modules/system/system.test', 'system', 0),
('ctools_context', 'class', 'sites/all/modules/contrib/ctools/includes/context.inc', 'ctools', 0),
('ctools_context_optional', 'class', 'sites/all/modules/contrib/ctools/includes/context.inc', 'ctools', 0),
('ctools_context_required', 'class', 'sites/all/modules/contrib/ctools/includes/context.inc', 'ctools', 0),
('ctools_export_ui', 'class', 'sites/all/modules/contrib/ctools/plugins/export_ui/ctools_export_ui.class.php', 'ctools', 0),
('ctools_math_expr', 'class', 'sites/all/modules/contrib/ctools/includes/math-expr.inc', 'ctools', 0),
('ctools_math_expr_stack', 'class', 'sites/all/modules/contrib/ctools/includes/math-expr.inc', 'ctools', 0),
('ctools_stylizer_image_processor', 'class', 'sites/all/modules/contrib/ctools/includes/stylizer.inc', 'ctools', 0),
('Database', 'class', 'includes/database/database.inc', '', 0),
('DatabaseCondition', 'class', 'includes/database/query.inc', '', 0),
('DatabaseConnection', 'class', 'includes/database/database.inc', '', 0),
('DatabaseConnectionNotDefinedException', 'class', 'includes/database/database.inc', '', 0),
('DatabaseConnection_mysql', 'class', 'includes/database/mysql/database.inc', '', 0),
('DatabaseConnection_pgsql', 'class', 'includes/database/pgsql/database.inc', '', 0),
('DatabaseConnection_sqlite', 'class', 'includes/database/sqlite/database.inc', '', 0),
('DatabaseDriverNotSpecifiedException', 'class', 'includes/database/database.inc', '', 0),
('DatabaseLog', 'class', 'includes/database/log.inc', '', 0),
('DatabaseSchema', 'class', 'includes/database/schema.inc', '', 0),
('DatabaseSchemaObjectDoesNotExistException', 'class', 'includes/database/schema.inc', '', 0),
('DatabaseSchemaObjectExistsException', 'class', 'includes/database/schema.inc', '', 0),
('DatabaseSchema_mysql', 'class', 'includes/database/mysql/schema.inc', '', 0),
('DatabaseSchema_pgsql', 'class', 'includes/database/pgsql/schema.inc', '', 0),
('DatabaseSchema_sqlite', 'class', 'includes/database/sqlite/schema.inc', '', 0),
('DatabaseStatementBase', 'class', 'includes/database/database.inc', '', 0),
('DatabaseStatementEmpty', 'class', 'includes/database/database.inc', '', 0),
('DatabaseStatementInterface', 'interface', 'includes/database/database.inc', '', 0),
('DatabaseStatementPrefetch', 'class', 'includes/database/prefetch.inc', '', 0),
('DatabaseStatement_sqlite', 'class', 'includes/database/sqlite/database.inc', '', 0),
('DatabaseTaskException', 'class', 'includes/install.inc', '', 0),
('DatabaseTasks', 'class', 'includes/install.inc', '', 0),
('DatabaseTasks_mysql', 'class', 'includes/database/mysql/install.inc', '', 0),
('DatabaseTasks_pgsql', 'class', 'includes/database/pgsql/install.inc', '', 0),
('DatabaseTasks_sqlite', 'class', 'includes/database/sqlite/install.inc', '', 0),
('DatabaseTransaction', 'class', 'includes/database/database.inc', '', 0),
('DatabaseTransactionCommitFailedException', 'class', 'includes/database/database.inc', '', 0),
('DatabaseTransactionExplicitCommitNotAllowedException', 'class', 'includes/database/database.inc', '', 0),
('DatabaseTransactionNameNonUniqueException', 'class', 'includes/database/database.inc', '', 0),
('DatabaseTransactionNoActiveException', 'class', 'includes/database/database.inc', '', 0),
('DatabaseTransactionOutOfOrderException', 'class', 'includes/database/database.inc', '', 0),
('DateTimeFunctionalTest', 'class', 'modules/system/system.test', 'system', 0),
('DBLogTestCase', 'class', 'modules/dblog/dblog.test', 'dblog', 0),
('DefaultMailSystem', 'class', 'modules/system/system.mail.inc', 'system', 0),
('DeleteQuery', 'class', 'includes/database/query.inc', '', 0),
('DeleteQuery_sqlite', 'class', 'includes/database/sqlite/query.inc', '', 0),
('DrupalCacheArray', 'class', 'includes/bootstrap.inc', '', 0),
('DrupalCacheInterface', 'interface', 'includes/cache.inc', '', 0),
('DrupalDatabaseCache', 'class', 'includes/cache.inc', '', 0),
('DrupalDefaultEntityController', 'class', 'includes/entity.inc', '', 0),
('DrupalEntityControllerInterface', 'interface', 'includes/entity.inc', '', 0),
('DrupalFakeCache', 'class', 'includes/cache-install.inc', '', 0),
('DrupalLocalStreamWrapper', 'class', 'includes/stream_wrappers.inc', '', 0),
('DrupalPrivateStreamWrapper', 'class', 'includes/stream_wrappers.inc', '', 0),
('DrupalPublicStreamWrapper', 'class', 'includes/stream_wrappers.inc', '', 0),
('DrupalQueue', 'class', 'modules/system/system.queue.inc', 'system', 0),
('DrupalQueueInterface', 'interface', 'modules/system/system.queue.inc', 'system', 0),
('DrupalReliableQueueInterface', 'interface', 'modules/system/system.queue.inc', 'system', 0),
('DrupalStreamWrapperInterface', 'interface', 'includes/stream_wrappers.inc', '', 0),
('DrupalTemporaryStreamWrapper', 'class', 'includes/stream_wrappers.inc', '', 0),
('DrupalUpdateException', 'class', 'includes/update.inc', '', 0),
('DrupalUpdaterInterface', 'interface', 'includes/updater.inc', '', 0),
('EnableDisableTestCase', 'class', 'modules/system/system.test', 'system', 0),
('EntityFieldQuery', 'class', 'includes/entity.inc', '', 0),
('EntityFieldQueryException', 'class', 'includes/entity.inc', '', 0),
('EntityMalformedException', 'class', 'includes/entity.inc', '', 0),
('EntityPropertiesTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FeaturesUserTestCase', 'class', 'sites/all/modules/contrib/features/tests/features.test', 'features', 20),
('FieldAttachOtherTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldAttachStorageTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldAttachTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldBulkDeleteTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldCrudTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldDisplayAPITestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldException', 'class', 'modules/field/field.module', 'field', 0),
('FieldFormTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldInfoTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldInstanceCrudTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldsOverlapException', 'class', 'includes/database/database.inc', '', 0),
('FieldSqlStorageTestCase', 'class', 'modules/field/modules/field_sql_storage/field_sql_storage.test', 'field_sql_storage', 0),
('FieldTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldTranslationsTestCase', 'class', 'modules/field/tests/field.test', 'field', 0),
('FieldUIManageDisplayTestCase', 'class', 'modules/field_ui/field_ui.test', 'field_ui', 0),
('FieldUIManageFieldsTestCase', 'class', 'modules/field_ui/field_ui.test', 'field_ui', 0),
('FieldUITestCase', 'class', 'modules/field_ui/field_ui.test', 'field_ui', 0),
('FieldUpdateForbiddenException', 'class', 'modules/field/field.module', 'field', 0),
('FieldValidationException', 'class', 'modules/field/field.attach.inc', 'field', 0),
('FileFieldDisplayTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FileFieldPathTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FileFieldRevisionTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FileFieldTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FileFieldValidateTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FileFieldWidgetTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FileManagedFileElementTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FilePrivateTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FileTokenReplaceTestCase', 'class', 'modules/file/tests/file.test', 'file', 0),
('FileTransfer', 'class', 'includes/filetransfer/filetransfer.inc', '', 0),
('FileTransferChmodInterface', 'interface', 'includes/filetransfer/filetransfer.inc', '', 0),
('FileTransferException', 'class', 'includes/filetransfer/filetransfer.inc', '', 0),
('FileTransferFTP', 'class', 'includes/filetransfer/ftp.inc', '', 0),
('FileTransferFTPExtension', 'class', 'includes/filetransfer/ftp.inc', '', 0),
('FileTransferLocal', 'class', 'includes/filetransfer/local.inc', '', 0),
('FileTransferSSH', 'class', 'includes/filetransfer/ssh.inc', '', 0),
('FilterAdminTestCase', 'class', 'modules/filter/filter.test', 'filter', 0),
('FilterCRUDTestCase', 'class', 'modules/filter/filter.test', 'filter', 0),
('FilterDefaultFormatTestCase', 'class', 'modules/filter/filter.test', 'filter', 0),
('FilterFormatAccessTestCase', 'class', 'modules/filter/filter.test', 'filter', 0),
('FilterHooksTestCase', 'class', 'modules/filter/filter.test', 'filter', 0),
('FilterNoFormatTestCase', 'class', 'modules/filter/filter.test', 'filter', 0),
('FilterSecurityTestCase', 'class', 'modules/filter/filter.test', 'filter', 0),
('FilterUnitTestCase', 'class', 'modules/filter/filter.test', 'filter', 0),
('FloodFunctionalTest', 'class', 'modules/system/system.test', 'system', 0),
('FrontPageTestCase', 'class', 'modules/system/system.test', 'system', 0),
('GlobalRedirectTestCase', 'class', 'sites/all/modules/contrib/globalredirect/globalredirect.test', 'globalredirect', 0),
('GlobalRedirectTestCaseConfigAlpha', 'class', 'sites/all/modules/contrib/globalredirect/globalredirect.test', 'globalredirect', 0),
('GlobalRedirectTestCaseDefault', 'class', 'sites/all/modules/contrib/globalredirect/globalredirect.test', 'globalredirect', 0),
('GoogleAnalyticsBasicTest', 'class', 'sites/all/modules/contrib/google_analytics/googleanalytics.test', 'googleanalytics', 0),
('GoogleAnalyticsRolesTest', 'class', 'sites/all/modules/contrib/google_analytics/googleanalytics.test', 'googleanalytics', 0),
('GroupUITestCase', 'class', 'sites/all/modules/contrib/field_group/field_group.test', 'field_group', 0),
('HelpTestCase', 'class', 'modules/help/help.test', 'help', 0),
('HookRequirementsTestCase', 'class', 'modules/system/system.test', 'system', 0),
('InfoFileParserTestCase', 'class', 'modules/system/system.test', 'system', 0),
('InsertQuery', 'class', 'includes/database/query.inc', '', 0),
('InsertQuery_mysql', 'class', 'includes/database/mysql/query.inc', '', 0),
('InsertQuery_pgsql', 'class', 'includes/database/pgsql/query.inc', '', 0),
('InsertQuery_sqlite', 'class', 'includes/database/sqlite/query.inc', '', 0),
('InvalidMergeQueryException', 'class', 'includes/database/database.inc', '', 0),
('IPAddressBlockingTestCase', 'class', 'modules/system/system.test', 'system', 0),
('LinkAttributeCrudTest', 'class', 'sites/all/modules/contrib/link/tests/link.attribute.test', 'link', 0),
('LinkContentCrudTest', 'class', 'sites/all/modules/contrib/link/tests/link.crud.test', 'link', 0),
('LinkUITest', 'class', 'sites/all/modules/contrib/link/tests/link.crud_browser.test', 'link', 0),
('LinkValidateSpecificURL', 'class', 'sites/all/modules/contrib/link/tests/link.validate.test', 'link', 0),
('LinkValidateTest', 'class', 'sites/all/modules/contrib/link/tests/link.validate.test', 'link', 0),
('LinkValidateTestCase', 'class', 'sites/all/modules/contrib/link/tests/link.validate.test', 'link', 0),
('LinkValidateTestNews', 'class', 'sites/all/modules/contrib/link/tests/link.validate.test', 'link', 0),
('LinkValidateUrlLight', 'class', 'sites/all/modules/contrib/link/tests/link.validate.test', 'link', 0),
('link_views_handler_argument_target', 'class', 'sites/all/modules/contrib/link/views/link_views_handler_argument_target.inc', 'link', 0),
('link_views_handler_filter_protocol', 'class', 'sites/all/modules/contrib/link/views/link_views_handler_filter_protocol.inc', 'link', 0),
('ListFieldTestCase', 'class', 'modules/field/modules/list/tests/list.test', 'list', 0),
('ListFieldUITestCase', 'class', 'modules/field/modules/list/tests/list.test', 'list', 0),
('MailSystemInterface', 'interface', 'includes/mail.inc', '', 0),
('MemoryQueue', 'class', 'modules/system/system.queue.inc', 'system', 0),
('MenuNodeTestCase', 'class', 'modules/menu/menu.test', 'menu', 0),
('MenuTestCase', 'class', 'modules/menu/menu.test', 'menu', 0),
('MergeQuery', 'class', 'includes/database/query.inc', '', 0),
('ModuleDependencyTestCase', 'class', 'modules/system/system.test', 'system', 0),
('ModuleRequiredTestCase', 'class', 'modules/system/system.test', 'system', 0),
('ModuleTestCase', 'class', 'modules/system/system.test', 'system', 0),
('ModuleUpdater', 'class', 'modules/system/system.updater.inc', 'system', 0),
('ModuleVersionTestCase', 'class', 'modules/system/system.test', 'system', 0),
('MollomAccessTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomAnalysisTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomBlacklistTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomCommentFormTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomContactFormTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomDataCRUDTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomDataTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomFallbackTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomFormConfigurationTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomInstallationTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomLanguageDetectionTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomNodeFormTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomProfanityTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomProfileFormsTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomReportTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomResellerTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomResponseLocalTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomResponseTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomServerListRecoveryTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomUserFormsTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MollomWebTestCase', 'class', 'sites/all/modules/contrib/mollom/tests/mollom.test', 'mollom', 0),
('MultiStepNodeFormBasicOptionsTest', 'class', 'modules/node/node.test', 'node', 0),
('NewDefaultThemeBlocks', 'class', 'modules/block/block.test', 'block', -5),
('NodeAccessBaseTableTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeAccessRebuildTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeAccessRecordsUnitTest', 'class', 'modules/node/node.test', 'node', 0),
('NodeAccessUnitTest', 'class', 'modules/node/node.test', 'node', 0),
('NodeAdminTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeBlockFunctionalTest', 'class', 'modules/node/node.test', 'node', 0),
('NodeBlockTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeBuildContent', 'class', 'modules/node/node.test', 'node', 0),
('NodeController', 'class', 'modules/node/node.module', 'node', 0),
('NodeCreationTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeEntityFieldQueryAlter', 'class', 'modules/node/node.test', 'node', 0),
('NodeFeedTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeLoadHooksTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeLoadMultipleUnitTest', 'class', 'modules/node/node.test', 'node', 0),
('NodePostSettingsTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeQueryAlter', 'class', 'modules/node/node.test', 'node', 0),
('NodeRevisionsTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeRSSContentTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeSaveTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeTitleTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeTitleXSSTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeTokenReplaceTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeTypePersistenceTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NodeTypeTestCase', 'class', 'modules/node/node.test', 'node', 0),
('NoFieldsException', 'class', 'includes/database/database.inc', '', 0),
('NoHelpTestCase', 'class', 'modules/help/help.test', 'help', 0),
('NonDefaultBlockAdmin', 'class', 'modules/block/block.test', 'block', -5),
('OptionsWidgetsTestCase', 'class', 'modules/field/modules/options/options.test', 'options', 0),
('PageEditTestCase', 'class', 'modules/node/node.test', 'node', 0),
('PageNotFoundTestCase', 'class', 'modules/system/system.test', 'system', 0),
('PagePreviewTestCase', 'class', 'modules/node/node.test', 'node', 0),
('PagerDefault', 'class', 'includes/pager.inc', '', 0),
('PageTitleFiltering', 'class', 'modules/system/system.test', 'system', 0),
('PageViewTestCase', 'class', 'modules/node/node.test', 'node', 0),
('PathautoBulkUpdateTestCase', 'class', 'sites/all/modules/contrib/pathauto/pathauto.test', 'pathauto', 1),
('PathautoFunctionalTestCase', 'class', 'sites/all/modules/contrib/pathauto/pathauto.test', 'pathauto', 1),
('PathautoFunctionalTestHelper', 'class', 'sites/all/modules/contrib/pathauto/pathauto.test', 'pathauto', 1),
('PathautoLocaleTestCase', 'class', 'sites/all/modules/contrib/pathauto/pathauto.test', 'pathauto', 1),
('PathautoTestHelper', 'class', 'sites/all/modules/contrib/pathauto/pathauto.test', 'pathauto', 1),
('PathautoUnitTestCase', 'class', 'sites/all/modules/contrib/pathauto/pathauto.test', 'pathauto', 1),
('PathLanguageTestCase', 'class', 'modules/path/path.test', 'path', 0),
('PathLanguageUITestCase', 'class', 'modules/path/path.test', 'path', 0),
('PathMonolingualTestCase', 'class', 'modules/path/path.test', 'path', 0),
('PathTaxonomyTermTestCase', 'class', 'modules/path/path.test', 'path', 0),
('PathTestCase', 'class', 'modules/path/path.test', 'path', 0),
('PiwikBasicTest', 'class', 'sites/all/modules/contrib/piwik/piwik.test', 'piwik', 0),
('PiwikRolesTest', 'class', 'sites/all/modules/contrib/piwik/piwik.test', 'piwik', 0),
('Query', 'class', 'includes/database/query.inc', '', 0),
('QueryAlterableInterface', 'interface', 'includes/database/query.inc', '', 0),
('QueryConditionInterface', 'interface', 'includes/database/query.inc', '', 0),
('QueryExtendableInterface', 'interface', 'includes/database/select.inc', '', 0),
('QueryPlaceholderInterface', 'interface', 'includes/database/query.inc', '', 0),
('QueueTestCase', 'class', 'modules/system/system.test', 'system', 0),
('RdfCommentAttributesTestCase', 'class', 'modules/rdf/rdf.test', 'rdf', 0),
('RdfCrudTestCase', 'class', 'modules/rdf/rdf.test', 'rdf', 0),
('RdfGetRdfNamespacesTestCase', 'class', 'modules/rdf/rdf.test', 'rdf', 0),
('RdfMappingDefinitionTestCase', 'class', 'modules/rdf/rdf.test', 'rdf', 0),
('RdfMappingHookTestCase', 'class', 'modules/rdf/rdf.test', 'rdf', 0),
('RdfRdfaMarkupTestCase', 'class', 'modules/rdf/rdf.test', 'rdf', 0),
('RdfTrackerAttributesTestCase', 'class', 'modules/rdf/rdf.test', 'rdf', 0),
('RetrieveFileTestCase', 'class', 'modules/system/system.test', 'system', 0),
('SchedulerTestCase', 'class', 'sites/all/modules/contrib/scheduler/scheduler.test', 'scheduler', 0),
('scheduler_handler_field_scheduler_countdown', 'class', 'sites/all/modules/contrib/scheduler/scheduler_handler_field_scheduler_countdown.inc', 'scheduler', 0),
('SchemaCache', 'class', 'includes/bootstrap.inc', '', 0),
('SearchAdvancedSearchForm', 'class', 'modules/search/search.test', 'search', 0),
('SearchBlockTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchCommentCountToggleTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchCommentTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchConfigSettingsForm', 'class', 'modules/search/search.test', 'search', 0),
('SearchEmbedForm', 'class', 'modules/search/search.test', 'search', 0),
('SearchExactTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchExcerptTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchExpressionInsertExtractTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchKeywordsConditions', 'class', 'modules/search/search.test', 'search', 0),
('SearchLanguageTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchMatchTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchNodeAccessTest', 'class', 'modules/search/search.test', 'search', 0),
('SearchNumberMatchingTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchNumbersTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchPageOverride', 'class', 'modules/search/search.test', 'search', 0),
('SearchPageText', 'class', 'modules/search/search.test', 'search', 0),
('SearchQuery', 'class', 'modules/search/search.extender.inc', 'search', 0),
('SearchRankingTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchSimplifyTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SearchTokenizerTestCase', 'class', 'modules/search/search.test', 'search', 0),
('SelectQuery', 'class', 'includes/database/select.inc', '', 0),
('SelectQueryExtender', 'class', 'includes/database/select.inc', '', 0),
('SelectQueryInterface', 'interface', 'includes/database/select.inc', '', 0),
('SelectQuery_pgsql', 'class', 'includes/database/pgsql/select.inc', '', 0),
('SelectQuery_sqlite', 'class', 'includes/database/sqlite/select.inc', '', 0),
('ShortcutLinksTestCase', 'class', 'modules/shortcut/shortcut.test', 'shortcut', 0),
('ShortcutSetsTestCase', 'class', 'modules/shortcut/shortcut.test', 'shortcut', 0),
('ShortcutTestCase', 'class', 'modules/shortcut/shortcut.test', 'shortcut', 0),
('ShutdownFunctionsTest', 'class', 'modules/system/system.test', 'system', 0),
('SiteMaintenanceTestCase', 'class', 'modules/system/system.test', 'system', 0),
('SkipDotsRecursiveDirectoryIterator', 'class', 'includes/filetransfer/filetransfer.inc', '', 0),
('StreamWrapperInterface', 'interface', 'includes/stream_wrappers.inc', '', 0),
('SummaryLengthTestCase', 'class', 'modules/node/node.test', 'node', 0),
('SystemAdminTestCase', 'class', 'modules/system/system.test', 'system', 0),
('SystemAuthorizeCase', 'class', 'modules/system/system.test', 'system', 0),
('SystemBlockTestCase', 'class', 'modules/system/system.test', 'system', 0),
('SystemIndexPhpTest', 'class', 'modules/system/system.test', 'system', 0),
('SystemInfoAlterTestCase', 'class', 'modules/system/system.test', 'system', 0),
('SystemMainContentFallback', 'class', 'modules/system/system.test', 'system', 0),
('SystemQueue', 'class', 'modules/system/system.queue.inc', 'system', 0),
('SystemThemeFunctionalTest', 'class', 'modules/system/system.test', 'system', 0),
('TableSort', 'class', 'includes/tablesort.inc', '', 0),
('TaxonomyHooksTestCase', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyLegacyTestCase', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyLoadMultipleUnitTest', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyTermController', 'class', 'modules/taxonomy/taxonomy.module', 'taxonomy', 0),
('TaxonomyTermFieldTestCase', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyTermTestCase', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyTermUnitTest', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyThemeTestCase', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyTokenReplaceTestCase', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyVocabularyController', 'class', 'modules/taxonomy/taxonomy.module', 'taxonomy', 0),
('TaxonomyVocabularyFunctionalTest', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyVocabularyUnitTest', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TaxonomyWebTestCase', 'class', 'modules/taxonomy/taxonomy.test', 'taxonomy', 0),
('TestingMailSystem', 'class', 'modules/system/system.mail.inc', 'system', 0),
('TextFieldTestCase', 'class', 'modules/field/modules/text/text.test', 'text', 0),
('TextSummaryTestCase', 'class', 'modules/field/modules/text/text.test', 'text', 0),
('TextTranslationTestCase', 'class', 'modules/field/modules/text/text.test', 'text', 0),
('ThemeUpdater', 'class', 'modules/system/system.updater.inc', 'system', 0),
('TokenArrayTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenCommentTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenCurrentPageTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenDateTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenEntityTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenMenuTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenNodeTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenProfileTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenRandomTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenReplaceTestCase', 'class', 'modules/system/system.test', 'system', 0),
('TokenTaxonomyTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenTestHelper', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenUnitTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenURLTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TokenUserTestCase', 'class', 'sites/all/modules/contrib/token/token.test', 'token', 0),
('TriggerActionTestCase', 'class', 'modules/trigger/trigger.test', 'trigger', 0),
('TriggerContentTestCase', 'class', 'modules/trigger/trigger.test', 'trigger', 0),
('TriggerCronTestCase', 'class', 'modules/trigger/trigger.test', 'trigger', 0),
('TriggerOrphanedActionsTestCase', 'class', 'modules/trigger/trigger.test', 'trigger', 0),
('TriggerOtherTestCase', 'class', 'modules/trigger/trigger.test', 'trigger', 0),
('TriggerUserActionTestCase', 'class', 'modules/trigger/trigger.test', 'trigger', 0),
('TriggerUserTokenTestCase', 'class', 'modules/trigger/trigger.test', 'trigger', 0),
('TriggerWebTestCase', 'class', 'modules/trigger/trigger.test', 'trigger', 0),
('TruncateQuery', 'class', 'includes/database/query.inc', '', 0),
('TruncateQuery_mysql', 'class', 'includes/database/mysql/query.inc', '', 0),
('TruncateQuery_sqlite', 'class', 'includes/database/sqlite/query.inc', '', 0),
('UpdateCoreTestCase', 'class', 'modules/update/update.test', 'update', 0),
('UpdateQuery', 'class', 'includes/database/query.inc', '', 0),
('UpdateQuery_pgsql', 'class', 'includes/database/pgsql/query.inc', '', 0),
('UpdateQuery_sqlite', 'class', 'includes/database/sqlite/query.inc', '', 0),
('Updater', 'class', 'includes/updater.inc', '', 0),
('UpdaterException', 'class', 'includes/updater.inc', '', 0),
('UpdaterFileTransferException', 'class', 'includes/updater.inc', '', 0),
('UpdateScriptFunctionalTest', 'class', 'modules/system/system.test', 'system', 0),
('UpdateTestContribCase', 'class', 'modules/update/update.test', 'update', 0),
('UpdateTestHelper', 'class', 'modules/update/update.test', 'update', 0),
('UpdateTestUploadCase', 'class', 'modules/update/update.test', 'update', 0),
('UserAccountLinksUnitTests', 'class', 'modules/user/user.test', 'user', 0),
('UserAdminTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserAuthmapAssignmentTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserAutocompleteTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserBlocksUnitTests', 'class', 'modules/user/user.test', 'user', 0),
('UserCancelTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserController', 'class', 'modules/user/user.module', 'user', 0),
('UserCreateTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserEditedOwnAccountTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserEditTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserLoginTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserPermissionsTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserPictureTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserRegistrationTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserRoleAdminTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserRolesAssignmentTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserSaveTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserSignatureTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserTimeZoneFunctionalTest', 'class', 'modules/user/user.test', 'user', 0),
('UserTokenReplaceTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserUserSearchTestCase', 'class', 'modules/user/user.test', 'user', 0),
('UserValidateCurrentPassCustomForm', 'class', 'modules/user/user.test', 'user', 0),
('UserValidationTestCase', 'class', 'modules/user/user.test', 'user', 0);

-- --------------------------------------------------------

--
-- Table structure for table `registry_file`
--

CREATE TABLE IF NOT EXISTS `registry_file` (
  `filename` varchar(255) NOT NULL COMMENT 'Path to the file.',
  `hash` varchar(64) NOT NULL COMMENT 'sha-256 hash of the file’s contents when last parsed.',
  PRIMARY KEY (`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `registry_file`
--

INSERT INTO `registry_file` (`filename`, `hash`) VALUES
('includes/actions.inc', '3e1b89b7dd2465549361915ffc50b713a8f3a568baa703f034e48b24977f83c8'),
('includes/ajax.inc', 'a6a0847d63032f67c4bd06c3926c639cfafc58f52c17f31f4c8c13fa5699cc6a'),
('includes/archiver.inc', '097a78f5794237e8242b540649d824b930008027362c1359773e22c2b21cd6e5'),
('includes/authorize.inc', 'bd85cb5d7bec2906e85be1b7187410680190b568e433fdcff944f74b7e1c616d'),
('includes/batch.inc', 'f32d52b88dc6bd0b3117fef0057d6084fbe132afb0fbf638daaa42bce7a2a3c5'),
('includes/batch.queue.inc', '34face1f61857ec26e414712c647b06acbd5ec4437a71abf090e83cbdf691794'),
('includes/bootstrap.inc', 'faeef91dec3a689471b90199da366756459f70ff9084bb78f94b755cb3b04dd4'),
('includes/cache-install.inc', '2d223093cf3740d190746d1c348607694a8475c0da91ffd2386454995a17995e'),
('includes/cache.inc', '5239bd1707257d0abdd5396d6febd34bea08dd6ceb318265f3c9b7b21b38f23f'),
('includes/common.inc', '3e60fff0c30dea3c0739e52d0cc1f30070b60f2406edcde31e71006139b40bff'),
('includes/database/database.inc', '6e508386cce4f1f26dba5e897fc99dd7a4b5cbf12f4076e979ff2a6c98137357'),
('includes/database/log.inc', '4ecbdf9022d8c612310b41af575f10b0d4c041c0fbc41c6dc7e1f2ab6eacce6b'),
('includes/database/mysql/database.inc', 'b0f19ed69d68e1a43f46e10a5a3bfbf97ce72cf936379c1519ceccfa3b359584'),
('includes/database/mysql/install.inc', '6ae316941f771732fbbabed7e1d6b4cbb41b1f429dd097d04b3345aa15e461a0'),
('includes/database/mysql/query.inc', 'e2a5457ec40a8f88f6a822bdc77f74865e4c02206fc733c2945c8897f46093de'),
('includes/database/mysql/schema.inc', 'f71af9dda287f0f37e7bd0077b801a6d3f38c951a9c2c6ea3b71dff1b69077d3'),
('includes/database/pgsql/database.inc', 'c2bf3fa2d03583f3a6c6df76dc5ee204f7d44d5c2ee451af500583d4775877e0'),
('includes/database/pgsql/install.inc', '585b80c5bbd6f134bff60d06397f15154657a577d4da8d1b181858905f09dea5'),
('includes/database/pgsql/query.inc', 'cb4c84f8f1ffc73098ed71137248dcd078a505a7530e60d979d74b3a3cdaa658'),
('includes/database/pgsql/schema.inc', '1442123ab5040a55797126cfa1cf9103f7a9df22b3c23b5055c9c27e4f12d262'),
('includes/database/pgsql/select.inc', 'ce06c4353d4322e519e1c90ca863e6666edc370fb3c12568fedf466334b2e2be'),
('includes/database/prefetch.inc', '8d39658800c5b648b8aafc253cd36162c22ba54febe543ad14fc50016b02ba93'),
('includes/database/query.inc', '5c7c960209b84c874e9e6bafdcdc59eeb45651b6969e7f8ba17a460294fa2256'),
('includes/database/schema.inc', '1996c5e11a984348f29baa6f19e9a995280828bdbbaa3e8c5d747dd28e93d7a2'),
('includes/database/select.inc', 'f623cc9572f87b76716389d7188884f78a0aa110006e48374151c1aef31b29f0'),
('includes/database/sqlite/database.inc', '644fe9e0b31303b46b080cbc41fe4c2b3fc972071dcb34f754d7f83f0ce79083'),
('includes/database/sqlite/install.inc', '381f3db8c59837d961978ba3097bb6443534ed1659fd713aa563963fa0c42cc5'),
('includes/database/sqlite/query.inc', '61e0459c0c9252ca465b86c475d88e09ea34c8cdb28220eb37a7d44357f5474f'),
('includes/database/sqlite/schema.inc', 'b43202cce5e8a637432b0d83c90b6250822b722ee033e1b6f7b3d76b92ffc9a7'),
('includes/database/sqlite/select.inc', '4ecb9d21d2f07237f7603e925519886dde0b8da82f96999b865ff0803438744e'),
('includes/date.inc', '32124baa81a1411631de23ade5615be0d81bc7c7169ea60d22f9badd333cf284'),
('includes/entity.inc', '0d3e537e907e9465ef3affe63adaf3a22889673c0618789998c09b831807e8b1'),
('includes/errors.inc', '2bb3582fbee23850aa480f9a13bf11f886cf81de3fa02545aba64a407facd982'),
('includes/file.inc', 'cf898bf744766b0ee006da7a5745a8487305ffc777bacbb2cea10bf7ed788a14'),
('includes/file.mimetypes.inc', 'c6078a196ca29acb4b62a3a3c336e822d2a74cbc2c9df630e539790cb8bcbbbc'),
('includes/filetransfer/filetransfer.inc', 'ee9393beddc7190f7a161f5563953d1b58e355026fcc2392443a9e6b4c600531'),
('includes/filetransfer/ftp.inc', '589ebf4b8bd4a2973aa56a156ac1fa83b6c73e703391361fb573167670e0d832'),
('includes/filetransfer/local.inc', '7cbfdb46abbdf539640db27e66fb30e5265128f31002bd0dfc3af16ae01a9492'),
('includes/filetransfer/ssh.inc', '002e24a24cac133d12728bd3843868ce378681237d7fad420761af84e6efe5ad'),
('includes/form.inc', '88d2f1e41bd84dced516a392b2b0428de0e1214d6d4ddee143f473e9c57ff013'),
('includes/graph.inc', '577a50594521edecd7139fcecd6af3a941e456ea0e0577e38ee14b785422aabb'),
('includes/image.inc', '2fefbd7e73eb51eece8acd7b374b23bf77a717c1553ad83b321a7be194c9e531'),
('includes/install.core.inc', 'b230ede834f21c75dc736d5f583b41b02f3c88eef37b1ee9036d294c7f9dbba2'),
('includes/install.inc', '2dda96a9169cd82e5f49c08c311a1be9decd6c259a385c57b370284072078ec5'),
('includes/iso.inc', '379c2bd8332ce03a3772787b004e9b1a4468fd23f18d1b9397902fd6d9dbf2d8'),
('includes/language.inc', '5e0595c6def071694fa500b4636d15d482dafddb612a977201b5406b813be7a6'),
('includes/locale.inc', '5e6890eaaab5acd3bda2f2d2dc6e3faa9a4a77649ca2cae4225b9d0f24b50fda'),
('includes/lock.inc', 'daa62e95528f6b986b85680b600a896452bf2ce6f38921242857dcc5a3460a1b'),
('includes/mail.inc', '673b413f445966854954699ceccd0deae860c1359e2334c3bbe93e31a52dd9b0'),
('includes/menu.inc', 'd9460911178cc73d72a414f5a048d5b51f754d4f2e987ee97d474dc2102f2671'),
('includes/module.inc', 'ac27386cf8bfb02192580b8f51ca354a7ea30e444084203d02f2ce9285e85b60'),
('includes/pager.inc', '48733f9985fd5879b964b91b69215edb63efc30d24a222df0893d35e0096b9e6'),
('includes/password.inc', 'c3fc2fef03822dfe9981bab502a37893f8865ff529ad34cf9be9a17e86add510'),
('includes/path.inc', '992d563dbd6e67f58e358176be09eb1fb75f95510a93cb45bf463ce798670bff'),
('includes/registry.inc', 'ce22f7715c8037095e6b7dfb86594d3f5ca0908e0614862cc60334852ce3b971'),
('includes/session.inc', '2a904d6eb8f561b5c6b08c6e7528b76b2b8d7f1de34e9738cebe69a1a0b922b2'),
('includes/stream_wrappers.inc', '2942d0e700d46b8eae25dd72ede0e355de3b3b2ff309447fb6cbe89543370d2e'),
('includes/tablesort.inc', '3f3cb2820920f7edc0c3d046ffba4fc4e3b73a699a2492780371141cf501aa50'),
('includes/theme.inc', 'b82fd541fc6b375ebc833f87eb4ee8eef4b31ee51f7fe5c5321ae831df0a73ee'),
('includes/theme.maintenance.inc', 'd110314b4d943c3e965fcefe452f6873b53cd6a8844154467dfcbb2b6142dc82'),
('includes/token.inc', '015328d6573ceece0a0712fcbad890719cff8d65a37839ece36bc64e97d63466'),
('includes/unicode.entities.inc', '2b858138596d961fbaa4c6e3986e409921df7f76b6ee1b109c4af5970f1e0f54'),
('includes/unicode.inc', '5409227091e55cef4c1b0bb9c159720aecaa07e7bf2683fe7c242691aa1036cc'),
('includes/update.inc', '11b276443e4eb4515453c47608f0e019a9f90e4354f2f157502eb9258636b4e5'),
('includes/updater.inc', '1715fbda750de86ecde8abd71d61886423367d3c9a17c31138638361b1c27e51'),
('includes/utility.inc', '04865d2c973e3df62f673b68631a880dbf39fdc5e22a5935e2e6b86576fa9030'),
('includes/xmlrpc.inc', '1176a9e5b5990f8219b48c49bb858a2a980f95428aa519acea19282109e27e83'),
('includes/xmlrpcs.inc', '2df450cf2153959a4581d8e61867c587f61fcdea5dd2653e36c6a6028fc1b395'),
('modules/block/block.test', '910abf2e1b7d31e5e5330f34cf21d04e8b8d55f24cfdd7ee3e82e38bf572267e'),
('modules/color/color.test', '5cc2a668dba0b8905ca360a7bfa04e9e501b61b7a8ac88b51ecca688dda1a21e'),
('modules/comment/comment.module', '9f9d5a7b5e654276c81d3cbe0089bb990f085823e892dc26b90f825aef8faab7'),
('modules/comment/comment.test', '262c7f7982e3c3d6dea3646ad5bacc6f0611dffaeb2043675b789edc31bb19ec'),
('modules/contact/contact.test', 'bc84b64bf9d5bca6c55832d36c0e32b5e50b05132c40cdac3018151135e8ee28'),
('modules/dblog/dblog.test', '8538535f68ac410003a9d0776915b4ca42e61f9fec848b4d65a79dc28a43d49c'),
('modules/field/field.attach.inc', '65b6f010e3f9d1868098d771963113307b63fd6e6454c01f0086cd4c0de71414'),
('modules/field/field.module', 'e4b0bab77e29904d0a95077aa3425e54bf15d8d1185bee26969bf5c59ac68698'),
('modules/field/modules/field_sql_storage/field_sql_storage.test', 'fa8f69ac79f4190a612faa6d1df3075be39571da2e897265c13e219dccf65b1c'),
('modules/field/modules/list/tests/list.test', '13e32f6e649512897f4e277d88aa0dbead2a605346f581321396464ab8ad0b0c'),
('modules/field/modules/options/options.test', '2f2e15ab5e6da04033933af77663df220db3da30d0546327ef757968d628e43a'),
('modules/field/modules/text/text.test', '9d74c6d039f55dd7d6447a59186da8d48bf20617bfe58424612798f649797586'),
('modules/field/tests/field.test', '1b8d334223ca9e8b5cf7ebfc0727baf5552e303ee01040986e82c852bda1741a'),
('modules/field_ui/field_ui.test', '58c6515fd7b3bf1d48dbf7a8f5f414df8e74b6e525af5d3ccc852060e245526a'),
('modules/file/tests/file.test', '651e17859b7ba69958a72fa5a3b5bbca40dc53c79a7b512eb83076c81da0960d'),
('modules/filter/filter.test', 'd1c4f5c10917aa93b6cc1dab58a7f3a86fe4530d21d6c8e63a8fe58a7bd7487f'),
('modules/help/help.test', 'ff6d9f5fc415451951c21a07b125ff749a7cefba879c27e14bb42eb621c58f9d'),
('modules/menu/menu.test', '5d584ef0191c39c11dda474a6a8f6223f6bc82cdbc41ee5742c8fe28f300949a'),
('modules/node/node.module', 'cc290bd3cf407046025f88feb8d4e353e579128b101713abdb2e2c63ee637f14'),
('modules/node/node.test', 'e37213792452a8f98cd0cca66396d9de27464dcc53c50c9032d1225fd794f356'),
('modules/path/path.test', 'bf6a774f0d9b92a48d752eaa270f430ea21ce35e0c09da423442939ac56f9473'),
('modules/rdf/rdf.test', '358e2ae2069a15c6ba828f3428ab979632ece7aa0ba33a6a5bdbc1d065961373'),
('modules/search/search.extender.inc', 'a8c42b2cac7863835f7f632c7fbfd77b6fe936d465b3bbff73b1645a99c0c9d3'),
('modules/search/search.test', '2a7af7339aae041f1ddf3916fefc58635c3101b9397ea865cf712a87034aa963'),
('modules/shortcut/shortcut.test', '0bbc6b16348442ce0aa5cd610feed80ac2b2b3887c709fc457ba0a913ae01f3b'),
('modules/system/system.archiver.inc', 'faa849f3e646a910ab82fd6c8bbf0a4e6b8c60725d7ba81ec0556bd716616cd1'),
('modules/system/system.mail.inc', 'b7ee9ea80059788d8b53823a91db015dfa6c2a66589a6eca6f97b99340e12d6f'),
('modules/system/system.queue.inc', '4bfc1845db9c888f3df0937a9ff6d783de77880e6301431db9eb2268b9fe572d'),
('modules/system/system.tar.inc', '743529eab763be74e8169c945e875381fd77d71e336c6d77b7d28e2dfd023a21'),
('modules/system/system.test', '1bbebd6438335e2b1b6bf4758b6a02c642a2cbe4180bb03fb7dcce2782c3f0cf'),
('modules/system/system.updater.inc', 'e2eeed65b833a6215f807b113f6fb4cc3cc487e93efcb1402ed87c536d2c9ea6'),
('modules/taxonomy/taxonomy.module', 'aab96a917f887d5cd09c517316ca3253d94b08b141a0946449f0a40683411401'),
('modules/taxonomy/taxonomy.test', 'bf998b97d53e036d6f5a0af8a26dc78b0afa1ae37d2f4aefd4aae087a9351f08'),
('modules/trigger/trigger.test', 'b837c431835eec912a0e922d871392c3daa97ea42b8beba35f6e0ae7d3747c45'),
('modules/update/update.test', 'c357e4a16e1d96b13706a03aff7a3f30011f4e997087c040c5cf8ec77a132a5f'),
('modules/user/user.module', 'd4466cdad9273944d42b059607586bc155d52ca2a6b898523295159e2c5b0aa0'),
('modules/user/user.test', '9b6cc136d3a267ad039069ac040f9ec33481ef43fd1fb888929750a076302c7c'),
('profiles/standard/standard.profile', '7237f80e54061c9611c6dc4fcf6225951eedba0704694f4d801673693ba11a05'),
('sites/all/modules/contrib/admin_menu/admin_menu_toolbar/admin_menu_toolbar.install', 'fa43670359b69b413a4424986239a72e4fa93b40bc0f0947d5c516b2edfd4600'),
('sites/all/modules/contrib/admin_menu/admin_menu_toolbar/admin_menu_toolbar.module', '6a9ff3627164ff54b0441cdb6b293aee4f0f5443362b7572ef70d9183f55c792'),
('sites/all/modules/contrib/admin_menu/tests/admin_menu.test', 'cbe5e711cd57da3203e60269be8864c70269d6e41492f964b4f4d1e7b71bcea1'),
('sites/all/modules/contrib/backup_migrate/backup_migrate.install', '0b1200a2e52bc23577f220b33b6a3c0077473181af02a7e80b0cd7fa49153127'),
('sites/all/modules/contrib/backup_migrate/backup_migrate.module', '17d0bd1057a6bb01b683a84c13d35fd91a3f92e18d416b5d028ce82d2388017e'),
('sites/all/modules/contrib/backup_migrate/includes/destinations.inc', '91d464dc8cde11dbe4a781881007325eba8ceed029bfee8afb3b627c5a80a4b1'),
('sites/all/modules/contrib/backup_migrate/includes/profiles.inc', '7a1268ab91f7fcfb1079864a52ba09f2dc0cde64b1bac3a6d50b72e79e2fa76c'),
('sites/all/modules/contrib/backup_migrate/includes/schedules.inc', 'c9069d29807bc611cd366dadf4eed1b0557aff40eea0277af2eb1cc801790ca8'),
('sites/all/modules/contrib/context/context.module', 'a6374709cfcadaaf7f0ed5932d770864a2d5b945c333c78ef8419903b4c48b9d'),
('sites/all/modules/contrib/context/context_ui/export_ui/context_export_ui.class.php', '2dbf7ad85ea90a6bdf616988bae0d5b0af11ee09a2f8b6ccb96a6b28729a7fd5'),
('sites/all/modules/contrib/context/context_ui/tests/context_ui.test', 'd3cfef417918e64e2e04a5da4986ab237a3007c69acb514b4153cf698c6fbd81'),
('sites/all/modules/contrib/context/plugins/context_condition.inc', '2701acb0f8667cf922052a9265bb84c936a3b716afaf3a8eff2ad04e332b5a2f'),
('sites/all/modules/contrib/context/plugins/context_condition_context.inc', 'aac79d0b4ae5168e93e777f4f7676d9bf8f5ff4e56fd41bfaaf5897d49418639'),
('sites/all/modules/contrib/context/plugins/context_condition_menu.inc', 'c73c873e97366a79c084e4fdee6be1c2fa5095b79ee898def9dcfe52d97b4c5c'),
('sites/all/modules/contrib/context/plugins/context_condition_node.inc', '8d54a13f2ed57cd1a36d1dbcba62e32f256ed6e71554643599fca50a3dddbbd0'),
('sites/all/modules/contrib/context/plugins/context_condition_node_taxonomy.inc', '3adeef238700135f30ae6c427b526c8cac72b45363314407dd105d0abb66d5ee'),
('sites/all/modules/contrib/context/plugins/context_condition_path.inc', '14c1004f88044be28194280127d0c30d2f0e42b0d1f38d5adc8187ab4fe05821'),
('sites/all/modules/contrib/context/plugins/context_condition_sitewide.inc', 'cb5061fe6757287744f3db7296380120089c4e56af3298395aeaa3da16aedc3b'),
('sites/all/modules/contrib/context/plugins/context_condition_taxonomy_term.inc', '94eb955d5705e75936cc440417893e341905fa7fb3df3b6d3e7d838fa33e313c'),
('sites/all/modules/contrib/context/plugins/context_condition_user.inc', 'a6fd04ce6574d5391427a038da1f158f47b062cde7655811fa5a41271e75d20c'),
('sites/all/modules/contrib/context/plugins/context_condition_user_page.inc', 'c5c48146a183e6d2cdfa07222e7f614bd9ba3ff4b745131c9910aeb79bbf4bcd'),
('sites/all/modules/contrib/context/plugins/context_reaction.inc', 'eceef7d8d1c8ca0a7f155eabe6c5b5851e310bd07348bced0c8de3815711b3a3'),
('sites/all/modules/contrib/context/plugins/context_reaction_block.inc', '7667c001fbc81c20c0ca93363df0f7064fc3dadb30d3753976a05d73c7eab6ff'),
('sites/all/modules/contrib/context/plugins/context_reaction_breadcrumb.inc', '74f584631e0b4b3f6dae6dfc0d29cc04b0c3801976a41dedec91230973bc271a'),
('sites/all/modules/contrib/context/plugins/context_reaction_debug.inc', '3d53d1789bba9a842d1ace8042056fb75c670a8d049e9ca89a3777d9a709c2be'),
('sites/all/modules/contrib/context/plugins/context_reaction_menu.inc', '9e4af0f82b9cc03dbf433335239f5832be21955d9f22c4d9efca9ee76c1ab47d'),
('sites/all/modules/contrib/context/plugins/context_reaction_theme.inc', 'eae05dc2e34947aacc18bdfb4925df9a7946d64d9b23e7cde92ee23610cadffd'),
('sites/all/modules/contrib/context/plugins/context_reaction_theme_html.inc', 'b0b4f355aebce29dbaa3e2bf26c35443d134f73649f1e197170e73d5ab93e0a2'),
('sites/all/modules/contrib/context/tests/context.conditions.test', 'cfac55cd55c9679218f1a141278a82398612097465414e7fa754348fc1b92583'),
('sites/all/modules/contrib/context/tests/context.reactions.test', '61bd63ae2c34c94bccb7a660a968626ea044f81a510d4a006a472e701461ae50'),
('sites/all/modules/contrib/context/tests/context.test', '1d2e8a3111c019286770501fa259e11640d5dc7b200da8469e44ecf20f5487fe'),
('sites/all/modules/contrib/ctools/includes/context.inc', '1fea8bd479e653096ddc1674225911a8169b272d332d6a038dd7421c4cd5726e'),
('sites/all/modules/contrib/ctools/includes/math-expr.inc', 'fa1ba6a7642e847acf3777ceb38f366b50d103d5b7dddcf8833b7470ea2008ea'),
('sites/all/modules/contrib/ctools/includes/stylizer.inc', '1632f3c68f92c79b1200a191680edcadaf34e5b48f3562fa494b2e983f255ec7'),
('sites/all/modules/contrib/ctools/plugins/export_ui/ctools_export_ui.class.php', '651bc6f8c7d533fcf76c463e1fbbec453b8e84b7eb6887e54ec50faa6709891a'),
('sites/all/modules/contrib/easy_social/easy_social.module', '709b80a081810abd46e35970872a8266e9b2c24d165570c41f4fb1501d0d7965'),
('sites/all/modules/contrib/features/tests/features.test', '3e02be511611b8ab3e3edc6420a57ba677d3aedcb0c416d08b85546bfb67e9bf'),
('sites/all/modules/contrib/field_group/field_group.field_ui.inc', '7b6c51efbf2d85509a9ac7e757db99b685e56366127d6b5e3d2b25d80e1ad648'),
('sites/all/modules/contrib/field_group/field_group.install', 'ab3bf4f8f4da2471c8d0a126e3e48bcbe9269ccfc377f410f139d08db8453042'),
('sites/all/modules/contrib/field_group/field_group.module', '74af00bf7248a780e55ff3d116aa276fd41a36964bb8dbcf178ab303f5c76fb1'),
('sites/all/modules/contrib/field_group/field_group.test', '3d26d8d1408bcf661c07db962ce287bdd5cc513329a8af4d357e7a66fa068244'),
('sites/all/modules/contrib/globalredirect/globalredirect.admin.inc', 'ac7438bb52dd6348b0ad8faa167ae54a5d948d7ff9abb2e165f6a3f72c62a6c4'),
('sites/all/modules/contrib/globalredirect/globalredirect.install', '2d605b2613f9bfd2ee99066a73827dc54f318dfd26c4fec31a44d01a164699e7'),
('sites/all/modules/contrib/globalredirect/globalredirect.module', '77f536c963ac706c69a00a9a68b3bb71b0e4f2c68ef143389b3c318e21ee8156'),
('sites/all/modules/contrib/globalredirect/globalredirect.test', '466f4570403e48410ed36d5d4e7635a382738bd818680d8e093c513a1c72a985'),
('sites/all/modules/contrib/google_analytics/googleanalytics.test', '2dc4bfb9bb8e097bfffe40cc53c639175c0d3861e29c0b1eab39160f158e3c8e'),
('sites/all/modules/contrib/link/link.install', '3e54bb31bd3cf9a70e47918c6308e4f0820f2d06e8ada9f167ec031849a5868e'),
('sites/all/modules/contrib/link/link.module', '6389c543a5f03ebda04fd538b38a21f3396b26479c8a2224b3177bada7d99ff0'),
('sites/all/modules/contrib/link/tests/link.attribute.test', '3d8207552d3d1c36a22fcc550c4effac5fc50dab3e0fbb398085a8e28fe3161d'),
('sites/all/modules/contrib/link/tests/link.crud.test', 'f73ad92adb9957695da6f698fe7f5e3df71d138edfa578e9c4e66bda1f1bb873'),
('sites/all/modules/contrib/link/tests/link.crud_browser.test', '19904ae350149dfea09b2625951f8277342d456a32bb28566235d219676d475f'),
('sites/all/modules/contrib/link/tests/link.validate.test', '319d78550baa9988e7cda74d16ca6e251149dd61bfeca30a4c01b2f743ed8ef4'),
('sites/all/modules/contrib/link/views/link_views_handler_argument_target.inc', '0cddc8a7ba8b61bd210af6b2adef082eb9eb2b74242b05bb3c48816a270ca83e'),
('sites/all/modules/contrib/link/views/link_views_handler_filter_protocol.inc', 'a48a04297b580d7ebd58cd9b9ec1764581868c5a3d2b668d6ac5cdf2587d067b'),
('sites/all/modules/contrib/module_filter/css/module_filter.css', '69609136efe52982305062cdf17756ad168aaf35920b7840ea1323e22b0ea0d0'),
('sites/all/modules/contrib/module_filter/css/module_filter_tab.css', '1789901bbb6bed007fff82895bf6d3ecfed7e237b408930c6c51a1c08e648487'),
('sites/all/modules/contrib/module_filter/js/module_filter.js', '90e47a6803c96a0e61219fd4e39e0e0055d7c8899d7cec2c23095d05e158c8a1'),
('sites/all/modules/contrib/module_filter/js/module_filter_tab.js', '1929c99482b71126e6007aaf08df036a9012de433b29d1071de6bb91e71b6513'),
('sites/all/modules/contrib/module_filter/module_filter.admin.inc', '30b1be9c743e4a4d468c2382cbe74666b45e50cfd9251deb0b1a149357c9d03a'),
('sites/all/modules/contrib/module_filter/module_filter.install', 'f2e5776e82d984eb13e2cb63b7edc0de51d438c64327486cc170fea931177110'),
('sites/all/modules/contrib/module_filter/module_filter.module', 'bd1a646af8672e94fc281b65b613cfceb31be020b3b8c41696f39b3ee2c980e0'),
('sites/all/modules/contrib/module_filter/module_filter.theme.inc', '1f94a041fbdb8bbd6637a30b57d7aa9a171fdea61a4707eb3e2a0a08c0b497f0'),
('sites/all/modules/contrib/mollom/mollom.admin.inc', '692c1c51cf39613e1a5cea3cb76ed28613b0cc5d3e1c546666748cfa6c618b90'),
('sites/all/modules/contrib/mollom/mollom.install', '29f7a754086007dfe599fc6bd2c34d2c0efe7e7d91dfcb13b8dcd3f0505e355c'),
('sites/all/modules/contrib/mollom/mollom.module', '27ce1d01f486c153f8a4cce65563d7952144a1575c911cd19fa7c35dda19cee3'),
('sites/all/modules/contrib/mollom/mollom.pages.inc', '6dabb812a04de5b3e034eee2b923846b79c7496172592ee6d803718c04d75902'),
('sites/all/modules/contrib/mollom/tests/mollom.test', 'a3251a03a133f88efeff169cf70aceeeab8e49280f427d6df9bde5f2c3e5cfcb'),
('sites/all/modules/contrib/pathauto/pathauto.test', '52b661d8af48b6127a68a36dca521339ba935dcd50d4aba8d378b95dcb3b3279'),
('sites/all/modules/contrib/piwik/piwik.test', '6ed5e13b10a6df26b11a82fb2203b08a2783ccd227b12380c554db6c71736f77'),
('sites/all/modules/contrib/scheduler/scheduler.install', '8f6366aa5a3cc0e8d8cc5fdd741752fe069dbda56cad529b4cb86017faebb335'),
('sites/all/modules/contrib/scheduler/scheduler.module', '3143cb802686dd7eb984a3b2a7f622dfe91af464749946588b08700c4d35771d'),
('sites/all/modules/contrib/scheduler/scheduler.test', '4b0d6abb9751cf24808e110a3f6e6940ec70f7bff6d82f7024e8ef5524160745'),
('sites/all/modules/contrib/scheduler/scheduler.views.inc', '139ccb64ce7d9fb87b14788d3a76e00ec6f33f488c3aff3fb0db0e17142f6727'),
('sites/all/modules/contrib/scheduler/scheduler_handler_field_scheduler_countdown.inc', '10fba45fa3eadbcde737961939764a821805cf9793a38dc6cedcd5c5c4ab889e'),
('sites/all/modules/contrib/token/token.install', 'a05dc17c007e3fdef53360b2c0933dd1b55548a62bfe312f7b233be60dc59697'),
('sites/all/modules/contrib/token/token.module', 'e9207be6cab01407c9d7e61b66c097f711704230b6bcdb4433e375d23975963c'),
('sites/all/modules/contrib/token/token.pages.inc', '837e633da53f00a89b9d571b2f98ce965406137ea4d47ef176c93b1b62bf8bbd'),
('sites/all/modules/contrib/token/token.test', '8e1e3d192de61aa130f7da7b39f98bf43c3d78bd65ce862cb433d946cac2999c'),
('sites/all/modules/contrib/token/token.tokens.inc', 'c77eab521245e726adc4f9cbc299d671585c610643a84e3b23b82c79b52160d4'),
('sites/all/modules/contrib/variable/includes/node.variable.inc', '8d799471d504f45e6a1050b614a33ef4c3dc6688414135dd20d964cf11b03789'),
('sites/all/modules/contrib/variable/includes/system.variable.inc', '1a5f641b6348f60863259fc4a0402eba192d38b3f129150ea81785651dd87f7c'),
('sites/all/modules/contrib/variable/includes/user.variable.inc', '3127ac0e2c51f52a8b0681cf7cc7aea5c9ead1c96b2e7d7de9c642e9104c8f5d');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique role ID.',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT 'Unique role name.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'The weight of this role in listings and the user interface.',
  PRIMARY KEY (`rid`),
  UNIQUE KEY `name` (`name`),
  KEY `name_weight` (`name`,`weight`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`rid`, `name`, `weight`) VALUES
(3, 'administrator', 2),
(1, 'anonymous user', 0),
(2, 'authenticated user', 1),
(4, 'editor', 3);

-- --------------------------------------------------------

--
-- Table structure for table `role_permission`
--

CREATE TABLE IF NOT EXISTS `role_permission` (
  `rid` int(10) unsigned NOT NULL COMMENT 'Foreign Key: role.rid.',
  `permission` varchar(128) NOT NULL DEFAULT '' COMMENT 'A single permission granted to the role identified by rid.',
  `module` varchar(255) NOT NULL DEFAULT '' COMMENT 'The module declaring the permission.',
  PRIMARY KEY (`rid`,`permission`),
  KEY `permission` (`permission`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role_permission`
--

INSERT INTO `role_permission` (`rid`, `permission`, `module`) VALUES
(1, 'access comments', 'comment'),
(1, 'access content', 'node'),
(1, 'access site-wide contact form', 'contact'),
(1, 'access user profiles', 'user'),
(1, 'post comments', 'comment'),
(1, 'search content', 'search'),
(1, 'use text format filtered_html', 'filter'),
(2, 'access comments', 'comment'),
(2, 'access content', 'node'),
(2, 'access site-wide contact form', 'contact'),
(2, 'access user profiles', 'user'),
(2, 'bypass mollom protection', 'mollom'),
(2, 'cancel account', 'user'),
(2, 'post comments', 'comment'),
(2, 'search content', 'search'),
(2, 'skip comment approval', 'comment'),
(2, 'use text format filtered_html', 'filter'),
(3, 'access administration menu', 'admin_menu'),
(3, 'access administration pages', 'system'),
(3, 'access all views', 'views'),
(3, 'access backup and migrate', 'backup_migrate'),
(3, 'access backup files', 'backup_migrate'),
(3, 'access comments', 'comment'),
(3, 'access content', 'node'),
(3, 'access content overview', 'node'),
(3, 'access contextual links', 'contextual'),
(3, 'access mollom statistics', 'mollom'),
(3, 'access overlay', 'overlay'),
(3, 'access site in maintenance mode', 'system'),
(3, 'access site reports', 'system'),
(3, 'access site-wide contact form', 'contact'),
(3, 'access toolbar', 'toolbar'),
(3, 'access user contact forms', 'contact'),
(3, 'access user profiles', 'user'),
(3, 'administer actions', 'system'),
(3, 'administer backup and migrate', 'backup_migrate'),
(3, 'administer blocks', 'block'),
(3, 'administer comments', 'comment'),
(3, 'administer contact forms', 'contact'),
(3, 'administer content types', 'node'),
(3, 'administer easy social', 'easy_social'),
(3, 'administer features', 'features'),
(3, 'administer fieldgroups', 'field_group'),
(3, 'administer filters', 'filter'),
(3, 'administer google analytics', 'googleanalytics'),
(3, 'administer menu', 'menu'),
(3, 'administer module filter', 'module_filter'),
(3, 'administer modules', 'system'),
(3, 'administer mollom', 'mollom'),
(3, 'administer nodes', 'node'),
(3, 'administer pathauto', 'pathauto'),
(3, 'administer permissions', 'user'),
(3, 'administer piwik', 'piwik'),
(3, 'administer scheduler', 'scheduler'),
(3, 'administer search', 'search'),
(3, 'administer shortcuts', 'shortcut'),
(3, 'administer site configuration', 'system'),
(3, 'administer software updates', 'system'),
(3, 'administer taxonomy', 'taxonomy'),
(3, 'administer themes', 'system'),
(3, 'administer url aliases', 'path'),
(3, 'administer users', 'user'),
(3, 'administer views', 'views'),
(3, 'block IP addresses', 'system'),
(3, 'bypass mollom protection', 'mollom'),
(3, 'bypass node access', 'node'),
(3, 'cancel account', 'user'),
(3, 'change own username', 'user'),
(3, 'create article content', 'node'),
(3, 'create page content', 'node'),
(3, 'create url aliases', 'path'),
(3, 'customize shortcut links', 'shortcut'),
(3, 'delete any article content', 'node'),
(3, 'delete any page content', 'node'),
(3, 'delete backup files', 'backup_migrate'),
(3, 'delete own article content', 'node'),
(3, 'delete own page content', 'node'),
(3, 'delete revisions', 'node'),
(3, 'delete terms in 1', 'taxonomy'),
(3, 'display drupal links', 'admin_menu'),
(3, 'edit any article content', 'node'),
(3, 'edit any page content', 'node'),
(3, 'edit own article content', 'node'),
(3, 'edit own comments', 'comment'),
(3, 'edit own page content', 'node'),
(3, 'edit terms in 1', 'taxonomy'),
(3, 'flush caches', 'admin_menu'),
(3, 'manage features', 'features'),
(3, 'notify of path changes', 'pathauto'),
(3, 'opt-in or out of tracking', 'piwik'),
(3, 'perform backup', 'backup_migrate'),
(3, 'post comments', 'comment'),
(3, 'restore from backup', 'backup_migrate'),
(3, 'revert revisions', 'node'),
(3, 'schedule (un)publishing of nodes', 'scheduler'),
(3, 'search content', 'search'),
(3, 'select account cancellation method', 'user'),
(3, 'skip comment approval', 'comment'),
(3, 'switch shortcut sets', 'shortcut'),
(3, 'use advanced search', 'search'),
(3, 'use PHP for tracking visibility', 'piwik'),
(3, 'use text format filtered_html', 'filter'),
(3, 'use text format full_html', 'filter'),
(3, 'view own unpublished content', 'node'),
(3, 'view revisions', 'node'),
(3, 'view the administration theme', 'system'),
(4, 'access administration menu', 'admin_menu'),
(4, 'access comments', 'comment'),
(4, 'access content', 'node'),
(4, 'access content overview', 'node'),
(4, 'access contextual links', 'contextual'),
(4, 'access site-wide contact form', 'contact'),
(4, 'access user profiles', 'user'),
(4, 'administer comments', 'comment'),
(4, 'bypass mollom protection', 'mollom'),
(4, 'create function content', 'node'),
(4, 'delete own function content', 'node'),
(4, 'edit metatags_quick', 'metatags_quick'),
(4, 'edit own comments', 'comment'),
(4, 'edit own function content', 'node'),
(4, 'post comments', 'comment'),
(4, 'schedule (un)publishing of nodes', 'scheduler'),
(4, 'search content', 'search'),
(4, 'skip comment approval', 'comment'),
(4, 'use text format filtered_html', 'filter'),
(4, 'use text format full_html', 'filter'),
(4, 'view own unpublished content', 'node'),
(4, 'view the administration theme', 'system');

-- --------------------------------------------------------

--
-- Table structure for table `scheduler`
--

CREATE TABLE IF NOT EXISTS `scheduler` (
  `nid` int(10) unsigned NOT NULL COMMENT 'The foreign key to node.nid',
  `publish_on` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The UNIX UTC timestamp when to publish',
  `unpublish_on` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The UNIX UTC timestamp when to unpublish',
  PRIMARY KEY (`nid`),
  KEY `scheduler_publish_on` (`publish_on`),
  KEY `scheduler_unpublish_on` (`unpublish_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `scheduler`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_dataset`
--

CREATE TABLE IF NOT EXISTS `search_dataset` (
  `sid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Search item ID, e.g. node ID for nodes.',
  `type` varchar(16) NOT NULL COMMENT 'Type of item, e.g. node.',
  `data` longtext NOT NULL COMMENT 'List of space-separated words from the item.',
  `reindex` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Set to force node reindexing.',
  PRIMARY KEY (`sid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_dataset`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_index`
--

CREATE TABLE IF NOT EXISTS `search_index` (
  `word` varchar(50) NOT NULL DEFAULT '' COMMENT 'The search_total.word that is associated with the search item.',
  `sid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The search_dataset.sid of the searchable item to which the word belongs.',
  `type` varchar(16) NOT NULL COMMENT 'The search_dataset.type of the searchable item to which the word belongs.',
  `score` float DEFAULT NULL COMMENT 'The numeric score of the word, higher being more important.',
  PRIMARY KEY (`word`,`sid`,`type`),
  KEY `sid_type` (`sid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_node_links`
--

CREATE TABLE IF NOT EXISTS `search_node_links` (
  `sid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The search_dataset.sid of the searchable item containing the link to the node.',
  `type` varchar(16) NOT NULL DEFAULT '' COMMENT 'The search_dataset.type of the searchable item containing the link to the node.',
  `nid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The node.nid that this item links to.',
  `caption` longtext COMMENT 'The text used to link to the node.nid.',
  PRIMARY KEY (`sid`,`type`,`nid`),
  KEY `nid` (`nid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_node_links`
--

INSERT INTO `search_node_links` (`sid`, `type`, `nid`, `caption`) VALUES
(2, 'node', 1, 'about page');

-- --------------------------------------------------------

--
-- Table structure for table `search_total`
--

CREATE TABLE IF NOT EXISTS `search_total` (
  `word` varchar(50) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique word in the search index.',
  `count` float DEFAULT NULL COMMENT 'The count of the word in the index using Zipf’s law to equalize the probability distribution.',
  PRIMARY KEY (`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_total`
--


-- --------------------------------------------------------

--
-- Table structure for table `semaphore`
--

CREATE TABLE IF NOT EXISTS `semaphore` (
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Unique name.',
  `value` varchar(255) NOT NULL DEFAULT '' COMMENT 'A value for the semaphore.',
  `expire` double NOT NULL COMMENT 'A Unix timestamp with microseconds indicating when the semaphore should expire.',
  PRIMARY KEY (`name`),
  KEY `value` (`value`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `semaphore`
--


-- --------------------------------------------------------

--
-- Table structure for table `sequences`
--

CREATE TABLE IF NOT EXISTS `sequences` (
  `value` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The value of the sequence.',
  PRIMARY KEY (`value`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `sequences`
--

INSERT INTO `sequences` (`value`) VALUES
(15);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `uid` int(10) unsigned NOT NULL COMMENT 'The users.uid corresponding to a session, or 0 for anonymous user.',
  `sid` varchar(128) NOT NULL COMMENT 'A session ID. The value is generated by Drupal’s session handlers.',
  `ssid` varchar(128) NOT NULL DEFAULT '' COMMENT 'Secure session ID. The value is generated by Drupal’s session handlers.',
  `hostname` varchar(128) NOT NULL DEFAULT '' COMMENT 'The IP address that last used this session ID (sid).',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp when this session last requested a page. Old records are purged by PHP automatically.',
  `cache` int(11) NOT NULL DEFAULT '0' COMMENT 'The time of this user’s last post. This is used when the site has specified a minimum_cache_lifetime. See cache_get().',
  `session` longblob COMMENT 'The serialized contents of $_SESSION, an array of name/value pairs that persists across page requests by this session ID. Drupal loads $_SESSION from here at the start of each request and saves it at the end.',
  PRIMARY KEY (`sid`,`ssid`),
  KEY `timestamp` (`timestamp`),
  KEY `uid` (`uid`),
  KEY `ssid` (`ssid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `shortcut_set`
--

CREATE TABLE IF NOT EXISTS `shortcut_set` (
  `set_name` varchar(32) NOT NULL DEFAULT '' COMMENT 'Primary Key: The menu_links.menu_name under which the set’s links are stored.',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT 'The title of the set.',
  PRIMARY KEY (`set_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores information about sets of shortcuts links.';

--
-- Dumping data for table `shortcut_set`
--

INSERT INTO `shortcut_set` (`set_name`, `title`) VALUES
('shortcut-set-1', 'Default');

-- --------------------------------------------------------

--
-- Table structure for table `shortcut_set_users`
--

CREATE TABLE IF NOT EXISTS `shortcut_set_users` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The users.uid for this set.',
  `set_name` varchar(32) NOT NULL DEFAULT '' COMMENT 'The shortcut_set.set_name that will be displayed for this user.',
  PRIMARY KEY (`uid`),
  KEY `set_name` (`set_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maps users to shortcut sets.';

--
-- Dumping data for table `shortcut_set_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `system`
--

CREATE TABLE IF NOT EXISTS `system` (
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT 'The path of the primary file for this item, relative to the Drupal root; e.g. modules/node/node.module.',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'The name of the item; e.g. node.',
  `type` varchar(12) NOT NULL DEFAULT '' COMMENT 'The type of the item, either module, theme, or theme_engine.',
  `owner` varchar(255) NOT NULL DEFAULT '' COMMENT 'A theme’s ’parent’ . Can be either a theme or an engine.',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether or not this item is enabled.',
  `bootstrap` int(11) NOT NULL DEFAULT '0' COMMENT 'Boolean indicating whether this module is loaded during Drupal’s early bootstrapping phase (e.g. even before the page cache is consulted).',
  `schema_version` smallint(6) NOT NULL DEFAULT '-1' COMMENT 'The module’s database schema version number. -1 if the module is not installed (its tables do not exist); 0 or the largest N of the module’s hook_update_N() function that has either been run or existed when the module was first installed.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'The order in which this module’s hooks should be invoked relative to other modules. Equal-weighted modules are ordered by name.',
  `info` blob COMMENT 'A serialized array containing information from the module’s .info file; keys can include name, description, package, version, core, dependencies, and php.',
  PRIMARY KEY (`filename`),
  KEY `system_list` (`status`,`bootstrap`,`type`,`weight`,`name`),
  KEY `type_name` (`type`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system`
--

INSERT INTO `system` (`filename`, `name`, `type`, `owner`, `status`, `bootstrap`, `schema_version`, `weight`, `info`) VALUES
('modules/aggregator/aggregator.module', 'aggregator', 'module', '', 0, 0, -1, 0, 0x613a31333a7b733a343a226e616d65223b733a31303a2241676772656761746f72223b733a31313a226465736372697074696f6e223b733a35373a22416767726567617465732073796e6469636174656420636f6e74656e7420285253532c205244462c20616e642041746f6d206665656473292e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31353a2261676772656761746f722e74657374223b7d733a393a22636f6e666967757265223b733a34313a2261646d696e2f636f6e6669672f73657276696365732f61676772656761746f722f73657474696e6773223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31343a2261676772656761746f722e637373223b733a33333a226d6f64756c65732f61676772656761746f722f61676772656761746f722e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/aggregator/tests/aggregator_test.module', 'aggregator_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32333a2241676772656761746f72206d6f64756c65207465737473223b733a31313a226465736372697074696f6e223b733a34363a22537570706f7274206d6f64756c6520666f722061676772656761746f722072656c617465642074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/block/block.module', 'block', 'module', '', 1, 0, 7008, -5, 0x613a31323a7b733a343a226e616d65223b733a353a22426c6f636b223b733a31313a226465736372697074696f6e223b733a3134303a22436f6e74726f6c73207468652076697375616c206275696c64696e6720626c6f636b732061207061676520697320636f6e737472756374656420776974682e20426c6f636b732061726520626f786573206f6620636f6e74656e742072656e646572656420696e746f20616e20617265612c206f7220726567696f6e2c206f6620612077656220706167652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31303a22626c6f636b2e74657374223b7d733a393a22636f6e666967757265223b733a32313a2261646d696e2f7374727563747572652f626c6f636b223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/block/tests/block_test.module', 'block_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31303a22426c6f636b2074657374223b733a31313a226465736372697074696f6e223b733a32313a2250726f7669646573207465737420626c6f636b732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/blog/blog.module', 'blog', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a343a22426c6f67223b733a31313a226465736372697074696f6e223b733a32353a22456e61626c6573206d756c74692d7573657220626c6f67732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a393a22626c6f672e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/book/book.module', 'book', 'module', '', 0, 0, -1, 0, 0x613a31333a7b733a343a226e616d65223b733a343a22426f6f6b223b733a31313a226465736372697074696f6e223b733a36363a22416c6c6f777320757365727320746f2063726561746520616e64206f7267616e697a652072656c6174656420636f6e74656e7420696e20616e206f75746c696e652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a393a22626f6f6b2e74657374223b7d733a393a22636f6e666967757265223b733a32373a2261646d696e2f636f6e74656e742f626f6f6b2f73657474696e6773223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a383a22626f6f6b2e637373223b733a32313a226d6f64756c65732f626f6f6b2f626f6f6b2e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/color/color.module', 'color', 'module', '', 1, 0, 7001, 0, 0x613a31313a7b733a343a226e616d65223b733a353a22436f6c6f72223b733a31313a226465736372697074696f6e223b733a37303a22416c6c6f77732061646d696e6973747261746f727320746f206368616e67652074686520636f6c6f7220736368656d65206f6620636f6d70617469626c65207468656d65732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31303a22636f6c6f722e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/comment/comment.module', 'comment', 'module', '', 1, 0, 7008, 0, 0x613a31333a7b733a343a226e616d65223b733a373a22436f6d6d656e74223b733a31313a226465736372697074696f6e223b733a35373a22416c6c6f777320757365727320746f20636f6d6d656e74206f6e20616e642064697363757373207075626c697368656420636f6e74656e742e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a343a2274657874223b7d733a353a2266696c6573223b613a323a7b693a303b733a31343a22636f6d6d656e742e6d6f64756c65223b693a313b733a31323a22636f6d6d656e742e74657374223b7d733a393a22636f6e666967757265223b733a32313a2261646d696e2f636f6e74656e742f636f6d6d656e74223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31313a22636f6d6d656e742e637373223b733a32373a226d6f64756c65732f636f6d6d656e742f636f6d6d656e742e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/contact/contact.module', 'contact', 'module', '', 1, 0, 7003, 0, 0x613a31323a7b733a343a226e616d65223b733a373a22436f6e74616374223b733a31313a226465736372697074696f6e223b733a36313a22456e61626c65732074686520757365206f6620626f746820706572736f6e616c20616e6420736974652d7769646520636f6e7461637420666f726d732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31323a22636f6e746163742e74657374223b7d733a393a22636f6e666967757265223b733a32333a2261646d696e2f7374727563747572652f636f6e74616374223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/contextual/contextual.module', 'contextual', 'module', '', 1, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a31363a22436f6e7465787475616c206c696e6b73223b733a31313a226465736372697074696f6e223b733a37353a2250726f766964657320636f6e7465787475616c206c696e6b7320746f20706572666f726d20616374696f6e732072656c6174656420746f20656c656d656e7473206f6e206120706167652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/dashboard/dashboard.module', 'dashboard', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a393a2244617368626f617264223b733a31313a226465736372697074696f6e223b733a3133363a2250726f766964657320612064617368626f617264207061676520696e207468652061646d696e69737472617469766520696e7465726661636520666f72206f7267616e697a696e672061646d696e697374726174697665207461736b7320616e6420747261636b696e6720696e666f726d6174696f6e2077697468696e20796f757220736974652e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a353a2266696c6573223b613a313a7b693a303b733a31343a2264617368626f6172642e74657374223b7d733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a22626c6f636b223b7d733a393a22636f6e666967757265223b733a32353a2261646d696e2f64617368626f6172642f637573746f6d697a65223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/dblog/dblog.module', 'dblog', 'module', '', 1, 1, 7001, 0, 0x613a31313a7b733a343a226e616d65223b733a31363a224461746162617365206c6f6767696e67223b733a31313a226465736372697074696f6e223b733a34373a224c6f677320616e64207265636f7264732073797374656d206576656e747320746f207468652064617461626173652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31303a2264626c6f672e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/field/field.module', 'field', 'module', '', 1, 0, 7001, 0, 0x613a31333a7b733a343a226e616d65223b733a353a224669656c64223b733a31313a226465736372697074696f6e223b733a35373a224669656c642041504920746f20616464206669656c647320746f20656e746974696573206c696b65206e6f64657320616e642075736572732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a333a7b693a303b733a31323a226669656c642e6d6f64756c65223b693a313b733a31363a226669656c642e6174746163682e696e63223b693a323b733a31363a2274657374732f6669656c642e74657374223b7d733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a31373a226669656c645f73716c5f73746f72616765223b7d733a383a227265717569726564223b623a313b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31353a227468656d652f6669656c642e637373223b733a32393a226d6f64756c65732f6669656c642f7468656d652f6669656c642e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/field/modules/field_sql_storage/field_sql_storage.module', 'field_sql_storage', 'module', '', 1, 0, 7002, 0, 0x613a31323a7b733a343a226e616d65223b733a31373a224669656c642053514c2073746f72616765223b733a31313a226465736372697074696f6e223b733a33373a2253746f726573206669656c64206461746120696e20616e2053514c2064617461626173652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a226669656c64223b7d733a353a2266696c6573223b613a313a7b693a303b733a32323a226669656c645f73716c5f73746f726167652e74657374223b7d733a383a227265717569726564223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/field/modules/list/list.module', 'list', 'module', '', 1, 0, 7002, 0, 0x613a31313a7b733a343a226e616d65223b733a343a224c697374223b733a31313a226465736372697074696f6e223b733a36393a22446566696e6573206c697374206669656c642074797065732e205573652077697468204f7074696f6e7320746f206372656174652073656c656374696f6e206c697374732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a353a226669656c64223b693a313b733a373a226f7074696f6e73223b7d733a353a2266696c6573223b613a313a7b693a303b733a31353a2274657374732f6c6973742e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/field/modules/list/tests/list_test.module', 'list_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a393a224c6973742074657374223b733a31313a226465736372697074696f6e223b733a34313a22537570706f7274206d6f64756c6520666f7220746865204c697374206d6f64756c652074657374732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/field/modules/number/number.module', 'number', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a363a224e756d626572223b733a31313a226465736372697074696f6e223b733a32383a22446566696e6573206e756d65726963206669656c642074797065732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a226669656c64223b7d733a353a2266696c6573223b613a313a7b693a303b733a31313a226e756d6265722e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/field/modules/options/options.module', 'options', 'module', '', 1, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a373a224f7074696f6e73223b733a31313a226465736372697074696f6e223b733a38323a22446566696e65732073656c656374696f6e2c20636865636b20626f7820616e6420726164696f20627574746f6e207769646765747320666f72207465787420616e64206e756d65726963206669656c64732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a226669656c64223b7d733a353a2266696c6573223b613a313a7b693a303b733a31323a226f7074696f6e732e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/field/modules/text/text.module', 'text', 'module', '', 1, 0, 7000, 0, 0x613a31333a7b733a343a226e616d65223b733a343a2254657874223b733a31313a226465736372697074696f6e223b733a33323a22446566696e65732073696d706c652074657874206669656c642074797065732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a226669656c64223b7d733a353a2266696c6573223b613a313a7b693a303b733a393a22746578742e74657374223b7d733a383a227265717569726564223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b733a31313a226578706c616e6174696f6e223b733a37333a224669656c64207479706528732920696e20757365202d20736565203c6120687265663d222f61646d696e2f7265706f7274732f6669656c6473223e4669656c64206c6973743c2f613e223b7d),
('modules/field/tests/field_test.module', 'field_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31343a224669656c64204150492054657374223b733a31313a226465736372697074696f6e223b733a33393a22537570706f7274206d6f64756c6520666f7220746865204669656c64204150492074657374732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a353a2266696c6573223b613a313a7b693a303b733a32313a226669656c645f746573742e656e746974792e696e63223b7d733a373a2276657273696f6e223b733a333a22372e38223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/field_ui/field_ui.module', 'field_ui', 'module', '', 1, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a383a224669656c64205549223b733a31313a226465736372697074696f6e223b733a33333a225573657220696e7465726661636520666f7220746865204669656c64204150492e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a226669656c64223b7d733a353a2266696c6573223b613a313a7b693a303b733a31333a226669656c645f75692e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/file/file.module', 'file', 'module', '', 1, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a343a2246696c65223b733a31313a226465736372697074696f6e223b733a32363a22446566696e657320612066696c65206669656c6420747970652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a226669656c64223b7d733a353a2266696c6573223b613a313a7b693a303b733a31353a2274657374732f66696c652e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/file/tests/file_module_test.module', 'file_module_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a393a2246696c652074657374223b733a31313a226465736372697074696f6e223b733a35333a2250726f766964657320686f6f6b7320666f722074657374696e672046696c65206d6f64756c652066756e6374696f6e616c6974792e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/filter/filter.module', 'filter', 'module', '', 1, 0, 7010, 0, 0x613a31333a7b733a343a226e616d65223b733a363a2246696c746572223b733a31313a226465736372697074696f6e223b733a34333a2246696c7465727320636f6e74656e7420696e207072657061726174696f6e20666f7220646973706c61792e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31313a2266696c7465722e74657374223b7d733a383a227265717569726564223b623a313b733a393a22636f6e666967757265223b733a32383a2261646d696e2f636f6e6669672f636f6e74656e742f666f726d617473223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/forum/forum.module', 'forum', 'module', '', 0, 0, -1, 0, 0x613a31333a7b733a343a226e616d65223b733a353a22466f72756d223b733a31313a226465736372697074696f6e223b733a32373a2250726f76696465732064697363757373696f6e20666f72756d732e223b733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a383a227461786f6e6f6d79223b693a313b733a373a22636f6d6d656e74223b7d733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31303a22666f72756d2e74657374223b7d733a393a22636f6e666967757265223b733a32313a2261646d696e2f7374727563747572652f666f72756d223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a393a22666f72756d2e637373223b733a32333a226d6f64756c65732f666f72756d2f666f72756d2e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/help/help.module', 'help', 'module', '', 1, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a343a2248656c70223b733a31313a226465736372697074696f6e223b733a33353a224d616e616765732074686520646973706c6179206f66206f6e6c696e652068656c702e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a393a2268656c702e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/image/image.module', 'image', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a353a22496d616765223b733a31313a226465736372697074696f6e223b733a33343a2250726f766964657320696d616765206d616e6970756c6174696f6e20746f6f6c732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a343a2266696c65223b7d733a353a2266696c6573223b613a313a7b693a303b733a31303a22696d6167652e74657374223b7d733a393a22636f6e666967757265223b733a33313a2261646d696e2f636f6e6669672f6d656469612f696d6167652d7374796c6573223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/image/tests/image_module_test.module', 'image_module_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31303a22496d6167652074657374223b733a31313a226465736372697074696f6e223b733a36393a2250726f766964657320686f6f6b20696d706c656d656e746174696f6e7320666f722074657374696e6720496d616765206d6f64756c652066756e6374696f6e616c6974792e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a32343a22696d6167655f6d6f64756c655f746573742e6d6f64756c65223b7d733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/locale/locale.module', 'locale', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a363a224c6f63616c65223b733a31313a226465736372697074696f6e223b733a3131393a2241646473206c616e67756167652068616e646c696e672066756e6374696f6e616c69747920616e6420656e61626c657320746865207472616e736c6174696f6e206f6620746865207573657220696e7465726661636520746f206c616e677561676573206f74686572207468616e20456e676c6973682e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31313a226c6f63616c652e74657374223b7d733a393a22636f6e666967757265223b733a33303a2261646d696e2f636f6e6669672f726567696f6e616c2f6c616e6775616765223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/locale/tests/locale_test.module', 'locale_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a224c6f63616c652054657374223b733a31313a226465736372697074696f6e223b733a34323a22537570706f7274206d6f64756c6520666f7220746865206c6f63616c65206c617965722074657374732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/menu/menu.module', 'menu', 'module', '', 1, 0, 7002, 0, 0x613a31323a7b733a343a226e616d65223b733a343a224d656e75223b733a31313a226465736372697074696f6e223b733a36303a22416c6c6f77732061646d696e6973747261746f727320746f20637573746f6d697a65207468652073697465206e617669676174696f6e206d656e752e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a393a226d656e752e74657374223b7d733a393a22636f6e666967757265223b733a32303a2261646d696e2f7374727563747572652f6d656e75223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/node/node.module', 'node', 'module', '', 1, 0, 7012, 0, 0x613a31343a7b733a343a226e616d65223b733a343a224e6f6465223b733a31313a226465736372697074696f6e223b733a36363a22416c6c6f777320636f6e74656e7420746f206265207375626d697474656420746f20746865207369746520616e6420646973706c61796564206f6e2070616765732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a323a7b693a303b733a31313a226e6f64652e6d6f64756c65223b693a313b733a393a226e6f64652e74657374223b7d733a383a227265717569726564223b623a313b733a393a22636f6e666967757265223b733a32313a2261646d696e2f7374727563747572652f7479706573223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a383a226e6f64652e637373223b733a32313a226d6f64756c65732f6e6f64652f6e6f64652e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/node/tests/node_access_test.module', 'node_access_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32343a224e6f6465206d6f64756c6520616363657373207465737473223b733a31313a226465736372697074696f6e223b733a34333a22537570706f7274206d6f64756c6520666f72206e6f6465207065726d697373696f6e2074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/node/tests/node_test.module', 'node_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31373a224e6f6465206d6f64756c65207465737473223b733a31313a226465736372697074696f6e223b733a34303a22537570706f7274206d6f64756c6520666f72206e6f64652072656c617465642074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/node/tests/node_test_exception.module', 'node_test_exception', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32373a224e6f6465206d6f64756c6520657863657074696f6e207465737473223b733a31313a226465736372697074696f6e223b733a35303a22537570706f7274206d6f64756c6520666f72206e6f64652072656c6174656420657863657074696f6e2074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/openid/openid.module', 'openid', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a363a224f70656e4944223b733a31313a226465736372697074696f6e223b733a34383a22416c6c6f777320757365727320746f206c6f6720696e746f20796f75722073697465207573696e67204f70656e49442e223b733a373a2276657273696f6e223b733a333a22372e38223b733a373a227061636b616765223b733a343a22436f7265223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31313a226f70656e69642e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/openid/tests/openid_test.module', 'openid_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32313a224f70656e49442064756d6d792070726f7669646572223b733a31313a226465736372697074696f6e223b733a33333a224f70656e49442070726f7669646572207573656420666f722074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a226f70656e6964223b7d733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/overlay/overlay.module', 'overlay', 'module', '', 0, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a373a224f7665726c6179223b733a31313a226465736372697074696f6e223b733a35393a22446973706c617973207468652044727570616c2061646d696e697374726174696f6e20696e7465726661636520696e20616e206f7665726c61792e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/path/path.module', 'path', 'module', '', 1, 0, 0, 0, 0x613a31323a7b733a343a226e616d65223b733a343a2250617468223b733a31313a226465736372697074696f6e223b733a32383a22416c6c6f777320757365727320746f2072656e616d652055524c732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a393a22706174682e74657374223b7d733a393a22636f6e666967757265223b733a32343a2261646d696e2f636f6e6669672f7365617263682f70617468223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/php/php.module', 'php', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31303a225048502066696c746572223b733a31313a226465736372697074696f6e223b733a35303a22416c6c6f777320656d6265646465642050485020636f64652f736e69707065747320746f206265206576616c75617465642e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a383a227068702e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/poll/poll.module', 'poll', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a343a22506f6c6c223b733a31313a226465736372697074696f6e223b733a39353a22416c6c6f777320796f7572207369746520746f206361707475726520766f746573206f6e20646966666572656e7420746f7069637320696e2074686520666f726d206f66206d756c7469706c652063686f696365207175657374696f6e732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a393a22706f6c6c2e74657374223b7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a383a22706f6c6c2e637373223b733a32313a226d6f64756c65732f706f6c6c2f706f6c6c2e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/profile/profile.module', 'profile', 'module', '', 0, 0, -1, 0, 0x613a31333a7b733a343a226e616d65223b733a373a2250726f66696c65223b733a31313a226465736372697074696f6e223b733a33363a22537570706f72747320636f6e666967757261626c6520757365722070726f66696c65732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31323a2270726f66696c652e74657374223b7d733a393a22636f6e666967757265223b733a32373a2261646d696e2f636f6e6669672f70656f706c652f70726f66696c65223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/rdf/rdf.module', 'rdf', 'module', '', 1, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a333a22524446223b733a31313a226465736372697074696f6e223b733a3134383a22456e72696368657320796f757220636f6e74656e742077697468206d6574616461746120746f206c6574206f74686572206170706c69636174696f6e732028652e672e2073656172636820656e67696e65732c2061676772656761746f7273292062657474657220756e6465727374616e64206974732072656c6174696f6e736869707320616e6420617474726962757465732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a383a227264662e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/rdf/tests/rdf_test.module', 'rdf_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31363a22524446206d6f64756c65207465737473223b733a31313a226465736372697074696f6e223b733a33383a22537570706f7274206d6f64756c6520666f7220524446206d6f64756c652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/search/search.module', 'search', 'module', '', 1, 0, 7000, 0, 0x613a31333a7b733a343a226e616d65223b733a363a22536561726368223b733a31313a226465736372697074696f6e223b733a33363a22456e61626c657320736974652d77696465206b6579776f726420736561726368696e672e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a323a7b693a303b733a31393a227365617263682e657874656e6465722e696e63223b693a313b733a31313a227365617263682e74657374223b7d733a393a22636f6e666967757265223b733a32383a2261646d696e2f636f6e6669672f7365617263682f73657474696e6773223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a227365617263682e637373223b733a32353a226d6f64756c65732f7365617263682f7365617263682e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/search/tests/search_embedded_form.module', 'search_embedded_form', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32303a2253656172636820656d62656464656420666f726d223b733a31313a226465736372697074696f6e223b733a35393a22537570706f7274206d6f64756c6520666f7220736561726368206d6f64756c652074657374696e67206f6620656d62656464656420666f726d732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/search/tests/search_extra_type.module', 'search_extra_type', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31363a2254657374207365617263682074797065223b733a31313a226465736372697074696f6e223b733a34313a22537570706f7274206d6f64756c6520666f7220736561726368206d6f64756c652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/shortcut/shortcut.module', 'shortcut', 'module', '', 1, 0, 0, 0, 0x613a31323a7b733a343a226e616d65223b733a383a2253686f7274637574223b733a31313a226465736372697074696f6e223b733a36303a22416c6c6f777320757365727320746f206d616e61676520637573746f6d697a61626c65206c69737473206f662073686f7274637574206c696e6b732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31333a2273686f72746375742e74657374223b7d733a393a22636f6e666967757265223b733a33363a2261646d696e2f636f6e6669672f757365722d696e746572666163652f73686f7274637574223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/simpletest.module', 'simpletest', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a373a2254657374696e67223b733a31313a226465736372697074696f6e223b733a35333a2250726f76696465732061206672616d65776f726b20666f7220756e697420616e642066756e6374696f6e616c2074657374696e672e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a34323a7b693a303b733a31353a2273696d706c65746573742e74657374223b693a313b733a32343a2264727570616c5f7765625f746573745f636173652e706870223b693a323b733a31383a2274657374732f616374696f6e732e74657374223b693a333b733a31353a2274657374732f616a61782e74657374223b693a343b733a31363a2274657374732f62617463682e74657374223b693a353b733a32303a2274657374732f626f6f7473747261702e74657374223b693a363b733a31363a2274657374732f63616368652e74657374223b693a373b733a31373a2274657374732f636f6d6d6f6e2e74657374223b693a383b733a32343a2274657374732f64617461626173655f746573742e74657374223b693a393b733a33323a2274657374732f656e746974795f637275645f686f6f6b5f746573742e74657374223b693a31303b733a32333a2274657374732f656e746974795f71756572792e74657374223b693a31313b733a31363a2274657374732f6572726f722e74657374223b693a31323b733a31353a2274657374732f66696c652e74657374223b693a31333b733a32333a2274657374732f66696c657472616e736665722e74657374223b693a31343b733a31353a2274657374732f666f726d2e74657374223b693a31353b733a31363a2274657374732f67726170682e74657374223b693a31363b733a31363a2274657374732f696d6167652e74657374223b693a31373b733a31353a2274657374732f6c6f636b2e74657374223b693a31383b733a31353a2274657374732f6d61696c2e74657374223b693a31393b733a31353a2274657374732f6d656e752e74657374223b693a32303b733a31373a2274657374732f6d6f64756c652e74657374223b693a32313b733a31393a2274657374732f70617373776f72642e74657374223b693a32323b733a31353a2274657374732f706174682e74657374223b693a32333b733a31393a2274657374732f72656769737472792e74657374223b693a32343b733a31373a2274657374732f736368656d612e74657374223b693a32353b733a31383a2274657374732f73657373696f6e2e74657374223b693a32363b733a32303a2274657374732f7461626c65736f72742e74657374223b693a32373b733a31363a2274657374732f7468656d652e74657374223b693a32383b733a31383a2274657374732f756e69636f64652e74657374223b693a32393b733a31373a2274657374732f7570646174652e74657374223b693a33303b733a31373a2274657374732f786d6c7270632e74657374223b693a33313b733a32363a2274657374732f757067726164652f757067726164652e74657374223b693a33323b733a33343a2274657374732f757067726164652f757067726164652e636f6d6d656e742e74657374223b693a33333b733a33333a2274657374732f757067726164652f757067726164652e66696c7465722e74657374223b693a33343b733a33323a2274657374732f757067726164652f757067726164652e666f72756d2e74657374223b693a33353b733a33333a2274657374732f757067726164652f757067726164652e6c6f63616c652e74657374223b693a33363b733a33313a2274657374732f757067726164652f757067726164652e6d656e752e74657374223b693a33373b733a33313a2274657374732f757067726164652f757067726164652e6e6f64652e74657374223b693a33383b733a33353a2274657374732f757067726164652f757067726164652e7461786f6e6f6d792e74657374223b693a33393b733a33393a2274657374732f757067726164652f757067726164652e7472616e736c617461626c652e74657374223b693a34303b733a33333a2274657374732f757067726164652f757067726164652e75706c6f61642e74657374223b693a34313b733a33313a2274657374732f757067726164652f757067726164652e757365722e74657374223b7d733a393a22636f6e666967757265223b733a34313a2261646d696e2f636f6e6669672f646576656c6f706d656e742f74657374696e672f73657474696e6773223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/actions_loop_test.module', 'actions_loop_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31373a22416374696f6e73206c6f6f702074657374223b733a31313a226465736372697074696f6e223b733a33393a22537570706f7274206d6f64756c6520666f7220616374696f6e206c6f6f702074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/ajax_forms_test.module', 'ajax_forms_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32363a22414a415820666f726d2074657374206d6f636b206d6f64756c65223b733a31313a226465736372697074696f6e223b733a32353a225465737420666f7220414a415820666f726d2063616c6c732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/ajax_test.module', 'ajax_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a393a22414a41582054657374223b733a31313a226465736372697074696f6e223b733a34303a22537570706f7274206d6f64756c6520666f7220414a4158206672616d65776f726b2074657374732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/batch_test.module', 'batch_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31343a224261746368204150492074657374223b733a31313a226465736372697074696f6e223b733a33353a22537570706f7274206d6f64756c6520666f72204261746368204150492074657374732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d);
INSERT INTO `system` (`filename`, `name`, `type`, `owner`, `status`, `bootstrap`, `schema_version`, `weight`, `info`) VALUES
('modules/simpletest/tests/common_test.module', 'common_test', 'module', '', 0, 0, -1, 0, 0x613a31333a7b733a343a226e616d65223b733a31313a22436f6d6d6f6e2054657374223b733a31313a226465736372697074696f6e223b733a33323a22537570706f7274206d6f64756c6520666f7220436f6d6d6f6e2074657374732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a313a7b733a31353a22636f6d6d6f6e5f746573742e637373223b733a34303a226d6f64756c65732f73696d706c65746573742f74657374732f636f6d6d6f6e5f746573742e637373223b7d733a353a227072696e74223b613a313a7b733a32313a22636f6d6d6f6e5f746573742e7072696e742e637373223b733a34363a226d6f64756c65732f73696d706c65746573742f74657374732f636f6d6d6f6e5f746573742e7072696e742e637373223b7d7d733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/common_test_cron_helper.module', 'common_test_cron_helper', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32333a22436f6d6d6f6e20546573742043726f6e2048656c706572223b733a31313a226465736372697074696f6e223b733a35363a2248656c706572206d6f64756c6520666f722043726f6e52756e54657374436173653a3a7465737443726f6e457863657074696f6e7328292e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/database_test.module', 'database_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31333a2244617461626173652054657374223b733a31313a226465736372697074696f6e223b733a34303a22537570706f7274206d6f64756c6520666f72204461746162617365206c617965722074657374732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/drupal_system_listing_compatible_test/drupal_system_listing_compatible_test.module', 'drupal_system_listing_compatible_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a33373a2244727570616c2073797374656d206c697374696e6720636f6d70617469626c652074657374223b733a31313a226465736372697074696f6e223b733a36323a22537570706f7274206d6f64756c6520666f722074657374696e67207468652064727570616c5f73797374656d5f6c697374696e672066756e6374696f6e2e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/drupal_system_listing_incompatible_test/drupal_system_listing_incompatible_test.module', 'drupal_system_listing_incompatible_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a33393a2244727570616c2073797374656d206c697374696e6720696e636f6d70617469626c652074657374223b733a31313a226465736372697074696f6e223b733a36323a22537570706f7274206d6f64756c6520666f722074657374696e67207468652064727570616c5f73797374656d5f6c697374696e672066756e6374696f6e2e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/entity_cache_test.module', 'entity_cache_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31373a22456e746974792063616368652074657374223b733a31313a226465736372697074696f6e223b733a34303a22537570706f7274206d6f64756c6520666f722074657374696e6720656e746974792063616368652e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a32383a22656e746974795f63616368655f746573745f646570656e64656e6379223b7d733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/entity_cache_test_dependency.module', 'entity_cache_test_dependency', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32383a22456e74697479206361636865207465737420646570656e64656e6379223b733a31313a226465736372697074696f6e223b733a35313a22537570706f727420646570656e64656e6379206d6f64756c6520666f722074657374696e6720656e746974792063616368652e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/entity_crud_hook_test.module', 'entity_crud_hook_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32323a22456e74697479204352554420486f6f6b732054657374223b733a31313a226465736372697074696f6e223b733a33353a22537570706f7274206d6f64756c6520666f72204352554420686f6f6b2074657374732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/error_test.module', 'error_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31303a224572726f722074657374223b733a31313a226465736372697074696f6e223b733a34373a22537570706f7274206d6f64756c6520666f72206572726f7220616e6420657863657074696f6e2074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/file_test.module', 'file_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a393a2246696c652074657374223b733a31313a226465736372697074696f6e223b733a33393a22537570706f7274206d6f64756c6520666f722066696c652068616e646c696e672074657374732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31363a2266696c655f746573742e6d6f64756c65223b7d733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/filter_test.module', 'filter_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31383a2246696c7465722074657374206d6f64756c65223b733a31313a226465736372697074696f6e223b733a33333a2254657374732066696c74657220686f6f6b7320616e642066756e6374696f6e732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/form_test.module', 'form_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31323a22466f726d4150492054657374223b733a31313a226465736372697074696f6e223b733a33343a22537570706f7274206d6f64756c6520666f7220466f726d204150492074657374732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/image_test.module', 'image_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31303a22496d6167652074657374223b733a31313a226465736372697074696f6e223b733a33393a22537570706f7274206d6f64756c6520666f7220696d61676520746f6f6c6b69742074657374732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/menu_test.module', 'menu_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31353a22486f6f6b206d656e75207465737473223b733a31313a226465736372697074696f6e223b733a33373a22537570706f7274206d6f64756c6520666f72206d656e7520686f6f6b2074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/module_test.module', 'module_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a224d6f64756c652074657374223b733a31313a226465736372697074696f6e223b733a34313a22537570706f7274206d6f64756c6520666f72206d6f64756c652073797374656d2074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/requirements1_test.module', 'requirements1_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31393a22526571756972656d656e747320312054657374223b733a31313a226465736372697074696f6e223b733a38303a22546573747320746861742061206d6f64756c65206973206e6f7420696e7374616c6c6564207768656e206974206661696c7320686f6f6b5f726571756972656d656e74732827696e7374616c6c27292e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/requirements2_test.module', 'requirements2_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31393a22526571756972656d656e747320322054657374223b733a31313a226465736372697074696f6e223b733a39383a22546573747320746861742061206d6f64756c65206973206e6f7420696e7374616c6c6564207768656e20746865206f6e6520697420646570656e6473206f6e206661696c7320686f6f6b5f726571756972656d656e74732827696e7374616c6c292e223b733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a31383a22726571756972656d656e7473315f74657374223b693a313b733a373a22636f6d6d656e74223b7d733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/session_test.module', 'session_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31323a2253657373696f6e2074657374223b733a31313a226465736372697074696f6e223b733a34303a22537570706f7274206d6f64756c6520666f722073657373696f6e20646174612074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/system_dependencies_test.module', 'system_dependencies_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32323a2253797374656d20646570656e64656e63792074657374223b733a31313a226465736372697074696f6e223b733a34373a22537570706f7274206d6f64756c6520666f722074657374696e672073797374656d20646570656e64656e636965732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a31393a225f6d697373696e675f646570656e64656e6379223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/system_test.module', 'system_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a2253797374656d2074657374223b733a31313a226465736372697074696f6e223b733a33343a22537570706f7274206d6f64756c6520666f722073797374656d2074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31383a2273797374656d5f746573742e6d6f64756c65223b7d733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/taxonomy_test.module', 'taxonomy_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32303a225461786f6e6f6d792074657374206d6f64756c65223b733a31313a226465736372697074696f6e223b733a34353a222254657374732066756e6374696f6e7320616e6420686f6f6b73206e6f74207573656420696e20636f7265222e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a383a227461786f6e6f6d79223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/theme_test.module', 'theme_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31303a225468656d652074657374223b733a31313a226465736372697074696f6e223b733a34303a22537570706f7274206d6f64756c6520666f72207468656d652073797374656d2074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/update_test_1.module', 'update_test_1', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a225570646174652074657374223b733a31313a226465736372697074696f6e223b733a33343a22537570706f7274206d6f64756c6520666f72207570646174652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/update_test_2.module', 'update_test_2', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a225570646174652074657374223b733a31313a226465736372697074696f6e223b733a33343a22537570706f7274206d6f64756c6520666f72207570646174652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/update_test_3.module', 'update_test_3', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a225570646174652074657374223b733a31313a226465736372697074696f6e223b733a33343a22537570706f7274206d6f64756c6520666f72207570646174652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/url_alter_test.module', 'url_alter_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31353a2255726c5f616c746572207465737473223b733a31313a226465736372697074696f6e223b733a34353a224120737570706f7274206d6f64756c657320666f722075726c5f616c74657220686f6f6b2074657374696e672e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/simpletest/tests/xmlrpc_test.module', 'xmlrpc_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31323a22584d4c2d5250432054657374223b733a31313a226465736372697074696f6e223b733a37353a22537570706f7274206d6f64756c6520666f7220584d4c2d525043207465737473206163636f7264696e6720746f207468652076616c696461746f72312073706563696669636174696f6e2e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/statistics/statistics.module', 'statistics', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31303a2253746174697374696373223b733a31313a226465736372697074696f6e223b733a33373a224c6f677320616363657373207374617469737469637320666f7220796f757220736974652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31353a22737461746973746963732e74657374223b7d733a393a22636f6e666967757265223b733a33303a2261646d696e2f636f6e6669672f73797374656d2f73746174697374696373223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/syslog/syslog.module', 'syslog', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a363a225379736c6f67223b733a31313a226465736372697074696f6e223b733a34313a224c6f677320616e64207265636f7264732073797374656d206576656e747320746f207379736c6f672e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31313a227379736c6f672e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/system/system.module', 'system', 'module', '', 1, 1, 7071, 0, 0x613a31333a7b733a343a226e616d65223b733a363a2253797374656d223b733a31313a226465736372697074696f6e223b733a35343a2248616e646c65732067656e6572616c207369746520636f6e66696775726174696f6e20666f722061646d696e6973747261746f72732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a363a7b693a303b733a31393a2273797374656d2e61726368697665722e696e63223b693a313b733a31353a2273797374656d2e6d61696c2e696e63223b693a323b733a31363a2273797374656d2e71756575652e696e63223b693a333b733a31343a2273797374656d2e7461722e696e63223b693a343b733a31383a2273797374656d2e757064617465722e696e63223b693a353b733a31313a2273797374656d2e74657374223b7d733a383a227265717569726564223b623a313b733a393a22636f6e666967757265223b733a31393a2261646d696e2f636f6e6669672f73797374656d223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/taxonomy/taxonomy.module', 'taxonomy', 'module', '', 1, 0, 7010, 0, 0x613a31343a7b733a343a226e616d65223b733a383a225461786f6e6f6d79223b733a31313a226465736372697074696f6e223b733a33383a22456e61626c6573207468652063617465676f72697a6174696f6e206f6620636f6e74656e742e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a373a226f7074696f6e73223b7d733a353a2266696c6573223b613a323a7b693a303b733a31353a227461786f6e6f6d792e6d6f64756c65223b693a313b733a31333a227461786f6e6f6d792e74657374223b7d733a393a22636f6e666967757265223b733a32343a2261646d696e2f7374727563747572652f7461786f6e6f6d79223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b733a383a227265717569726564223b623a313b733a31313a226578706c616e6174696f6e223b733a37333a224669656c64207479706528732920696e20757365202d20736565203c6120687265663d222f61646d696e2f7265706f7274732f6669656c6473223e4669656c64206c6973743c2f613e223b7d),
('modules/toolbar/toolbar.module', 'toolbar', 'module', '', 0, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a373a22546f6f6c626172223b733a31313a226465736372697074696f6e223b733a39393a2250726f7669646573206120746f6f6c62617220746861742073686f77732074686520746f702d6c6576656c2061646d696e697374726174696f6e206d656e75206974656d7320616e64206c696e6b732066726f6d206f74686572206d6f64756c65732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/tracker/tracker.module', 'tracker', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a373a22547261636b6572223b733a31313a226465736372697074696f6e223b733a34353a22456e61626c657320747261636b696e67206f6620726563656e7420636f6e74656e7420666f722075736572732e223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a373a22636f6d6d656e74223b7d733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31323a22747261636b65722e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/translation/tests/translation_test.module', 'translation_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32343a22436f6e74656e74205472616e736c6174696f6e2054657374223b733a31313a226465736372697074696f6e223b733a34393a22537570706f7274206d6f64756c6520666f722074686520636f6e74656e74207472616e736c6174696f6e2074657374732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/translation/translation.module', 'translation', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31393a22436f6e74656e74207472616e736c6174696f6e223b733a31313a226465736372697074696f6e223b733a35373a22416c6c6f777320636f6e74656e7420746f206265207472616e736c6174656420696e746f20646966666572656e74206c616e6775616765732e223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a226c6f63616c65223b7d733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31363a227472616e736c6174696f6e2e74657374223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/trigger/tests/trigger_test.module', 'trigger_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31323a22547269676765722054657374223b733a31313a226465736372697074696f6e223b733a33333a22537570706f7274206d6f64756c6520666f7220547269676765722074657374732e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/trigger/trigger.module', 'trigger', 'module', '', 1, 0, 7000, 0, 0x613a31323a7b733a343a226e616d65223b733a373a2254726967676572223b733a31313a226465736372697074696f6e223b733a39303a22456e61626c657320616374696f6e7320746f206265206669726564206f6e206365727461696e2073797374656d206576656e74732c2073756368206173207768656e206e657720636f6e74656e7420697320637265617465642e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31323a22747269676765722e74657374223b7d733a393a22636f6e666967757265223b733a32333a2261646d696e2f7374727563747572652f74726967676572223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/update/tests/aaa_update_test.module', 'aaa_update_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31353a22414141205570646174652074657374223b733a31313a226465736372697074696f6e223b733a34313a22537570706f7274206d6f64756c6520666f7220757064617465206d6f64756c652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/update/tests/bbb_update_test.module', 'bbb_update_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31353a22424242205570646174652074657374223b733a31313a226465736372697074696f6e223b733a34313a22537570706f7274206d6f64756c6520666f7220757064617465206d6f64756c652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/update/tests/ccc_update_test.module', 'ccc_update_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31353a22434343205570646174652074657374223b733a31313a226465736372697074696f6e223b733a34313a22537570706f7274206d6f64756c6520666f7220757064617465206d6f64756c652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/update/tests/update_test.module', 'update_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a225570646174652074657374223b733a31313a226465736372697074696f6e223b733a34313a22537570706f7274206d6f64756c6520666f7220757064617465206d6f64756c652074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/update/update.module', 'update', 'module', '', 1, 0, 7001, 0, 0x613a31323a7b733a343a226e616d65223b733a31343a22557064617465206d616e61676572223b733a31313a226465736372697074696f6e223b733a3130343a22436865636b7320666f7220617661696c61626c6520757064617465732c20616e642063616e207365637572656c7920696e7374616c6c206f7220757064617465206d6f64756c657320616e64207468656d65732076696120612077656220696e746572666163652e223b733a373a2276657273696f6e223b733a333a22372e38223b733a373a227061636b616765223b733a343a22436f7265223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31313a227570646174652e74657374223b7d733a393a22636f6e666967757265223b733a33303a2261646d696e2f7265706f7274732f757064617465732f73657474696e6773223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('modules/user/tests/user_form_test.module', 'user_form_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32323a2255736572206d6f64756c6520666f726d207465737473223b733a31313a226465736372697074696f6e223b733a33373a22537570706f7274206d6f64756c6520666f72207573657220666f726d2074657374696e672e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('modules/user/user.module', 'user', 'module', '', 1, 0, 7017, 0, 0x613a31343a7b733a343a226e616d65223b733a343a2255736572223b733a31313a226465736372697074696f6e223b733a34373a224d616e6167657320746865207573657220726567697374726174696f6e20616e64206c6f67696e2073797374656d2e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a323a7b693a303b733a31313a22757365722e6d6f64756c65223b693a313b733a393a22757365722e74657374223b7d733a383a227265717569726564223b623a313b733a393a22636f6e666967757265223b733a31393a2261646d696e2f636f6e6669672f70656f706c65223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a383a22757365722e637373223b733a32313a226d6f64756c65732f757365722f757365722e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('profiles/standard/standard.profile', 'standard', 'module', '', 1, 0, 0, 1000, 0x613a31343a7b733a343a226e616d65223b733a383a225374616e64617264223b733a31313a226465736372697074696f6e223b733a35313a22496e7374616c6c207769746820636f6d6d6f6e6c792075736564206665617475726573207072652d636f6e666967757265642e223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a32313a7b693a303b733a353a22626c6f636b223b693a313b733a353a22636f6c6f72223b693a323b733a373a22636f6d6d656e74223b693a333b733a31303a22636f6e7465787475616c223b693a343b733a393a2264617368626f617264223b693a353b733a343a2268656c70223b693a363b733a353a22696d616765223b693a373b733a343a226c697374223b693a383b733a343a226d656e75223b693a393b733a363a226e756d626572223b693a31303b733a373a226f7074696f6e73223b693a31313b733a343a2270617468223b693a31323b733a383a227461786f6e6f6d79223b693a31333b733a353a2264626c6f67223b693a31343b733a363a22736561726368223b693a31353b733a383a2273686f7274637574223b693a31363b733a373a22746f6f6c626172223b693a31373b733a373a226f7665726c6179223b693a31383b733a383a226669656c645f7569223b693a31393b733a343a2266696c65223b693a32303b733a333a22726466223b7d733a353a2266696c6573223b613a313a7b693a303b733a31363a227374616e646172642e70726f66696c65223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b733a363a2268696464656e223b623a313b733a383a227265717569726564223b623a313b733a31373a22646973747269627574696f6e5f6e616d65223b733a363a2244727570616c223b7d),
('sites/all/modules/contrib/admin_menu/admin_devel/admin_devel.module', 'admin_devel', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a33323a2241646d696e697374726174696f6e20446576656c6f706d656e7420746f6f6c73223b733a31313a226465736372697074696f6e223b733a37363a2241646d696e697374726174696f6e20616e6420646562756767696e672066756e6374696f6e616c69747920666f7220646576656c6f7065727320616e642073697465206275696c646572732e223b733a373a227061636b616765223b733a31343a2241646d696e697374726174696f6e223b733a343a22636f7265223b733a333a22372e78223b733a373a2273637269707473223b613a313a7b733a31343a2261646d696e5f646576656c2e6a73223b733a36333a2273697465732f616c6c2f6d6f64756c65732f636f6e747269622f61646d696e5f6d656e752f61646d696e5f646576656c2f61646d696e5f646576656c2e6a73223b7d733a353a2266696c6573223b613a313a7b693a303b733a31383a2261646d696e5f646576656c2e6d6f64756c65223b7d733a373a2276657273696f6e223b733a31313a22372e782d332e302d726331223b733a373a2270726f6a656374223b733a31303a2261646d696e5f6d656e75223b733a393a22646174657374616d70223b733a31303a2231323934333738383730223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/admin_menu/admin_menu.module', 'admin_menu', 'module', '', 1, 0, 7303, 100, 0x613a31323a7b733a343a226e616d65223b733a31393a2241646d696e697374726174696f6e206d656e75223b733a31313a226465736372697074696f6e223b733a3132333a2250726f766964657320612064726f70646f776e206d656e7520746f206d6f73742061646d696e697374726174697665207461736b7320616e64206f7468657220636f6d6d6f6e2064657374696e6174696f6e732028746f2075736572732077697468207468652070726f706572207065726d697373696f6e73292e223b733a373a227061636b616765223b733a31343a2241646d696e697374726174696f6e223b733a393a22636f6e666967757265223b733a33383a2261646d696e2f636f6e6669672f61646d696e697374726174696f6e2f61646d696e5f6d656e75223b733a373a2276657273696f6e223b733a31313a22372e782d332e302d726331223b733a343a22636f7265223b733a333a22372e78223b733a373a2270726f6a656374223b733a31303a2261646d696e5f6d656e75223b733a353a2266696c6573223b613a313a7b693a303b733a32313a2274657374732f61646d696e5f6d656e752e74657374223b7d733a393a22646174657374616d70223b733a31303a2231323934333738383730223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/admin_menu/admin_menu_toolbar/admin_menu_toolbar.module', 'admin_menu_toolbar', 'module', '', 1, 0, 6300, 101, 0x613a31313a7b733a343a226e616d65223b733a33333a2241646d696e697374726174696f6e206d656e7520546f6f6c626172207374796c65223b733a31313a226465736372697074696f6e223b733a31373a22412062657474657220546f6f6c6261722e223b733a373a227061636b616765223b733a31343a2241646d696e697374726174696f6e223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a31303a2261646d696e5f6d656e75223b7d733a353a2266696c6573223b613a323a7b693a303b733a32353a2261646d696e5f6d656e755f746f6f6c6261722e6d6f64756c65223b693a313b733a32363a2261646d696e5f6d656e755f746f6f6c6261722e696e7374616c6c223b7d733a373a2276657273696f6e223b733a31313a22372e782d332e302d726331223b733a373a2270726f6a656374223b733a31303a2261646d696e5f6d656e75223b733a393a22646174657374616d70223b733a31303a2231323934333738383730223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/admin_menu/admin_views/admin_views.module', 'admin_views', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a32303a2241646d696e697374726174696f6e207669657773223b733a31313a226465736372697074696f6e223b733a37353a225265706c6163657320616c6c2073797374656d206f626a656374206d616e6167656d656e7420706167657320696e2044727570616c20636f72652077697468207265616c2076696577732e223b733a373a227061636b616765223b733a31343a2241646d696e697374726174696f6e223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a353a227669657773223b693a313b733a32313a2276696577735f62756c6b5f6f7065726174696f6e73223b7d733a353a2266696c6573223b613a323a7b693a303b733a31383a2261646d696e5f76696577732e6d6f64756c65223b693a313b733a33393a22706c7567696e732f76696577735f706c7567696e5f646973706c61795f73797374656d2e696e63223b7d733a373a2276657273696f6e223b733a31313a22372e782d332e302d726331223b733a373a2270726f6a656374223b733a31303a2261646d696e5f6d656e75223b733a393a22646174657374616d70223b733a31303a2231323934333738383730223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/backup_migrate/backup_migrate.module', 'backup_migrate', 'module', '', 1, 0, 7200, 0, 0x613a31313a7b733a343a226e616d65223b733a31383a224261636b757020616e64204d696772617465223b733a31313a226465736372697074696f6e223b733a37353a224261636b7570206f72206d696772617465207468652044727570616c20446174616261736520717569636b6c7920616e6420776974686f757420756e6e656365737361727920646174612e223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a353a7b693a303b733a32313a226261636b75705f6d6967726174652e6d6f64756c65223b693a313b733a32323a226261636b75705f6d6967726174652e696e7374616c6c223b693a323b733a32353a22696e636c756465732f64657374696e6174696f6e732e696e63223b693a333b733a32313a22696e636c756465732f70726f66696c65732e696e63223b693a343b733a32323a22696e636c756465732f7363686564756c65732e696e63223b7d733a373a2276657273696f6e223b733a373a22372e782d322e32223b733a373a2270726f6a656374223b733a31343a226261636b75705f6d696772617465223b733a393a22646174657374616d70223b733a31303a2231333130353238323134223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/context/context.module', 'context', 'module', '', 1, 0, 7000, 0, 0x613a31313a7b733a343a226e616d65223b733a373a22436f6e74657874223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a2263746f6f6c73223b7d733a31313a226465736372697074696f6e223b733a36363a2250726f76696465206d6f64756c6573207769746820612063616368652074686174206c6173747320666f7220612073696e676c65207061676520726571756573742e223b733a373a227061636b616765223b733a373a22436f6e74657874223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a343a7b693a303b733a31343a22636f6e746578742e6d6f64756c65223b693a313b733a31383a2274657374732f636f6e746578742e74657374223b693a323b733a32393a2274657374732f636f6e746578742e636f6e646974696f6e732e74657374223b693a333b733a32383a2274657374732f636f6e746578742e7265616374696f6e732e74657374223b7d733a373a2276657273696f6e223b733a31333a22372e782d332e302d6265746131223b733a373a2270726f6a656374223b733a373a22636f6e74657874223b733a393a22646174657374616d70223b733a31303a2231323938393235303638223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/context/context_layouts/context_layouts.module', 'context_layouts', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31353a22436f6e74657874206c61796f757473223b733a31313a226465736372697074696f6e223b733a38303a22416c6c6f77207468656d65206c6179657220746f2070726f76696465206d756c7469706c6520726567696f6e206c61796f75747320616e6420696e74656772617465207769746820636f6e746578742e223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a373a22636f6e74657874223b7d733a373a227061636b616765223b733a373a22436f6e74657874223b733a343a22636f7265223b733a333a22372e78223b733a373a2276657273696f6e223b733a31333a22372e782d332e302d6265746131223b733a373a2270726f6a656374223b733a373a22636f6e74657874223b733a393a22646174657374616d70223b733a31303a2231323938393235303638223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/context/context_ui/context_ui.module', 'context_ui', 'module', '', 1, 0, 6004, 0, 0x613a31313a7b733a343a226e616d65223b733a31303a22436f6e74657874205549223b733a31313a226465736372697074696f6e223b733a36383a2250726f766964657320612073696d706c6520554920666f722073657474696e67732075702061207369746520737472756374757265207573696e6720436f6e746578742e223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a373a22636f6e74657874223b7d733a373a227061636b616765223b733a373a22436f6e74657874223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a323a7b693a303b733a31343a22636f6e746578742e6d6f64756c65223b693a313b733a32313a2274657374732f636f6e746578745f75692e74657374223b7d733a373a2276657273696f6e223b733a31333a22372e782d332e302d6265746131223b733a373a2270726f6a656374223b733a373a22636f6e74657874223b733a393a22646174657374616d70223b733a31303a2231323938393235303638223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/bulk_export/bulk_export.module', 'bulk_export', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31313a2242756c6b204578706f7274223b733a31313a226465736372697074696f6e223b733a36373a22506572666f726d732062756c6b206578706f7274696e67206f662064617461206f626a65637473206b6e6f776e2061626f7574206279204368616f7320746f6f6c732e223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a2263746f6f6c73223b7d733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d);
INSERT INTO `system` (`filename`, `name`, `type`, `owner`, `status`, `bootstrap`, `schema_version`, `weight`, `info`) VALUES
('sites/all/modules/contrib/ctools/ctools.module', 'ctools', 'module', '', 1, 0, 6007, 0, 0x613a31313a7b733a343a226e616d65223b733a31313a224368616f7320746f6f6c73223b733a31313a226465736372697074696f6e223b733a34363a2241206c696272617279206f662068656c7066756c20746f6f6c73206279204d65726c696e206f66204368616f732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a353a2266696c6573223b613a333a7b693a303b733a32303a22696e636c756465732f636f6e746578742e696e63223b693a313b733a32323a22696e636c756465732f6d6174682d657870722e696e63223b693a323b733a32313a22696e636c756465732f7374796c697a65722e696e63223b7d733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/ctools_access_ruleset/ctools_access_ruleset.module', 'ctools_access_ruleset', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31353a22437573746f6d2072756c6573657473223b733a31313a226465736372697074696f6e223b733a38313a2243726561746520637573746f6d2c206578706f727461626c652c207265757361626c65206163636573732072756c657365747320666f72206170706c69636174696f6e73206c696b652050616e656c732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a2263746f6f6c73223b7d733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/ctools_ajax_sample/ctools_ajax_sample.module', 'ctools_ajax_sample', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a33333a224368616f7320546f6f6c73202843546f6f6c732920414a4158204578616d706c65223b733a31313a226465736372697074696f6e223b733a34313a2253686f777320686f7720746f207573652074686520706f776572206f66204368616f7320414a41582e223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a2263746f6f6c73223b7d733a343a22636f7265223b733a333a22372e78223b733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/ctools_custom_content/ctools_custom_content.module', 'ctools_custom_content', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a32303a22437573746f6d20636f6e74656e742070616e6573223b733a31313a226465736372697074696f6e223b733a37393a2243726561746520637573746f6d2c206578706f727461626c652c207265757361626c6520636f6e74656e742070616e657320666f72206170706c69636174696f6e73206c696b652050616e656c732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a2263746f6f6c73223b7d733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/ctools_plugin_example/ctools_plugin_example.module', 'ctools_plugin_example', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a33353a224368616f7320546f6f6c73202843546f6f6c732920506c7567696e204578616d706c65223b733a31313a226465736372697074696f6e223b733a37353a2253686f777320686f7720616e2065787465726e616c206d6f64756c652063616e2070726f766964652063746f6f6c7320706c7567696e732028666f722050616e656c732c206574632e292e223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a31323a22646570656e64656e63696573223b613a343a7b693a303b733a363a2263746f6f6c73223b693a313b733a363a2270616e656c73223b693a323b733a31323a22706167655f6d616e61676572223b693a333b733a31333a22616476616e6365645f68656c70223b7d733a343a22636f7265223b733a333a22372e78223b733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/page_manager/page_manager.module', 'page_manager', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31323a2250616765206d616e61676572223b733a31313a226465736372697074696f6e223b733a35343a2250726f7669646573206120554920616e642041504920746f206d616e6167652070616765732077697468696e2074686520736974652e223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a2263746f6f6c73223b7d733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/stylizer/stylizer.module', 'stylizer', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a383a225374796c697a6572223b733a31313a226465736372697074696f6e223b733a35333a2243726561746520637573746f6d207374796c657320666f72206170706c69636174696f6e7320737563682061732050616e656c732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a363a2263746f6f6c73223b693a313b733a353a22636f6c6f72223b7d733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/tests/ctools_plugin_test.module', 'ctools_plugin_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a32343a224368616f7320746f6f6c7320706c7567696e732074657374223b733a31313a226465736372697074696f6e223b733a34323a2250726f766964657320686f6f6b7320666f722074657374696e672063746f6f6c7320706c7567696e732e223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a2263746f6f6c73223b7d733a353a2266696c6573223b613a323a7b693a303b733a31393a2263746f6f6c732e706c7567696e732e74657374223b693a313b733a31373a226f626a6563745f63616368652e74657374223b7d733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/ctools/views_content/views_content.module', 'views_content', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31393a22566965777320636f6e74656e742070616e6573223b733a31313a226465736372697074696f6e223b733a3130343a22416c6c6f777320566965777320636f6e74656e7420746f206265207573656420696e2050616e656c732c2044617368626f61726420616e64206f74686572206d6f64756c657320776869636820757365207468652043546f6f6c7320436f6e74656e74204150492e223b733a373a227061636b616765223b733a31363a224368616f7320746f6f6c207375697465223b733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a363a2263746f6f6c73223b693a313b733a353a227669657773223b7d733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a333a7b693a303b733a36313a22706c7567696e732f76696577732f76696577735f636f6e74656e745f706c7567696e5f646973706c61795f63746f6f6c735f636f6e746578742e696e63223b693a313b733a35373a22706c7567696e732f76696577732f76696577735f636f6e74656e745f706c7567696e5f646973706c61795f70616e656c5f70616e652e696e63223b693a323b733a35393a22706c7567696e732f76696577732f76696577735f636f6e74656e745f706c7567696e5f7374796c655f63746f6f6c735f636f6e746578742e696e63223b7d733a373a2276657273696f6e223b733a31313a22372e782d312e302d726331223b733a373a2270726f6a656374223b733a363a2263746f6f6c73223b733a393a22646174657374616d70223b733a31303a2231333131383934343135223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/devel/devel.module', 'devel', 'module', '', 0, 0, -1, 0, 0x613a31333a7b733a343a226e616d65223b733a353a22446576656c223b733a31313a226465736372697074696f6e223b733a35323a22566172696f757320626c6f636b732c2070616765732c20616e642066756e6374696f6e7320666f7220646576656c6f706572732e223b733a373a227061636b616765223b733a31313a22446576656c6f706d656e74223b733a343a22636f7265223b733a333a22372e78223b733a393a22636f6e666967757265223b733a33303a2261646d696e2f636f6e6669672f646576656c6f706d656e742f646576656c223b733a343a2274616773223b613a313a7b693a303b733a393a22646576656c6f706572223b7d733a353a2266696c6573223b613a323a7b693a303b733a31303a22646576656c2e74657374223b693a313b733a31343a22646576656c2e6d61696c2e696e63223b7d733a373a2276657273696f6e223b733a373a22372e782d312e32223b733a373a2270726f6a656374223b733a353a22646576656c223b733a393a22646174657374616d70223b733a31303a2231333131333535333136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/devel/devel_generate/devel_generate.module', 'devel_generate', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31343a22446576656c2067656e6572617465223b733a31313a226465736372697074696f6e223b733a34383a2247656e65726174652064756d6d792075736572732c206e6f6465732c20616e64207461786f6e6f6d79207465726d732e223b733a373a227061636b616765223b733a31313a22446576656c6f706d656e74223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a22646576656c223b7d733a343a2274616773223b613a313a7b693a303b733a393a22646576656c6f706572223b7d733a373a2276657273696f6e223b733a373a22372e782d312e32223b733a373a2270726f6a656374223b733a353a22646576656c223b733a393a22646174657374616d70223b733a31303a2231333131333535333136223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/devel/devel_node_access.module', 'devel_node_access', 'module', '', 0, 0, -1, 0, 0x613a31333a7b733a343a226e616d65223b733a31373a22446576656c206e6f646520616363657373223b733a31313a226465736372697074696f6e223b733a36383a22446576656c6f70657220626c6f636b7320616e64207061676520696c6c757374726174696e672072656c6576616e74206e6f64655f616363657373207265636f7264732e223b733a373a227061636b616765223b733a31313a22446576656c6f706d656e74223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a343a226d656e75223b7d733a343a22636f7265223b733a333a22372e78223b733a393a22636f6e666967757265223b733a33303a2261646d696e2f636f6e6669672f646576656c6f706d656e742f646576656c223b733a343a2274616773223b613a313a7b693a303b733a393a22646576656c6f706572223b7d733a373a2276657273696f6e223b733a373a22372e782d312e32223b733a373a2270726f6a656374223b733a353a22646576656c223b733a393a22646174657374616d70223b733a31303a2231333131333535333136223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/easy_social/easy_social.module', 'easy_social', 'module', '', 1, 0, 0, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a224561737920536f6369616c223b733a31313a226465736372697074696f6e223b733a35373a2253696d706c65206d6f64756c65207468617420616464206d6f737420636f6d6d6f6e20736861726520627574746f6e7320746f206e6f646573223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31383a22656173795f736f6369616c2e6d6f64756c65223b7d733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a383a227661726961626c65223b693a313b733a31343a227661726961626c655f7265616c6d223b7d733a393a22636f6e666967757265223b733a33313a2261646d696e2f636f6e6669672f636f6e74656e742f65617379736f6369616c223b733a373a2276657273696f6e223b733a31333a22372e782d312e302d6265746134223b733a373a2270726f6a656374223b733a31313a22656173795f736f6369616c223b733a393a22646174657374616d70223b733a31303a2231333133343633343136223b733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/features/features.module', 'features', 'module', '', 1, 0, 6101, 20, 0x613a31313a7b733a343a226e616d65223b733a383a224665617475726573223b733a31313a226465736372697074696f6e223b733a33393a2250726f76696465732066656174757265206d616e6167656d656e7420666f722044727570616c2e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a383a224665617475726573223b733a353a2266696c6573223b613a313a7b693a303b733a31393a2274657374732f66656174757265732e74657374223b7d733a373a2276657273696f6e223b733a31333a22372e782d312e302d6265746133223b733a373a2270726f6a656374223b733a383a226665617475726573223b733a393a22646174657374616d70223b733a31303a2231333038353938393135223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/features/tests/features_test.module', 'features_test', 'module', '', 0, 0, -1, 0, 0x613a31333a7b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a343a7b693a303b733a383a226665617475726573223b693a313b733a353a22696d616765223b693a323b733a393a227374726f6e6761726d223b693a333b733a353a227669657773223b7d733a31313a226465736372697074696f6e223b733a33333a2254657374206d6f64756c6520666f722046656174757265732074657374696e672e223b733a383a226665617475726573223b613a373a7b733a363a2263746f6f6c73223b613a323a7b693a303b733a32313a227374726f6e6761726d3a7374726f6e6761726d3a31223b693a313b733a32333a2276696577733a76696577735f64656661756c743a332e30223b7d733a353a226669656c64223b613a313a7b693a303b733a33383a226e6f64652d66656174757265735f746573742d6669656c645f66656174757265735f74657374223b7d733a363a2266696c746572223b613a313a7b693a303b733a31333a2266656174757265735f74657374223b7d733a353a22696d616765223b613a313a7b693a303b733a31333a2266656174757265735f74657374223b7d733a343a226e6f6465223b613a313a7b693a303b733a31333a2266656174757265735f74657374223b7d733a31353a22757365725f7065726d697373696f6e223b613a313a7b693a303b733a32383a226372656174652066656174757265735f7465737420636f6e74656e74223b7d733a31303a2276696577735f76696577223b613a313a7b693a303b733a31333a2266656174757265735f74657374223b7d7d733a363a2268696464656e223b623a313b733a343a226e616d65223b733a31343a224665617475726573205465737473223b733a373a227061636b616765223b733a373a2254657374696e67223b733a333a22706870223b733a353a22352e322e30223b733a373a2276657273696f6e223b733a31333a22372e782d312e302d6265746133223b733a373a2270726f6a656374223b733a383a226665617475726573223b733a393a22646174657374616d70223b733a31303a2231333038353938393135223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/field_group/field_group.module', 'field_group', 'module', '', 1, 0, 7002, 1, 0x613a31313a7b733a343a226e616d65223b733a31303a224669656c6467726f7570223b733a31313a226465736372697074696f6e223b733a31303a224669656c6467726f7570223b733a373a227061636b616765223b733a363a224669656c6473223b733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a353a226669656c64223b693a313b733a363a2263746f6f6c73223b7d733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a363a7b693a303b733a31393a226669656c645f67726f75702e696e7374616c6c223b693a313b733a31383a226669656c645f67726f75702e6d6f64756c65223b693a323b733a32343a226669656c645f67726f75702e6669656c645f75692e696e63223b693a333b733a32303a226669656c645f67726f75702e666f726d2e696e63223b693a343b733a32343a226669656c645f67726f75702e66656174757265732e696e63223b693a353b733a31363a226669656c645f67726f75702e74657374223b7d733a373a2276657273696f6e223b733a373a22372e782d312e30223b733a373a2270726f6a656374223b733a31313a226669656c645f67726f7570223b733a393a22646174657374616d70223b733a31303a2231333036323636343136223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/filter_perms/filter_perms.module', 'filter_perms', 'module', '', 1, 0, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a31383a2246696c746572207065726d697373696f6e73223b733a31313a226465736372697074696f6e223b733a37313a2250726f766964657320726f6c6520616e64206d6f64756c652066696c7465727320746f2073696d706c696679207468652075736572207065726d697373696f6e7320706167652e223b733a373a227061636b616765223b733a31343a2241646d696e697374726174696f6e223b733a343a22636f7265223b733a333a22372e78223b733a373a2276657273696f6e223b733a31313a22372e782d312e782d646576223b733a373a2270726f6a656374223b733a31323a2266696c7465725f7065726d73223b733a393a22646174657374616d70223b733a31303a2231333134373530343732223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/globalredirect/globalredirect.module', 'globalredirect', 'module', '', 1, 0, 6101, 0, 0x613a31313a7b733a343a226e616d65223b733a31353a22476c6f62616c205265646972656374223b733a31313a226465736372697074696f6e223b733a3132393a22536561726368657320666f7220616e20616c696173206f66207468652063757272656e742055524c20616e64203330312072656469726563747320696620666f756e642e2053746f7073206475706c696361746520636f6e74656e742061726973696e67207768656e2070617468206d6f64756c6520697320656e61626c65642e223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a343a7b693a303b733a32313a22676c6f62616c72656469726563742e6d6f64756c65223b693a313b733a32323a22676c6f62616c72656469726563742e696e7374616c6c223b693a323b733a32343a22676c6f62616c72656469726563742e61646d696e2e696e63223b693a333b733a31393a22676c6f62616c72656469726563742e74657374223b7d733a373a2276657273696f6e223b733a373a22372e782d312e33223b733a373a2270726f6a656374223b733a31343a22676c6f62616c7265646972656374223b733a393a22646174657374616d70223b733a31303a2231323934323432393535223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/google_analytics/googleanalytics.module', 'googleanalytics', 'module', '', 1, 0, 7005, 0, 0x613a31323a7b733a343a226e616d65223b733a31363a22476f6f676c6520416e616c7974696373223b733a31313a226465736372697074696f6e223b733a3130323a22416c6c6f777320796f7572207369746520746f20626520747261636b656420627920476f6f676c6520416e616c797469637320627920616464696e672061204a61766173637269707420747261636b696e6720636f646520746f20657665727920706167652e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a31303a2253746174697374696373223b733a393a22636f6e666967757265223b733a33353a2261646d696e2f636f6e6669672f73797374656d2f676f6f676c65616e616c7974696373223b733a353a2266696c6573223b613a313a7b693a303b733a32303a22676f6f676c65616e616c79746963732e74657374223b7d733a373a2276657273696f6e223b733a373a22372e782d312e32223b733a373a2270726f6a656374223b733a31363a22676f6f676c655f616e616c7974696373223b733a393a22646174657374616d70223b733a31303a2231333031333430333637223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/headjs/headjs.module', 'headjs', 'module', '', 1, 0, 0, 999, 0x613a31313a7b733a343a226e616d65223b733a363a22486561644a53223b733a31313a226465736372697074696f6e223b733a33363a22546865206f6e6c792073637269707420696e20796f757220266c743b484541442667743b223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a32373a22506572666f726d616e636520616e64207363616c6162696c697479223b733a373a2270726f6a656374223b733a363a22686561646a73223b733a373a2276657273696f6e223b733a373a22372e782d312e34223b733a393a22646174657374616d70223b733a31303a2231333036393839343135223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/link/link.module', 'link', 'module', '', 1, 0, 6001, 0, 0x613a31333a7b733a343a226e616d65223b733a343a224c696e6b223b733a31313a226465736372697074696f6e223b733a33323a22446566696e65732073696d706c65206c696e6b206669656c642074797065732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a363a224669656c6473223b733a353a2266696c6573223b613a383a7b693a303b733a31313a226c696e6b2e6d6f64756c65223b693a313b733a31323a226c696e6b2e696e7374616c6c223b693a323b733a32303a2274657374732f6c696e6b2e637275642e74657374223b693a333b733a32353a2274657374732f6c696e6b2e6174747269627574652e74657374223b693a343b733a32383a2274657374732f6c696e6b2e637275645f62726f777365722e74657374223b693a353b733a32343a2274657374732f6c696e6b2e76616c69646174652e74657374223b693a363b733a34343a2276696577732f6c696e6b5f76696577735f68616e646c65725f617267756d656e745f7461726765742e696e63223b693a373b733a34343a2276696577732f6c696e6b5f76696577735f68616e646c65725f66696c7465725f70726f746f636f6c2e696e63223b7d733a373a2276657273696f6e223b733a31343a22372e782d312e302d616c70686133223b733a373a2270726f6a656374223b733a343a226c696e6b223b733a393a22646174657374616d70223b733a31303a2231323937303631323136223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b733a383a227265717569726564223b623a313b733a31313a226578706c616e6174696f6e223b733a37333a224669656c64207479706528732920696e20757365202d20736565203c6120687265663d222f61646d696e2f7265706f7274732f6669656c6473223e4669656c64206c6973743c2f613e223b7d),
('sites/all/modules/contrib/metatags_quick/metatags_quick.module', 'metatags_quick', 'module', '', 1, 0, 7003, 0, 0x613a31333a7b733a343a226e616d65223b733a31373a224d65746120746167732028717569636b29223b733a31313a226465736372697074696f6e223b733a36353a2241646473206d6574612074616773206669656c647320746f207669727475616c6c7920616e792070616765206f6620796f75722044727570616c20372073697465223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a363a224669656c6473223b733a373a2276657273696f6e223b733a373a22372e782d322e30223b733a373a2270726f6a656374223b733a31343a226d657461746167735f717569636b223b733a393a22646174657374616d70223b733a31303a2231333132343033353233223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b733a383a227265717569726564223b623a313b733a31313a226578706c616e6174696f6e223b733a37333a224669656c64207479706528732920696e20757365202d20736565203c6120687265663d222f61646d696e2f7265706f7274732f6669656c6473223e4669656c64206c6973743c2f613e223b7d),
('sites/all/modules/contrib/module_filter/module_filter.module', 'module_filter', 'module', '', 1, 0, 7100, 0, 0x613a31323a7b733a343a226e616d65223b733a31333a224d6f64756c652066696c746572223b733a31313a226465736372697074696f6e223b733a32343a2246696c74657220746865206d6f64756c6573206c6973742e223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a393a7b693a303b733a32313a226d6f64756c655f66696c7465722e696e7374616c6c223b693a313b733a31363a226d6f64756c655f66696c7465722e6a73223b693a323b733a32303a226d6f64756c655f66696c7465722e6d6f64756c65223b693a333b733a32333a226d6f64756c655f66696c7465722e61646d696e2e696e63223b693a343b733a32333a226d6f64756c655f66696c7465722e7468656d652e696e63223b693a353b733a32313a226373732f6d6f64756c655f66696c7465722e637373223b693a363b733a32353a226373732f6d6f64756c655f66696c7465725f7461622e637373223b693a373b733a31393a226a732f6d6f64756c655f66696c7465722e6a73223b693a383b733a32333a226a732f6d6f64756c655f66696c7465725f7461622e6a73223b7d733a393a22636f6e666967757265223b733a34303a2261646d696e2f636f6e6669672f757365722d696e746572666163652f6d6f64756c6566696c746572223b733a373a2276657273696f6e223b733a373a22372e782d312e35223b733a373a2270726f6a656374223b733a31333a226d6f64756c655f66696c746572223b733a393a22646174657374616d70223b733a31303a2231333133353938313230223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/mollom/mollom.module', 'mollom', 'module', '', 1, 0, 7011, 0, 0x613a31343a7b733a343a226e616d65223b733a363a224d6f6c6c6f6d223b733a31313a226465736372697074696f6e223b733a39343a224175746f6d61746963616c6c79206d6f6465726174657320757365722d7375626d697474656420636f6e74656e7420616e642070726f746563747320796f757220736974652066726f6d207370616d20616e642070726f66616e6974792e223b733a343a22636f7265223b733a333a22372e78223b733a393a22636f6e666967757265223b733a32373a2261646d696e2f636f6e6669672f636f6e74656e742f6d6f6c6c6f6d223b733a373a2273637269707473223b613a313a7b733a393a226d6f6c6c6f6d2e6a73223b733a34323a2273697465732f616c6c2f6d6f64756c65732f636f6e747269622f6d6f6c6c6f6d2f6d6f6c6c6f6d2e6a73223b7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a226d6f6c6c6f6d2e637373223b733a34333a2273697465732f616c6c2f6d6f64756c65732f636f6e747269622f6d6f6c6c6f6d2f6d6f6c6c6f6d2e637373223b7d7d733a353a2266696c6573223b613a353a7b693a303b733a31333a226d6f6c6c6f6d2e6d6f64756c65223b693a313b733a31363a226d6f6c6c6f6d2e61646d696e2e696e63223b693a323b733a31363a226d6f6c6c6f6d2e70616765732e696e63223b693a333b733a31343a226d6f6c6c6f6d2e696e7374616c6c223b693a343b733a31373a2274657374732f6d6f6c6c6f6d2e74657374223b7d733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a363a226d6f6c6c6f6d223b733a393a22646174657374616d70223b733a31303a2231333130323137373230223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/mollom/tests/mollom_test.module', 'mollom_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31313a224d6f6c6c6f6d2054657374223b733a31313a226465736372697074696f6e223b733a35353a2254657374696e67206d6f64756c6520666f72204d6f6c6c6f6d2066756e6374696f6e616c6974792e20446f206e6f7420656e61626c652e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a373a2254657374696e67223b733a363a2268696464656e223b623a313b733a353a2266696c6573223b613a313a7b693a303b733a31383a226d6f6c6c6f6d5f746573742e6d6f64756c65223b7d733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a363a226d6f6c6c6f6d223b733a393a22646174657374616d70223b733a31303a2231333130323137373230223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/pathauto/pathauto.module', 'pathauto', 'module', '', 1, 0, 7005, 1, 0x613a31333a7b733a343a226e616d65223b733a383a22506174686175746f223b733a31313a226465736372697074696f6e223b733a39353a2250726f76696465732061206d656368616e69736d20666f72206d6f64756c657320746f206175746f6d61746963616c6c792067656e657261746520616c696173657320666f722074686520636f6e74656e742074686579206d616e6167652e223b733a31323a22646570656e64656e63696573223b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22746f6b656e223b7d733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31333a22706174686175746f2e74657374223b7d733a393a22636f6e666967757265223b733a33333a2261646d696e2f636f6e6669672f7365617263682f706174682f7061747465726e73223b733a31303a227265636f6d6d656e6473223b613a313a7b693a303b733a383a227265646972656374223b7d733a373a2276657273696f6e223b733a31313a22372e782d312e302d726332223b733a373a2270726f6a656374223b733a383a22706174686175746f223b733a393a22646174657374616d70223b733a31303a2231333038323431303231223b733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/piwik/piwik.module', 'piwik', 'module', '', 1, 0, 7204, 0, 0x613a31323a7b733a343a226e616d65223b733a31393a22506977696b2057656220616e616c7974696373223b733a31313a226465736372697074696f6e223b733a36313a224164647320506977696b206a61766173637269707420747261636b696e6720636f646520746f20616c6c20796f7572207369746527732070616765732e223b733a343a22636f7265223b733a333a22372e78223b733a373a227061636b616765223b733a31303a2253746174697374696373223b733a393a22636f6e666967757265223b733a32353a2261646d696e2f636f6e6669672f73797374656d2f706977696b223b733a353a2266696c6573223b613a313a7b693a303b733a31303a22706977696b2e74657374223b7d733a373a2276657273696f6e223b733a373a22372e782d322e32223b733a373a2270726f6a656374223b733a353a22706977696b223b733a393a22646174657374616d70223b733a31303a2231333039363036363230223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/scheduler/scheduler.module', 'scheduler', 'module', '', 1, 0, 6101, 0, 0x613a31313a7b733a343a226e616d65223b733a393a225363686564756c6572223b733a31313a226465736372697074696f6e223b733a38353a2254686973206d6f64756c6520616c6c6f7773206e6f64657320746f206265207075626c697368656420616e6420756e7075626c6973686564206f6e2073706563696669656420646174657320616e642074696d652e223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a353a7b693a303b733a31373a227363686564756c65722e696e7374616c6c223b693a313b733a31363a227363686564756c65722e6d6f64756c65223b693a323b733a31393a227363686564756c65722e76696577732e696e63223b693a333b733a31343a227363686564756c65722e74657374223b693a343b733a34373a227363686564756c65725f68616e646c65725f6669656c645f7363686564756c65725f636f756e74646f776e2e696e63223b7d733a373a2276657273696f6e223b733a373a22372e782d312e30223b733a373a2270726f6a656374223b733a393a227363686564756c6572223b733a393a22646174657374616d70223b733a31303a2231323939393339303639223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/tagadelic/tagadelic.module', 'tagadelic', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a393a225461676164656c6963223b733a31313a226465736372697074696f6e223b733a36313a225461676164656c6963206d616b65732077656967687465642074616720636c6f7564732066726f6d20796f7572207461786f6e6f6d79207465726d732e223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a383a227461786f6e6f6d79223b7d733a373a227061636b616765223b733a383a225461786f6e6f6d79223b733a373a2276657273696f6e223b733a31313a22372e782d312e782d646576223b733a373a2270726f6a656374223b733a393a227461676164656c6963223b733a393a22646174657374616d70223b733a31303a2231333035363739363630223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/token/tests/token_test.module', 'token_test', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a31303a22546f6b656e2054657374223b733a31313a226465736372697074696f6e223b733a33393a2254657374696e67206d6f64756c6520666f7220746f6b656e2066756e6374696f6e616c6974792e223b733a373a227061636b616765223b733a373a2254657374696e67223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a313a7b693a303b733a31373a22746f6b656e5f746573742e6d6f64756c65223b7d733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a31333a22372e782d312e302d6265746135223b733a373a2270726f6a656374223b733a353a22746f6b656e223b733a393a22646174657374616d70223b733a31303a2231333134383034373232223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/token/token.module', 'token', 'module', '', 1, 0, 7001, 0, 0x613a31313a7b733a343a226e616d65223b733a353a22546f6b656e223b733a31313a226465736372697074696f6e223b733a37333a2250726f76696465732061207573657220696e7465726661636520666f722074686520546f6b656e2041504920616e6420736f6d65206d697373696e6720636f726520746f6b656e732e223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a353a7b693a303b733a31323a22746f6b656e2e6d6f64756c65223b693a313b733a31333a22746f6b656e2e696e7374616c6c223b693a323b733a31363a22746f6b656e2e746f6b656e732e696e63223b693a333b733a31353a22746f6b656e2e70616765732e696e63223b693a343b733a31303a22746f6b656e2e74657374223b7d733a373a2276657273696f6e223b733a31333a22372e782d312e302d6265746135223b733a373a2270726f6a656374223b733a353a22746f6b656e223b733a393a22646174657374616d70223b733a31303a2231333134383034373232223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/variable/variable.module', 'variable', 'module', '', 1, 1, 0, 0, 0x613a31313a7b733a343a226e616d65223b733a383a225661726961626c65223b733a31313a226465736372697074696f6e223b733a34333a225661726961626c6520496e666f726d6174696f6e20616e64206261736963207661726961626c6520415049223b733a343a22636f7265223b733a333a22372e78223b733a353a2266696c6573223b613a333a7b693a303b733a32363a22696e636c756465732f6e6f64652e7661726961626c652e696e63223b693a313b733a32383a22696e636c756465732f73797374656d2e7661726961626c652e696e63223b693a323b733a32363a22696e636c756465732f757365722e7661726961626c652e696e63223b7d733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a383a227661726961626c65223b733a393a22646174657374616d70223b733a31303a2231333133303838373231223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/variable/variable_admin/variable_admin.module', 'variable_admin', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31343a225661726961626c652061646d696e223b733a31313a226465736372697074696f6e223b733a32363a225661726961626c652041646d696e697374726174696f6e205549223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a383a227661726961626c65223b7d733a343a22636f7265223b733a333a22372e78223b733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a383a227661726961626c65223b733a393a22646174657374616d70223b733a31303a2231333133303838373231223b733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/variable/variable_advanced/variable_advanced.module', 'variable_advanced', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31373a225661726961626c6520616476616e636564223b733a31313a226465736372697074696f6e223b733a3130353a2250726f76696465732061636365737320746f20616476616e636564206c6f77206c6576656c207661726961626c65732e204279207573696e67207468697320796f752077696c6c2062652061626c6520746f20627265616b20796f75722073697465206261646c792e223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a383a227661726961626c65223b7d733a343a22636f7265223b733a333a22372e78223b733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a383a227661726961626c65223b733a393a22646174657374616d70223b733a31303a2231333133303838373231223b733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/variable/variable_realm/variable_realm.module', 'variable_realm', 'module', '', 1, 1, 0, -1000, 0x613a31313a7b733a343a226e616d65223b733a31343a225661726961626c65207265616c6d223b733a31313a226465736372697074696f6e223b733a34393a2241504920746f20757365207661726961626c65207265616c6d732066726f6d20646966666572656e74206d6f64756c6573223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a383a227661726961626c65223b7d733a343a22636f7265223b733a333a22372e78223b733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a383a227661726961626c65223b733a393a22646174657374616d70223b733a31303a2231333133303838373231223b733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/variable/variable_store/variable_store.module', 'variable_store', 'module', '', 0, 0, -1, 0, 0x613a31313a7b733a343a226e616d65223b733a31343a225661726961626c652073746f7265223b733a31313a226465736372697074696f6e223b733a36303a2244617461626173652073746f7261676520666f72207661726961626c65207265616c6d732e205468697320697320616e20415049206d6f64756c652e223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a31343a227661726961626c655f7265616c6d223b7d733a343a22636f7265223b733a333a22372e78223b733a373a2276657273696f6e223b733a373a22372e782d312e31223b733a373a2270726f6a656374223b733a383a227661726961626c65223b733a393a22646174657374616d70223b733a31303a2231333133303838373231223b733a373a227061636b616765223b733a353a224f74686572223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d);
INSERT INTO `system` (`filename`, `name`, `type`, `owner`, `status`, `bootstrap`, `schema_version`, `weight`, `info`) VALUES
('sites/all/modules/contrib/views/views.module', 'views', 'module', '', 0, 0, 7000, 10, 0x613a31323a7b733a343a226e616d65223b733a353a225669657773223b733a31313a226465736372697074696f6e223b733a35353a2243726561746520637573746f6d697a6564206c6973747320616e6420717565726965732066726f6d20796f75722064617461626173652e223b733a373a227061636b616765223b733a353a225669657773223b733a343a22636f7265223b733a333a22372e78223b733a333a22706870223b733a333a22352e32223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31333a226373732f76696577732e637373223b733a34353a2273697465732f616c6c2f6d6f64756c65732f636f6e747269622f76696577732f6373732f76696577732e637373223b7d7d733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a363a2263746f6f6c73223b7d733a353a2266696c6573223b613a3235363a7b693a303b733a33313a2268616e646c6572732f76696577735f68616e646c65725f617265612e696e63223b693a313b733a33363a2268616e646c6572732f76696577735f68616e646c65725f617265615f746578742e696e63223b693a323b733a33363a2268616e646c6572732f76696577735f68616e646c65725f617265615f766965772e696e63223b693a333b733a33353a2268616e646c6572732f76696577735f68616e646c65725f617267756d656e742e696e63223b693a343b733a34303a2268616e646c6572732f76696577735f68616e646c65725f617267756d656e745f646174652e696e63223b693a353b733a34333a2268616e646c6572732f76696577735f68616e646c65725f617267756d656e745f666f726d756c612e696e63223b693a363b733a34373a2268616e646c6572732f76696577735f68616e646c65725f617267756d656e745f6d616e795f746f5f6f6e652e696e63223b693a373b733a34303a2268616e646c6572732f76696577735f68616e646c65725f617267756d656e745f6e756c6c2e696e63223b693a383b733a34333a2268616e646c6572732f76696577735f68616e646c65725f617267756d656e745f6e756d657269632e696e63223b693a393b733a34323a2268616e646c6572732f76696577735f68616e646c65725f617267756d656e745f737472696e672e696e63223b693a31303b733a35323a2268616e646c6572732f76696577735f68616e646c65725f617267756d656e745f67726f75705f62795f6e756d657269632e696e63223b693a31313b733a33323a2268616e646c6572732f76696577735f68616e646c65725f6669656c642e696e63223b693a31323b733a34303a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f636f756e7465722e696e63223b693a31333b733a34393a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f67726f75705f62795f6e756d657269632e696e63223b693a31343b733a34303a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f626f6f6c65616e2e696e63223b693a31353b733a33393a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f637573746f6d2e696e63223b693a31363b733a33373a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f646174652e696e63223b693a31373b733a33393a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f6d61726b75702e696e63223b693a31383b733a33373a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f6d6174682e696e63223b693a31393b733a34303a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f6e756d657269632e696e63223b693a32303b733a34373a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f70726572656e6465725f6c6973742e696e63223b693a32313b733a34363a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f74696d655f696e74657276616c2e696e63223b693a32323b733a34333a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f73657269616c697a65642e696e63223b693a32333b733a33363a2268616e646c6572732f76696577735f68616e646c65725f6669656c645f75726c2e696e63223b693a32343b733a33333a2268616e646c6572732f76696577735f68616e646c65725f66696c7465722e696e63223b693a32353b733a35303a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f67726f75705f62795f6e756d657269632e696e63223b693a32363b733a35303a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f626f6f6c65616e5f6f70657261746f722e696e63223b693a32373b733a35373a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f626f6f6c65616e5f6f70657261746f725f737472696e672e696e63223b693a32383b733a33383a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f646174652e696e63223b693a32393b733a34323a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f657175616c6974792e696e63223b693a33303b733a34353a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f696e5f6f70657261746f722e696e63223b693a33313b733a34353a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f6d616e795f746f5f6f6e652e696e63223b693a33323b733a34313a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f6e756d657269632e696e63223b693a33333b733a34303a2268616e646c6572732f76696577735f68616e646c65725f66696c7465725f737472696e672e696e63223b693a33343b733a33393a2268616e646c6572732f76696577735f68616e646c65725f72656c6174696f6e736869702e696e63223b693a33353b733a33313a2268616e646c6572732f76696577735f68616e646c65725f736f72742e696e63223b693a33363b733a34383a2268616e646c6572732f76696577735f68616e646c65725f736f72745f67726f75705f62795f6e756d657269632e696e63223b693a33373b733a33363a2268616e646c6572732f76696577735f68616e646c65725f736f72745f646174652e696e63223b693a33383b733a33393a2268616e646c6572732f76696577735f68616e646c65725f736f72745f666f726d756c612e696e63223b693a33393b733a34363a2268616e646c6572732f76696577735f68616e646c65725f736f72745f6d656e755f6869657261726368792e696e63223b693a34303b733a33383a2268616e646c6572732f76696577735f68616e646c65725f736f72745f72616e646f6d2e696e63223b693a34313b733a31373a22696e636c756465732f626173652e696e63223b693a34323b733a32313a22696e636c756465732f68616e646c6572732e696e63223b693a34333b733a32303a22696e636c756465732f706c7567696e732e696e63223b693a34343b733a31373a22696e636c756465732f766965772e696e63223b693a34353b733a36303a226d6f64756c65732f61676772656761746f722f76696577735f68616e646c65725f617267756d656e745f61676772656761746f725f6669642e696e63223b693a34363b733a36303a226d6f64756c65732f61676772656761746f722f76696577735f68616e646c65725f617267756d656e745f61676772656761746f725f6969642e696e63223b693a34373b733a36393a226d6f64756c65732f61676772656761746f722f76696577735f68616e646c65725f617267756d656e745f61676772656761746f725f63617465676f72795f6369642e696e63223b693a34383b733a36343a226d6f64756c65732f61676772656761746f722f76696577735f68616e646c65725f6669656c645f61676772656761746f725f7469746c655f6c696e6b2e696e63223b693a34393b733a36323a226d6f64756c65732f61676772656761746f722f76696577735f68616e646c65725f6669656c645f61676772656761746f725f63617465676f72792e696e63223b693a35303b733a37303a226d6f64756c65732f61676772656761746f722f76696577735f68616e646c65725f6669656c645f61676772656761746f725f6974656d5f6465736372697074696f6e2e696e63223b693a35313b733a35373a226d6f64756c65732f61676772656761746f722f76696577735f68616e646c65725f6669656c645f61676772656761746f725f7873732e696e63223b693a35323b733a36373a226d6f64756c65732f61676772656761746f722f76696577735f68616e646c65725f66696c7465725f61676772656761746f725f63617465676f72795f6369642e696e63223b693a35333b733a35343a226d6f64756c65732f61676772656761746f722f76696577735f706c7567696e5f726f775f61676772656761746f725f7273732e696e63223b693a35343b733a35393a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f617267756d656e745f636f6d6d656e745f757365725f7569642e696e63223b693a35353b733a34373a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f636f6d6d656e742e696e63223b693a35363b733a35333a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f636f6d6d656e745f64657074682e696e63223b693a35373b733a35323a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f636f6d6d656e745f6c696e6b2e696e63223b693a35383b733a35393a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f636f6d6d656e745f6c696e6b5f64656c6574652e696e63223b693a35393b733a35373a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f636f6d6d656e745f6c696e6b5f656469742e696e63223b693a36303b733a35383a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f636f6d6d656e745f6c696e6b5f7265706c792e696e63223b693a36313b733a35373a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f636f6d6d656e745f6e6f64655f6c696e6b2e696e63223b693a36323b733a35363a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f636f6d6d656e745f757365726e616d652e696e63223b693a36333b733a36313a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f6e63735f6c6173745f636f6d6d656e745f6e616d652e696e63223b693a36343b733a35363a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f6e63735f6c6173745f757064617465642e696e63223b693a36353b733a35323a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f6e6f64655f636f6d6d656e742e696e63223b693a36363b733a35373a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f6e6f64655f6e65775f636f6d6d656e74732e696e63223b693a36373b733a36323a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f6669656c645f6c6173745f636f6d6d656e745f74696d657374616d702e696e63223b693a36383b733a35373a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f66696c7465725f636f6d6d656e745f757365725f7569642e696e63223b693a36393b733a35373a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f66696c7465725f6e63735f6c6173745f757064617465642e696e63223b693a37303b733a35333a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f66696c7465725f6e6f64655f636f6d6d656e742e696e63223b693a37313b733a35333a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f736f72745f636f6d6d656e745f7468726561642e696e63223b693a37323b733a36303a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f736f72745f6e63735f6c6173745f636f6d6d656e745f6e616d652e696e63223b693a37333b733a35353a226d6f64756c65732f636f6d6d656e742f76696577735f68616e646c65725f736f72745f6e63735f6c6173745f757064617465642e696e63223b693a37343b733a34383a226d6f64756c65732f636f6d6d656e742f76696577735f706c7567696e5f726f775f636f6d6d656e745f7273732e696e63223b693a37353b733a34393a226d6f64756c65732f636f6d6d656e742f76696577735f706c7567696e5f726f775f636f6d6d656e745f766965772e696e63223b693a37363b733a35323a226d6f64756c65732f636f6e746163742f76696577735f68616e646c65725f6669656c645f636f6e746163745f6c696e6b2e696e63223b693a37373b733a34333a226d6f64756c65732f6669656c642f76696577735f68616e646c65725f6669656c645f6669656c642e696e63223b693a37383b733a34393a226d6f64756c65732f6669656c642f76696577735f68616e646c65725f66696c7465725f6669656c645f6c6973742e696e63223b693a37393b733a35373a226d6f64756c65732f66696c7465722f76696577735f68616e646c65725f6669656c645f66696c7465725f666f726d61745f6e616d652e696e63223b693a38303b733a35343a226d6f64756c65732f6c6f63616c652f76696577735f68616e646c65725f617267756d656e745f6c6f63616c655f67726f75702e696e63223b693a38313b733a35373a226d6f64756c65732f6c6f63616c652f76696577735f68616e646c65725f617267756d656e745f6c6f63616c655f6c616e67756167652e696e63223b693a38323b733a35313a226d6f64756c65732f6c6f63616c652f76696577735f68616e646c65725f6669656c645f6c6f63616c655f67726f75702e696e63223b693a38333b733a35343a226d6f64756c65732f6c6f63616c652f76696577735f68616e646c65725f6669656c645f6c6f63616c655f6c616e67756167652e696e63223b693a38343b733a35353a226d6f64756c65732f6c6f63616c652f76696577735f68616e646c65725f6669656c645f6c6f63616c655f6c696e6b5f656469742e696e63223b693a38353b733a35323a226d6f64756c65732f6c6f63616c652f76696577735f68616e646c65725f66696c7465725f6c6f63616c655f67726f75702e696e63223b693a38363b733a35353a226d6f64756c65732f6c6f63616c652f76696577735f68616e646c65725f66696c7465725f6c6f63616c655f6c616e67756167652e696e63223b693a38373b733a35343a226d6f64756c65732f6c6f63616c652f76696577735f68616e646c65725f66696c7465725f6c6f63616c655f76657273696f6e2e696e63223b693a38383b733a35333a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f617267756d656e745f64617465735f766172696f75732e696e63223b693a38393b733a35333a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f617267756d656e745f6e6f64655f6c616e67756167652e696e63223b693a39303b733a34383a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f617267756d656e745f6e6f64655f6e69642e696e63223b693a39313b733a34393a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f617267756d656e745f6e6f64655f747970652e696e63223b693a39323b733a34383a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f617267756d656e745f6e6f64655f7669642e696e63223b693a39333b733a35393a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f686973746f72795f757365725f74696d657374616d702e696e63223b693a39343b733a34313a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64652e696e63223b693a39353b733a34363a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64655f6c696e6b2e696e63223b693a39363b733a35333a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64655f6c696e6b5f64656c6574652e696e63223b693a39373b733a35313a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64655f6c696e6b5f656469742e696e63223b693a39383b733a35303a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64655f7265766973696f6e2e696e63223b693a39393b733a36323a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64655f7265766973696f6e5f6c696e6b5f64656c6574652e696e63223b693a3130303b733a36323a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64655f7265766973696f6e5f6c696e6b5f7265766572742e696e63223b693a3130313b733a34363a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64655f706174682e696e63223b693a3130323b733a34363a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f6669656c645f6e6f64655f747970652e696e63223b693a3130333b733a36303a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f66696c7465725f686973746f72795f757365725f74696d657374616d702e696e63223b693a3130343b733a34393a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f66696c7465725f6e6f64655f6163636573732e696e63223b693a3130353b733a34393a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f66696c7465725f6e6f64655f7374617475732e696e63223b693a3130363b733a34373a226d6f64756c65732f6e6f64652f76696577735f68616e646c65725f66696c7465725f6e6f64655f747970652e696e63223b693a3130373b733a35313a226d6f64756c65732f6e6f64652f76696577735f706c7567696e5f617267756d656e745f64656661756c745f6e6f64652e696e63223b693a3130383b733a35323a226d6f64756c65732f6e6f64652f76696577735f706c7567696e5f617267756d656e745f76616c69646174655f6e6f64652e696e63223b693a3130393b733a34323a226d6f64756c65732f6e6f64652f76696577735f706c7567696e5f726f775f6e6f64655f7273732e696e63223b693a3131303b733a34333a226d6f64756c65732f6e6f64652f76696577735f706c7567696e5f726f775f6e6f64655f766965772e696e63223b693a3131313b733a35323a226d6f64756c65732f70726f66696c652f76696577735f68616e646c65725f6669656c645f70726f66696c655f646174652e696e63223b693a3131323b733a35323a226d6f64756c65732f70726f66696c652f76696577735f68616e646c65725f6669656c645f70726f66696c655f6c6973742e696e63223b693a3131333b733a35383a226d6f64756c65732f70726f66696c652f76696577735f68616e646c65725f66696c7465725f70726f66696c655f73656c656374696f6e2e696e63223b693a3131343b733a34383a226d6f64756c65732f7365617263682f76696577735f68616e646c65725f617267756d656e745f7365617263682e696e63223b693a3131353b733a35313a226d6f64756c65732f7365617263682f76696577735f68616e646c65725f6669656c645f7365617263685f73636f72652e696e63223b693a3131363b733a34363a226d6f64756c65732f7365617263682f76696577735f68616e646c65725f66696c7465725f7365617263682e696e63223b693a3131373b733a35303a226d6f64756c65732f7365617263682f76696577735f68616e646c65725f736f72745f7365617263685f73636f72652e696e63223b693a3131383b733a34373a226d6f64756c65732f7365617263682f76696577735f706c7567696e5f726f775f7365617263685f766965772e696e63223b693a3131393b733a35373a226d6f64756c65732f737461746973746963732f76696577735f68616e646c65725f6669656c645f6163636573736c6f675f706174682e696e63223b693a3132303b733a35303a226d6f64756c65732f73797374656d2f76696577735f68616e646c65725f617267756d656e745f66696c655f6669642e696e63223b693a3132313b733a34333a226d6f64756c65732f73797374656d2f76696577735f68616e646c65725f6669656c645f66696c652e696e63223b693a3132323b733a35333a226d6f64756c65732f73797374656d2f76696577735f68616e646c65725f6669656c645f66696c655f657874656e73696f6e2e696e63223b693a3132333b733a35323a226d6f64756c65732f73797374656d2f76696577735f68616e646c65725f6669656c645f66696c655f66696c656d696d652e696e63223b693a3132343b733a34373a226d6f64756c65732f73797374656d2f76696577735f68616e646c65725f6669656c645f66696c655f7572692e696e63223b693a3132353b733a35303a226d6f64756c65732f73797374656d2f76696577735f68616e646c65725f6669656c645f66696c655f7374617475732e696e63223b693a3132363b733a35313a226d6f64756c65732f73797374656d2f76696577735f68616e646c65725f66696c7465725f66696c655f7374617475732e696e63223b693a3132373b733a35323a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f617267756d656e745f7461786f6e6f6d792e696e63223b693a3132383b733a35373a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f617267756d656e745f7465726d5f6e6f64655f7469642e696e63223b693a3132393b733a36333a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f617267756d656e745f7465726d5f6e6f64655f7469645f64657074682e696e63223b693a3133303b733a37323a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f617267756d656e745f7465726d5f6e6f64655f7469645f64657074685f6d6f6469666965722e696e63223b693a3133313b733a35383a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f617267756d656e745f766f636162756c6172795f7669642e696e63223b693a3133323b733a34393a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f6669656c645f7461786f6e6f6d792e696e63223b693a3133333b733a35343a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f6669656c645f7465726d5f6e6f64655f7469642e696e63223b693a3133343b733a35353a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f6669656c645f7465726d5f6c696e6b5f656469742e696e63223b693a3133353b733a35353a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f66696c7465725f7465726d5f6e6f64655f7469642e696e63223b693a3133363b733a36313a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f66696c7465725f7465726d5f6e6f64655f7469645f64657074682e696e63223b693a3133373b733a35363a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f66696c7465725f766f636162756c6172795f7669642e696e63223b693a3133383b733a36353a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f66696c7465725f766f636162756c6172795f6d616368696e655f6e616d652e696e63223b693a3133393b733a36323a226d6f64756c65732f7461786f6e6f6d792f76696577735f68616e646c65725f72656c6174696f6e736869705f6e6f64655f7465726d5f646174612e696e63223b693a3134303b733a36353a226d6f64756c65732f7461786f6e6f6d792f76696577735f706c7567696e5f617267756d656e745f76616c69646174655f7461786f6e6f6d795f7465726d2e696e63223b693a3134313b733a36333a226d6f64756c65732f7461786f6e6f6d792f76696577735f706c7567696e5f617267756d656e745f64656661756c745f7461786f6e6f6d795f7469642e696e63223b693a3134323b733a35313a226d6f64756c65732f73797374656d2f76696577735f68616e646c65725f66696c7465725f73797374656d5f747970652e696e63223b693a3134333b733a35363a226d6f64756c65732f7472616e736c6174696f6e2f76696577735f68616e646c65725f617267756d656e745f6e6f64655f746e69642e696e63223b693a3134343b733a35373a226d6f64756c65732f7472616e736c6174696f6e2f76696577735f68616e646c65725f6669656c645f6e6f64655f6c616e67756167652e696e63223b693a3134353b733a36333a226d6f64756c65732f7472616e736c6174696f6e2f76696577735f68616e646c65725f6669656c645f6e6f64655f6c696e6b5f7472616e736c6174652e696e63223b693a3134363b733a36353a226d6f64756c65732f7472616e736c6174696f6e2f76696577735f68616e646c65725f6669656c645f6e6f64655f7472616e736c6174696f6e5f6c696e6b2e696e63223b693a3134373b733a35383a226d6f64756c65732f7472616e736c6174696f6e2f76696577735f68616e646c65725f66696c7465725f6e6f64655f6c616e67756167652e696e63223b693a3134383b733a35343a226d6f64756c65732f7472616e736c6174696f6e2f76696577735f68616e646c65725f66696c7465725f6e6f64655f746e69642e696e63223b693a3134393b733a36303a226d6f64756c65732f7472616e736c6174696f6e2f76696577735f68616e646c65725f66696c7465725f6e6f64655f746e69645f6368696c642e696e63223b693a3135303b733a36323a226d6f64756c65732f7472616e736c6174696f6e2f76696577735f68616e646c65725f72656c6174696f6e736869705f7472616e736c6174696f6e2e696e63223b693a3135313b733a35373a226d6f64756c65732f75706c6f61642f76696577735f68616e646c65725f6669656c645f75706c6f61645f6465736372697074696f6e2e696e63223b693a3135323b733a34393a226d6f64756c65732f75706c6f61642f76696577735f68616e646c65725f6669656c645f75706c6f61645f6669642e696e63223b693a3135333b733a35303a226d6f64756c65732f75706c6f61642f76696577735f68616e646c65725f66696c7465725f75706c6f61645f6669642e696e63223b693a3135343b733a34383a226d6f64756c65732f757365722f76696577735f68616e646c65725f617267756d656e745f757365725f7569642e696e63223b693a3135353b733a35353a226d6f64756c65732f757365722f76696577735f68616e646c65725f617267756d656e745f75736572735f726f6c65735f7269642e696e63223b693a3135363b733a34313a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365722e696e63223b693a3135373b733a35303a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365725f6c616e67756167652e696e63223b693a3135383b733a34363a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365725f6c696e6b2e696e63223b693a3135393b733a35333a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365725f6c696e6b5f63616e63656c2e696e63223b693a3136303b733a35313a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365725f6c696e6b5f656469742e696e63223b693a3136313b733a34363a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365725f6d61696c2e696e63223b693a3136323b733a34363a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365725f6e616d652e696e63223b693a3136333b733a34393a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365725f706963747572652e696e63223b693a3136343b733a34373a226d6f64756c65732f757365722f76696577735f68616e646c65725f6669656c645f757365725f726f6c65732e696e63223b693a3136353b733a35303a226d6f64756c65732f757365722f76696577735f68616e646c65725f66696c7465725f757365725f63757272656e742e696e63223b693a3136363b733a34373a226d6f64756c65732f757365722f76696577735f68616e646c65725f66696c7465725f757365725f6e616d652e696e63223b693a3136373b733a34383a226d6f64756c65732f757365722f76696577735f68616e646c65725f66696c7465725f757365725f726f6c65732e696e63223b693a3136383b733a35393a226d6f64756c65732f757365722f76696577735f706c7567696e5f617267756d656e745f64656661756c745f63757272656e745f757365722e696e63223b693a3136393b733a35313a226d6f64756c65732f757365722f76696577735f706c7567696e5f617267756d656e745f64656661756c745f757365722e696e63223b693a3137303b733a35323a226d6f64756c65732f757365722f76696577735f706c7567696e5f617267756d656e745f76616c69646174655f757365722e696e63223b693a3137313b733a33313a22706c7567696e732f76696577735f706c7567696e5f6163636573732e696e63223b693a3137323b733a33363a22706c7567696e732f76696577735f706c7567696e5f6163636573735f6e6f6e652e696e63223b693a3137333b733a33363a22706c7567696e732f76696577735f706c7567696e5f6163636573735f7065726d2e696e63223b693a3137343b733a33363a22706c7567696e732f76696577735f706c7567696e5f6163636573735f726f6c652e696e63223b693a3137353b733a34313a22706c7567696e732f76696577735f706c7567696e5f617267756d656e745f64656661756c742e696e63223b693a3137363b733a34353a22706c7567696e732f76696577735f706c7567696e5f617267756d656e745f64656661756c745f7068702e696e63223b693a3137373b733a34373a22706c7567696e732f76696577735f706c7567696e5f617267756d656e745f64656661756c745f66697865642e696e63223b693a3137383b733a34323a22706c7567696e732f76696577735f706c7567696e5f617267756d656e745f76616c69646174652e696e63223b693a3137393b733a35303a22706c7567696e732f76696577735f706c7567696e5f617267756d656e745f76616c69646174655f6e756d657269632e696e63223b693a3138303b733a34363a22706c7567696e732f76696577735f706c7567696e5f617267756d656e745f76616c69646174655f7068702e696e63223b693a3138313b733a33303a22706c7567696e732f76696577735f706c7567696e5f63616368652e696e63223b693a3138323b733a33353a22706c7567696e732f76696577735f706c7567696e5f63616368655f6e6f6e652e696e63223b693a3138333b733a33353a22706c7567696e732f76696577735f706c7567696e5f63616368655f74696d652e696e63223b693a3138343b733a33323a22706c7567696e732f76696577735f706c7567696e5f646973706c61792e696e63223b693a3138353b733a34333a22706c7567696e732f76696577735f706c7567696e5f646973706c61795f6174746163686d656e742e696e63223b693a3138363b733a33383a22706c7567696e732f76696577735f706c7567696e5f646973706c61795f626c6f636b2e696e63223b693a3138373b733a34303a22706c7567696e732f76696577735f706c7567696e5f646973706c61795f64656661756c742e696e63223b693a3138383b733a33373a22706c7567696e732f76696577735f706c7567696e5f646973706c61795f666565642e696e63223b693a3138393b733a34333a22706c7567696e732f76696577735f706c7567696e5f6578706f7365645f666f726d5f62617369632e696e63223b693a3139303b733a33373a22706c7567696e732f76696577735f706c7567696e5f6578706f7365645f666f726d2e696e63223b693a3139313b733a35323a22706c7567696e732f76696577735f706c7567696e5f6578706f7365645f666f726d5f696e7075745f72657175697265642e696e63223b693a3139323b733a33373a22706c7567696e732f76696577735f706c7567696e5f646973706c61795f706167652e696e63223b693a3139333b733a34323a22706c7567696e732f76696577735f706c7567696e5f6c6f63616c697a6174696f6e5f636f72652e696e63223b693a3139343b733a33373a22706c7567696e732f76696577735f706c7567696e5f6c6f63616c697a6174696f6e2e696e63223b693a3139353b733a34323a22706c7567696e732f76696577735f706c7567696e5f6c6f63616c697a6174696f6e5f6e6f6e652e696e63223b693a3139363b733a33303a22706c7567696e732f76696577735f706c7567696e5f70616765722e696e63223b693a3139373b733a33353a22706c7567696e732f76696577735f706c7567696e5f70616765725f66756c6c2e696e63223b693a3139383b733a33353a22706c7567696e732f76696577735f706c7567696e5f70616765725f6d696e692e696e63223b693a3139393b733a33353a22706c7567696e732f76696577735f706c7567696e5f70616765725f6e6f6e652e696e63223b693a3230303b733a33353a22706c7567696e732f76696577735f706c7567696e5f70616765725f736f6d652e696e63223b693a3230313b733a33303a22706c7567696e732f76696577735f706c7567696e5f71756572792e696e63223b693a3230323b733a33383a22706c7567696e732f76696577735f706c7567696e5f71756572795f64656661756c742e696e63223b693a3230333b733a32383a22706c7567696e732f76696577735f706c7567696e5f726f772e696e63223b693a3230343b733a33353a22706c7567696e732f76696577735f706c7567696e5f726f775f6669656c64732e696e63223b693a3230353b733a33303a22706c7567696e732f76696577735f706c7567696e5f7374796c652e696e63223b693a3230363b733a33383a22706c7567696e732f76696577735f706c7567696e5f7374796c655f64656661756c742e696e63223b693a3230373b733a33353a22706c7567696e732f76696577735f706c7567696e5f7374796c655f677269642e696e63223b693a3230383b733a33353a22706c7567696e732f76696577735f706c7567696e5f7374796c655f6c6973742e696e63223b693a3230393b733a34303a22706c7567696e732f76696577735f706c7567696e5f7374796c655f6a756d705f6d656e752e696e63223b693a3231303b733a33343a22706c7567696e732f76696577735f706c7567696e5f7374796c655f7273732e696e63223b693a3231313b733a33383a22706c7567696e732f76696577735f706c7567696e5f7374796c655f73756d6d6172792e696e63223b693a3231323b733a34383a22706c7567696e732f76696577735f706c7567696e5f7374796c655f73756d6d6172795f6a756d705f6d656e752e696e63223b693a3231333b733a35303a22706c7567696e732f76696577735f706c7567696e5f7374796c655f73756d6d6172795f756e666f726d61747465642e696e63223b693a3231343b733a33363a22706c7567696e732f76696577735f706c7567696e5f7374796c655f7461626c652e696e63223b693a3231353b733a34333a2274657374732f68616e646c6572732f76696577735f68616e646c65725f617265615f746578742e74657374223b693a3231363b733a34373a2274657374732f68616e646c6572732f76696577735f68616e646c65725f617267756d656e745f6e756c6c2e74657374223b693a3231373b733a34373a2274657374732f68616e646c6572732f76696577735f68616e646c65725f6669656c645f626f6f6c65616e2e74657374223b693a3231383b733a34363a2274657374732f68616e646c6572732f76696577735f68616e646c65725f6669656c645f637573746f6d2e74657374223b693a3231393b733a34373a2274657374732f68616e646c6572732f76696577735f68616e646c65725f6669656c645f636f756e7465722e74657374223b693a3232303b733a34343a2274657374732f68616e646c6572732f76696577735f68616e646c65725f6669656c645f646174652e74657374223b693a3232313b733a34393a2274657374732f68616e646c6572732f76696577735f68616e646c65725f6669656c645f66696c655f73697a652e74657374223b693a3232323b733a34343a2274657374732f68616e646c6572732f76696577735f68616e646c65725f6669656c645f6d6174682e74657374223b693a3232333b733a34333a2274657374732f68616e646c6572732f76696577735f68616e646c65725f6669656c645f75726c2e74657374223b693a3232343b733a34333a2274657374732f68616e646c6572732f76696577735f68616e646c65725f6669656c645f7873732e74657374223b693a3232353b733a34353a2274657374732f68616e646c6572732f76696577735f68616e646c65725f66696c7465725f646174652e74657374223b693a3232363b733a34393a2274657374732f68616e646c6572732f76696577735f68616e646c65725f66696c7465725f657175616c6974792e74657374223b693a3232373b733a35323a2274657374732f68616e646c6572732f76696577735f68616e646c65725f66696c7465725f696e5f6f70657261746f722e74657374223b693a3232383b733a34383a2274657374732f68616e646c6572732f76696577735f68616e646c65725f66696c7465725f6e756d657269632e74657374223b693a3232393b733a34373a2274657374732f68616e646c6572732f76696577735f68616e646c65725f66696c7465725f737472696e672e74657374223b693a3233303b733a34353a2274657374732f68616e646c6572732f76696577735f68616e646c65725f736f72745f72616e646f6d2e74657374223b693a3233313b733a34333a2274657374732f68616e646c6572732f76696577735f68616e646c65725f736f72745f646174652e74657374223b693a3233323b733a33383a2274657374732f68616e646c6572732f76696577735f68616e646c65725f736f72742e74657374223b693a3233333b733a36303a2274657374732f746573745f706c7567696e732f76696577735f746573745f706c7567696e5f6163636573735f746573745f64796e616d69632e696e63223b693a3233343b733a35393a2274657374732f746573745f706c7567696e732f76696577735f746573745f706c7567696e5f6163636573735f746573745f7374617469632e696e63223b693a3233353b733a32333a2274657374732f76696577735f6163636573732e74657374223b693a3233363b733a32343a2274657374732f76696577735f616e616c797a652e74657374223b693a3233373b733a32323a2274657374732f76696577735f62617369632e74657374223b693a3233383b733a33333a2274657374732f76696577735f617267756d656e745f64656661756c742e74657374223b693a3233393b733a33353a2274657374732f76696577735f617267756d656e745f76616c696461746f722e74657374223b693a3234303b733a32393a2274657374732f76696577735f6578706f7365645f666f726d2e74657374223b693a3234313b733a32353a2274657374732f76696577735f676c6f73736172792e74657374223b693a3234323b733a32343a2274657374732f76696577735f67726f757062792e74657374223b693a3234333b733a32353a2274657374732f76696577735f68616e646c6572732e74657374223b693a3234343b733a32333a2274657374732f76696577735f6d6f64756c652e74657374223b693a3234353b733a32323a2274657374732f76696577735f70616765722e74657374223b693a3234363b733a34303a2274657374732f76696577735f706c7567696e5f6c6f63616c697a6174696f6e5f746573742e696e63223b693a3234373b733a32393a2274657374732f76696577735f7472616e736c617461626c652e74657374223b693a3234383b733a32323a2274657374732f76696577735f71756572792e74657374223b693a3234393b733a32343a2274657374732f76696577735f757067726164652e74657374223b693a3235303b733a33343a2274657374732f76696577735f746573742e76696577735f64656661756c742e696e63223b693a3235313b733a34333a2274657374732f757365722f76696577735f757365725f617267756d656e745f64656661756c742e74657374223b693a3235323b733a34343a2274657374732f757365722f76696577735f757365725f617267756d656e745f76616c69646174652e74657374223b693a3235333b733a32323a2274657374732f76696577735f63616368652e74657374223b693a3235343b733a32313a2274657374732f76696577735f766965772e74657374223b693a3235353b733a31393a2274657374732f76696577735f75692e74657374223b7d733a373a2276657273696f6e223b733a31333a22372e782d332e302d6265746133223b733a373a2270726f6a656374223b733a353a227669657773223b733a393a22646174657374616d70223b733a31303a2231333031333031393730223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/views/views_ui.module', 'views_ui', 'module', '', 0, 0, 0, 0, 0x613a31323a7b733a343a226e616d65223b733a383a225669657773205549223b733a31313a226465736372697074696f6e223b733a39333a2241646d696e69737472617469766520696e7465726661636520746f2076696577732e20576974686f75742074686973206d6f64756c652c20796f752063616e6e6f7420637265617465206f72206564697420796f75722076696577732e223b733a373a227061636b616765223b733a353a225669657773223b733a343a22636f7265223b733a333a22372e78223b733a393a22636f6e666967757265223b733a32313a2261646d696e2f7374727563747572652f7669657773223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a227669657773223b7d733a353a2266696c6573223b613a323a7b693a303b733a31353a2276696577735f75692e6d6f64756c65223b693a313b733a35373a22706c7567696e732f76696577735f77697a6172642f76696577735f75695f626173655f76696577735f77697a6172642e636c6173732e706870223b7d733a373a2276657273696f6e223b733a31333a22372e782d332e302d6265746133223b733a373a2270726f6a656374223b733a353a227669657773223b733a393a22646174657374616d70223b733a31303a2231333031333031393730223b733a333a22706870223b733a353a22352e322e34223b733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/contrib/workbench/workbench.module', 'workbench', 'module', '', 0, 0, -1, 0, 0x613a31323a7b733a343a226e616d65223b733a393a22576f726b62656e6368223b733a31313a226465736372697074696f6e223b733a32363a22576f726b62656e636820656469746f7269616c2073756974652e223b733a373a227061636b616765223b733a393a22576f726b62656e6368223b733a343a22636f7265223b733a333a22372e78223b733a393a22636f6e666967757265223b733a33313a2261646d696e2f636f6e6669672f776f726b62656e63682f73657474696e6773223b733a31323a22646570656e64656e63696573223b613a313a7b693a303b733a353a227669657773223b7d733a373a2276657273696f6e223b733a373a22372e782d312e30223b733a373a2270726f6a656374223b733a393a22776f726b62656e6368223b733a393a22646174657374616d70223b733a31303a2231333134333835363234223b733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/custom/dfotw/dfotw.module', 'dfotw', 'module', '', 1, 0, 0, 0, 0x613a31313a7b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a31303a7b693a303b733a373a22636f6d6d656e74223b693a313b733a373a22636f6e74657874223b693a323b733a31323a2264666f74775f747765616b73223b693a333b733a383a226665617475726573223b693a343b733a31313a226669656c645f67726f7570223b693a353b733a343a226c696e6b223b693a363b733a343a226d656e75223b693a373b733a31343a226d657461746167735f717569636b223b693a383b733a363a22736561726368223b693a393b733a383a227461786f6e6f6d79223b7d733a31313a226465736372697074696f6e223b733a32373a2244727570616c2046756e6374696f6e206f6620746865205765656b223b733a383a226665617475726573223b613a383a7b733a373a22636f6e74657874223b613a333a7b693a303b733a373a22636f6e74616374223b693a313b733a353a2264666f7477223b693a323b733a383a2266756e6374696f6e223b7d733a363a2263746f6f6c73223b613a323a7b693a303b733a31373a22636f6e746578743a636f6e746578743a33223b693a313b733a32353a226669656c645f67726f75703a6669656c645f67726f75703a31223b7d733a353a226669656c64223b613a31393a7b693a303b733a34313a22636f6d6d656e742d636f6d6d656e745f6e6f64655f61727469636c652d636f6d6d656e745f626f6479223b693a313b733a34323a22636f6d6d656e742d636f6d6d656e745f6e6f64655f66756e6374696f6e2d636f6d6d656e745f626f6479223b693a323b733a33383a22636f6d6d656e742d636f6d6d656e745f6e6f64655f706167652d636f6d6d656e745f626f6479223b693a333b733a31373a226e6f64652d61727469636c652d626f6479223b693a343b733a32393a226e6f64652d61727469636c652d6d6574615f6465736372697074696f6e223b693a353b733a32363a226e6f64652d61727469636c652d6d6574615f6b6579776f726473223b693a363b733a31383a226e6f64652d66756e6374696f6e2d626f6479223b693a373b733a33353a226e6f64652d66756e6374696f6e2d6669656c645f66756e6374696f6e5f617574686f72223b693a383b733a33333a226e6f64652d66756e6374696f6e2d6669656c645f66756e6374696f6e5f64657363223b693a393b733a33333a226e6f64652d66756e6374696f6e2d6669656c645f66756e6374696f6e5f646f6373223b693a31303b733a33363a226e6f64652d66756e6374696f6e2d6669656c645f66756e6374696f6e5f6578616d706c65223b693a31313b733a33343a226e6f64652d66756e6374696f6e2d6669656c645f66756e6374696f6e5f696e74726f223b693a31323b733a33333a226e6f64652d66756e6374696f6e2d6669656c645f66756e6374696f6e5f74616773223b693a31333b733a33363a226e6f64652d66756e6374696f6e2d6669656c645f66756e6374696f6e5f76657273696f6e223b693a31343b733a33303a226e6f64652d66756e6374696f6e2d6d6574615f6465736372697074696f6e223b693a31353b733a32373a226e6f64652d66756e6374696f6e2d6d6574615f6b6579776f726473223b693a31363b733a31343a226e6f64652d706167652d626f6479223b693a31373b733a32363a226e6f64652d706167652d6d6574615f6465736372697074696f6e223b693a31383b733a32333a226e6f64652d706167652d6d6574615f6b6579776f726473223b7d733a31313a226669656c645f67726f7570223b613a343a7b693a303b733a33383a2267726f75705f66756e6374696f6e5f696e666f7c6e6f64657c66756e6374696f6e7c666f726d223b693a313b733a34303a2267726f75705f66756e6374696f6e5f6c61796f75747c6e6f64657c66756e6374696f6e7c666f726d223b693a323b733a33383a2267726f75705f66756e6374696f6e5f6d6574617c6e6f64657c66756e6374696f6e7c666f726d223b693a333b733a33393a2267726f75705f66756e6374696f6e5f75736167657c6e6f64657c66756e6374696f6e7c666f726d223b7d733a31313a226d656e755f637573746f6d223b613a313a7b693a303b733a393a226d61696e2d6d656e75223b7d733a31303a226d656e755f6c696e6b73223b613a333a7b693a303b733a31373a226d61696e2d6d656e753a3c66726f6e743e223b693a313b733a31373a226d61696e2d6d656e753a636f6e74616374223b693a323b733a31363a226d61696e2d6d656e753a6e6f64652f31223b7d733a343a226e6f6465223b613a333a7b693a303b733a373a2261727469636c65223b693a313b733a383a2266756e6374696f6e223b693a323b733a343a2270616765223b7d733a383a227461786f6e6f6d79223b613a323a7b693a303b733a343a2274616773223b693a313b733a373a2276657273696f6e223b7d7d733a343a226e616d65223b733a353a2244464f5457223b733a373a227061636b616765223b733a353a2244464f5457223b733a333a22706870223b733a353a22352e322e34223b733a373a2270726f6a656374223b733a353a2264666f7477223b733a373a2276657273696f6e223b733a373a22372e782d312e35223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/modules/custom/dfotw_tweaks/dfotw_tweaks.module', 'dfotw_tweaks', 'module', '', 1, 0, 0, 0, 0x613a393a7b733a343a226e616d65223b733a31323a2244464f545720547765616b73223b733a31313a226465736372697074696f6e223b733a33393a2250726f766964657320637573746f6d2066756e6374696f6e616c69747920666f722044464f5457223b733a373a227061636b616765223b733a353a2244464f5457223b733a373a2276657273696f6e223b733a333a22312e30223b733a343a22636f7265223b733a333a22372e78223b733a31323a22646570656e64656e63696573223b613a303a7b7d733a333a22706870223b733a353a22352e322e34223b733a353a2266696c6573223b613a303a7b7d733a393a22626f6f747374726170223b693a303b7d),
('sites/all/themes/corolla/corolla.info', 'corolla', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, -1, 0, 0x613a31353a7b733a343a226e616d65223b733a373a22436f726f6c6c61223b733a31313a226465736372697074696f6e223b733a39323a224120636f6c6f7261626c652c20666c756964207769647468207468656d652c2077697468206d696e20616e64206d6178207769647468732c20746861742063616e20737570706f727420312c2032206f72203320636f6c756d6e732e223b733a373a2276657273696f6e223b733a383a22372e782d312e3231223b733a343a22636f7265223b733a333a22372e78223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a363a7b693a303b733a343a226c6f676f223b693a313b733a343a226e616d65223b693a323b733a363a22736c6f67616e223b693a333b733a31373a226e6f64655f757365725f70696374757265223b693a343b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a353b733a373a2266617669636f6e223b7d733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a383a22626173652e637373223b733a33333a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f626173652e637373223b733a393a227374796c652e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7374796c652e637373223b733a31303a22636f6c6f72732e637373223b733a33353a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a33343a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f7072696e742e637373223b7d7d733a373a22726567696f6e73223b613a31313a7b733a31313a226865616465725f6d656e75223b733a31313a22486561646572206d656e75223b733a31313a22666f6f7465725f6d656e75223b733a31313a22466f6f746572206d656e75223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31343a225365636f6e642073696465626172223b733a393a22686967686c69676874223b733a31313a22486967686c696768746564223b733a31313a22636f6e74656e745f746f70223b733a31313a22436f6e74656e7420746f70223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31343a22636f6e74656e745f626f74746f6d223b733a31343a22436f6e74656e7420626f74746f6d223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a2273657474696e6773223b613a31313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a31383a22c2a9203230313020596f7572204e616d652e223b7d733a373a2270726f6a656374223b733a373a22636f726f6c6c61223b733a393a22646174657374616d70223b733a31303a2231323934373737323831223b733a31303a2273637265656e73686f74223b733a33393a2273697465732f616c6c2f7468656d65732f636f726f6c6c612f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d),
('sites/all/themes/dfotw_corolla/dfotw_corolla.info', 'dfotw_corolla', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 1, 0, -1, 0, 0x613a31343a7b733a343a226e616d65223b733a31333a2244464f545720436f726f6c6c61223b733a31313a226465736372697074696f6e223b733a34393a22436f726f6c6c61207375622d7468656d6520666f722044727570616c2046756e6374696f6e206f6620746865205765656b223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a31303a2262617365207468656d65223b733a373a22636f726f6c6c61223b733a383a226665617475726573223b613a363a7b693a303b733a343a226c6f676f223b693a313b733a343a226e616d65223b693a323b733a363a22736c6f67616e223b693a333b733a31373a226e6f64655f757365725f70696374757265223b693a343b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a353b733a373a2266617669636f6e223b7d733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31373a2264666f74775f636f726f6c6c612e637373223b733a34383a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f64666f74775f636f726f6c6c612e637373223b7d7d733a373a22726567696f6e73223b613a31313a7b733a31313a226865616465725f6d656e75223b733a31313a22486561646572206d656e75223b733a31313a22666f6f7465725f6d656e75223b733a31313a22466f6f746572206d656e75223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31343a225365636f6e642073696465626172223b733a393a22686967686c69676874223b733a31313a22486967686c696768746564223b733a31313a22636f6e74656e745f746f70223b733a31313a22436f6e74656e7420746f70223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31343a22636f6e74656e745f626f74746f6d223b733a31343a22436f6e74656e7420626f74746f6d223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a2273657474696e6773223b613a31313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a38303a22c2a92032303131203c6120687265663d22687474703a2f2f77656264726f702e6e65742e627222207469746c653d2257656264726f70222072656c3d22666f6c6c6f77223e57656264726f703c2f613e223b7d733a31303a2273637265656e73686f74223b733a34353a2273697465732f616c6c2f7468656d65732f64666f74775f636f726f6c6c612f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d),
('themes/bartik/bartik.info', 'bartik', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, -1, 0, 0x613a31363a7b733a343a226e616d65223b733a363a2242617274696b223b733a31313a226465736372697074696f6e223b733a34383a224120666c657869626c652c207265636f6c6f7261626c65207468656d652077697468206d616e7920726567696f6e732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a333a7b733a31343a226373732f6c61796f75742e637373223b733a32383a227468656d65732f62617274696b2f6373732f6c61796f75742e637373223b733a31333a226373732f7374796c652e637373223b733a32373a227468656d65732f62617274696b2f6373732f7374796c652e637373223b733a31343a226373732f636f6c6f72732e637373223b733a32383a227468656d65732f62617274696b2f6373732f636f6c6f72732e637373223b7d733a353a227072696e74223b613a313a7b733a31333a226373732f7072696e742e637373223b733a32373a227468656d65732f62617274696b2f6373732f7072696e742e637373223b7d7d733a373a22726567696f6e73223b613a31373a7b733a363a22686561646572223b733a363a22486561646572223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a383a226665617475726564223b733a383a224665617475726564223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a31333a22736964656261725f6669727374223b733a31333a2253696465626172206669727374223b733a31343a22736964656261725f7365636f6e64223b733a31343a2253696465626172207365636f6e64223b733a31343a2274726970747963685f6669727374223b733a31343a225472697074796368206669727374223b733a31353a2274726970747963685f6d6964646c65223b733a31353a225472697074796368206d6964646c65223b733a31333a2274726970747963685f6c617374223b733a31333a225472697074796368206c617374223b733a31383a22666f6f7465725f6669727374636f6c756d6e223b733a31393a22466f6f74657220666972737420636f6c756d6e223b733a31393a22666f6f7465725f7365636f6e64636f6c756d6e223b733a32303a22466f6f746572207365636f6e6420636f6c756d6e223b733a31383a22666f6f7465725f7468697264636f6c756d6e223b733a31393a22466f6f74657220746869726420636f6c756d6e223b733a31393a22666f6f7465725f666f75727468636f6c756d6e223b733a32303a22466f6f74657220666f7572746820636f6c756d6e223b733a363a22666f6f746572223b733a363a22466f6f746572223b7d733a383a2273657474696e6773223b613a313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2230223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32383a227468656d65732f62617274696b2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d);
INSERT INTO `system` (`filename`, `name`, `type`, `owner`, `status`, `bootstrap`, `schema_version`, `weight`, `info`) VALUES
('themes/garland/garland.info', 'garland', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, -1, 0, 0x613a31363a7b733a343a226e616d65223b733a373a224761726c616e64223b733a31313a226465736372697074696f6e223b733a3131313a2241206d756c74692d636f6c756d6e207468656d652077686963682063616e20626520636f6e6669677572656420746f206d6f6469667920636f6c6f727320616e6420737769746368206265747765656e20666978656420616e6420666c756964207769647468206c61796f7574732e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a323a7b733a333a22616c6c223b613a313a7b733a393a227374796c652e637373223b733a32343a227468656d65732f6761726c616e642f7374796c652e637373223b7d733a353a227072696e74223b613a313a7b733a393a227072696e742e637373223b733a32343a227468656d65732f6761726c616e642f7072696e742e637373223b7d7d733a383a2273657474696e6773223b613a313a7b733a31333a226761726c616e645f7769647468223b733a353a22666c756964223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32393a227468656d65732f6761726c616e642f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d),
('themes/seven/seven.info', 'seven', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, -1, 0, 0x613a31363a7b733a343a226e616d65223b733a353a22536576656e223b733a31313a226465736372697074696f6e223b733a36353a22412073696d706c65206f6e652d636f6c756d6e2c207461626c656c6573732c20666c7569642077696474682061646d696e697374726174696f6e207468656d652e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a313a7b733a363a2273637265656e223b613a323a7b733a393a2272657365742e637373223b733a32323a227468656d65732f736576656e2f72657365742e637373223b733a393a227374796c652e637373223b733a32323a227468656d65732f736576656e2f7374796c652e637373223b7d7d733a383a2273657474696e6773223b613a313a7b733a32303a2273686f72746375745f6d6f64756c655f6c696e6b223b733a313a2231223b7d733a373a22726567696f6e73223b613a353a7b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b733a31333a22736964656261725f6669727374223b733a31333a2246697273742073696465626172223b7d733a31343a22726567696f6e735f68696464656e223b613a333a7b693a303b733a31333a22736964656261725f6669727374223b693a313b733a383a22706167655f746f70223b693a323b733a31313a22706167655f626f74746f6d223b7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32373a227468656d65732f736576656e2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d7d),
('themes/stark/stark.info', 'stark', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, -1, 0, 0x613a31353a7b733a343a226e616d65223b733a353a22537461726b223b733a31313a226465736372697074696f6e223b733a3230383a2254686973207468656d652064656d6f6e737472617465732044727570616c27732064656661756c742048544d4c206d61726b757020616e6420435353207374796c65732e20546f206c6561726e20686f7720746f206275696c6420796f7572206f776e207468656d6520616e64206f766572726964652044727570616c27732064656661756c7420636f64652c2073656520746865203c6120687265663d22687474703a2f2f64727570616c2e6f72672f7468656d652d6775696465223e5468656d696e672047756964653c2f613e2e223b733a373a227061636b616765223b733a343a22436f7265223b733a373a2276657273696f6e223b733a333a22372e38223b733a343a22636f7265223b733a333a22372e78223b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31303a226c61796f75742e637373223b733a32333a227468656d65732f737461726b2f6c61796f75742e637373223b7d7d733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a32373a227468656d65732f737461726b2f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d),
('themes/tests/test_theme/test_theme.info', 'test_theme', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, -1, 0, 0x613a31353a7b733a343a226e616d65223b733a31303a2254657374207468656d65223b733a31313a226465736372697074696f6e223b733a33343a225468656d6520666f722074657374696e6720746865207468656d652073797374656d223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a31313a227374796c65736865657473223b613a313a7b733a333a22616c6c223b613a313a7b733a31353a2273797374656d2e626173652e637373223b733a33393a227468656d65732f74657374732f746573745f7468656d652f73797374656d2e626173652e637373223b7d7d733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a33383a227468656d65732f74657374732f746573745f7468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d),
('themes/tests/update_test_basetheme/update_test_basetheme.info', 'update_test_basetheme', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, -1, 0, 0x613a31353a7b733a343a226e616d65223b733a32323a2255706461746520746573742062617365207468656d65223b733a31313a226465736372697074696f6e223b733a36333a2254657374207468656d65207768696368206163747320617320612062617365207468656d6520666f72206f746865722074657374207375627468656d65732e223b733a343a22636f7265223b733a333a22372e78223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a34393a227468656d65732f74657374732f7570646174655f746573745f626173657468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a31313a227374796c65736865657473223b613a303a7b7d733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d),
('themes/tests/update_test_subtheme/update_test_subtheme.info', 'update_test_subtheme', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, -1, 0, 0x613a31363a7b733a343a226e616d65223b733a32303a225570646174652074657374207375627468656d65223b733a31313a226465736372697074696f6e223b733a36323a2254657374207468656d652077686963682075736573207570646174655f746573745f626173657468656d65206173207468652062617365207468656d652e223b733a343a22636f7265223b733a333a22372e78223b733a31303a2262617365207468656d65223b733a32313a227570646174655f746573745f626173657468656d65223b733a363a2268696464656e223b623a313b733a373a2276657273696f6e223b733a333a22372e38223b733a373a2270726f6a656374223b733a363a2264727570616c223b733a393a22646174657374616d70223b733a31303a2231333134383137363136223b733a363a22656e67696e65223b733a31313a2270687074656d706c617465223b733a373a22726567696f6e73223b613a393a7b733a31333a22736964656261725f6669727374223b733a31323a224c6566742073696465626172223b733a31343a22736964656261725f7365636f6e64223b733a31333a2252696768742073696465626172223b733a373a22636f6e74656e74223b733a373a22436f6e74656e74223b733a363a22686561646572223b733a363a22486561646572223b733a363a22666f6f746572223b733a363a22466f6f746572223b733a31313a22686967686c696768746564223b733a31313a22486967686c696768746564223b733a343a2268656c70223b733a343a2248656c70223b733a383a22706167655f746f70223b733a383a225061676520746f70223b733a31313a22706167655f626f74746f6d223b733a31313a225061676520626f74746f6d223b7d733a383a226665617475726573223b613a393a7b693a303b733a343a226c6f676f223b693a313b733a373a2266617669636f6e223b693a323b733a343a226e616d65223b693a333b733a363a22736c6f67616e223b693a343b733a31373a226e6f64655f757365725f70696374757265223b693a353b733a32303a22636f6d6d656e745f757365725f70696374757265223b693a363b733a32353a22636f6d6d656e745f757365725f766572696669636174696f6e223b693a373b733a393a226d61696e5f6d656e75223b693a383b733a31343a227365636f6e646172795f6d656e75223b7d733a31303a2273637265656e73686f74223b733a34383a227468656d65732f74657374732f7570646174655f746573745f7375627468656d652f73637265656e73686f742e706e67223b733a333a22706870223b733a353a22352e322e34223b733a31313a227374796c65736865657473223b613a303a7b7d733a373a2273637269707473223b613a303a7b7d733a31343a22726567696f6e735f68696464656e223b613a323a7b693a303b733a383a22706167655f746f70223b693a313b733a31313a22706167655f626f74746f6d223b7d7d);

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_index`
--

CREATE TABLE IF NOT EXISTS `taxonomy_index` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The node.nid this record tracks.',
  `tid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The term ID.',
  `sticky` tinyint(4) DEFAULT '0' COMMENT 'Boolean indicating whether the node is sticky.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'The Unix timestamp when the node was created.',
  KEY `term_node` (`tid`,`sticky`,`created`),
  KEY `nid` (`nid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `taxonomy_index`
--

INSERT INTO `taxonomy_index` (`nid`, `tid`, `sticky`, `created`) VALUES
(6, 9, 0, 1307549918),
(6, 10, 0, 1307549918),
(6, 11, 0, 1307549918),
(6, 1, 0, 1307549918),
(6, 2, 0, 1307549918),
(6, 4, 0, 1307549918),
(3, 3, 0, 1306426042),
(3, 1, 0, 1306426042),
(3, 2, 0, 1306426042),
(3, 4, 0, 1306426042),
(4, 5, 0, 1306765977),
(4, 6, 0, 1306765977),
(4, 1, 0, 1306765977),
(4, 2, 0, 1306765977),
(4, 4, 0, 1306765977);

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_term_data`
--

CREATE TABLE IF NOT EXISTS `taxonomy_term_data` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique term ID.',
  `vid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The taxonomy_vocabulary.vid of the vocabulary to which the term is assigned.',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'The term name.',
  `description` longtext COMMENT 'A description of the term.',
  `format` varchar(255) DEFAULT NULL COMMENT 'The filter_format.format of the description.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'The weight of this term in relation to other terms.',
  PRIMARY KEY (`tid`),
  KEY `taxonomy_tree` (`vid`,`weight`,`name`),
  KEY `vid_name` (`vid`,`name`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `taxonomy_term_data`
--

INSERT INTO `taxonomy_term_data` (`tid`, `vid`, `name`, `description`, `format`, `weight`) VALUES
(1, 2, 'Drupal 6', '<h3>Functions of the Week</h3>', 'full_html', 0),
(2, 2, 'Drupal 7', '<h3>Functions of the Week</h3>', 'full_html', 1),
(3, 1, 'validation', NULL, NULL, 0),
(4, 2, 'Drupal 8', '<h3>Functions of the Week</h3>', 'full_html', 2),
(5, 1, 'database', NULL, NULL, 0),
(6, 1, 'schema', NULL, NULL, 0),
(7, 1, 'taxonomy', NULL, NULL, 0),
(8, 1, 'node', NULL, NULL, 0),
(9, 1, 'filefield', NULL, NULL, 0),
(10, 1, 'contrib', NULL, NULL, 0),
(11, 1, 'upload', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_term_hierarchy`
--

CREATE TABLE IF NOT EXISTS `taxonomy_term_hierarchy` (
  `tid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary Key: The taxonomy_term_data.tid of the term.',
  `parent` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary Key: The taxonomy_term_data.tid of the term’s parent. 0 indicates no parent.',
  PRIMARY KEY (`tid`,`parent`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `taxonomy_term_hierarchy`
--

INSERT INTO `taxonomy_term_hierarchy` (`tid`, `parent`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(5, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(11, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_vocabulary`
--

CREATE TABLE IF NOT EXISTS `taxonomy_vocabulary` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique vocabulary ID.',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT 'Name of the vocabulary.',
  `machine_name` varchar(255) NOT NULL DEFAULT '' COMMENT 'The vocabulary machine name.',
  `description` longtext COMMENT 'Description of the vocabulary.',
  `hierarchy` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'The type of hierarchy allowed within the vocabulary. (0 = disabled, 1 = single, 2 = multiple)',
  `module` varchar(255) NOT NULL DEFAULT '' COMMENT 'The module which created the vocabulary.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'The weight of this vocabulary in relation to other vocabularies.',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `machine_name` (`machine_name`),
  KEY `list` (`weight`,`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `taxonomy_vocabulary`
--

INSERT INTO `taxonomy_vocabulary` (`vid`, `name`, `machine_name`, `description`, `hierarchy`, `module`, `weight`) VALUES
(1, 'Tags', 'tags', 'Use tags to group articles on similar topics into categories.', 0, 'taxonomy', 0),
(2, 'Version', 'version', 'Drupal Version', 0, 'taxonomy', 0);

-- --------------------------------------------------------

--
-- Table structure for table `trigger_assignments`
--

CREATE TABLE IF NOT EXISTS `trigger_assignments` (
  `hook` varchar(32) NOT NULL DEFAULT '' COMMENT 'Primary Key: The name of the internal Drupal hook; for example, node_insert.',
  `aid` varchar(255) NOT NULL DEFAULT '' COMMENT 'Primary Key: Action’s actions.aid.',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT 'The weight of the trigger assignment in relation to other triggers.',
  PRIMARY KEY (`hook`,`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trigger_assignments`
--

INSERT INTO `trigger_assignments` (`hook`, `aid`, `weight`) VALUES
('comment_presave', '4', 1);

-- --------------------------------------------------------

--
-- Table structure for table `url_alias`
--

CREATE TABLE IF NOT EXISTS `url_alias` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'A unique path alias identifier.',
  `source` varchar(255) NOT NULL DEFAULT '' COMMENT 'The Drupal path this alias is for; e.g. node/12.',
  `alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'The alias for this path; e.g. title-of-the-story.',
  `language` varchar(12) NOT NULL DEFAULT '' COMMENT 'The language this alias is for; if ’und’, the alias will be used for unknown languages. Each Drupal path can have an alias for each supported language.',
  PRIMARY KEY (`pid`),
  KEY `alias_language_pid` (`alias`,`language`,`pid`),
  KEY `source_language_pid` (`source`,`language`,`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `url_alias`
--

INSERT INTO `url_alias` (`pid`, `source`, `alias`, `language`) VALUES
(1, 'taxonomy/term/1', 'drupal-6', 'und'),
(2, 'taxonomy/term/2', 'drupal-7', 'und'),
(3, 'node/1', 'about', 'und'),
(4, 'taxonomy/term/4', 'drupal-8', 'und'),
(5, 'node/3', 'valid_email_address', 'und'),
(6, 'node/2', 'introducing-dfotw', 'und'),
(7, 'taxonomy/term/5', 'tags/database', 'und'),
(8, 'node/4', 'drupal_write_record', 'und'),
(9, 'taxonomy/term/6', 'tags/schema', 'und'),
(10, 'taxonomy/term/7', 'tags/taxonomy', 'und'),
(12, 'taxonomy/term/8', 'tags/node', 'und'),
(14, 'taxonomy/term/9', 'tags/filefield', 'und'),
(15, 'taxonomy/term/10', 'tags/contrib', 'und'),
(16, 'taxonomy/term/11', 'tags/upload', 'und'),
(18, 'node/6', 'file_load', 'und'),
(19, 'node/6', 'field_file_load', 'und'),
(20, 'user/1', 'users/admin', 'und'),
(21, 'user/10', 'users/alex', 'und'),
(22, 'user/11', 'users/leandro', 'und'),
(23, 'user/12', 'users/miguel', 'und'),
(24, 'user/13', 'users/joao', 'und'),
(25, 'user/14', 'users/barraponto', 'und');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary Key: Unique user ID.',
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT 'Unique user name.',
  `pass` varchar(128) NOT NULL DEFAULT '' COMMENT 'User’s password (hashed).',
  `mail` varchar(254) DEFAULT '' COMMENT 'User’s e-mail address.',
  `theme` varchar(255) NOT NULL DEFAULT '' COMMENT 'User’s default theme.',
  `signature` varchar(255) NOT NULL DEFAULT '' COMMENT 'User’s signature.',
  `signature_format` varchar(255) DEFAULT NULL COMMENT 'The filter_format.format of the signature.',
  `created` int(11) NOT NULL DEFAULT '0' COMMENT 'Timestamp for when user was created.',
  `access` int(11) NOT NULL DEFAULT '0' COMMENT 'Timestamp for previous time user accessed the site.',
  `login` int(11) NOT NULL DEFAULT '0' COMMENT 'Timestamp for user’s last login.',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Whether the user is active(1) or blocked(0).',
  `timezone` varchar(32) DEFAULT NULL COMMENT 'User’s time zone.',
  `language` varchar(12) NOT NULL DEFAULT '' COMMENT 'User’s default language.',
  `picture` int(11) NOT NULL DEFAULT '0' COMMENT 'Foreign key: file_managed.fid of user’s picture.',
  `init` varchar(254) DEFAULT '' COMMENT 'E-mail address used for initial account creation.',
  `data` longblob COMMENT 'A serialized array of name value pairs that are related to the user. Any form values posted during user edit are stored and are loaded into the $user object during user_load(). Use of this field is discouraged and it will likely disappear in a future...',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `name` (`name`),
  KEY `access` (`access`),
  KEY `created` (`created`),
  KEY `mail` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `pass`, `mail`, `theme`, `signature`, `signature_format`, `created`, `access`, `login`, `status`, `timezone`, `language`, `picture`, `init`, `data`) VALUES
(0, '', '', '', '', '', NULL, 0, 0, 0, 0, NULL, '', 0, '', NULL),
(1, 'admin', '$S$DNR09aAKJ4jGvOh2RUAEmcZhy0SjxezIjBqGVDbAfW3mtz0bMvnq', 'social@webdrop.net.br', '', '', 'filtered_html', 1306422824, 1315427116, 1315425212, 1, 'America/Sao_Paulo', '', 2, 'alex@webdrop.net.br', 0x613a313a7b733a373a22636f6e74616374223b693a303b7d),
(10, 'alex', '$S$DE9Fsg0mY63dMhy5JU.paQbQYrp7v0Z7App7rMAouVDO.RN90VJa', 'alex@webdrop.net.br', '', '', 'filtered_html', 1306422824, 1315425114, 1315425114, 1, 'America/Sao_Paulo', '', 1, 'alex@webdrop.net.br', 0x613a313a7b733a373a22636f6e74616374223b693a303b7d),
(11, 'leandro', '$S$Dcy8Tzd5z.8kfncJVWjLyHubmg2pDnGify8FkLjg4bG4qQ1ATRBT', 'leandro@webdrop.net.br', '', '', 'filtered_html', 1315423410, 0, 0, 1, 'America/Sao_Paulo', '', 0, 'leandro@webdrop.net.br', 0x613a313a7b733a373a22636f6e74616374223b693a303b7d),
(12, 'miguel', '$S$DwvkanfAef22HGz/grC0C6HgKIhfMg52444H.7/cRiDmjgP9On8w', 'miguel@webdrop.net.br', '', '', 'filtered_html', 1315423423, 0, 0, 1, 'America/Sao_Paulo', '', 0, 'miguel@webdrop.net.br', 0x613a313a7b733a373a22636f6e74616374223b693a303b7d),
(13, 'joao', '$S$DsyJ.nbpZXTKZrhqlkkhRRdHQPauq2NB.vD4ezl9uYZmiFM2eA0/', 'joao@webdrop.net.br', '', '', 'filtered_html', 1315423434, 0, 0, 1, 'America/Sao_Paulo', '', 0, 'joao@webdrop.net.br', 0x613a313a7b733a373a22636f6e74616374223b693a303b7d),
(14, 'barraponto', '$S$DQjjKb1hXJp.B16ewVPT6VXUpduD8JIrXZL2TQEAw/Dv5PX1q5pI', 'barraponto@gmail.com', '', '', 'filtered_html', 1315423467, 1315425183, 1315425183, 1, 'America/Sao_Paulo', '', 0, 'barraponto@gmail.com', 0x613a313a7b733a373a22636f6e74616374223b693a303b7d);

-- --------------------------------------------------------

--
-- Table structure for table `users_roles`
--

CREATE TABLE IF NOT EXISTS `users_roles` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary Key: users.uid for user.',
  `rid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary Key: role.rid for role.',
  PRIMARY KEY (`uid`,`rid`),
  KEY `rid` (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_roles`
--

INSERT INTO `users_roles` (`uid`, `rid`) VALUES
(1, 3),
(10, 3),
(11, 3),
(12, 3),
(13, 3),
(14, 4);

-- --------------------------------------------------------

--
-- Table structure for table `variable`
--

CREATE TABLE IF NOT EXISTS `variable` (
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT 'The name of the variable.',
  `value` longblob NOT NULL COMMENT 'The value of the variable.',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `variable`
--

INSERT INTO `variable` (`name`, `value`) VALUES
('additional_settings__active_tab_function', 0x733a31343a22656469742d7363686564756c6572223b),
('additional_settings__active_tab_page', 0x733a31353a22656469742d7375626d697373696f6e223b),
('admin_theme', 0x733a353a22736576656e223b),
('anonymous', 0x733a393a22416e6f6e796d6f7573223b),
('backup_migrate_destination_id', 0x733a383a22646f776e6c6f6164223b),
('backup_migrate_profile_id', 0x733a373a2264656661756c74223b),
('backup_migrate_source_id', 0x733a323a226462223b),
('block_cache', 0x693a313b),
('cache', 0x693a313b),
('cache_lifetime', 0x733a313a2230223b),
('clean_url', 0x733a313a2231223b),
('comment_anonymous_function', 0x693a303b),
('comment_anonymous_page', 0x693a303b),
('comment_default_mode_function', 0x693a313b),
('comment_default_mode_page', 0x693a313b),
('comment_default_per_page_function', 0x733a323a223530223b),
('comment_default_per_page_page', 0x733a323a223530223b),
('comment_form_location_function', 0x693a313b),
('comment_form_location_page', 0x693a313b),
('comment_function', 0x733a313a2232223b),
('comment_page', 0x733a313a2230223b),
('comment_preview_function', 0x733a313a2231223b),
('comment_preview_page', 0x733a313a2231223b),
('comment_subject_field_function', 0x693a313b),
('comment_subject_field_page', 0x693a313b),
('configurable_timezones', 0x693a313b),
('context_block_rebuild_needed', 0x623a313b),
('cron_key', 0x733a34333a2233694e544479746563516374344e4c68326356686974357a6e51395341594f79586739384754554d793777223b),
('cron_last', 0x693a313331353432313038363b),
('css_js_query_string', 0x733a363a226c7236367734223b),
('ctools_last_cron', 0x693a313331353432313038373b),
('date_default_timezone', 0x733a31373a22416d65726963612f53616f5f5061756c6f223b),
('date_first_day', 0x733a313a2230223b),
('date_format_long', 0x733a31353a226c2c2046206a2c2059202d20483a69223b),
('date_format_medium', 0x733a31323a22442c20592d6d2d6420483a69223b),
('date_format_short', 0x733a393a22592d6d2d6420483a69223b),
('dblog_row_limit', 0x733a343a2231303030223b),
('drupal_http_request_fails', 0x623a303b),
('drupal_private_key', 0x733a34333a22375f414f3933576a6553364a61684442474b6f56656b4e396d6e6c546f614a31577a6d41717a6f6f693667223b),
('easysocial_article_override', 0x693a303b),
('easysocial_article_social_buttons', 0x613a343a7b733a373a2274776974746572223b693a303b733a383a2266616365626f6f6b223b693a303b733a31303a22676f6f676c65706c7573223b693a303b733a383a226c696e6b6564696e223b693a303b7d),
('easysocial_article_typebtn', 0x693a2d313b),
('easysocial_function_override', 0x693a303b),
('easysocial_function_social_buttons', 0x613a343a7b733a373a2274776974746572223b693a303b733a383a2266616365626f6f6b223b693a303b733a31303a22676f6f676c65706c7573223b693a303b733a383a226c696e6b6564696e223b693a303b7d),
('easysocial_function_typebtn', 0x693a2d313b),
('easysocial_global_social_buttons', 0x613a343a7b733a373a2274776974746572223b733a373a2274776974746572223b733a383a2266616365626f6f6b223b733a383a2266616365626f6f6b223b733a31303a22676f6f676c65706c7573223b733a31303a22676f6f676c65706c7573223b733a383a226c696e6b6564696e223b733a383a226c696e6b6564696e223b7d),
('easysocial_global_typebtn', 0x733a313a2231223b),
('easysocial_page_override', 0x693a303b),
('easysocial_page_social_buttons', 0x613a343a7b733a373a2274776974746572223b693a303b733a383a2266616365626f6f6b223b693a303b733a31303a22676f6f676c65706c7573223b693a303b733a383a226c696e6b6564696e223b693a303b7d),
('easysocial_page_typebtn', 0x693a2d313b),
('easysocial_tt_global_account_description', 0x733a35303a2244727570616c2046756e6374696f6e206f6620746865205765656b3a20217469746c65202364727570616c202364666f7477223b),
('easysocial_tt_global_account_related', 0x733a393a2277656264726f706272223b),
('easysocial_tt_global_account_via', 0x733a363a226472666f7477223b),
('email__active_tab', 0x733a32343a22656469742d656d61696c2d61646d696e2d63726561746564223b),
('empty_timezone_message', 0x693a303b),
('error_level', 0x733a313a2232223b),
('features_codecache', 0x613a313a7b733a353a2264666f7477223b613a383a7b733a31313a226d656e755f637573746f6d223b733a33323a223230343239333163633132633034363661616238666338613734663264343030223b733a31303a226d656e755f6c696e6b73223b733a33323a223566613336333036396264653137356532636137303233336264373761383036223b733a383a227461786f6e6f6d79223b733a33323a223463396164633831363761353238303238646239383439343533333664393164223b733a31323a22646570656e64656e63696573223b733a33323a226264353135393833643561313034333836636639373634386238366663383462223b733a353a226669656c64223b733a33323a226662303434396538333764343135343134613636306335363337356362303230223b733a343a226e6f6465223b733a33323a223261393034623962333734623837336231363662663938316633353530346638223b733a373a22636f6e74657874223b733a33323a226432396630343965393161326666333232396565633430376330316436373764223b733a31313a226669656c645f67726f7570223b733a33323a226363366138653536383135313964353032343636363539343264303665306539223b7d7d),
('features_ignored_orphans', 0x613a303a7b7d),
('features_semaphore', 0x613a303a7b7d),
('feed_default_items', 0x733a323a223130223b),
('feed_description', 0x733a35313a2255736566756c2044727570616c2066756e6374696f6e7320796f75206d69676874206e6f74206b6e6f77206578697374656421223b),
('feed_item_length', 0x733a363a22746561736572223b),
('field_bundle_settings', 0x613a323a7b733a343a226e6f6465223b613a333a7b733a383a2266756e6374696f6e223b613a323a7b733a31303a22766965775f6d6f646573223b613a363a7b733a363a22746561736572223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a313b7d733a343a2266756c6c223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a333a22727373223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a313b7d733a31323a227365617263685f696e646578223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a313b7d733a31333a227365617263685f726573756c74223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a313b7d733a353a22746f6b656e223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d7d733a31323a2265787472615f6669656c6473223b613a323a7b733a343a22666f726d223b613a323a7b733a353a227469746c65223b613a313a7b733a363a22776569676874223b733a313a2230223b7d733a343a2270617468223b613a313a7b733a363a22776569676874223b733a313a2237223b7d7d733a373a22646973706c6179223b613a313a7b733a31313a22656173795f736f6369616c223b613a353a7b733a373a2264656661756c74223b613a323a7b733a363a22776569676874223b733a313a2231223b733a373a2276697369626c65223b623a313b7d733a363a22746561736572223b613a323a7b733a363a22776569676874223b733a333a22313030223b733a373a2276697369626c65223b623a303b7d733a333a22727373223b613a323a7b733a363a22776569676874223b733a333a22313030223b733a373a2276697369626c65223b623a303b7d733a31323a227365617263685f696e646578223b613a323a7b733a363a22776569676874223b733a333a22313030223b733a373a2276697369626c65223b623a303b7d733a31333a227365617263685f726573756c74223b613a323a7b733a363a22776569676874223b733a333a22313030223b733a373a2276697369626c65223b623a303b7d7d7d7d7d733a373a2261727469636c65223b613a323a7b733a31303a22766965775f6d6f646573223b613a363a7b733a363a22746561736572223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a333a22727373223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a31323a227365617263685f696e646578223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a31333a227365617263685f726573756c74223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a343a2266756c6c223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a353a22746f6b656e223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d7d733a31323a2265787472615f6669656c6473223b613a323a7b733a343a22666f726d223b613a303a7b7d733a373a22646973706c6179223b613a313a7b733a31313a22656173795f736f6369616c223b613a313a7b733a373a2264656661756c74223b613a323a7b733a363a22776569676874223b733a333a22313030223b733a373a2276697369626c65223b623a303b7d7d7d7d7d733a343a2270616765223b613a323a7b733a31303a22766965775f6d6f646573223b613a363a7b733a363a22746561736572223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a313b7d733a343a2266756c6c223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a333a22727373223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a31323a227365617263685f696e646578223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a31333a227365617263685f726573756c74223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a353a22746f6b656e223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d7d733a31323a2265787472615f6669656c6473223b613a323a7b733a343a22666f726d223b613a303a7b7d733a373a22646973706c6179223b613a313a7b733a31313a22656173795f736f6369616c223b613a323a7b733a373a2264656661756c74223b613a323a7b733a363a22776569676874223b733a333a22313030223b733a373a2276697369626c65223b623a303b7d733a363a22746561736572223b613a323a7b733a363a22776569676874223b733a333a22313030223b733a373a2276697369626c65223b623a303b7d7d7d7d7d7d733a343a2275736572223b613a313a7b733a343a2275736572223b613a323a7b733a31303a22766965775f6d6f646573223b613a323a7b733a343a2266756c6c223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d733a353a22746f6b656e223b613a313a7b733a31353a22637573746f6d5f73657474696e6773223b623a303b7d7d733a31323a2265787472615f6669656c6473223b613a323a7b733a343a22666f726d223b613a353a7b733a363a226d6f6c6c6f6d223b613a313a7b733a363a22776569676874223b733a313a2236223b7d733a373a226163636f756e74223b613a313a7b733a363a22776569676874223b733a313a2230223b7d733a383a2274696d657a6f6e65223b613a313a7b733a363a22776569676874223b733a313a2235223b7d733a373a22636f6e74616374223b613a313a7b733a363a22776569676874223b733a313a2234223b7d733a373a2270696374757265223b613a313a7b733a363a22776569676874223b733a313a2233223b7d7d733a373a22646973706c6179223b613a313a7b733a373a2273756d6d617279223b613a313a7b733a373a2264656661756c74223b613a323a7b733a363a22776569676874223b733a313a2232223b733a373a2276697369626c65223b623a313b7d7d7d7d7d7d7d),
('file_default_scheme', 0x733a363a227075626c6963223b),
('file_private_path', 0x733a333a22626b70223b),
('file_public_path', 0x733a31393a2273697465732f64656661756c742f66696c6573223b),
('file_temporary_path', 0x733a343a222f746d70223b),
('filter_fallback_format', 0x733a31303a22706c61696e5f74657874223b),
('globalredirect_settings', 0x613a333a7b733a31333a22747261696c696e675f7a65726f223b693a313b733a393a2263616e6f6e6963616c223b693a313b733a32333a22636f6e74656e745f6c6f636174696f6e5f686561646572223b693a313b7d),
('googleanalytics_account', 0x733a31333a2255412d32333630353037312d31223b),
('googleanalytics_cache', 0x693a303b),
('googleanalytics_codesnippet_after', 0x733a303a22223b),
('googleanalytics_codesnippet_before', 0x733a303a22223b),
('googleanalytics_cross_domains', 0x733a303a22223b),
('googleanalytics_custom', 0x733a313a2230223b),
('googleanalytics_custom_var', 0x613a313a7b733a353a22736c6f7473223b613a353a7b693a313b613a343a7b733a343a22736c6f74223b693a313b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a313a2233223b7d693a323b613a343a7b733a343a22736c6f74223b693a323b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a313a2233223b7d693a333b613a343a7b733a343a22736c6f74223b693a333b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a313a2233223b7d693a343b613a343a7b733a343a22736c6f74223b693a343b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a313a2233223b7d693a353b613a343a7b733a343a22736c6f74223b693a353b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a313a2233223b7d7d7d),
('googleanalytics_domain_mode', 0x733a313a2230223b),
('googleanalytics_js_scope', 0x733a363a22666f6f746572223b),
('googleanalytics_pages', 0x733a35323a2261646d696e0d0a61646d696e2f2a0d0a62617463680d0a6e6f64652f6164642a0d0a6e6f64652f2a2f2a0d0a757365722f2a2f2a223b),
('googleanalytics_privacy_donottrack', 0x693a313b),
('googleanalytics_roles', 0x613a333a7b693a313b693a303b693a323b693a303b693a333b693a303b7d),
('googleanalytics_site_search', 0x693a313b),
('googleanalytics_trackadsense', 0x693a303b),
('googleanalytics_tracker_anonymizeip', 0x693a303b),
('googleanalytics_trackfiles', 0x693a313b),
('googleanalytics_trackfiles_extensions', 0x733a3139353a22377a7c6161637c6172637c61726a7c6173667c6173787c6176697c62696e7c6373767c646f637c6578657c666c767c6769667c677a7c677a69707c6871787c6a61727c6a70653f677c6a737c6d7028327c337c347c653f67297c6d6f76286965293f7c6d73697c6d73707c7064667c706870737c706e677c7070747c71746d3f7c7261286d7c72293f7c7365617c7369747c7461727c74677a7c746f7272656e747c7478747c7761767c776d617c776d767c7770647c786c737c786d6c7c7a7c7a6970223b),
('googleanalytics_trackmailto', 0x693a313b),
('googleanalytics_trackoutbound', 0x693a313b),
('googleanalytics_trackoutboundaspageview', 0x693a303b),
('googleanalytics_visibility_pages', 0x733a313a2230223b),
('googleanalytics_visibility_roles', 0x733a313a2231223b),
('headjs_embed', 0x693a313b),
('headjs_enable', 0x693a303b),
('headjs_version', 0x733a363a226c6f61646572223b),
('image_toolkit', 0x733a323a226764223b),
('install_profile', 0x733a383a227374616e64617264223b),
('install_task', 0x733a343a22646f6e65223b),
('install_time', 0x693a313330363432323934303b),
('maintenance_mode', 0x693a303b),
('maintenance_mode_message', 0x733a3131353a2244727570616c2046756e6374696f6e206f6620746865205765656b2069732063757272656e746c7920756e646572206d61696e74656e616e63652e2057652073686f756c64206265206261636b2073686f72746c792e205468616e6b20796f7520666f7220796f75722070617469656e63652e223b),
('menu_expanded', 0x613a303a7b7d),
('menu_masks', 0x613a33333a7b693a303b693a3439333b693a313b693a3234373b693a323b693a3234363b693a333b693a3234353b693a343b693a3132373b693a353b693a3132353b693a363b693a3132333b693a373b693a3132323b693a383b693a3132313b693a393b693a3131373b693a31303b693a36333b693a31313b693a36323b693a31323b693a36313b693a31333b693a36303b693a31343b693a35393b693a31353b693a35383b693a31363b693a34343b693a31373b693a33313b693a31383b693a33303b693a31393b693a32393b693a32303b693a32343b693a32313b693a32313b693a32323b693a31353b693a32333b693a31343b693a32343b693a31333b693a32353b693a31323b693a32363b693a31313b693a32373b693a373b693a32383b693a363b693a32393b693a353b693a33303b693a333b693a33313b693a323b693a33323b693a313b7d),
('menu_options_function', 0x613a303a7b7d),
('menu_options_page', 0x613a313a7b693a303b733a393a226d61696e2d6d656e75223b7d),
('menu_parent_function', 0x733a31313a226d61696e2d6d656e753a30223b),
('menu_parent_page', 0x733a31313a226d61696e2d6d656e753a30223b),
('metatags_quick_settings', 0x613a323a7b733a393a227573655f66726f6e74223b623a313b733a31323a2266726f6e745f76616c756573223b613a323a7b733a383a226b6579776f726473223b733a33323a2264727570616c2c2066756e6374696f6e2c206170692c207265666572656e6365223b733a31313a226465736372697074696f6e223b733a3134383a2244727570616c2046756e6374696f6e206f6620746865205765656b206973206120776562736974652064656469636174656420746f206578706f73696e6720766572792075736566756c20616e64206f6674656e206e6f7420746861742077656c6c2d6b6e6f776e2044727570616c2066756e6374696f6e732e2053656e6420757320796f75722073756767657374696f6e7321223b7d7d),
('minimum_word_size', 0x733a313a2233223b),
('mollom_fallback', 0x733a313a2231223b),
('mollom_privacy_link', 0x693a313b),
('mollom_private_key', 0x733a33323a223665383563613263666264313863396538396163323563666130633663616431223b),
('mollom_public_key', 0x733a33323a226235393262323162333931373834333164626536323738366136316635643364223b),
('mollom_servers', 0x613a323a7b693a303b733a32313a22687474703a2f2f3137342e33372e3230352e313532223b693a313b733a31393a22687474703a2f2f36372e3232382e38342e3131223b7d),
('mollom_status', 0x613a333a7b733a343a226b657973223b623a313b733a31303a226b6579732076616c6964223b623a313b733a373a2273657276657273223b623a303b7d),
('mollom_testing_mode', 0x693a303b),
('node_admin_theme', 0x733a313a2231223b),
('node_cron_last', 0x733a31303a2231333135343133393633223b),
('node_options_function', 0x613a323a7b693a303b733a363a22737461747573223b693a313b733a373a2270726f6d6f7465223b7d),
('node_options_page', 0x613a313a7b693a303b733a363a22737461747573223b7d),
('node_preview_function', 0x733a313a2231223b),
('node_preview_page', 0x733a313a2231223b),
('node_rank_comments', 0x733a313a2232223b),
('node_rank_promote', 0x733a313a2230223b),
('node_rank_recent', 0x733a313a2231223b),
('node_rank_relevance', 0x733a313a2235223b),
('node_rank_sticky', 0x733a313a2230223b),
('node_recent_block_count', 0x733a323a223130223b),
('node_submitted_function', 0x693a303b),
('node_submitted_page', 0x693a303b),
('overlap_cjk', 0x693a313b),
('page_cache_maximum_age', 0x733a313a2230223b),
('page_compression', 0x693a313b),
('pathauto_blog_pattern', 0x733a31373a22626c6f67732f5b757365723a6e616d655d223b),
('pathauto_case', 0x733a313a2231223b),
('pathauto_forum_pattern', 0x733a32393a225b7465726d3a766f636162756c6172795d2f5b7465726d3a6e616d655d223b),
('pathauto_ignore_words', 0x733a3133343a22612c20616e2c2061732c2061742c206265666f72652c206275742c2062792c20666f722c2066726f6d2c2069732c20696e2c20696e746f2c206c696b652c206f662c206f66662c206f6e2c206f6e746f2c207065722c2073696e63652c207468616e2c207468652c20746869732c20746861742c20746f2c2075702c207669612c2077697468223b),
('pathauto_max_component_length', 0x733a333a22313030223b),
('pathauto_max_length', 0x733a333a22313030223b),
('pathauto_node_article_pattern', 0x733a31323a225b6e6f64653a7469746c655d223b),
('pathauto_node_function_pattern', 0x733a31323a225b6e6f64653a7469746c655d223b),
('pathauto_node_page_pattern', 0x733a31323a225b6e6f64653a7469746c655d223b),
('pathauto_node_pattern', 0x733a31323a225b6e6f64653a7469746c655d223b),
('pathauto_punctuation_ampersand', 0x733a313a2230223b),
('pathauto_punctuation_asterisk', 0x733a313a2230223b),
('pathauto_punctuation_at', 0x733a313a2230223b),
('pathauto_punctuation_backtick', 0x733a313a2230223b),
('pathauto_punctuation_back_slash', 0x733a313a2230223b),
('pathauto_punctuation_caret', 0x733a313a2230223b),
('pathauto_punctuation_colon', 0x733a313a2230223b),
('pathauto_punctuation_comma', 0x733a313a2230223b),
('pathauto_punctuation_dollar', 0x733a313a2230223b),
('pathauto_punctuation_double_quotes', 0x733a313a2230223b),
('pathauto_punctuation_equal', 0x733a313a2230223b),
('pathauto_punctuation_exclamation', 0x733a313a2230223b),
('pathauto_punctuation_greater_than', 0x733a313a2230223b),
('pathauto_punctuation_hash', 0x733a313a2230223b),
('pathauto_punctuation_hyphen', 0x733a313a2231223b),
('pathauto_punctuation_left_curly', 0x733a313a2230223b),
('pathauto_punctuation_left_parenthesis', 0x733a313a2230223b),
('pathauto_punctuation_left_square', 0x733a313a2230223b),
('pathauto_punctuation_less_than', 0x733a313a2230223b),
('pathauto_punctuation_percent', 0x733a313a2230223b),
('pathauto_punctuation_period', 0x733a313a2230223b),
('pathauto_punctuation_pipe', 0x733a313a2230223b),
('pathauto_punctuation_plus', 0x733a313a2230223b),
('pathauto_punctuation_question_mark', 0x733a313a2230223b),
('pathauto_punctuation_quotes', 0x733a313a2230223b),
('pathauto_punctuation_right_curly', 0x733a313a2230223b),
('pathauto_punctuation_right_parenthesis', 0x733a313a2230223b),
('pathauto_punctuation_right_square', 0x733a313a2230223b),
('pathauto_punctuation_semicolon', 0x733a313a2230223b),
('pathauto_punctuation_slash', 0x733a313a2230223b),
('pathauto_punctuation_tilde', 0x733a313a2230223b),
('pathauto_punctuation_underscore', 0x733a313a2232223b),
('pathauto_reduce_ascii', 0x693a303b),
('pathauto_separator', 0x733a313a222d223b),
('pathauto_taxonomy_term_pattern', 0x733a32393a225b7465726d3a766f636162756c6172795d2f5b7465726d3a6e616d655d223b),
('pathauto_taxonomy_term_tags_pattern', 0x733a303a22223b),
('pathauto_taxonomy_term_version_pattern', 0x733a303a22223b),
('pathauto_transliterate', 0x623a303b),
('pathauto_update_action', 0x733a313a2232223b),
('pathauto_user_pattern', 0x733a31373a2275736572732f5b757365723a6e616d655d223b),
('pathauto_verbose', 0x693a303b),
('path_alias_whitelist', 0x613a333a7b733a343a226e6f6465223b623a313b733a383a227461786f6e6f6d79223b623a313b733a343a2275736572223b623a313b7d),
('piwik_cache', 0x693a313b),
('piwik_codesnippet_after', 0x733a303a22223b),
('piwik_codesnippet_before', 0x733a303a22223b),
('piwik_custom', 0x733a313a2230223b),
('piwik_custom_var', 0x613a313a7b733a353a22736c6f7473223b613a353a7b693a313b613a343a7b733a343a22736c6f74223b693a313b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a353a227669736974223b7d693a323b613a343a7b733a343a22736c6f74223b693a323b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a353a227669736974223b7d693a333b613a343a7b733a343a22736c6f74223b693a333b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a353a227669736974223b7d693a343b613a343a7b733a343a22736c6f74223b693a343b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a353a227669736974223b7d693a353b613a343a7b733a343a22736c6f74223b693a353b733a343a226e616d65223b733a303a22223b733a353a2276616c7565223b733a303a22223b733a353a2273636f7065223b733a353a227669736974223b7d7d7d),
('piwik_domain_mode', 0x733a313a2230223b),
('piwik_js_scope', 0x733a363a22666f6f746572223b),
('piwik_last_cache', 0x693a313331353339353739373b),
('piwik_pages', 0x733a35323a2261646d696e0d0a61646d696e2f2a0d0a62617463680d0a6e6f64652f6164642a0d0a6e6f64652f2a2f2a0d0a757365722f2a2f2a223b),
('piwik_page_title_hierarchy', 0x693a303b),
('piwik_page_title_hierarchy_exclude_home', 0x693a313b),
('piwik_privacy_donottrack', 0x693a313b),
('piwik_roles', 0x613a333a7b693a313b693a303b693a323b693a303b693a333b693a303b7d),
('piwik_site_id', 0x733a313a2233223b),
('piwik_site_search', 0x693a303b),
('piwik_track', 0x693a313b),
('piwik_trackfiles_extensions', 0x733a3139353a22377a7c6161637c6172637c61726a7c6173667c6173787c6176697c62696e7c6373767c646f637c6578657c666c767c6769667c677a7c677a69707c6871787c6a61727c6a70653f677c6a737c6d7028327c337c347c653f67297c6d6f76286965293f7c6d73697c6d73707c7064667c706870737c706e677c7070747c71746d3f7c7261286d7c72293f7c7365617c7369747c7461727c74677a7c746f7272656e747c7478747c7761767c776d617c776d767c7770647c786c737c786d6c7c7a7c7a6970223b),
('piwik_url_http', 0x733a32383a22687474703a2f2f73746174732e77656264726f702e6e65742e62722f223b),
('piwik_url_https', 0x733a303a22223b),
('piwik_visibility_pages', 0x733a313a2230223b),
('piwik_visibility_roles', 0x733a313a2230223b),
('preprocess_css', 0x693a313b),
('preprocess_js', 0x693a313b),
('save_continue_function', 0x733a31393a225361766520616e6420616464206669656c6473223b),
('scheduler_publish_enable_function', 0x693a313b),
('scheduler_publish_required_function', 0x693a303b),
('scheduler_publish_revision_function', 0x693a303b),
('scheduler_publish_touch_function', 0x693a313b),
('scheduler_unpublish_enable_function', 0x693a303b),
('scheduler_unpublish_required_function', 0x693a303b),
('scheduler_unpublish_revision_function', 0x693a303b),
('search_active_modules', 0x613a323a7b733a343a226e6f6465223b733a343a226e6f6465223b733a343a2275736572223b693a303b7d),
('search_cron_limit', 0x733a333a22313030223b),
('search_default_module', 0x733a343a226e6f6465223b),
('site_default_country', 0x733a323a224252223b),
('site_mail', 0x733a31393a22616c65784077656264726f702e6e65742e6272223b),
('site_name', 0x733a32373a2244727570616c2046756e6374696f6e206f6620746865205765656b223b),
('site_offline', 0x693a303b),
('tagadelic_levels', 0x733a313a2236223b),
('tagadelic_page_amount', 0x733a323a223630223b),
('tagadelic_sort_order', 0x733a31313a2272616e646f6d2c6e6f6e65223b),
('theme_corolla_settings', 0x613a32363a7b733a31313a22746f67676c655f6c6f676f223b693a313b733a31313a22746f67676c655f6e616d65223b693a313b733a31333a22746f67676c655f736c6f67616e223b693a313b733a32343a22746f67676c655f6e6f64655f757365725f70696374757265223b693a313b733a32373a22746f67676c655f636f6d6d656e745f757365725f70696374757265223b693a313b733a31343a22746f67676c655f66617669636f6e223b693a313b733a31323a2264656661756c745f6c6f676f223b693a313b733a393a226c6f676f5f70617468223b733a303a22223b733a31313a226c6f676f5f75706c6f6164223b733a303a22223b733a31353a2264656661756c745f66617669636f6e223b693a313b733a31323a2266617669636f6e5f70617468223b733a303a22223b733a31343a2266617669636f6e5f75706c6f6164223b733a303a22223b733a31343a22626173655f666f6e745f73697a65223b733a343a2231327078223b733a32303a22736964656261725f66697273745f776569676874223b733a313a2231223b733a32313a22736964656261725f7365636f6e645f776569676874223b733a313a2232223b733a31383a226c61796f75745f315f6d696e5f7769647468223b733a353a223535307078223b733a31383a226c61796f75745f315f6d61785f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f325f6d696e5f7769647468223b733a353a223735307078223b733a31383a226c61796f75745f325f6d61785f7769647468223b733a353a223936307078223b733a31383a226c61796f75745f335f6d696e5f7769647468223b733a353a223830307078223b733a31383a226c61796f75745f335f6d61785f7769647468223b733a363a22313030307078223b733a32313a22636f707972696768745f696e666f726d6174696f6e223b733a38303a22c2a92032303131203c6120687265663d22687474703a2f2f77656264726f702e6e65742e627222207469746c653d2257656264726f70222072656c3d22666f6c6c6f77223e57656264726f703c2f613e223b733a363a22736368656d65223b733a373a2264656661756c74223b733a373a2270616c65747465223b613a31353a7b733a343a2262617365223b733a373a2223666666666666223b733a31303a226261636b67726f756e64223b733a373a2223663866386638223b733a343a2274657874223b733a373a2223326532653265223b733a343a226c696e6b223b733a373a2223303836373832223b733a393a226c696e6b686f766572223b733a373a2223653235343031223b733a31333a226c696e6b756e6465726c696e65223b733a373a2223636664646535223b733a363a22736c6f67616e223b733a373a2223653235343030223b733a31303a226e617669676174696f6e223b733a373a2223326532653264223b733a31353a226e617669676174696f6e686f766572223b733a373a2223653235343032223b733a333a22746162223b733a373a2223663566346633223b733a31303a22626c6f636b7469746c65223b733a373a2223373739313235223b733a363a22626f72646572223b733a373a2223653165316531223b733a31323a22626f726465727374726f6e67223b733a373a2223633463346334223b733a383a226669656c64736574223b733a373a2223666266626662223b733a31343a226669656c64736574626f72646572223b733a373a2223653165316532223b7d733a353a227468656d65223b733a373a22636f726f6c6c61223b733a343a22696e666f223b613a31313a7b733a363a226669656c6473223b613a31353a7b733a343a2262617365223b733a343a2242617365223b733a31303a226261636b67726f756e64223b733a31303a224261636b67726f756e64223b733a343a2274657874223b733a343a2254657874223b733a343a226c696e6b223b733a343a224c696e6b223b733a393a226c696e6b686f766572223b733a31323a22486f7665726564204c696e6b223b733a31333a226c696e6b756e6465726c696e65223b733a31343a224c696e6b20756e6465726c696e65223b733a363a22736c6f67616e223b733a363a22536c6f67616e223b733a31303a226e617669676174696f6e223b733a31303a224e617669676174696f6e223b733a31353a226e617669676174696f6e686f766572223b733a31363a224e617669676174696f6e20686f766572223b733a333a22746162223b733a333a22546162223b733a31303a22626c6f636b7469746c65223b733a31313a22426c6f636b207469746c65223b733a363a22626f72646572223b733a363a22426f72646572223b733a31323a22626f726465727374726f6e67223b733a31333a22426f72646572207374726f6e67223b733a383a226669656c64736574223b733a383a224669656c64736574223b733a31343a226669656c64736574626f72646572223b733a31353a224669656c6473657420626f72646572223b7d733a373a22736368656d6573223b613a373a7b733a373a2264656661756c74223b613a323a7b733a353a227469746c65223b733a31343a2247726179202844656661756c7429223b733a363a22636f6c6f7273223b613a31353a7b733a343a2262617365223b733a373a2223666666666666223b733a31303a226261636b67726f756e64223b733a373a2223663866386638223b733a343a2274657874223b733a373a2223326532653265223b733a343a226c696e6b223b733a373a2223303836373832223b733a393a226c696e6b686f766572223b733a373a2223653235343031223b733a31333a226c696e6b756e6465726c696e65223b733a373a2223636664646535223b733a363a22736c6f67616e223b733a373a2223653235343030223b733a31303a226e617669676174696f6e223b733a373a2223326532653264223b733a31353a226e617669676174696f6e686f766572223b733a373a2223653235343032223b733a333a22746162223b733a373a2223663566346633223b733a31303a22626c6f636b7469746c65223b733a373a2223373739313235223b733a363a22626f72646572223b733a373a2223653165316531223b733a31323a22626f726465727374726f6e67223b733a373a2223633463346334223b733a383a226669656c64736574223b733a373a2223666266626662223b733a31343a226669656c64736574626f72646572223b733a373a2223653165316532223b7d7d733a363a22677265656e31223b613a323a7b733a353a227469746c65223b733a373a22477265656e2031223b733a363a22636f6c6f7273223b613a31353a7b733a343a2262617365223b733a373a2223666666666666223b733a31303a226261636b67726f756e64223b733a373a2223666266626636223b733a343a2274657874223b733a373a2223336433643364223b733a343a226c696e6b223b733a373a2223383939383333223b733a393a226c696e6b686f766572223b733a373a2223653134363031223b733a31333a226c696e6b756e6465726c696e65223b733a373a2223653365616331223b733a363a22736c6f67616e223b733a373a2223383939383333223b733a31303a226e617669676174696f6e223b733a373a2223386539653335223b733a31353a226e617669676174696f6e686f766572223b733a373a2223363236633235223b733a333a22746162223b733a373a2223666266626636223b733a31303a22626c6f636b7469746c65223b733a373a2223373338623235223b733a363a22626f72646572223b733a373a2223653765316365223b733a31323a22626f726465727374726f6e67223b733a373a2223643263386161223b733a383a226669656c64736574223b733a373a2223666466646662223b733a31343a226669656c64736574626f72646572223b733a373a2223646164366339223b7d7d733a363a22677265656e32223b613a323a7b733a353a227469746c65223b733a373a22477265656e2032223b733a363a22636f6c6f7273223b613a31353a7b733a343a2262617365223b733a373a2223666666666666223b733a31303a226261636b67726f756e64223b733a373a2223666266626636223b733a343a2274657874223b733a373a2223336433643364223b733a343a226c696e6b223b733a373a2223313537613963223b733a393a226c696e6b686f766572223b733a373a2223653134363031223b733a31333a226c696e6b756e6465726c696e65223b733a373a2223636664646535223b733a363a22736c6f67616e223b733a373a2223653134363031223b733a31303a226e617669676174696f6e223b733a373a2223386539653335223b733a31353a226e617669676174696f6e686f766572223b733a373a2223363236633235223b733a333a22746162223b733a373a2223666266626636223b733a31303a22626c6f636b7469746c65223b733a373a2223373739313235223b733a363a22626f72646572223b733a373a2223653765316365223b733a31323a22626f726465727374726f6e67223b733a373a2223643263386161223b733a383a226669656c64736574223b733a373a2223666466646662223b733a31343a226669656c64736574626f72646572223b733a373a2223646164366339223b7d7d733a363a22707572706c65223b613a323a7b733a353a227469746c65223b733a363a22507572706c65223b733a363a22636f6c6f7273223b613a31353a7b733a343a2262617365223b733a373a2223666666666666223b733a31303a226261636b67726f756e64223b733a373a2223666566616662223b733a343a2274657874223b733a373a2223326532653265223b733a343a226c696e6b223b733a373a2223366330643238223b733a393a226c696e6b686f766572223b733a373a2223653235343031223b733a31333a226c696e6b756e6465726c696e65223b733a373a2223656163386431223b733a363a22736c6f67616e223b733a373a2223653235343031223b733a31303a226e617669676174696f6e223b733a373a2223366330643238223b733a31353a226e617669676174696f6e686f766572223b733a373a2223383361383065223b733a333a22746162223b733a373a2223666266336636223b733a31303a22626c6f636b7469746c65223b733a373a2223653235343031223b733a363a22626f72646572223b733a373a2223663764366532223b733a31323a22626f726465727374726f6e67223b733a373a2223643961336237223b733a383a226669656c64736574223b733a373a2223666566616662223b733a31343a226669656c64736574626f72646572223b733a373a2223663764366532223b7d7d733a333a22726564223b613a323a7b733a353a227469746c65223b733a333a22526564223b733a363a22636f6c6f7273223b613a31353a7b733a343a2262617365223b733a373a2223666666666666223b733a31303a226261636b67726f756e64223b733a373a2223666566626661223b733a343a2274657874223b733a373a2223326532653265223b733a343a226c696e6b223b733a373a2223623934303065223b733a393a226c696e6b686f766572223b733a373a2223656637363266223b733a31333a226c696e6b756e6465726c696e65223b733a373a2223666164656433223b733a363a22736c6f67616e223b733a373a2223636135393262223b733a31303a226e617669676174696f6e223b733a373a2223623934303065223b733a31353a226e617669676174696f6e686f766572223b733a373a2223376532633061223b733a333a22746162223b733a373a2223666466366634223b733a31303a22626c6f636b7469746c65223b733a373a2223623934303065223b733a363a22626f72646572223b733a373a2223653864616435223b733a31323a22626f726465727374726f6e67223b733a373a2223653262646165223b733a383a226669656c64736574223b733a373a2223666566626661223b733a31343a226669656c64736574626f72646572223b733a373a2223663764616436223b7d7d733a363a2279656c6c6f77223b613a323a7b733a353a227469746c65223b733a363a2259656c6c6f77223b733a363a22636f6c6f7273223b613a31353a7b733a343a2262617365223b733a373a2223666666666666223b733a31303a226261636b67726f756e64223b733a373a2223663966616566223b733a343a2274657874223b733a373a2223333833383338223b733a343a226c696e6b223b733a373a2223386438303137223b733a393a226c696e6b686f766572223b733a373a2223646534633031223b733a31333a226c696e6b756e6465726c696e65223b733a373a2223663465656263223b733a363a22736c6f67616e223b733a373a2223616661303266223b733a31303a226e617669676174696f6e223b733a373a2223613061343635223b733a31353a226e617669676174696f6e686f766572223b733a373a2223366336663432223b733a333a22746162223b733a373a2223663766386563223b733a31303a22626c6f636b7469746c65223b733a373a2223616661303266223b733a363a22626f72646572223b733a373a2223653265356333223b733a31323a22626f726465727374726f6e67223b733a373a2223646364303933223b733a383a226669656c64736574223b733a373a2223666266626638223b733a31343a226669656c64736574626f72646572223b733a373a2223646464376236223b7d7d733a303a22223b613a323a7b733a353a227469746c65223b733a363a22437573746f6d223b733a363a22636f6c6f7273223b613a303a7b7d7d7d733a343a22636f7079223b613a313a7b693a303b733a383a226c6f676f2e706e67223b7d733a333a22637373223b613a313a7b693a303b733a31303a22636f6c6f72732e637373223b7d733a393a226772616469656e7473223b613a313a7b693a303b613a333a7b733a393a2264696d656e73696f6e223b613a343a7b693a303b693a303b693a313b693a303b693a323b693a303b693a333b693a303b7d733a393a22646972656374696f6e223b733a383a22766572746963616c223b733a363a22636f6c6f7273223b613a323a7b693a303b733a343a226c696e6b223b693a313b733a343a2274657874223b7d7d7d733a343a2266696c6c223b613a303a7b7d733a363a22736c69636573223b613a303a7b7d733a31323a22626c656e645f746172676574223b733a373a2223666666666666223b733a31333a22707265766965775f696d616765223b733a31373a22636f6c6f722f707265766965772e706e67223b733a31313a22707265766965775f637373223b733a31373a22636f6c6f722f707265766965772e637373223b733a31303a22626173655f696d616765223b733a31343a22636f6c6f722f626173652e706e67223b7d7d),
('theme_default', 0x733a31333a2264666f74775f636f726f6c6c61223b),
('tracking__active_tab', 0x733a32323a22656469742d726f6c652d7669732d73657474696e6773223b),
('update_last_check', 0x693a313331353432333737323b),
('update_notify_emails', 0x613a313a7b693a303b733a31393a22616c65784077656264726f702e6e65742e6272223b7d),
('user_admin_role', 0x733a313a2233223b),
('user_cancel_method', 0x733a31373a22757365725f63616e63656c5f626c6f636b223b),
('user_default_timezone', 0x733a313a2230223b),
('user_email_verification', 0x693a313b),
('user_mail_cancel_confirm_body', 0x733a3338313a225b757365723a6e616d655d2c0d0a0d0a41207265717565737420746f2063616e63656c20796f7572206163636f756e7420686173206265656e206d616465206174205b736974653a6e616d655d2e0d0a0d0a596f75206d6179206e6f772063616e63656c20796f7572206163636f756e74206f6e205b736974653a75726c2d62726965665d20627920636c69636b696e672074686973206c696e6b206f7220636f7079696e6720616e642070617374696e6720697420696e746f20796f75722062726f777365723a0d0a0d0a5b757365723a63616e63656c2d75726c5d0d0a0d0a4e4f54453a205468652063616e63656c6c6174696f6e206f6620796f7572206163636f756e74206973206e6f742072657665727369626c652e0d0a0d0a54686973206c696e6b206578706972657320696e206f6e652064617920616e64206e6f7468696e672077696c6c2068617070656e206966206974206973206e6f7420757365642e0d0a0d0a2d2d20205b736974653a6e616d655d207465616d223b),
('user_mail_cancel_confirm_subject', 0x733a35393a224163636f756e742063616e63656c6c6174696f6e207265717565737420666f72205b757365723a6e616d655d206174205b736974653a6e616d655d223b),
('user_mail_password_reset_body', 0x733a3430373a225b757365723a6e616d655d2c0d0a0d0a41207265717565737420746f207265736574207468652070617373776f726420666f7220796f7572206163636f756e7420686173206265656e206d616465206174205b736974653a6e616d655d2e0d0a0d0a596f75206d6179206e6f77206c6f6720696e20627920636c69636b696e672074686973206c696e6b206f7220636f7079696e6720616e642070617374696e6720697420746f20796f75722062726f777365723a0d0a0d0a5b757365723a6f6e652d74696d652d6c6f67696e2d75726c5d0d0a0d0a54686973206c696e6b2063616e206f6e6c792062652075736564206f6e636520746f206c6f6720696e20616e642077696c6c206c65616420796f7520746f2061207061676520776865726520796f752063616e2073657420796f75722070617373776f72642e2049742065787069726573206166746572206f6e652064617920616e64206e6f7468696e672077696c6c2068617070656e2069662069742773206e6f7420757365642e0d0a0d0a2d2d20205b736974653a6e616d655d207465616d223b),
('user_mail_password_reset_subject', 0x733a36303a225265706c6163656d656e74206c6f67696e20696e666f726d6174696f6e20666f72205b757365723a6e616d655d206174205b736974653a6e616d655d223b),
('user_mail_register_admin_created_body', 0x733a3437363a225b757365723a6e616d655d2c0d0a0d0a4120736974652061646d696e6973747261746f72206174205b736974653a6e616d655d20686173206372656174656420616e206163636f756e7420666f7220796f752e20596f75206d6179206e6f77206c6f6720696e20627920636c69636b696e672074686973206c696e6b206f7220636f7079696e6720616e642070617374696e6720697420746f20796f75722062726f777365723a0d0a0d0a5b757365723a6f6e652d74696d652d6c6f67696e2d75726c5d0d0a0d0a54686973206c696e6b2063616e206f6e6c792062652075736564206f6e636520746f206c6f6720696e20616e642077696c6c206c65616420796f7520746f2061207061676520776865726520796f752063616e2073657420796f75722070617373776f72642e0d0a0d0a41667465722073657474696e6720796f75722070617373776f72642c20796f752077696c6c2062652061626c6520746f206c6f6720696e206174205b736974653a6c6f67696e2d75726c5d20696e2074686520667574757265207573696e673a0d0a0d0a757365726e616d653a205b757365723a6e616d655d0d0a70617373776f72643a20596f75722070617373776f72640d0a0d0a2d2d20205b736974653a6e616d655d207465616d223b),
('user_mail_register_admin_created_subject', 0x733a35383a22416e2061646d696e6973747261746f72206372656174656420616e206163636f756e7420666f7220796f75206174205b736974653a6e616d655d223b),
('user_mail_register_no_approval_required_body', 0x733a3435303a225b757365723a6e616d655d2c0d0a0d0a5468616e6b20796f7520666f72207265676973746572696e67206174205b736974653a6e616d655d2e20596f75206d6179206e6f77206c6f6720696e20627920636c69636b696e672074686973206c696e6b206f7220636f7079696e6720616e642070617374696e6720697420746f20796f75722062726f777365723a0d0a0d0a5b757365723a6f6e652d74696d652d6c6f67696e2d75726c5d0d0a0d0a54686973206c696e6b2063616e206f6e6c792062652075736564206f6e636520746f206c6f6720696e20616e642077696c6c206c65616420796f7520746f2061207061676520776865726520796f752063616e2073657420796f75722070617373776f72642e0d0a0d0a41667465722073657474696e6720796f75722070617373776f72642c20796f752077696c6c2062652061626c6520746f206c6f6720696e206174205b736974653a6c6f67696e2d75726c5d20696e2074686520667574757265207573696e673a0d0a0d0a757365726e616d653a205b757365723a6e616d655d0d0a70617373776f72643a20596f75722070617373776f72640d0a0d0a2d2d20205b736974653a6e616d655d207465616d223b),
('user_mail_register_no_approval_required_subject', 0x733a34363a224163636f756e742064657461696c7320666f72205b757365723a6e616d655d206174205b736974653a6e616d655d223b),
('user_mail_register_pending_approval_body', 0x733a3238373a225b757365723a6e616d655d2c0d0a0d0a5468616e6b20796f7520666f72207265676973746572696e67206174205b736974653a6e616d655d2e20596f7572206170706c69636174696f6e20666f7220616e206163636f756e742069732063757272656e746c792070656e64696e6720617070726f76616c2e204f6e636520697420686173206265656e20617070726f7665642c20796f752077696c6c207265636569766520616e6f7468657220652d6d61696c20636f6e7461696e696e6720696e666f726d6174696f6e2061626f757420686f7720746f206c6f6720696e2c2073657420796f75722070617373776f72642c20616e64206f746865722064657461696c732e0d0a0d0a0d0a2d2d20205b736974653a6e616d655d207465616d223b),
('user_mail_register_pending_approval_subject', 0x733a37313a224163636f756e742064657461696c7320666f72205b757365723a6e616d655d206174205b736974653a6e616d655d202870656e64696e672061646d696e20617070726f76616c29223b),
('user_mail_status_activated_body', 0x733a3436313a225b757365723a6e616d655d2c0d0a0d0a596f7572206163636f756e74206174205b736974653a6e616d655d20686173206265656e206163746976617465642e0d0a0d0a596f75206d6179206e6f77206c6f6720696e20627920636c69636b696e672074686973206c696e6b206f7220636f7079696e6720616e642070617374696e6720697420696e746f20796f75722062726f777365723a0d0a0d0a5b757365723a6f6e652d74696d652d6c6f67696e2d75726c5d0d0a0d0a54686973206c696e6b2063616e206f6e6c792062652075736564206f6e636520746f206c6f6720696e20616e642077696c6c206c65616420796f7520746f2061207061676520776865726520796f752063616e2073657420796f75722070617373776f72642e0d0a0d0a41667465722073657474696e6720796f75722070617373776f72642c20796f752077696c6c2062652061626c6520746f206c6f6720696e206174205b736974653a6c6f67696e2d75726c5d20696e2074686520667574757265207573696e673a0d0a0d0a757365726e616d653a205b757365723a6e616d655d0d0a70617373776f72643a20596f75722070617373776f72640d0a0d0a2d2d20205b736974653a6e616d655d207465616d223b),
('user_mail_status_activated_notify', 0x733a313a2231223b),
('user_mail_status_activated_subject', 0x733a35373a224163636f756e742064657461696c7320666f72205b757365723a6e616d655d206174205b736974653a6e616d655d2028617070726f76656429223b),
('user_mail_status_blocked_body', 0x733a38353a225b757365723a6e616d655d2c0d0a0d0a596f7572206163636f756e74206f6e205b736974653a6e616d655d20686173206265656e20626c6f636b65642e0d0a0d0a2d2d20205b736974653a6e616d655d207465616d223b),
('user_mail_status_blocked_notify', 0x693a303b),
('user_mail_status_blocked_subject', 0x733a35363a224163636f756e742064657461696c7320666f72205b757365723a6e616d655d206174205b736974653a6e616d655d2028626c6f636b656429223b),
('user_mail_status_canceled_body', 0x733a38363a225b757365723a6e616d655d2c0d0a0d0a596f7572206163636f756e74206f6e205b736974653a6e616d655d20686173206265656e2063616e63656c65642e0d0a0d0a2d2d20205b736974653a6e616d655d207465616d223b),
('user_mail_status_canceled_notify', 0x693a303b),
('user_mail_status_canceled_subject', 0x733a35373a224163636f756e742064657461696c7320666f72205b757365723a6e616d655d206174205b736974653a6e616d655d202863616e63656c656429223b),
('user_pictures', 0x693a313b),
('user_picture_default', 0x733a303a22223b),
('user_picture_dimensions', 0x733a373a2231323078313230223b),
('user_picture_file_size', 0x733a333a22323030223b),
('user_picture_guidelines', 0x733a303a22223b),
('user_picture_path', 0x733a383a227069637475726573223b),
('user_picture_style', 0x733a393a227468756d626e61696c223b),
('user_register', 0x733a313a2232223b),
('user_signatures', 0x693a303b);

-- --------------------------------------------------------

--
-- Table structure for table `views_display`
--

CREATE TABLE IF NOT EXISTS `views_display` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The view this display is attached to.',
  `id` varchar(64) NOT NULL DEFAULT '' COMMENT 'An identifier for this display; usually generated from the display_plugin, so should be something like page or page_1 or block_2, etc.',
  `display_title` varchar(64) NOT NULL DEFAULT '' COMMENT 'The title of the display, viewable by the administrator.',
  `display_plugin` varchar(64) NOT NULL DEFAULT '' COMMENT 'The type of the display. Usually page, block or embed, but is pluggable so may be other things.',
  `position` int(11) DEFAULT '0' COMMENT 'The order in which this display is loaded.',
  `display_options` longtext COMMENT 'A serialized array of options for this display; it contains options that are generally only pertinent to that display plugin type.',
  PRIMARY KEY (`vid`,`id`),
  KEY `vid` (`vid`,`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `views_display`
--


-- --------------------------------------------------------

--
-- Table structure for table `views_view`
--

CREATE TABLE IF NOT EXISTS `views_view` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'The view ID of the field, defined by the database.',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT 'The unique name of the view. This is the primary field views are loaded from, and is used so that views may be internal and not necessarily in the database. May only be alphanumeric characters plus underscores.',
  `description` varchar(255) DEFAULT '' COMMENT 'A description of the view for the admin interface.',
  `tag` varchar(255) DEFAULT '' COMMENT 'A tag used to group/sort views in the admin interface',
  `base_table` varchar(64) NOT NULL DEFAULT '' COMMENT 'What table this view is based on, such as node, user, comment, or term.',
  `human_name` varchar(255) DEFAULT '' COMMENT 'A human readable name used to be displayed in the admin interface',
  `core` int(11) DEFAULT '0' COMMENT 'Stores the drupal core version of the view.',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `views_view`
--


-- --------------------------------------------------------

--
-- Table structure for table `watchdog`
--

CREATE TABLE IF NOT EXISTS `watchdog` (
  `wid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key: Unique watchdog event ID.',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'The users.uid of the user who triggered the event.',
  `type` varchar(64) NOT NULL DEFAULT '' COMMENT 'Type of log message, for example `user` or `page not found.`',
  `message` longtext NOT NULL COMMENT 'Text of log message to be passed into the t() function.',
  `variables` longblob NOT NULL COMMENT 'Serialized array of variables that match the message string and that is passed into the t() function.',
  `severity` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'The severity level of the event; ranges from 0 (Emergency) to 7 (Debug)',
  `link` varchar(255) DEFAULT '' COMMENT 'Link to view the result of the event.',
  `location` text NOT NULL COMMENT 'URL of the origin of the event.',
  `referer` text COMMENT 'URL of referring page.',
  `hostname` varchar(128) NOT NULL DEFAULT '' COMMENT 'Hostname of the user who triggered the event.',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT 'Unix timestamp of when event occurred.',
  PRIMARY KEY (`wid`),
  KEY `type` (`type`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `watchdog`
--

